# Atmos 0.64.1 Effects

- Reintroduced feathered condition-aware clouds as a lightweight overlay.
- Cloud density responds to current conditions.
- Cloud speed and direction respond to observed wind.
- Added realistic solar glare positioned from local sunrise, sunset and time of day.
- Weather effects remain active and blend smoothly while swiping locations.
- Cloud motion is capped at approximately 24 fps and isolated from native UI recomposition.
- Preserved the 0.64.0 performance build configuration.
