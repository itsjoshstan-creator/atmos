# Atmos 0.64.2 — Cloud & Solar Refinement

- Rebuilt the cloud visual treatment with broad multi-layer masses, irregular lobes, soft transparent fringes, highlights, and shaded undersides.
- Removed the visible bubble/oval appearance of the first effects build.
- Added draw-phase cloud opacity blending during horizontal location swipes without recomposing the forecast UI.
- Increased solar glare radius, brightness, warmth, and core visibility while retaining cloud attenuation and realistic solar positioning.
- Preserved wind-responsive cloud speed and direction and the release-optimised performance configuration.
