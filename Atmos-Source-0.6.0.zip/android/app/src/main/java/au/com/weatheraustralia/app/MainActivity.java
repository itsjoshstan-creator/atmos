package au.com.weatheraustralia.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onBackPressed() {
        if (bridge != null && bridge.getWebView() != null) {
            bridge.getWebView().evaluateJavascript(
                "Boolean(window.AtmosHandleBack && window.AtmosHandleBack())",
                handled -> {
                    if (!"true".equals(handled)) {
                        moveTaskToBack(true);
                    }
                }
            );
        } else {
            super.onBackPressed();
        }
    }
}
