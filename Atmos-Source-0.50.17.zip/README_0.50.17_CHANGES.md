# Atmos 0.50.17

## Condition-aware Atmos gradients

- Added restrained gradient grading for partly cloudy, cloudy, overcast, fog, mist, haze, smoke and dust conditions.
- Solar time, season and feels-like temperature remain the foundation of every palette.
- Cloud density now influences saturation, contrast and light distribution without reintroducing animated layers.
- Fog and mist softly compress the gradient and lift atmospheric tones.
- Haze, smoke and dust introduce a warmer, muted wash.
- Night and OLED grading is attenuated to preserve dark presentation.

## Immersive lower atmosphere

- Replaced the near-black lower fade with a colour-preserving dark overlay derived from the active location palette.
- The horizon colour now carries subtly into the lower reading area.
- Swiping between locations blends the lower-zone tint with the destination atmosphere.
- OLED mode retains only a restrained trace of colour.

## Build

- Version code: 217
- Version name: 0.50.17
- GitHub artifact: Atmos-0.50.17-debug
