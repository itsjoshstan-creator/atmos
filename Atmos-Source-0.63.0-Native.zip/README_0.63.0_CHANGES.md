# Atmos 0.63.0

- Rebased from Atmos 0.62.4.
- Removed obsolete Capacitor, Cordova, WebView and packaged web-application scaffolding.
- Kept the application entirely native with Kotlin and Jetpack Compose.
- Added Material 3 / Material You dynamic colour for Android app chrome on Android 12 and newer.
- Added standard Android bottom navigation for Weather, Locations and Settings.
- Replaced the custom floating quick menu with a Material 3 floating action button and dropdown menu.
- Replaced custom back controls with Material 3 app bars and standard back icons.
- Restyled settings sections with Material 3 cards, list items, icons, switches, radio buttons and sliders.
- Preserved the Atmos weather renderer, forecast engine, notifications, widgets, background updates and saved preferences.
- Increased version code to 330 so it can update later development builds signed with the same key.
