# Atmos 0.11.2

Changes:
- Fixed duplicate saved locations, including first-run current-location duplication.
- Removed condition artwork from the main current observations card and current conditions details page.
- Kept clean, condition-driven gradients as the visual representation.
- Sunrise and sunset markers only appear while their event is still ahead on the current day.
