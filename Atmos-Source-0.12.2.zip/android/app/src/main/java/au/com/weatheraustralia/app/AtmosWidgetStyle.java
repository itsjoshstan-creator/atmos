package au.com.weatheraustralia.app;

import android.content.SharedPreferences;
import java.util.Calendar;

final class AtmosWidgetStyle {
    private AtmosWidgetStyle() {}

    static String kind(SharedPreferences p) {
        String value = p.getString("icon", "clear").toLowerCase();
        if (value.contains("storm") || value.contains("thunder")) return "storm";
        if (value.contains("rain") || value.contains("shower")) return "rain";
        if (value.contains("cloud") || value.contains("overcast") || value.contains("fog")) return "cloudy";
        if (value.contains("night")) return "night";
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 6 || hour >= 18) return "night";
        return "sunny";
    }

    static int background(SharedPreferences p) {
        switch (kind(p)) {
            case "storm": return R.drawable.widget_bg_storm;
            case "rain": return R.drawable.widget_bg_rain;
            case "cloudy": return R.drawable.widget_bg_cloudy;
            case "night": return R.drawable.widget_bg_night;
            default: return R.drawable.widget_bg_sunny;
        }
    }

    static int icon(SharedPreferences p) {
        switch (kind(p)) {
            case "storm": return R.drawable.ic_weather_storm;
            case "rain": return R.drawable.ic_weather_rain;
            case "cloudy": return R.drawable.ic_weather_cloudy;
            case "night": return R.drawable.ic_weather_night;
            default: return R.drawable.ic_weather_sunny;
        }
    }
}
