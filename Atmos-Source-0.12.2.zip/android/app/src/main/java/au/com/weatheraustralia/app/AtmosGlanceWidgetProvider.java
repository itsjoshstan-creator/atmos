package au.com.weatheraustralia.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AtmosGlanceWidgetProvider extends AppWidgetProvider {
    @Override public void onEnabled(Context context) {
        AtmosWidgetUpdater.schedule(context);
        AtmosWidgetUpdater.refresh(context, null);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) manager.updateAppWidget(id, views(context));
        AtmosWidgetUpdater.schedule(context);
        AtmosWidgetUpdater.refresh(context, null);
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, AtmosGlanceWidgetProvider.class);
        for (int id : manager.getAppWidgetIds(name)) manager.updateAppWidget(id, views(context));
    }

    private static RemoteViews views(Context context) {
        SharedPreferences p = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE);
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_atmos_glance);
        v.setInt(R.id.widget_glance_root, "setBackgroundResource", AtmosWidgetStyle.background(p));
        v.setImageViewResource(R.id.widget_glance_icon, AtmosWidgetStyle.icon(p));
        v.setTextViewText(R.id.widget_glance_date, new SimpleDateFormat("EEEE d MMMM", Locale.ENGLISH).format(new Date()));
        v.setTextViewText(R.id.widget_glance_temp, p.getString("temp", "—") + "°");
        v.setTextViewText(R.id.widget_glance_condition, p.getString("condition", "Open Atmos"));
        v.setOnClickPendingIntent(R.id.widget_glance_root, AtmosWidgetProvider.openApp(context));
        return v;
    }
}
