package au.com.weatheraustralia.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class AtmosWidgetProvider extends AppWidgetProvider {
    @Override public void onEnabled(Context context) {
        AtmosWidgetUpdater.schedule(context);
        AtmosWidgetUpdater.refresh(context, null);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (AtmosWidgetUpdater.ACTION_REFRESH.equals(intent.getAction())) {
            AtmosWidgetUpdater.refresh(context, goAsync());
        }
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) manager.updateAppWidget(id, views(context));
        AtmosWidgetUpdater.schedule(context);
        AtmosWidgetUpdater.refresh(context, null);
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, AtmosWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(name);
        for (int id : ids) manager.updateAppWidget(id, views(context));
    }

    private static RemoteViews views(Context context) {
        SharedPreferences p = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE);
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_atmos_compact);
        v.setInt(R.id.widget_root, "setBackgroundResource", AtmosWidgetStyle.background(p));
        v.setImageViewResource(R.id.widget_icon, AtmosWidgetStyle.icon(p));
        v.setTextViewText(R.id.widget_location, p.getString("location", "Open Atmos"));
        v.setTextViewText(R.id.widget_temp, p.getString("temp", "—") + "°");
        v.setTextViewText(R.id.widget_condition, p.getString("condition", "Tap to load forecast"));
        v.setTextViewText(R.id.widget_range, "H " + p.getString("high", "—") + "°  ·  L " + p.getString("low", "—") + "°");
        v.setOnClickPendingIntent(R.id.widget_root, openApp(context));
        return v;
    }

    static PendingIntent openApp(Context context) {
        Intent intent = new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(context, 40, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
