package au.com.weatheraustralia.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class AtmosWideWidgetProvider extends AppWidgetProvider {
    @Override public void onEnabled(Context context) {
        AtmosWidgetUpdater.schedule(context);
        AtmosWidgetUpdater.refresh(context, null);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) manager.updateAppWidget(id, views(context));
        AtmosWidgetUpdater.schedule(context);
        AtmosWidgetUpdater.refresh(context, null);
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, AtmosWideWidgetProvider.class);
        for (int id : manager.getAppWidgetIds(name)) manager.updateAppWidget(id, views(context));
    }

    private static RemoteViews views(Context context) {
        SharedPreferences p = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE);
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_atmos_wide);
        v.setInt(R.id.widget_wide_root, "setBackgroundResource", AtmosWidgetStyle.background(p));
        v.setImageViewResource(R.id.widget_wide_icon, AtmosWidgetStyle.icon(p));
        v.setTextViewText(R.id.widget_wide_location, p.getString("location", "Open Atmos"));
        v.setTextViewText(R.id.widget_wide_temp, p.getString("temp", "—") + "°");
        v.setTextViewText(R.id.widget_wide_condition, p.getString("condition", "Tap to load forecast"));
        v.setTextViewText(R.id.widget_wide_range, "H " + p.getString("high", "—") + "°  ·  L " + p.getString("low", "—") + "°  ·  Rain " + p.getString("rain", "0") + "%");
        int[] times = {R.id.hour_time_0, R.id.hour_time_1, R.id.hour_time_2};
        int[] temps = {R.id.hour_temp_0, R.id.hour_temp_1, R.id.hour_temp_2};
        for (int i = 0; i < 3; i++) {
            v.setTextViewText(times[i], p.getString("hour_time_" + i, "—"));
            v.setTextViewText(temps[i], p.getString("hour_temp_" + i, "—") + "°");
        }
        v.setOnClickPendingIntent(R.id.widget_wide_root, AtmosWidgetProvider.openApp(context));
        return v;
    }
}
