# Atmos 0.67.6 Open-Meteo build fix

- Fixed the precipitation map Compose state declaration that used `mutableIntStateOf`, which is unavailable in this project's current Compose runtime.
- Replaced it with the existing compatible `mutableStateOf(0)` API.
- No weather-provider, renderer, UI, signing, or version behavior was changed.
