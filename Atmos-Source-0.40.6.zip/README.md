# Atmos 0.40.4

Atmos is a native Jetpack Compose weather app with one shared procedural Kotlin atmosphere renderer.

## Active Atmos surfaces

`AtmosSceneRenderer` is used by Fullscreen Hero, Immersive preloaded scenes, Current Conditions, saved-location cards, and the Atmos System demonstration.

## Native simulation

The renderer maintains a mutable particle population with continuous spawning, frame-by-frame movement, ageing, fading, and removal. Weather and location data influence precipitation, clouds, haze, wind motion, pressure instability, seasonal particles, temperature grading, solar lighting, frost, heat shimmer, and storm lightning.

## 0.40.4 changes

- Seasonal particles spawn across the full display rather than clustering at the left edge.
- A minority spawn from the upwind edge only when a meaningful breeze exists.
- Calm-weather particles receive independent random drift.
- Existing seasonal particles react progressively to gust and breeze changes.
- Atmos scenes pre-populate seasonal particles on first display.
- Added an independent Particle visibility slider from 45% to 200%.

## Version

- Version name: 0.40.4
- Version code: 144
- GitHub Actions artifact: `Atmos-0.40.4-debug`

## Build validation

Source structure, workflow paths, version metadata, ZIP integrity, and Kotlin delimiter balance were checked. A local Gradle compile could not run because this environment cannot download Gradle 8.14.3, so GitHub Actions remains the definitive Android compiler validation.
