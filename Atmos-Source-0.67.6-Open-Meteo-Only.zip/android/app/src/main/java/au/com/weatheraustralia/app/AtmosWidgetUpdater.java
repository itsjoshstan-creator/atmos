package au.com.weatheraustralia.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.BroadcastReceiver;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;

final class AtmosWidgetUpdater {
    static final String ACTION_REFRESH = "au.com.weatheraustralia.app.REFRESH_WIDGETS";
    private static final long INTERVAL = 15L * 60L * 1000L;
    private AtmosWidgetUpdater() {}

    static void schedule(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        alarm.setInexactRepeating(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + 60_000L,
            INTERVAL,
            refreshIntent(context)
        );
    }

    static void cancel(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) alarm.cancel(refreshIntent(context));
    }

    private static PendingIntent refreshIntent(Context context) {
        Intent intent = new Intent(context, AtmosWidgetProvider.class).setAction(ACTION_REFRESH);
        return PendingIntent.getBroadcast(context, 81, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void refresh(Context context, BroadcastReceiver.PendingResult result) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                SharedPreferences p = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE);
                SharedPreferences nativePrefs = context.getSharedPreferences("atmos_native", Context.MODE_PRIVATE);
                SharedPreferences.Editor initialEditor = p.edit()
                    .putString("atmos_intensity", nativePrefs.getString("atmosIntensityChoice", "Balanced"));
                String cachedTemperature = cachedCurrentTemperature(nativePrefs);
                if (cachedTemperature != null) initialEditor.putString("temp", cachedTemperature);
                initialEditor.apply();
            } catch (Exception ignored) {
            } finally {
                AtmosWidgetProvider.updateAll(context);
                AtmosHeroWidgetProvider.updateAll(context);
                if (result != null) result.finish();
            }
        });
    }

    private static String cachedCurrentTemperature(SharedPreferences nativePrefs) {
        try {
            JSONArray places = new JSONArray(nativePrefs.getString("savedPlaces", "[]"));
            if (places.length() == 0) return null;
            JSONObject first = places.optJSONObject(0);
            if (first == null) return null;
            String key = String.format(java.util.Locale.US, "%.4f:%.4f", first.optDouble("lat"), first.optDouble("lon"));
            JSONObject root = new JSONObject(nativePrefs.getString("weatherCache", "{}"));
            JSONObject state = root.optJSONObject(key);
            if (state == null) return null;
            JSONObject observation = state.optJSONObject("observation");
            if (observation != null && observation.has("temp") && !observation.isNull("temp")) {
                return String.valueOf(Math.round(observation.optDouble("temp")));
            }
            JSONArray hours = state.optJSONArray("hours");
            if (hours != null && hours.length() > 0) {
                JSONObject hour = hours.optJSONObject(0);
                if (hour != null && hour.has("temp") && !hour.isNull("temp")) {
                    return String.valueOf(Math.round(hour.optDouble("temp")));
                }
            }
            JSONArray days = state.optJSONArray("days");
            if (days != null && days.length() > 0) {
                JSONObject day = days.optJSONObject(0);
                if (day != null && day.has("high") && !day.isNull("high")) {
                    return String.valueOf(Math.round(day.optDouble("high") - 2.0));
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String solarTime(JSONObject object, String key, String fallback) {
        String raw = object.optString(key, "");
        if (raw.isEmpty()) { JSONObject astro = object.optJSONObject("astronomical"); if (astro != null) raw = astro.optString(key, ""); }
        if (raw.isEmpty()) return fallback;
        try {
            java.text.SimpleDateFormat input = new java.text.SimpleDateFormat("yyyy-MM-dd\'T\'HH:mm:ssXXX", java.util.Locale.US);
            java.util.Date value = input.parse(raw);
            return new java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault()).format(value).toLowerCase(java.util.Locale.getDefault());
        } catch (Exception ignored) { return fallback; }
    }

    private static String number(JSONObject object, String key, String fallback) {
        Object value = object.opt(key);
        return value instanceof Number ? String.valueOf(Math.round(((Number) value).doubleValue())) : fallback;
    }

    private static JSONObject get(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(12000);
        connection.setRequestProperty("Accept", "application/json");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            StringBuilder text = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) text.append(line);
            return new JSONObject(text.toString());
        } finally {
            connection.disconnect();
        }
    }
}
