# Atmos 0.67.6 Open-Meteo Only

This is a separate Open-Meteo-only branch based on Atmos 0.67.5.

## Changes
- All runtime BOM API calls and provider selection logic removed.
- Every saved location now loads current, hourly and daily weather from Open-Meteo.
- Pressure attribution, data labels, About text and footer attribution now reference Open-Meteo only.
- BOM warning and tide links/references removed from the app.
- Widget alarm no longer performs an independent BOM fetch; widgets consume Atmos's coordinated Open-Meteo weather cache.
- The former Rain radar page is now an Open-Meteo precipitation forecast map.
- The map samples a 7x7 grid around the selected location using Open-Meteo's multi-coordinate hourly precipitation API.
- Includes Now through approximately +3 hours and clearly labels the result as modelled precipitation, not observed radar.

## Version
- versionName: 0.67.6-openmeteo
- versionCode: 376

## Build verification
A full Gradle compile could not be completed in the sandbox because services.gradle.org was not reachable. Static delimiter checks passed and no BOM references remain in app/src/main runtime source.
