# Atmos 0.63.8 Rebased

- Added a per-location solar status icon beside local time in single and dual hero layouts.
- Uses a filled sun during daylight, crescent moon at night, and horizon/sun symbol around sunrise and sunset.
- Combined solar status and local time into a consistent status pill, with the season pill aligned opposite it.
- Location-name Atmos gradients now subtly respond to daylight, nighttime, and sunrise/sunset while retaining adaptive legibility.
- Solar state is calculated independently for every saved location using its coordinates, time zone, sunrise, and sunset.
