package au.com.weatheraustralia.app

import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin



private fun blendSceneColor(from: Color, to: Color, amount: Float): Color {
    val t = amount.coerceIn(0f, 1f)
    return Color(
        red = from.red + (to.red - from.red) * t,
        green = from.green + (to.green - from.green) * t,
        blue = from.blue + (to.blue - from.blue) * t,
        alpha = from.alpha + (to.alpha - from.alpha) * t
    )
}

private fun sharedPlaceSeed(place: Place): Long {
    val lat = "%.4f".format(Locale.US, place.latitude)
    val lon = "%.4f".format(Locale.US, place.longitude)
    return "$lat:$lon".hashCode().toLong()
}

internal fun applyAtmosIntensityToPalette(
    balanced: Palette,
    intensity: AtmosIntensityChoice
): Palette = when (intensity) {
    AtmosIntensityChoice.Balanced -> balanced
    AtmosIntensityChoice.Subtle -> {
        val neutral = blendSceneColor(balanced.top, balanced.bottom, .5f)
        Palette(
            blendSceneColor(balanced.top, neutral, .46f),
            blendSceneColor(balanced.bottom, neutral, .44f),
            blendSceneColor(balanced.accent, neutral, .40f),
            blendSceneColor(balanced.secondary, neutral, .40f)
        )
    }
    AtmosIntensityChoice.Cinematic -> Palette(
        blendSceneColor(balanced.top, balanced.accent, .24f),
        blendSceneColor(blendSceneColor(balanced.bottom, balanced.secondary, .30f), Color.Black, .08f),
        blendSceneColor(balanced.accent, Color.White, .16f),
        blendSceneColor(balanced.secondary, balanced.accent, .24f)
    )
}


internal data class WeatherRealismProfile(
    val cloudDepth: Float,
    val surfaceLight: Float,
    val airClarity: Float,
    val moistureWeight: Float,
    val weatherInstability: Float,
    val precipitationIntensity: Float
)

/**
 * Lightweight, event-driven interpretation of how the current air mass should feel.
 * It deliberately uses only data already available to Atmos, so the profile can be
 * shared by the app and wallpaper without adding a network request or render loop.
 */
internal fun buildWeatherRealismProfile(
    observation: Observation,
    condition: String,
    temperatureC: Int
): WeatherRealismProfile {
    val lower = condition.lowercase(Locale.ENGLISH)
    val humidity = (observation.humidity ?: 55).coerceIn(0, 100) / 100f
    val pressure = observation.pressure ?: 1013.25
    val lowPressure = ((1013.25 - pressure) / 35.0).toFloat().coerceIn(0f, 1f)
    val wind = (observation.wind ?: 0).coerceAtLeast(0)
    val gust = (observation.gust ?: wind).coerceAtLeast(wind)
    val gustiness = ((gust - wind) / 28f).coerceIn(0f, 1f)
    val observedRain = ((observation.rainSince9 ?: 0.0) / 18.0).toFloat().coerceIn(0f, 1f)

    val conditionCloud = when {
        lower.contains("thunder") || lower.contains("storm") -> 1f
        lower.contains("overcast") -> .92f
        lower.contains("rain") || lower.contains("shower") -> .84f
        lower.contains("fog") || lower.contains("mist") -> .78f
        lower.contains("cloud") -> .60f
        lower.contains("haze") || lower.contains("smoke") -> .42f
        else -> .08f
    }
    val conditionRain = when {
        lower.contains("thunder") || lower.contains("storm") -> .90f
        lower.contains("heavy rain") -> .88f
        lower.contains("rain") -> .66f
        lower.contains("shower") -> .54f
        lower.contains("drizzle") -> .28f
        else -> 0f
    }
    val precipitationIntensity = max(conditionRain, observedRain).coerceIn(0f, 1f)
    val cloudDepth = (conditionCloud * .72f + humidity * .14f + lowPressure * .14f).coerceIn(0f, 1f)
    val moistureWeight = (humidity * .70f + precipitationIntensity * .20f + conditionCloud * .10f).coerceIn(0f, 1f)
    val weatherInstability = (lowPressure * .42f + gustiness * .24f + precipitationIntensity * .26f + if (lower.contains("thunder") || lower.contains("storm")) .22f else 0f).coerceIn(0f, 1f)
    val airClarity = (1f - moistureWeight * .46f - cloudDepth * .24f - if (lower.contains("fog") || lower.contains("mist")) .34f else 0f).coerceIn(.12f, 1f)
    val surfaceLight = (1f - cloudDepth * .48f - precipitationIntensity * .12f - weatherInstability * .10f + (1f - humidity) * .08f).coerceIn(.28f, 1.08f)

    return WeatherRealismProfile(cloudDepth, surfaceLight, airClarity, moistureWeight, weatherInstability, precipitationIntensity)
}

private data class AtmosIntensityProfile(
    val solar: Float,
    val atmosphere: Float,
    val pressure: Float,
    val moon: Float,
    val stars: Float,
    val cloudShadow: Float,
    val thermal: Float,
    val seasonal: Float,
    val glareRadius: Float
)

private fun AtmosIntensityChoice.profile(): AtmosIntensityProfile = when (this) {
    AtmosIntensityChoice.Subtle -> AtmosIntensityProfile(.38f, .46f, .40f, .34f, .24f, .32f, .46f, .42f, .78f)
    AtmosIntensityChoice.Balanced -> AtmosIntensityProfile(1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f)
    AtmosIntensityChoice.Cinematic -> AtmosIntensityProfile(1.68f, 1.46f, 1.58f, 1.72f, 1.95f, 1.62f, 1.52f, 1.78f, 1.24f)
}

/**
 * Single source of truth for the visual Atmos scene.
 * Both the in-app hero and the live wallpaper render this exact scene.
 */
internal data class AtmosSceneSpec(
    val top: Int,
    val secondary: Int,
    val bottom: Int,
    val enabled: Boolean,
    val pressureNormalised: Float,
    val atmosphericSoftness: Float,
    val cloudDepth: Float,
    val surfaceLight: Float,
    val airClarity: Float,
    val moistureWeight: Float,
    val weatherInstability: Float,
    val solarAlpha: Float,
    val solarX: Float,
    val solarY: Float,
    val glareRadiusScale: Float,
    val solarColour: Int,
    val seasonalLightColour: Int,
    val moonAlpha: Float,
    val moonX: Float,
    val moonY: Float,
    val starVisibility: Float,
    val starSeed: Long,
    val cloudShadowAlpha: Float,
    val thermalColour: Int,
    val thermalAlpha: Float,
    val seasonalColour: Int,
    val seasonalAlpha: Float
)

internal fun buildAtmosSceneSpec(
    palette: Palette,
    observation: Observation,
    condition: String,
    temperatureC: Int,
    place: Place,
    now: Date = Date(),
    enabled: Boolean = true,
    intensity: AtmosIntensityChoice = AtmosIntensityChoice.Balanced
): AtmosSceneSpec {
    val intensityProfile = intensity.profile()
    val solarMinute = now.time / 60_000L
    val night = isNight(now, place.timeZone())
    val solarTimes = calculateSolarTimes(now, place.latitude, place.longitude, place.timeZone())
    val solarProgress = solarTimes?.let { (sunrise, sunset) ->
        if (now.before(sunrise) || !now.before(sunset)) null
        else ((now.time - sunrise.time).toDouble() / (sunset.time - sunrise.time).toDouble()).coerceIn(0.0, 1.0).toFloat()
    }
    val solarEnergy = solarProgress?.let { sin(PI * it).toFloat().coerceIn(0f, 1f) } ?: if (night) 0f else .72f
    val localHour = Calendar.getInstance(place.timeZone()).apply { time = now }.get(Calendar.HOUR_OF_DAY)
    val oledFraction = when {
        !night -> 0f
        localHour < 6 -> 1f
        solarTimes == null -> 1f
        else -> {
            val start = solarTimes.second.time + 90L * 60_000L
            val end = solarTimes.second.time + 120L * 60_000L
            ((now.time - start).toFloat() / (end - start).toFloat()).coerceIn(0f, 1f)
        }
    }
    val lateNightAttenuation = 1f - oledFraction * .72f
    val season = seasonName(place, now)
    val thermal = ((temperatureC - 18f) / 17f).coerceIn(-1f, 1f)
    val pressureNormalised = (((observation.pressure ?: 1013.25) - 1013.25) / 32.0).toFloat().coerceIn(-1f, 1f)
    val realism = buildWeatherRealismProfile(observation, condition, temperatureC)
    val cloudWeight = realism.cloudDepth
    val visibilityClarity = realism.airClarity
    val atmosphericSoftness = (realism.moistureWeight * .64f + (1f - realism.airClarity) * .36f).coerceIn(0f, 1f)
    val seasonLight = when (season) {
        "Summer" -> Triple(1.08f, .92f, Color(0xFFFFF1C7))
        "Winter" -> Triple(.82f, 1.22f, Color(0xFFFFD6A1))
        "Spring" -> Triple(.98f, 1.00f, Color(0xFFFFE7B5))
        "Autumn" -> Triple(.88f, 1.16f, Color(0xFFFFC889))
        "Wet season" -> Triple(.92f, 1.05f, Color(0xFFFFE2B2))
        "Dry season" -> Triple(1.04f, .96f, Color(0xFFFFD99A))
        else -> Triple(1f, 1f, Color(0xFFFFE5A3))
    }
    val knownNewMoon = 947182440000L
    val synodicMonthMs = 29.530588853 * 86_400_000.0
    val moonPhase = (((now.time - knownNewMoon) % synodicMonthMs + synodicMonthMs) % synodicMonthMs / synodicMonthMs).toFloat()
    val moonIllumination = ((1f - cos(2.0 * PI * moonPhase).toFloat()) * .5f).coerceIn(0f, 1f)
    val nightDepth = if (night) solarTimes?.let { (_, sunset) ->
        ((now.time - sunset.time).toFloat() / (150f * 60_000f)).coerceIn(0f, 1f)
    } ?: 1f else 0f
    val starVisibility = (nightDepth * visibilityClarity * (1f - cloudWeight) * (1f - moonIllumination * .58f)).coerceIn(0f, 1f)
    val seasonalColour = when (season) {
        "Spring" -> Color(0xFFFFAFCB)
        "Summer" -> Color(0xFFFFC765)
        "Autumn" -> Color(0xFFD97B45)
        "Winter" -> Color(0xFFB6E5FF)
        "Wet season" -> Color(0xFF63C8B2)
        "Dry season" -> Color(0xFFE0AD68)
        else -> Color.Transparent
    }
    val thermalColour = if (thermal >= 0f) Color(0xFFFFB45E) else Color(0xFF8DDCFF)
    val thermalAlpha = abs(thermal) * if (thermal >= 0f) .32f else .35f
    val solarColour = if (night) Color(0xFFB7CCFF) else seasonLight.third
    val humidityDiffusion = .78f + atmosphericSoftness * .48f
    val pressureLight = 1f + pressureNormalised * .08f
    val solarAlpha = if (solarProgress == null) 0f else ((.09f + solarEnergy * .21f) * seasonLight.first * humidityDiffusion * pressureLight * realism.surfaceLight * lateNightAttenuation).coerceIn(0f, .36f)
    val solarX = solarProgress?.let { .08f + (.84f * it) } ?: .50f
    val solarY = solarProgress?.let {
        val arc = sin(PI * it).toFloat().coerceIn(0f, 1f)
        .47f - (.34f * seasonLight.first.coerceIn(.76f, 1.10f) * arc)
    } ?: .18f
    val glareRadiusScale = seasonLight.second * (1f + atmosphericSoftness * .22f)
    val moonAlpha = (nightDepth * moonIllumination * visibilityClarity * (1f - cloudWeight * .62f) * .16f).coerceIn(0f, .22f)
    val cloudShadowAlpha = (cloudWeight * (.025f + realism.weatherInstability * .034f + (1f - pressureNormalised) * .012f) * if (night) .35f else 1f).coerceIn(0f, .10f)

    return AtmosSceneSpec(
        top = palette.top.toArgb(), secondary = palette.secondary.toArgb(), bottom = palette.bottom.toArgb(), enabled = enabled,
        pressureNormalised = (pressureNormalised * intensityProfile.pressure).coerceIn(-1f, 1f),
        atmosphericSoftness = (atmosphericSoftness * intensityProfile.atmosphere).coerceIn(0f, 1f),
        cloudDepth = realism.cloudDepth, surfaceLight = realism.surfaceLight, airClarity = realism.airClarity,
        moistureWeight = realism.moistureWeight, weatherInstability = realism.weatherInstability,
        solarAlpha = (solarAlpha * intensityProfile.solar).coerceIn(0f, .58f), solarX = solarX, solarY = solarY,
        glareRadiusScale = glareRadiusScale * intensityProfile.glareRadius,
        solarColour = solarColour.toArgb(), seasonalLightColour = seasonLight.third.toArgb(),
        moonAlpha = (moonAlpha * intensityProfile.moon).coerceIn(0f, .28f), moonX = .82f - moonPhase * .64f, moonY = .19f + abs(moonPhase - .5f) * .13f,
        starVisibility = (starVisibility * intensityProfile.stars).coerceIn(0f, 1f), starSeed = sharedPlaceSeed(place),
        cloudShadowAlpha = (cloudShadowAlpha * intensityProfile.cloudShadow).coerceIn(0f, .13f),
        thermalColour = thermalColour.toArgb(), thermalAlpha = (thermalAlpha * lateNightAttenuation * intensityProfile.thermal).coerceIn(0f, .52f),
        seasonalColour = seasonalColour.toArgb(), seasonalAlpha = (.10f * lateNightAttenuation * intensityProfile.seasonal).coerceIn(0f, .22f)
    )
}

internal object SharedAtmosSceneRenderer {
    private fun alpha(color: Int, amount: Float): Int = AndroidColor.argb((amount.coerceIn(0f, 1f) * 255f).toInt(), AndroidColor.red(color), AndroidColor.green(color), AndroidColor.blue(color))

    fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        spec: AtmosSceneSpec,
        immersive: Boolean = false,
        immersiveBottom: Int = AndroidColor.rgb(7, 16, 31),
        immersiveVisibleHeight: Int = height
    ) {
        val w = width.coerceAtLeast(1).toFloat()
        val h = height.coerceAtLeast(1).toFloat()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)

        paint.shader = LinearGradient(0f, 0f, w, h, intArrayOf(spec.top, spec.secondary, spec.bottom), floatArrayOf(0f, .52f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        if (spec.enabled) {
            if (spec.pressureNormalised != 0f || spec.atmosphericSoftness > .05f) {
                paint.shader = null
                val pressureTint = if (spec.pressureNormalised >= 0f) AndroidColor.rgb(111,183,255) else AndroidColor.rgb(113,128,155)
                paint.color = alpha(pressureTint, abs(spec.pressureNormalised) * .055f)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = LinearGradient(0f, h * .18f, 0f, h,
                    intArrayOf(AndroidColor.TRANSPARENT, alpha(AndroidColor.rgb(231,239,243), spec.atmosphericSoftness * .075f), alpha(AndroidColor.rgb(244,233,221), spec.atmosphericSoftness * .105f)),
                    floatArrayOf(0f, .64f, 1f), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)

                // Low-clarity air compresses distant contrast near the lower atmosphere.
                paint.shader = LinearGradient(0f, h * .35f, 0f, h,
                    intArrayOf(AndroidColor.TRANSPARENT, alpha(AndroidColor.rgb(205,218,226), (1f - spec.airClarity) * .06f), alpha(AndroidColor.rgb(190,204,211), spec.moistureWeight * .10f)),
                    floatArrayOf(0f, .62f, 1f), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            if (spec.solarAlpha > 0f) {
                // Keep solar colour grading, but do not draw a visible sun or localised glare.
                // Distinct sunlight shafts are rendered by the optional weather-effects layer.
                paint.shader = LinearGradient(
                    0f, 0f, 0f, h,
                    intArrayOf(
                        alpha(spec.solarColour, spec.solarAlpha * .20f),
                        alpha(spec.seasonalLightColour, spec.solarAlpha * .09f),
                        AndroidColor.TRANSPARENT
                    ),
                    floatArrayOf(0f, .42f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            if (spec.moonAlpha > 0f) {
                paint.shader = RadialGradient(w*spec.moonX,h*spec.moonY,max(w,h)*.72f,
                    intArrayOf(alpha(AndroidColor.rgb(220,232,255),spec.moonAlpha),alpha(AndroidColor.rgb(147,181,255),spec.moonAlpha*.38f),AndroidColor.TRANSPARENT),
                    floatArrayOf(0f,.38f,1f),Shader.TileMode.CLAMP)
                canvas.drawRect(0f,0f,w,h,paint)
            }
            if (spec.starVisibility > .04f) drawStars(canvas, paint, w, h, spec.starSeed, spec.starVisibility)
            if (spec.cloudShadowAlpha > .002f) {
                paint.shader = LinearGradient(-w*.18f,h*.12f,w*1.18f,h*.78f,
                    intArrayOf(AndroidColor.TRANSPARENT,alpha(AndroidColor.rgb(23,35,59),spec.cloudShadowAlpha*.45f),alpha(AndroidColor.rgb(17,24,39),spec.cloudShadowAlpha),AndroidColor.TRANSPARENT),
                    floatArrayOf(0f,.36f,.58f,1f),Shader.TileMode.CLAMP)
                canvas.drawRect(0f,0f,w,h,paint)
            }
            paint.shader = RadialGradient(w*.52f,h*.62f,max(w,h)*.76f,intArrayOf(alpha(spec.thermalColour,spec.thermalAlpha),AndroidColor.TRANSPARENT),floatArrayOf(0f,1f),Shader.TileMode.CLAMP)
            canvas.drawRect(0f,0f,w,h,paint)
            if (AndroidColor.alpha(spec.seasonalColour) > 0) {
                paint.shader = RadialGradient(w*.20f,h*.72f,max(w,h)*.72f,intArrayOf(alpha(spec.seasonalColour,spec.seasonalAlpha),AndroidColor.TRANSPARENT),floatArrayOf(0f,1f),Shader.TileMode.CLAMP)
                canvas.drawRect(0f,0f,w,h,paint)
            }
        }
        if (immersive) {
            // Live wallpaper surfaces can be taller than the visible display. Anchor the
            // immersive dark zone to the visible screen so it matches the in-app hero.
            val visibleH = immersiveVisibleHeight.coerceIn(1, height).toFloat()
            paint.shader = LinearGradient(
                0f,
                0f,
                0f,
                visibleH,
                intArrayOf(
                    AndroidColor.TRANSPARENT,
                    AndroidColor.TRANSPARENT,
                    alpha(immersiveBottom, .30f),
                    immersiveBottom
                ),
                floatArrayOf(0f, .44f, .76f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, w, visibleH, paint)
            if (h > visibleH) {
                paint.shader = null
                paint.color = immersiveBottom
                canvas.drawRect(0f, visibleH, w, h, paint)
            }
        }
        paint.shader = null
    }

    private fun drawStars(canvas: Canvas, paint: Paint, w: Float, h: Float, seedValue: Long, visibility: Float) {
        var seed = seedValue
        repeat(34) { index ->
            val a = kotlin.math.abs((seed * 1103515245L + index * 12345L + 0x9E3779B9L).toInt())
            val b = kotlin.math.abs((seed * 1664525L + index * 1013904223L).toInt())
            val x = (a % 1000) / 1000f
            val y = .04f + (b % 510) / 1000f
            val brightness = .45f + ((a / 11) % 55) / 100f
            paint.shader = null
            paint.color = alpha(AndroidColor.WHITE, visibility * brightness * .72f)
            canvas.drawCircle(w*x,h*y,if (brightness > .78f) 1.35f else .85f,paint)
        }
    }
}
