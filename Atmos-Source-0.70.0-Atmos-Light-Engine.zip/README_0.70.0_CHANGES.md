# Atmos 0.70.0 — Atmos Light Engine

- Introduces a shared lighting profile derived from each location’s Atmos palette and scene brightness.
- Forecast cards now share coordinated ambient fill, directional highlights, border tint, glow and shadow colour.
- Atmos Moments and Today at a glance receive the same illuminated surface treatment.
- Weather Details cards gain richer condition-coloured depth and coherent elevation.
- Android navigation, selected state, floating button and popup icons now use the same lighting profile.
- Lighting changes blend over approximately 900 ms when conditions or locations change.
- Uses cached colour calculations and Compose colour interpolation; no new continuous rendering loop is introduced.
