# Atmos 0.31.1

Atmos 0.31.1 completes the first integration pass of the procedural Atmos Engine.

## What changed

- The Canvas renderer is now the authoritative weather visual layer in the Hero and current-conditions Hero.
- Legacy looping Hero glow, sun, cloud, and floating weather artwork animations were removed/disabled.
- Saved Locations now render miniature live Atmos scenes with their own seeded particle systems.
- Saved-location scenes preload current atmospheric inputs from Open-Meteo for immediate visual previews.
- The main Hero now uses a second pre-warmed procedural renderer for destination-scene crossfades during location changes.
- The destination renderer is prepared before the content handoff, avoiding a blank or generic transition.
- Offscreen saved-location renderers pause when the Locations page is closed to protect battery and frame rate.
- Main and detail renderers retain all existing weather mappings: temperature, feels-like temperature, humidity, pressure, wind, gusts, visibility, cloud cover, precipitation, rain probability, UV, condition, and solar state.
- Fixed a duplicate particle boundary check in the engine.

## Version

- Version name: 0.31.1
- Version code: 112

## Build

The GitHub Actions workflow builds from `android/` and uploads `Atmos-0.31.1-debug`.
