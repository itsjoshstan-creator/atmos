package au.com.weatheraustralia.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import kotlin.math.roundToInt

/**
 * Optional Nothing Glyph Matrix weather toy.
 *
 * Uses Nothing's native SDK only inside this optional service. Runtime device guards keep
 * the rest of Atmos compatible with other Android devices.
 */
class AtmosGlyphWeatherService : Service(), android.content.SharedPreferences.OnSharedPreferenceChangeListener {
    private var manager: com.nothing.ketchum.GlyphMatrixManager? = null
    private var frameIndex = 0
    private var isBoundToToy = false
    private val glyphPreferences by lazy { getSharedPreferences("atmos_glyph", Context.MODE_PRIVATE) }

    private val animationRunnable = object : Runnable {
        override fun run() {
            renderNextFrame(fromAnimationLoop = true)
        }
    }

    private val serviceHandler = object : android.os.Handler(android.os.Looper.getMainLooper()) {
        override fun handleMessage(msg: android.os.Message) {
            if (msg.what == com.nothing.ketchum.GlyphToy.MSG_GLYPH_TOY) {
                val event = msg.data?.getString(com.nothing.ketchum.GlyphToy.MSG_GLYPH_TOY_DATA)
                Log.i(TAG, "Glyph Toy event received: $event")
                if (event == com.nothing.ketchum.GlyphToy.EVENT_AOD ||
                    event == com.nothing.ketchum.GlyphToy.EVENT_CHANGE
                ) {
                    renderNextFrame()
                }
                return
            }
            super.handleMessage(msg)
        }
    }
    private val serviceMessenger = android.os.Messenger(serviceHandler)

    override fun onCreate() {
        super.onCreate()
        glyphPreferences.registerOnSharedPreferenceChangeListener(this)
        Log.i(TAG, "Atmos Glyph Toy service created")
    }

    override fun onBind(intent: Intent?): IBinder {
        Log.i(TAG, "Atmos Glyph Toy service bound: ${intent?.action}")
        isBoundToToy = true
        startGlyph()
        return serviceMessenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Log.i(TAG, "Atmos Glyph Toy service unbound")
        isBoundToToy = false
        serviceHandler.removeCallbacks(animationRunnable)
        stopGlyph()
        return false
    }

    override fun onDestroy() {
        Log.i(TAG, "Atmos Glyph Toy service destroyed")
        glyphPreferences.unregisterOnSharedPreferenceChangeListener(this)
        isBoundToToy = false
        serviceHandler.removeCallbacks(animationRunnable)
        stopGlyph()
        super.onDestroy()
    }

    override fun onSharedPreferenceChanged(sharedPreferences: android.content.SharedPreferences?, key: String?) {
        if (!isBoundToToy || manager == null) return
        Log.i(TAG, "Glyph setting changed: $key; redrawing immediately")
        frameIndex = 0
        serviceHandler.removeCallbacks(animationRunnable)
        serviceHandler.post { renderNextFrame() }
    }

    private fun startGlyph() {
        if (manager != null) return
        runCatching {
            val glyphManager = com.nothing.ketchum.GlyphMatrixManager.getInstance(applicationContext)
            manager = glyphManager
            glyphManager.init(object : com.nothing.ketchum.GlyphMatrixManager.Callback {
                override fun onServiceConnected(componentName: android.content.ComponentName) {
                    Log.i(TAG, "Nothing Glyph Matrix service connected: $componentName")
                    runCatching {
                        glyphManager.register(com.nothing.ketchum.Glyph.DEVICE_25111p)
                        Log.i(TAG, "Registered Phone (4a) Pro Glyph target")
                        renderNextFrame()
                    }.onFailure { Log.e(TAG, "Unable to register Glyph Matrix target", it) }
                }

                override fun onServiceDisconnected(componentName: android.content.ComponentName) {
                    Log.w(TAG, "Nothing Glyph Matrix service disconnected: $componentName")
                }
            })
        }.onFailure {
            manager = null
            Log.e(TAG, "Unable to initialise Nothing Glyph Matrix SDK", it)
        }
    }

    private fun renderNextFrame(fromAnimationLoop: Boolean = false) {
        serviceHandler.removeCallbacks(animationRunnable)
        val glyphManager = manager ?: run {
            Log.w(TAG, "Frame requested before Glyph manager was ready")
            return
        }
        val weather = readWeather()
        val settings = readGlyphSettings()
        val frames = AtmosGlyphFrames.frames(weather, settings, System.currentTimeMillis())
        val pixels = frames[frameIndex.mod(frames.size)]
        if (settings.animatedSymbols && frames.size > 1) frameIndex++ else frameIndex = 0

        runCatching {
            val bitmapPixels = IntArray(pixels.size) { index ->
                val level = pixels[index].coerceIn(0, 255)
                android.graphics.Color.argb(255, level, level, level)
            }
            val bitmap = android.graphics.Bitmap.createBitmap(
                bitmapPixels,
                13,
                13,
                android.graphics.Bitmap.Config.ARGB_8888
            )

            val matrixObject = com.nothing.ketchum.GlyphMatrixObject.Builder()
                .setImageSource(bitmap)
                .setPosition(0, 0)
                .setScale(100)
                .setBrightness(settings.brightness)
                .build()

            val matrixFrame = com.nothing.ketchum.GlyphMatrixFrame.Builder()
                .addTop(matrixObject)
                .build(applicationContext)

            glyphManager.setMatrixFrame(matrixFrame)
            bitmap.recycle()
            Log.i(TAG, "Nothing SDK accepted a structured 13x13 Glyph frame")

            // Keep animated condition frames smooth while the toy is active. Auto Weather also
            // needs a timed redraw when its 50-second temperature phase changes to the
            // 10-second condition phase, even if the current frame itself is static.
            if (isBoundToToy) {
                val refreshDelay = AtmosGlyphFrames.nextRefreshDelayMs(weather, settings, System.currentTimeMillis(), frames.size)
                if (refreshDelay != null) serviceHandler.postDelayed(animationRunnable, refreshDelay)
            }
        }.onFailure {
            Log.e(TAG, "Nothing SDK rejected the Glyph frame", it)
            if (fromAnimationLoop) serviceHandler.removeCallbacks(animationRunnable)
        }
    }

    private fun stopGlyph() {
        manager?.let { glyphManager ->
            runCatching { glyphManager.unInit() }
                .onFailure { Log.w(TAG, "Unable to uninitialise Glyph SDK", it) }
        }
        manager = null
    }

    private fun readWeather(): GlyphWeather {
        val glyphPrefs = getSharedPreferences("atmos_glyph", Context.MODE_PRIVATE)
        val source = glyphPrefs.getString("location_source", "first")
        val prefs = getSharedPreferences(if (source == "current") "atmos_glyph_current_weather" else "atmos_glyph_first_weather", Context.MODE_PRIVATE)
        val fallback = getSharedPreferences("atmos_widget", Context.MODE_PRIVATE)
        return GlyphWeather(
            temperature = (prefs.getString("temp", fallback.getString("temp", "18"))?.toDoubleOrNull() ?: 18.0).roundToInt().coerceIn(-99, 99),
            feelsLike = (prefs.getString("feels", prefs.getString("temp", fallback.getString("temp", "18")))?.toDoubleOrNull() ?: 18.0).roundToInt().coerceIn(-99, 99),
            condition = prefs.getString("condition", fallback.getString("condition", "Clear")).orEmpty(),
            rainChance = prefs.getString("rain", fallback.getString("rain", "0"))?.toIntOrNull()?.coerceIn(0, 100) ?: 0,
            humidity = prefs.getString("humidity", fallback.getString("humidity", "0"))?.toIntOrNull()?.coerceIn(0, 100) ?: 0,
            wind = prefs.getString("wind", fallback.getString("wind", "0"))?.toIntOrNull()?.coerceAtLeast(0) ?: 0,
            pressure = prefs.getString("pressure", fallback.getString("pressure", "0"))?.toDoubleOrNull() ?: 0.0,
            approachingCondition = prefs.getString("approach_condition", "").orEmpty(),
            approachingChance = prefs.getString("approach_chance", "0")?.toIntOrNull()?.coerceIn(0, 100) ?: 0,
            approachingMinutes = prefs.getString("approach_minutes", "")?.toIntOrNull(),
            sunrise = prefs.getString("sunrise", fallback.getString("sunrise", "")).orEmpty(),
            sunset = prefs.getString("sunset", fallback.getString("sunset", "")).orEmpty(),
            timeZoneId = prefs.getString("time_zone", fallback.getString("time_zone", "")).orEmpty()
        )
    }

    private fun readGlyphSettings(): GlyphSettings {
        val prefs = glyphPreferences
        val storedMode = prefs.getString("display_mode", "living_sky") ?: "living_sky"
        val supportedMode = storedMode.takeIf { it in setOf("temperature", "living_sky", "next_solar", "approaching_weather", "moon_phase", "atmos_mood") } ?: "living_sky"
        return GlyphSettings(
            mode = supportedMode,
            animatedSymbols = prefs.getBoolean("animated_symbols", true),
            fahrenheit = prefs.getString("temperature_unit", "celsius") == "fahrenheit",
            brightness = prefs.getInt("brightness", 255).coerceIn(32, 255)
        )
    }

    data class GlyphWeather(
        val temperature: Int,
        val feelsLike: Int,
        val condition: String,
        val rainChance: Int,
        val humidity: Int,
        val wind: Int,
        val pressure: Double,
        val approachingCondition: String,
        val approachingChance: Int,
        val approachingMinutes: Int?,
        val sunrise: String,
        val sunset: String,
        val timeZoneId: String
    )

    data class GlyphSettings(
        val mode: String,
        val animatedSymbols: Boolean,
        val fahrenheit: Boolean,
        val brightness: Int
    )

    companion object {
        private const val TAG = "AtmosGlyph"
        private const val ANIMATION_FRAME_DELAY_MS = 200L
    }
}

private object AtmosGlyphFrames {
    private const val SIZE = 13
    private const val ON = 255
    private const val DIM = 88
    private const val AUTO_TEMPERATURE_SECONDS = 50
    private const val SOLAR_COUNTDOWN_WINDOW_MINUTES = 120
    private const val ANIMATION_DELAY_MS = 200L

    fun frames(weather: AtmosGlyphWeatherService.GlyphWeather, settings: AtmosGlyphWeatherService.GlyphSettings, now: Long): List<IntArray> {
        val temperature = convertTemperature(weather.temperature, settings.fahrenheit)
        val symbols = conditionFrames(weather.condition, settings.animatedSymbols)
        val temperatureFrame = temperatureFrame(temperature)
        val selected = when (settings.mode) {
            "temperature" -> listOf(temperatureFrame)
            "living_sky" -> livingSkyFrames(weather, symbols, settings.animatedSymbols, now)
            "next_solar" -> nextSolarDisplayFrames(weather, symbols, now)
            "approaching_weather" -> approachingWeatherFrames(weather, symbols, settings.animatedSymbols)
            "moon_phase" -> moonPhaseFrames(now, settings.animatedSymbols)
            "atmos_mood" -> moodFrames(weather, settings.animatedSymbols)
            else -> livingSkyFrames(weather, symbols, settings.animatedSymbols, now)
        }
        return selected.ifEmpty { listOf(temperatureFrame) }
    }

    private fun livingSkyFrames(
        weather: AtmosGlyphWeatherService.GlyphWeather,
        symbols: List<IntArray>,
        animated: Boolean,
        now: Long
    ): List<IntArray> {
        val next = nextSolarMinutes(weather, now)
        if (next != null && next.second <= SOLAR_COUNTDOWN_WINDOW_MINUTES) {
            val progress = 1f - (next.second.coerceIn(0, SOLAR_COUNTDOWN_WINDOW_MINUTES) / SOLAR_COUNTDOWN_WINDOW_MINUTES.toFloat())
            return solarHorizonFrames(next.first == 'R', progress, animated)
        }
        return symbols
    }

    private fun approachingWeatherFrames(
        weather: AtmosGlyphWeatherService.GlyphWeather,
        fallback: List<IntArray>,
        animated: Boolean
    ): List<IntArray> {
        val minutes = weather.approachingMinutes ?: return fallback
        val base = countdownFrame(minutes.coerceIn(0, 599), 'A')
        val kind = weather.approachingCondition.lowercase()
        val markerX = when {
            "storm" in kind || "thunder" in kind -> 10
            "snow" in kind || "sleet" in kind -> 3
            weather.approachingChance >= 50 || "rain" in kind -> 6
            else -> 1
        }
        put(base, markerX, 1, ON)
        if (!animated) return listOf(base)
        return listOf(base, base.copyOf().also { put(it, markerX, 2, DIM) })
    }

    private fun moonPhaseFrames(now: Long, animated: Boolean): List<IntArray> {
        val phase = moonPhase(now)
        val base = moonPhaseFrame(phase, 0)
        return if (animated) listOf(base, moonPhaseFrame(phase, 1)) else listOf(base)
    }

    private fun moodFrames(weather: AtmosGlyphWeatherService.GlyphWeather, animated: Boolean): List<IntArray> {
        val code = when {
            weather.condition.contains("storm", true) || weather.condition.contains("thunder", true) -> "BRD"
            weather.condition.contains("fog", true) || weather.condition.contains("mist", true) -> "FOG"
            weather.rainChance >= 70 || weather.condition.contains("rain", true) -> "WET"
            weather.wind >= 35 -> "WND"
            weather.humidity >= 78 && weather.temperature >= 22 -> "MUG"
            weather.temperature >= 35 -> "HOT"
            weather.temperature <= 5 -> "CRP"
            weather.condition.contains("clear", true) || weather.condition.contains("sun", true) -> "CLR"
            else -> "CAL"
        }
        val frame = wordFrame(code)
        if (!animated) return listOf(frame)
        return listOf(frame, frame.copyOf().also { put(it, 6, 1, DIM) })
    }

    fun nextRefreshDelayMs(
        weather: AtmosGlyphWeatherService.GlyphWeather,
        settings: AtmosGlyphWeatherService.GlyphSettings,
        now: Long,
        frameCount: Int
    ): Long? {
        if (settings.animatedSymbols && frameCount > 1) return ANIMATION_DELAY_MS
        if (settings.mode == "next_solar") return millisUntilNextMinute(now)
        return null
    }

    private fun millisUntilNextMinute(now: Long): Long = (60_000L - (now % 60_000L)).coerceAtLeast(100L)

    private fun conditionFrames(condition: String, animated: Boolean): List<IntArray> {
        val kind = condition.lowercase()
        val frames = when {
            "storm" in kind || "thunder" in kind -> listOf(storm(false), storm(true))
            "rain" in kind || "shower" in kind || "drizzle" in kind -> listOf(rain(0), rain(1), rain(2))
            "snow" in kind || "sleet" in kind -> listOf(snow(0), snow(1), snow(2))
            "fog" in kind || "mist" in kind || "haze" in kind -> listOf(fog(0), fog(1))
            "cloud" in kind || "overcast" in kind -> listOf(cloud())
            "night" in kind -> listOf(moon())
            else -> listOf(sun(0), sun(1))
        }
        return if (animated) frames else listOf(frames.first())
    }

    private fun convertTemperature(celsius: Int, fahrenheit: Boolean) =
        if (fahrenheit) (celsius * 9.0 / 5.0 + 32.0).roundToInt().coerceIn(-99, 199) else celsius

    private fun nextSolarDisplayFrames(weather: AtmosGlyphWeatherService.GlyphWeather, symbols: List<IntArray>, now: Long): List<IntArray> {
        val next = nextSolarMinutes(weather, now) ?: return symbols
        return if (next.second <= SOLAR_COUNTDOWN_WINDOW_MINUTES) {
            listOf(countdownFrame(next.second, next.first))
        } else {
            symbols
        }
    }

    private fun solarCountdownFrame(raw: String, zone: String, now: Long, sunrise: Boolean): IntArray {
        val minutes = minutesUntil(raw, zone, now) ?: return unavailableFrame()
        return countdownFrame(minutes, if (sunrise) 'R' else 'S')
    }

    private fun nextSolarMinutes(weather: AtmosGlyphWeatherService.GlyphWeather, now: Long): Pair<Char, Int>? {
        val rise = minutesUntil(weather.sunrise, weather.timeZoneId, now)
        val set = minutesUntil(weather.sunset, weather.timeZoneId, now)
        return listOfNotNull(rise?.let { 'R' to it }, set?.let { 'S' to it }).minByOrNull { it.second }
    }

    private fun minutesUntil(raw: String, zoneId: String, now: Long): Int? {
        if (raw.isBlank()) return null
        return runCatching {
            val zone = runCatching { java.util.TimeZone.getTimeZone(zoneId.ifBlank { java.util.TimeZone.getDefault().id }) }.getOrDefault(java.util.TimeZone.getDefault())
            val formats = listOf("h:mm a", "h:mma", "HH:mm", "yyyy-MM-dd'T'HH:mm")
            val parsed = formats.firstNotNullOfOrNull { pattern ->
                runCatching { java.text.SimpleDateFormat(pattern, java.util.Locale.ENGLISH).apply { timeZone = zone }.parse(raw.trim()) }.getOrNull()
            } ?: return null
            val target = java.util.Calendar.getInstance(zone).apply {
                timeInMillis = now
                set(java.util.Calendar.HOUR_OF_DAY, java.util.Calendar.getInstance(zone).apply { time = parsed }.get(java.util.Calendar.HOUR_OF_DAY))
                set(java.util.Calendar.MINUTE, java.util.Calendar.getInstance(zone).apply { time = parsed }.get(java.util.Calendar.MINUTE))
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
                if (timeInMillis <= now) add(java.util.Calendar.DAY_OF_YEAR, 1)
            }.timeInMillis
            ((target - now + 59_999L) / 60_000L).toInt().coerceAtLeast(0)
        }.getOrNull()
    }

    private fun countdownFrame(minutes: Int, event: Char): IntArray {
        val frame = blank()
        if (minutes > 60) {
            // Long countdowns stay glanceable: show whole hours until the final hour.
            val hours = (minutes / 60).coerceIn(1, 99)
            drawText(frame, hours.toString(), 1, 4)
            drawChar(frame, 'H', 9, 4)
        } else {
            // During the final hour, switch to an exact minute countdown.
            drawText(frame, minutes.coerceIn(0, 60).toString(), 1, 4)
            drawChar(frame, 'M', 9, 4)
        }
        // A dim top-corner pixel differentiates sunrise from sunset without crowding the digits.
        put(frame, when (event) { 'R' -> 1; 'A' -> 6; else -> 11 }, 1, DIM)
        return frame
    }

    private fun solarHorizonFrames(sunrise: Boolean, progress: Float, animated: Boolean): List<IntArray> {
        fun frame(offset: Int): IntArray = blank().also { f ->
            line(f, 1, 9, 11, 9, DIM)
            val y = (10 - (progress * 6f).roundToInt() + offset).coerceIn(3, 10)
            for (yy in y - 1..y + 1) for (xx in 5..7) if ((xx - 6) * (xx - 6) + (yy - y) * (yy - y) <= 2) put(f, xx, yy)
            if (!sunrise) {
                put(f, 2, 2, DIM); put(f, 10, 3, DIM)
            } else {
                put(f, 1, 8, DIM); put(f, 11, 8, DIM)
            }
        }
        val first = frame(0)
        return if (animated) listOf(first, frame(if (sunrise) -1 else 1)) else listOf(first)
    }

    private fun moonPhase(now: Long): Double {
        val synodic = 29.53058867
        val knownNewMoon = 947182440000L // 2000-01-06 18:14 UTC
        val days = (now - knownNewMoon) / 86_400_000.0
        return ((days % synodic) + synodic) % synodic / synodic
    }

    private fun moonPhaseFrame(phase: Double, shimmer: Int): IntArray = blank().also { f ->
        val waxing = phase < 0.5
        val illumination = if (waxing) phase * 2.0 else (1.0 - phase) * 2.0
        for (y in 2..10) for (x in 2..10) {
            val dx = x - 6
            val dy = y - 6
            if (dx * dx + dy * dy <= 18) {
                val boundary = ((illumination * 8.0) - 4.0).roundToInt()
                val lit = if (waxing) dx >= -boundary else dx <= boundary
                if (lit) put(f, x, y, if ((x + y + shimmer) % 5 == 0) DIM else ON)
            }
        }
        put(f, 11, 2, DIM)
    }

    private fun wordFrame(text: String): IntArray = blank().also { frame ->
        val value = text.take(3).uppercase(java.util.Locale.ENGLISH)
        drawText(frame, value, 1, 4)
    }

    private fun percentFrame(value: Int): IntArray = blank().also { frame ->
        drawText(frame, value.coerceIn(0, 99).toString(), 1, 4)
        drawChar(frame, '%', 9, 4)
    }

    private fun unavailableFrame(): IntArray = blank().also { frame -> drawChar(frame, '-', 5, 4) }
    private fun temperatureFrame(value: Int): IntArray = blank().also { frame ->
        val text = value.toString()
        val width = text.length * 4 - 1
        val startX = ((SIZE - width) / 2).coerceAtLeast(0)
        drawText(frame, text, startX, 4)
        // A single dim pixel is the degree mark. The selected unit only changes the number.
        put(frame, (startX + width + 1).coerceAtMost(SIZE - 1), 4, DIM)
    }
    private fun drawText(frame: IntArray, text: String, ox: Int, oy: Int) = text.forEachIndexed { i, c -> drawChar(frame, c, ox + i * 4, oy) }

    private fun blank() = IntArray(SIZE * SIZE)
    private fun put(frame: IntArray, x: Int, y: Int, value: Int = ON) { if (x in 0 until SIZE && y in 0 until SIZE) frame[y * SIZE + x] = value }
    private fun line(frame: IntArray, x1: Int, y1: Int, x2: Int, y2: Int, value: Int = ON) { val steps=maxOf(kotlin.math.abs(x2-x1),kotlin.math.abs(y2-y1)).coerceAtLeast(1); for(i in 0..steps) put(frame,x1+(x2-x1)*i/steps,y1+(y2-y1)*i/steps,value) }
    private fun sun(phase:Int)=blank().also{f->for(y in 4..8)for(x in 4..8)if((x-6)*(x-6)+(y-6)*(y-6)<=6)put(f,x,y);(if(phase==0)arrayOf(6 to 1,6 to 11,1 to 6,11 to 6)else arrayOf(2 to 2,10 to 2,2 to 10,10 to 10)).forEach{(x,y)->put(f,x,y,DIM)}}
    private fun cloud()=blank().also{f->for(x in 2..10)put(f,x,8);for(x in 3..9)put(f,x,7);for(x in 4..8)put(f,x,6);for(x in 5..7)put(f,x,5);put(f,3,6,DIM);put(f,9,6,DIM)}
    private fun rain(phase:Int)=cloud().also{f->arrayOf(3,6,9).forEachIndexed{i,x->put(f,x,10+((phase+i)%3),if(i==1)ON else DIM)}}
    private fun snow(phase:Int)=cloud().also{f->arrayOf(3 to 10,6 to 11,9 to 10).forEachIndexed{i,(x,y)->put(f,x+((phase+i)%2),y+((phase+i)%2),if(i==1)ON else DIM)}}
    private fun fog(phase:Int)=blank().also{f->for(y in listOf(4,6,8)){val o=(phase+y)%2;line(f,1+o,y,10+o,y,if(y==6)ON else DIM)}}
    private fun storm(flash:Boolean)=rain(if(flash)1 else 0).also{f->line(f,7,8,5,10);line(f,5,10,7,10);line(f,7,10,5,12);if(flash)for(x in 0 until SIZE)put(f,x,0,DIM)}
    private fun moon()=blank().also{f->for(y in 2..10)for(x in 2..10){val d1=(x-6)*(x-6)+(y-6)*(y-6);val d2=(x-8)*(x-8)+(y-5)*(y-5);if(d1<=18&&d2>12)put(f,x,y)};put(f,10,2,DIM);put(f,11,5,DIM)}
    private fun drawChar(frame:IntArray,char:Char,ox:Int,oy:Int){(FONT[char]?:return).forEachIndexed{y,row->row.forEachIndexed{x,p->if(p=='1')put(frame,ox+x,oy+y)}}}
    private val FONT=mapOf(
        '-' to listOf("000","000","111","000","000"),'0' to listOf("111","101","101","101","111"),'1' to listOf("010","110","010","010","111"),'2' to listOf("111","001","111","100","111"),'3' to listOf("111","001","111","001","111"),'4' to listOf("101","101","111","001","001"),'5' to listOf("111","100","111","001","111"),'6' to listOf("111","100","111","101","111"),'7' to listOf("111","001","010","010","010"),'8' to listOf("111","101","111","101","111"),'9' to listOf("111","101","111","001","111"),
        'A' to listOf("010","101","111","101","101"),'B' to listOf("110","101","110","101","110"),'C' to listOf("111","100","100","100","111"),'D' to listOf("110","101","101","101","110"),'F' to listOf("111","100","110","100","100"),'G' to listOf("111","100","101","101","111"),'H' to listOf("101","101","111","101","101"),'L' to listOf("100","100","100","100","111"),'M' to listOf("101","111","111","101","101"),'O' to listOf("111","101","101","101","111"),'P' to listOf("110","101","110","100","100"),'R' to listOf("110","101","110","101","101"),'S' to listOf("111","100","111","001","111"),'T' to listOf("111","010","010","010","010"),'U' to listOf("101","101","101","101","111"),'W' to listOf("101","101","111","111","101"),'%' to listOf("101","001","010","100","101")
    )
}
