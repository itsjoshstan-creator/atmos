# Atmos 0.50.7

Lean Atmos renderer update. See `README_0.50.7_CHANGES.md` for details.

## 0.50.10
Layout controls are consolidated, compact content adapts to longer condition descriptions, saved-place previews use Atmos gradients and navigate directly, and condition details receive subtle condition-aware colouring.
