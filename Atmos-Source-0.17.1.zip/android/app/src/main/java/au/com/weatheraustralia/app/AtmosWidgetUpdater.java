package au.com.weatheraustralia.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.BroadcastReceiver;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;

final class AtmosWidgetUpdater {
    static final String ACTION_REFRESH = "au.com.weatheraustralia.app.REFRESH_WIDGETS";
    private static final long INTERVAL = 30L * 60L * 1000L;
    private AtmosWidgetUpdater() {}

    static void schedule(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        alarm.setInexactRepeating(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + 60_000L,
            INTERVAL,
            refreshIntent(context)
        );
    }

    static void cancel(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) alarm.cancel(refreshIntent(context));
    }

    private static PendingIntent refreshIntent(Context context) {
        Intent intent = new Intent(context, AtmosWidgetProvider.class).setAction(ACTION_REFRESH);
        return PendingIntent.getBroadcast(context, 81, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void refresh(Context context, BroadcastReceiver.PendingResult result) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                SharedPreferences p = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE);
                String id = p.getString("location_id", "");
                if (!id.isEmpty()) {
                    JSONObject daily = get("https://api.weather.bom.gov.au/v1/locations/" + id + "/forecasts/daily");
                    JSONObject hourly = get("https://api.weather.bom.gov.au/v1/locations/" + id + "/forecasts/hourly");
                    JSONArray days = daily.optJSONArray("data");
                    JSONArray hours = hourly.optJSONArray("data");
                    SharedPreferences.Editor e = p.edit();
                    if (days != null && days.length() > 0) {
                        JSONObject d = days.getJSONObject(0);
                        e.putString("condition", d.optString("short_text", p.getString("condition", "Current conditions")));
                        e.putString("icon", d.optString("icon_descriptor", p.getString("icon", "clear")));
                        e.putString("high", number(d, "temp_max", p.getString("high", "—")));
                        e.putString("low", number(d, "temp_min", p.getString("low", "—")));
                        JSONObject rain = d.optJSONObject("rain");
                        if (rain != null) e.putString("rain", String.valueOf(rain.optInt("chance", 0)));
                        for (int i = 0; i < Math.min(7, days.length()); i++) {
                            JSONObject day = days.getJSONObject(i);
                            String date = day.optString("date", "");
                            String label = "—";
                            try {
                                java.text.SimpleDateFormat input = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
                                java.util.Date parsed = input.parse(date.substring(0, 10));
                                label = new java.text.SimpleDateFormat(i == 0 ? "'TODAY'" : "EEE", java.util.Locale.ENGLISH).format(parsed).toUpperCase(java.util.Locale.ENGLISH);
                            } catch (Exception ignored) {}
                            e.putString("day_name_" + i, label);
                            e.putString("day_high_" + i, number(day, "temp_max", "—"));
                            e.putString("day_low_" + i, number(day, "temp_min", "—"));
                            e.putString("day_icon_" + i, day.optString("icon_descriptor", "clear"));
                        }
                    }
                    if (hours != null) {
                        for (int i = 0; i < Math.min(3, hours.length()); i++) {
                            JSONObject h = hours.getJSONObject(i);
                            if (i == 0) e.putString("temp", number(h, "temp", p.getString("temp", "—")));
                            String time = h.optString("time", h.optString("date", ""));
                            String label = "—";
                            try {
                                int marker = time.indexOf('T');
                                int hour = Integer.parseInt(time.substring(marker + 1, marker + 3));
                                label = (hour % 12 == 0 ? 12 : hour % 12) + (hour < 12 ? "am" : "pm");
                            } catch (Exception ignored) {}
                            e.putString("hour_time_" + i, label);
                            e.putString("hour_temp_" + i, number(h, "temp", "—"));
                        }
                    }
                    e.putLong("updated_at", System.currentTimeMillis()).apply();
                }
            } catch (Exception ignored) {
            } finally {
                AtmosWidgetProvider.updateAll(context);
                AtmosWideWidgetProvider.updateAll(context);
                AtmosGlanceWidgetProvider.updateAll(context);
                AtmosWeeklyWidgetProvider.updateAll(context);
                if (result != null) result.finish();
            }
        });
    }

    private static String number(JSONObject object, String key, String fallback) {
        Object value = object.opt(key);
        return value instanceof Number ? String.valueOf(Math.round(((Number) value).doubleValue())) : fallback;
    }

    private static JSONObject get(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(12000);
        connection.setRequestProperty("Accept", "application/json");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            StringBuilder text = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) text.append(line);
            return new JSONObject(text.toString());
        } finally {
            connection.disconnect();
        }
    }
}
