# Atmos 0.16.11

Native Android source for Atmos 0.16.11.

Changes in this build:
- Rebuilt the immersive chart as a rolling 24-hour forecast.
- The chart begins at the current hour and continues 24 hours ahead.
- Anchored the NOW marker to the far-left edge.
- Replaced the midnight-to-midnight heading and fixed time labels.
- Shows sunrise and sunset only when they fall inside the rolling window, including events after midnight.
- Removed historical/day-progress rendering from the immersive chart.

Build the Android project in the `android` directory.
