# Atmos 0.16.1

Native Android weather app source.

## New in 0.16.1
- Optional full-screen current conditions layout with an edge-to-edge condition gradient.
- The condition gradient continues behind the forecast cards as the page scrolls.
- Classic Atmos card layout remains available.
- New post-location onboarding screen for choosing the preferred home layout.
- Layout can be changed later in Settings > Appearance.


## 0.16.2
- Added a full-day temperature and precipitation chart to full-screen conditions.
- Redesigned layout previews to make the difference between card and full-screen modes clear.
- Added the visual layout selector to Appearance settings.
- Added Atmos colour accents to settings sections.
