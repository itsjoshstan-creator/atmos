# Atmos 0.30.8

- Immersive Atmos transitions are now driven by the pager's continuous position and begin changing immediately on swipe.
- Removed the retired standard card-style choice from onboarding and Settings.
- Forecast experience now offers Fullscreen Hero and Immersive as the two supported options.
- Updated launch and welcome splash copy for the unified Atmos experience.
- Condition-specific atmosphere effects cross-fade continuously between locations.
