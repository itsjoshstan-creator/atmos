# Atmos 0.65.1 — Exact Immersive Wallpaper Pass

- Moved the immersive lower darkening overlay into SharedAtmosSceneRenderer.
- Both the in-app immersive atmosphere and live wallpaper now use the exact same fixed 2100 px, four-stop overlay.
- Removed the separate Compose-only lower-gradient overlay to prevent renderer drift.
- Wallpaper remains text-free and event-driven.
