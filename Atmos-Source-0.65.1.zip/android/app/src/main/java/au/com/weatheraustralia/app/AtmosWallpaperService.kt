package au.com.weatheraustralia.app

import android.graphics.Canvas
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.min
import java.util.Date

/** Live wallpaper using the exact same Atmos scene renderer as the in-app hero. */
class AtmosWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = AtmosWallpaperEngine()

    private inner class AtmosWallpaperEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private val rawPrefs by lazy { getSharedPreferences("atmos_native", MODE_PRIVATE) }
        private val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "weatherCache" || key == "savedPlaces" || key == "seasonalAtmosphere" || key == "temperatureAtmosphere") drawFrame()
        }
        private val minuteTick = object : Runnable {
            override fun run() {
                if (!visible) return
                drawFrame()
                val now = System.currentTimeMillis()
                handler.postDelayed(this, 60_000L - now % 60_000L)
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            rawPrefs.registerOnSharedPreferenceChangeListener(listener)
        }

        override fun onDestroy() {
            handler.removeCallbacksAndMessages(null)
            rawPrefs.unregisterOnSharedPreferenceChangeListener(listener)
            super.onDestroy()
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(minuteTick)
            if (isVisible) {
                drawFrame()
                val now = System.currentTimeMillis()
                handler.postDelayed(minuteTick, 60_000L - now % 60_000L)
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = drawFrame()
        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) = drawFrame()

        private fun drawFrame() {
            if (!surfaceHolder.surface.isValid) return
            val canvas = runCatching { surfaceHolder.lockCanvas() }.getOrNull() ?: return
            try {
                renderExactAtmos(canvas)
            } catch (_: Throwable) {
                renderSafeFallback(canvas)
            } finally {
                runCatching { surfaceHolder.unlockCanvasAndPost(canvas) }
            }
        }

        private fun renderExactAtmos(canvas: Canvas) {
            val weather = loadFirstWallpaperWeather(this@AtmosWallpaperService)
                ?: throw IllegalStateException("No cached weather for first location")
            val firstPlace = weather.place
            val day = weather.days.firstOrNull() ?: throw IllegalStateException("No forecast day")
            val now = Date()
            val palette = applyAtmosphericPaletteVariables(
                solarAwarePalette(day.icon, firstPlace, now),
                weather.observation,
                day.condition,
                firstPlace,
                now
            )
            val temperature = weather.observation.feels ?: weather.observation.temp ?: 18
            val spec = buildAtmosSceneSpec(
                palette = palette,
                observation = weather.observation,
                condition = day.condition,
                temperatureC = temperature,
                place = firstPlace,
                now = now,
                enabled = true
            )
            SharedAtmosSceneRenderer.render(
                canvas = canvas,
                width = canvas.width,
                height = canvas.height,
                spec = spec,
                immersive = true,
                immersiveBottom = Color.rgb(7, 16, 31),
                immersiveVisibleHeight = visibleDisplayHeight(canvas)
            )
        }

        private fun visibleDisplayHeight(canvas: Canvas): Int {
            val displayHeight = resources.displayMetrics.heightPixels.coerceAtLeast(1)
            return min(canvas.height.coerceAtLeast(1), displayHeight)
        }

        private fun renderSafeFallback(canvas: Canvas) {
            val place = Place("wallpaper-fallback", "Atmos", "Western Australia", -31.95, 115.86, current = true, timeZoneId = "Australia/Perth")
            val observation = Observation(temp = 20, feels = 20, humidity = 55, pressure = 1013.25)
            val now = Date()
            val palette = applyAtmosphericPaletteVariables(solarAwarePalette("partly_cloudy", place, now), observation, "Partly cloudy", place, now)
            val spec = buildAtmosSceneSpec(palette, observation, "Partly cloudy", 20, place, now, true)
            SharedAtmosSceneRenderer.render(
                canvas,
                canvas.width,
                canvas.height,
                spec,
                immersive = true,
                immersiveBottom = Color.rgb(7,16,31),
                immersiveVisibleHeight = visibleDisplayHeight(canvas)
            )
        }
    }
}
