# Atmos Android Weather App — 0.31.0

This source is the existing Capacitor Android application rebuilt with the first genuine procedural **Atmos Engine**.

## Atmos Engine

The Hero and Current Conditions hero now render through an HTML Canvas engine rather than relying on CSS weather loops.

The renderer includes:

- Continuous `requestAnimationFrame` simulation.
- A reusable particle pool with spawn, update, fade and retirement lifecycles.
- Randomised per-particle position, depth, velocity, lifetime, turbulence, rotation and opacity.
- Rain, snow and atmospheric mist particles.
- Procedural cloud fields that move with observed wind.
- Solar-aware sky lighting and day/night palettes.
- Temperature and feels-like colour grading.
- Humidity and visibility-driven haze.
- Mean sea-level pressure and gust-driven instability/turbulence.
- Rain amount/probability-driven precipitation density.
- Condition-driven storms, clouds, fog, rain and snow.
- UV-driven solar brightness.
- Reduced-motion support and a capped device-pixel ratio for mobile performance.

Australian weather remains BOM-first. Missing pressure and selected rendering inputs can be supplemented by Open-Meteo. Estimated Australian pressure is labelled **Open-Meteo estimate · not BOM sourced** in Weather Details.

## Version

- Version name: `0.31.0`
- Version code: `111`

## Build

The Android project is under `android/`.

```bash
cd android
./gradlew assembleDebug
```

The GitHub Actions workflow in `.github/workflows/android-build.yml` builds from that directory and uploads the debug APK.
