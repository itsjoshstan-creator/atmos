# Atmos 0.30.14

This source build separates the app's stable appearance from the location-aware weather presentation.

## Appearance model

- **App appearance:** Follow Device, Light, or Dark. This controls Settings, Radar, Seasons, details, dialogs, and other non-weather screens.
- **Weather appearance:** Follow observation location, Follow app appearance, Always light, or Always dark. This is scoped to Fullscreen Hero, Immersive, charts, and saved-location scenes.

Users upgrading from the former Automatic (Location) app-wide theme are migrated to Follow Device for the app and Follow observation location for weather.

The root Material theme no longer changes when swiping between day and night locations. Only the weather experience interpolates, reducing recomposition and transition lag.
