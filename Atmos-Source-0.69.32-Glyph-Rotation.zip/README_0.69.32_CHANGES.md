# Atmos 0.69.32

- Replaced selectable Living Sky and Approaching Weather Glyph modes with Chance of Rain and Battery Percentage.
- Auto Glyph Rotation now cycles Temperature, Chance of Rain, Next Solar Event and Battery Percentage, with a stateful 10-second timer for every screen.
- Added minimal custom precipitation, solar-unit and battery markers using the established Atmos numeric style.
- Full battery displays a centred F with the three-pixel battery indicator.
- Hero forecast lows now use an evening-to-following-morning window built in the forecast location’s timezone.
