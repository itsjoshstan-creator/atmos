# Atmos 0.69.3

- Added seasonal Atmos launcher icons for Spring, Summer, Autumn and Winter.
- Added Aurora, Midnight, Monochrome and Original non-seasonal choices.
- Added automatic icon mode that follows the season of the first saved location.
- Added an App icon submenu under Settings.
