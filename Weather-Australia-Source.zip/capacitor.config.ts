import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'au.com.weatheraustralia.app',
  appName: 'Weather Australia',
  webDir: 'webapp',
  server: {
    url: 'https://bom-weather-australia.travis-sheeh-5179.chatgpt.site',
    cleartext: false
  },
  android: {
    backgroundColor: '#f7f7ff'
  }
};

export default config;
