# Atmos 0.50.0

Atmos Engine 2.0 Phase 1. See `README_0.50.0_CHANGES.md` for details.
