# Atmos 0.20.5

Natural Motion update for the Atmos particle engine.

- Seasonal particles now use independent randomized motion profiles.
- Smooth multi-frequency turbulence replaces the obvious repeated path animation.
- Every particle has its own drift, lift, rotation, depth, lifetime, and gust response.
- Wind influences direction without making all particles move in sync.
- Spring petals flutter, summer motes hover, autumn leaves tumble, and winter crystals drift calmly.
- Existing individual fade-in/fade-out and particle recycling remain enabled.

Version: 0.20.5
Build: 88

The source archive was integrity-checked. Android compilation could not be run locally because the Gradle distribution host was unavailable.
