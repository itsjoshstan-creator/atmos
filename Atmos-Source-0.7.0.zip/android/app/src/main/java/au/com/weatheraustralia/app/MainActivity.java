package au.com.weatheraustralia.app;

import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.view.WindowInsetsController;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (bridge != null && bridge.getWebView() != null) {
            bridge.getWebView().addJavascriptInterface(new AtmosSystemBars(), "AtmosNative");
        }
    }

    private class AtmosSystemBars {
        @JavascriptInterface
        public void setStatusBar(String colour, boolean darkIcons) {
            runOnUiThread(() -> {
                try {
                    getWindow().setStatusBarColor(Color.parseColor(colour));
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        WindowInsetsController controller = getWindow().getInsetsController();
                        if (controller != null) {
                            controller.setSystemBarsAppearance(
                                darkIcons ? WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS : 0,
                                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            );
                        }
                    } else {
                        int flags = getWindow().getDecorView().getSystemUiVisibility();
                        if (darkIcons) flags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        else flags &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        getWindow().getDecorView().setSystemUiVisibility(flags);
                    }
                } catch (Exception ignored) {}
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (bridge != null && bridge.getWebView() != null) {
            bridge.getWebView().evaluateJavascript(
                "Boolean(window.AtmosHandleBack && window.AtmosHandleBack())",
                handled -> {
                    if (!"true".equals(handled)) {
                        moveTaskToBack(true);
                    }
                }
            );
        } else {
            super.onBackPressed();
        }
    }
}
