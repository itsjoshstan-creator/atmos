# Atmos 0.69.32

- Fixed overnight low calculations to use the forecast location’s local timezone, including daylight-saving changes.
- Invalidated legacy cached forecast values so the hero card cannot continue showing the old midnight-based low after upgrading.
- Retains the redesigned sunrise and sunset Glyph scenes from 0.69.31.
