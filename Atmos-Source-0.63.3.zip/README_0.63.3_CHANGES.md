# Atmos 0.63.3

- Pre-renders each Atmos hero background into a reusable bitmap.
- Atmos gradients are regenerated only when location, weather palette, theme-related scene inputs, size, or the solar minute changes.
- Moves scene generation to a background dispatcher instead of drawing all full-screen gradients on the UI thread.
- Replaces multi-step full-screen palette redraws with a lightweight bitmap crossfade.
- Pauses the solar minute clock for inactive transition scenes.
- Recycles superseded scene bitmaps to limit memory use.
- Preserves the existing Atmos palette, solar lighting, seasonal tint, thermal grading, and layout.
