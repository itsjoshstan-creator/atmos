# Atmos 0.12.3

Performance-focused update based directly on Atmos 0.12.2.

Changes:
- Preserves the 0.12.2 interface and ambient condition animations without altering their appearance or behaviour.
- Caches the home-page condition palette and large background brush instead of rebuilding them during unrelated recompositions.
- Caches the saved-location pager structure and selected page calculations.
- Reuses placeholder weather state for unloaded location pages instead of allocating it repeatedly.
- Adds stable content types to the hourly and precipitation rows so Compose can reuse item compositions more effectively.
- Keeps the existing stable keys and lazy-list structure.
- Updated to versionCode 43 and versionName 0.12.3.

The source archive passed a ZIP integrity check. Android compilation must still be confirmed by GitHub Actions.
