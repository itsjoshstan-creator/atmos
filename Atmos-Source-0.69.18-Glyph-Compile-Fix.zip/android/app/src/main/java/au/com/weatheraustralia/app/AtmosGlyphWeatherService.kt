package au.com.weatheraustralia.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import kotlin.math.roundToInt

/**
 * Optional Nothing Glyph Matrix weather toy.
 *
 * The Nothing SDK is loaded reflectively so Atmos remains fully compatible with every
 * other Android device. Official builds download and package the SDK AAR during CI.
 */
class AtmosGlyphWeatherService : Service() {
    private var manager: com.nothing.ketchum.GlyphMatrixManager? = null
    private var frameIndex = 0

    private val serviceHandler = object : android.os.Handler(android.os.Looper.getMainLooper()) {
        override fun handleMessage(msg: android.os.Message) {
            if (msg.what == com.nothing.ketchum.GlyphToy.MSG_GLYPH_TOY) {
                val event = msg.data?.getString(com.nothing.ketchum.GlyphToy.MSG_GLYPH_TOY_DATA)
                Log.i(TAG, "Glyph Toy event received: $event")
                if (event == com.nothing.ketchum.GlyphToy.EVENT_AOD ||
                    event == com.nothing.ketchum.GlyphToy.EVENT_CHANGE
                ) {
                    renderNextFrame()
                }
                return
            }
            super.handleMessage(msg)
        }
    }
    private val serviceMessenger = android.os.Messenger(serviceHandler)

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Atmos Glyph Toy service created")
    }

    override fun onBind(intent: Intent?): IBinder {
        Log.i(TAG, "Atmos Glyph Toy service bound: ${intent?.action}")
        startGlyph()
        return serviceMessenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Log.i(TAG, "Atmos Glyph Toy service unbound")
        stopGlyph()
        return false
    }

    override fun onDestroy() {
        Log.i(TAG, "Atmos Glyph Toy service destroyed")
        stopGlyph()
        super.onDestroy()
    }

    private fun startGlyph() {
        if (manager != null) return
        runCatching {
            val glyphManager = com.nothing.ketchum.GlyphMatrixManager.getInstance(applicationContext)
            manager = glyphManager
            glyphManager.init(object : com.nothing.ketchum.GlyphMatrixManager.Callback {
                override fun onServiceConnected(componentName: android.content.ComponentName) {
                    Log.i(TAG, "Nothing Glyph Matrix service connected: $componentName")
                    runCatching {
                        glyphManager.register(com.nothing.ketchum.Glyph.DEVICE_25111p)
                        Log.i(TAG, "Registered Phone (4a) Pro Glyph target")
                        renderNextFrame()
                    }.onFailure { Log.e(TAG, "Unable to register Glyph Matrix target", it) }
                }

                override fun onServiceDisconnected(componentName: android.content.ComponentName) {
                    Log.w(TAG, "Nothing Glyph Matrix service disconnected: $componentName")
                }
            })
        }.onFailure {
            manager = null
            Log.e(TAG, "Unable to initialise Nothing Glyph Matrix SDK", it)
        }
    }

    private fun renderNextFrame() {
        val glyphManager = manager ?: run {
            Log.w(TAG, "Frame requested before Glyph manager was ready")
            return
        }
        val weather = readWeather()
        val frames = AtmosGlyphFrames.frames(weather.condition, weather.temperature)
        val pixels = frames[frameIndex.mod(frames.size)]
        frameIndex++

        runCatching {
            val bitmapPixels = IntArray(pixels.size) { index ->
                val level = pixels[index].coerceIn(0, 255)
                android.graphics.Color.argb(255, level, level, level)
            }
            val bitmap = android.graphics.Bitmap.createBitmap(
                bitmapPixels,
                13,
                13,
                android.graphics.Bitmap.Config.ARGB_8888
            )

            val matrixObject = com.nothing.ketchum.GlyphMatrixObject.Builder()
                .setImageSource(bitmap)
                .setPosition(0, 0)
                .setScale(100)
                .setBrightness(255)
                .build()

            val matrixFrame = com.nothing.ketchum.GlyphMatrixFrame.Builder()
                .addTop(matrixObject)
                .build(applicationContext)

            glyphManager.setMatrixFrame(matrixFrame)
            bitmap.recycle()
            Log.i(TAG, "Nothing SDK accepted a structured 13x13 Glyph frame")
        }.onFailure { Log.e(TAG, "Nothing SDK rejected the Glyph frame", it) }
    }

    private fun stopGlyph() {
        manager?.let { glyphManager ->
            runCatching { glyphManager.unInit() }
                .onFailure { Log.w(TAG, "Unable to uninitialise Glyph SDK", it) }
        }
        manager = null
    }

    private fun readWeather(): GlyphWeather {
        val prefs = getSharedPreferences("atmos_widget", Context.MODE_PRIVATE)
        val rawTemp = prefs.getString("temp", "18")?.toDoubleOrNull() ?: 18.0
        return GlyphWeather(
            temperature = rawTemp.roundToInt().coerceIn(-99, 99),
            condition = prefs.getString("condition", "Clear").orEmpty()
        )
    }

    private data class GlyphWeather(val temperature: Int, val condition: String)

    companion object {
        private const val TAG = "AtmosGlyph"
    }
}

private object AtmosGlyphFrames {
    private const val SIZE = 13
    private const val ON = 255
    private const val DIM = 88

    fun frames(condition: String, temperature: Int): List<IntArray> {
        val kind = condition.lowercase()
        val symbolFrames = when {
            "storm" in kind || "thunder" in kind -> listOf(storm(false), storm(true))
            "rain" in kind || "shower" in kind || "drizzle" in kind -> listOf(rain(0), rain(1), rain(2))
            "snow" in kind || "sleet" in kind -> listOf(snow(0), snow(1), snow(2))
            "fog" in kind || "mist" in kind || "haze" in kind -> listOf(fog(0), fog(1))
            "cloud" in kind || "overcast" in kind -> listOf(cloud())
            "night" in kind -> listOf(moon())
            else -> listOf(sun(0), sun(1))
        }
        return symbolFrames + temperatureFrames(temperature)
    }

    private fun blank() = IntArray(SIZE * SIZE)
    private fun put(frame: IntArray, x: Int, y: Int, value: Int = ON) {
        if (x in 0 until SIZE && y in 0 until SIZE) frame[y * SIZE + x] = value
    }
    private fun line(frame: IntArray, x1: Int, y1: Int, x2: Int, y2: Int, value: Int = ON) {
        val steps = maxOf(kotlin.math.abs(x2 - x1), kotlin.math.abs(y2 - y1)).coerceAtLeast(1)
        for (i in 0..steps) put(frame, x1 + (x2 - x1) * i / steps, y1 + (y2 - y1) * i / steps, value)
    }

    private fun sun(phase: Int) = blank().also { f ->
        for (y in 4..8) for (x in 4..8) if ((x - 6) * (x - 6) + (y - 6) * (y - 6) <= 6) put(f, x, y)
        val rays = if (phase == 0) arrayOf(6 to 1, 6 to 11, 1 to 6, 11 to 6) else arrayOf(2 to 2, 10 to 2, 2 to 10, 10 to 10)
        rays.forEach { (x, y) -> put(f, x, y, DIM) }
    }

    private fun cloud() = blank().also { f ->
        for (x in 2..10) put(f, x, 8)
        for (x in 3..9) put(f, x, 7)
        for (x in 4..8) put(f, x, 6)
        for (x in 5..7) put(f, x, 5)
        put(f, 3, 6, DIM); put(f, 9, 6, DIM)
    }

    private fun rain(phase: Int) = cloud().also { f ->
        val drops = arrayOf(3, 6, 9)
        drops.forEachIndexed { index, x -> put(f, x, 10 + ((phase + index) % 3), if (index == 1) ON else DIM) }
    }

    private fun snow(phase: Int) = cloud().also { f ->
        arrayOf(3 to 10, 6 to 11, 9 to 10).forEachIndexed { index, (x, y) ->
            put(f, x + ((phase + index) % 2), y + ((phase + index) % 2), if (index == 1) ON else DIM)
        }
    }

    private fun fog(phase: Int) = blank().also { f ->
        for (y in listOf(4, 6, 8)) {
            val offset = (phase + y) % 2
            line(f, 1 + offset, y, 10 + offset, y, if (y == 6) ON else DIM)
        }
    }

    private fun storm(flash: Boolean) = rain(if (flash) 1 else 0).also { f ->
        line(f, 7, 8, 5, 10, ON); line(f, 5, 10, 7, 10, ON); line(f, 7, 10, 5, 12, ON)
        if (flash) for (x in 0 until SIZE) put(f, x, 0, DIM)
    }

    private fun moon() = blank().also { f ->
        for (y in 2..10) for (x in 2..10) {
            val d1 = (x - 6) * (x - 6) + (y - 6) * (y - 6)
            val d2 = (x - 8) * (x - 8) + (y - 5) * (y - 5)
            if (d1 <= 18 && d2 > 12) put(f, x, y)
        }
        put(f, 10, 2, DIM); put(f, 11, 5, DIM)
    }

    private fun temperatureFrames(value: Int): List<IntArray> {
        val text = value.toString()
        val frame = blank()
        val width = text.length * 4 - 1
        val startX = ((SIZE - width) / 2).coerceAtLeast(0)
        text.forEachIndexed { index, char -> drawChar(frame, char, startX + index * 4, 4) }
        put(frame, (startX + width + 1).coerceAtMost(12), 4, DIM)
        return listOf(frame)
    }

    private fun drawChar(frame: IntArray, char: Char, ox: Int, oy: Int) {
        val rows = FONT[char] ?: return
        rows.forEachIndexed { y, row ->
            row.forEachIndexed { x, pixel -> if (pixel == '1') put(frame, ox + x, oy + y) }
        }
    }

    private val FONT = mapOf(
        '-' to listOf("000", "000", "111", "000", "000"),
        '0' to listOf("111", "101", "101", "101", "111"),
        '1' to listOf("010", "110", "010", "010", "111"),
        '2' to listOf("111", "001", "111", "100", "111"),
        '3' to listOf("111", "001", "111", "001", "111"),
        '4' to listOf("101", "101", "111", "001", "001"),
        '5' to listOf("111", "100", "111", "001", "111"),
        '6' to listOf("111", "100", "111", "101", "111"),
        '7' to listOf("111", "001", "010", "010", "010"),
        '8' to listOf("111", "101", "111", "101", "111"),
        '9' to listOf("111", "101", "111", "001", "111")
    )
}
