# Atmos 0.50.7

Lean Atmos renderer update. See `README_0.50.7_CHANGES.md` for details.
