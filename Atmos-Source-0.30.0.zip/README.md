
## 0.20.10
- The hero temperature can now be tapped to switch between Celsius and Fahrenheit, with a refined animated value transition.
- Newly loaded forecast data settles into view with a subtle, performant Atmos reveal.
- Tapping the location name opens the saved locations and search page in both card and immersive layouts.
- The locations page now uses the same deep atmospheric gradient language as About Atmos.
- Main page changes use directional Atmos-themed fade and slide transitions.
- versionName: 0.20.10
- versionCode: 92
# Atmos 0.20.10

Built from Atmos 0.20.6.

## Changes
- Adaptive hero foreground now applies to the current temperature, condition, feels-like/high/low text, narrative, location and chart.
- Android status-bar icons follow the hero gradient contrast on the home screen.
- Australian locations derive an appropriate IANA timezone and always show local time.
- Current Location now remains the device location; nearby place and BOM observation station are presented separately.
- Automatic refresh remains limited to once every 10 minutes, while manual pull-to-refresh always bypasses the cache limit.
- Optional WorkManager background refresh updates saved locations approximately every 30 minutes, subject to Android battery scheduling.

## Version
- versionName: 0.20.10
- versionCode: 90

## Verification
The source archive passed ZIP integrity checks. Local Gradle compilation could not be completed because this environment could not reach services.gradle.org. Verify with GitHub Actions.
## Atmos 0.30.0

- Extended the living Atmos visual language into saved locations, search, and settings with shared low-cost ambient Canvas backgrounds, local day/night location accents, and animated settings glyphs.
- Added restrained spring touch feedback to key choices, location selection, and home navigation.
- Added an Atmos refresh presentation that gathers and settles while fresh weather data is loading.
- Added smooth weather-state transitions: hero palette colours now blend between conditions and custom weather artwork crossfades and settles instead of snapping.
- Expanded the custom Atmos weather icon language with refined rain strokes plus dedicated fog, mist, haze, snow, sleet, and hail treatments.
- Preserved pager performance by avoiding per-frame page transforms and keeping continuous animation work in lightweight Canvas layers.
- Android version updated to 0.30.0 (versionCode 95).

## Atmos 0.20.11

- Forecast reveal animations now run only when genuinely new data arrives on the active location, not when pager pages are composed during swiping.
- Hero temperature number transitions are limited to the visible forecast page to reduce pager workload.
- Fahrenheit mode now displays a compact °F indicator beside the hero temperature.
- The living hero gradient moves at a more noticeable but still calm pace.
- Android version updated to 0.20.11 (versionCode 94).

