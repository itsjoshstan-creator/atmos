"use client";

import { useEffect, useMemo, useState } from "react";

type Place = { id: string; name: string; state: string; postcode?: string };
type Day = {
  date: string;
  temp_max: number;
  temp_min: number;
  icon_descriptor: string;
  short_text: string;
  rain_chance: number;
};

const places: Place[] = [
  { id: "qd66hr", name: "Fremantle", state: "WA", postcode: "6160" },
  { id: "qd66", name: "Perth", state: "WA", postcode: "6000" },
  { id: "r1r0", name: "Sydney", state: "NSW", postcode: "2000" },
  { id: "r1r0fs", name: "Melbourne", state: "VIC", postcode: "3000" },
  { id: "r3gx", name: "Brisbane", state: "QLD", postcode: "4000" },
  { id: "r1f9", name: "Adelaide", state: "SA", postcode: "5000" },
  { id: "r3dp", name: "Hobart", state: "TAS", postcode: "7000" },
  { id: "r1b", name: "Canberra", state: "ACT", postcode: "2600" },
  { id: "qvv1", name: "Darwin", state: "NT", postcode: "0800" },
];

const fallbackDays: Day[] = [
  { date: "2026-07-25", temp_max: 19, temp_min: 11, icon_descriptor: "partly_cloudy", short_text: "Partly cloudy", rain_chance: 20 },
  { date: "2026-07-26", temp_max: 18, temp_min: 10, icon_descriptor: "shower", short_text: "Possible shower", rain_chance: 40 },
  { date: "2026-07-27", temp_max: 20, temp_min: 9, icon_descriptor: "mostly_sunny", short_text: "Mostly sunny", rain_chance: 10 },
  { date: "2026-07-28", temp_max: 21, temp_min: 10, icon_descriptor: "sunny", short_text: "Sunny", rain_chance: 5 },
  { date: "2026-07-29", temp_max: 19, temp_min: 12, icon_descriptor: "cloudy", short_text: "Cloudy", rain_chance: 30 },
  { date: "2026-07-30", temp_max: 17, temp_min: 11, icon_descriptor: "rain", short_text: "Rain developing", rain_chance: 70 },
  { date: "2026-07-31", temp_max: 18, temp_min: 10, icon_descriptor: "shower", short_text: "Shower or two", rain_chance: 50 },
];

const weatherIcon = (value = "") => {
  if (/storm/.test(value)) return "⛈";
  if (/rain|shower/.test(value)) return "🌧";
  if (/cloud/.test(value)) return "☁";
  if (/frost|snow/.test(value)) return "❄";
  if (/sunny|clear/.test(value)) return "☀";
  return "⛅";
};

const hourly = [
  ["Now", "⛅", "17°"], ["1 pm", "⛅", "18°"], ["2 pm", "☀", "19°"],
  ["3 pm", "☀", "19°"], ["4 pm", "⛅", "18°"], ["5 pm", "☁", "17°"],
  ["6 pm", "☁", "16°"], ["7 pm", "☁", "15°"],
];

const dayLabel = (value: string) => {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return "—";
  return new Intl.DateTimeFormat("en-AU", { weekday: "short" }).format(parsed);
};

export default function Home() {
  const [selected, setSelected] = useState(places[0]);
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [dark, setDark] = useState(false);
  const [unit, setUnit] = useState<"C" | "F">("C");
  const [days, setDays] = useState<Day[]>(fallbackDays);
  const [status, setStatus] = useState<"live" | "demo" | "loading">("loading");

  useEffect(() => {
    const controller = new AbortController();
    setStatus("loading");
    fetch(`https://api.weather.bom.gov.au/v1/locations/${selected.id}/forecasts/daily`, {
      signal: controller.signal,
      headers: { Accept: "application/json" },
    })
      .then((r) => {
        if (!r.ok) throw new Error("BOM unavailable");
        return r.json();
      })
      .then((payload) => {
        const raw = payload?.data;
        if (!Array.isArray(raw) || !raw.length) throw new Error("No forecast");
        setDays(raw.map((d: any) => ({
          date: d.date,
          temp_max: d.temp_max,
          temp_min: d.temp_min,
          icon_descriptor: d.icon_descriptor,
          short_text: d.short_text,
          rain_chance: d.rain?.chance ?? 0,
        })));
        setStatus("live");
      })
      .catch(() => {
        setDays(fallbackDays);
        setStatus("demo");
      });
    return () => controller.abort();
  }, [selected]);

  const shown = useMemo(() => places.filter((p) =>
    `${p.name} ${p.state} ${p.postcode}`.toLowerCase().includes(query.toLowerCase())
  ), [query]);
  const convert = (c: number) => unit === "C" ? Math.round(c) : Math.round(c * 9 / 5 + 32);
  const today = days[0] ?? fallbackDays[0];

  return (
    <main className={dark ? "app dark" : "app"}>
      <div className="shell">
        <header>
          <button className="brand" aria-label="BOM Weather home">
            <span className="brand-mark"><i /><i /><i /></span>
            <span><strong>Weather</strong><small>Australia</small></span>
          </button>
          <div className="top-actions">
            <button className="icon-button" onClick={() => setDark(!dark)} aria-label="Toggle theme">{dark ? "☀" : "☾"}</button>
            <button className="avatar" aria-label="Profile">JS</button>
          </div>
        </header>

        <section className="search-wrap">
          <div className="search">
            <span>⌕</span>
            <input value={query} onFocus={() => setMenuOpen(true)} onChange={(e) => { setQuery(e.target.value); setMenuOpen(true); }} placeholder="Search suburb, town or postcode" aria-label="Search Australian locations" />
            <button onClick={() => { setQuery(""); setMenuOpen(false); }} aria-label="Clear search">{query ? "×" : "⌖"}</button>
          </div>
          {menuOpen && (
            <div className="search-results">
              {shown.slice(0, 6).map((p) => (
                <button key={p.name} onClick={() => { setSelected(p); setQuery(""); setMenuOpen(false); }}>
                  <span className="pin">●</span><span><strong>{p.name}</strong><small>{p.state} · {p.postcode}</small></span>
                </button>
              ))}
              {!shown.length && <p>No saved locations match. Try a capital city.</p>}
            </div>
          )}
        </section>

        <div className="location-row">
          <div><span className="location-pin">●</span><strong>{selected.name}</strong><span>{selected.state}</span></div>
          <button className="unit" onClick={() => setUnit(unit === "C" ? "F" : "C")}><b>°{unit}</b><span>°{unit === "C" ? "F" : "C"}</span></button>
        </div>

        <section className="hero-card">
          <div className="hero-copy">
            <p className="eyebrow">Saturday · 12:24 pm</p>
            <div className="temperature">{convert(today.temp_max - 2)}<sup>°</sup></div>
            <h1>{today.short_text || "Partly cloudy"}</h1>
            <p>Feels like {convert(today.temp_max - 3)}° · H {convert(today.temp_max)}° · L {convert(today.temp_min)}°</p>
          </div>
          <div className="weather-art" aria-hidden="true">
            <div className="sun" />
            <div className="cloud c1" /><div className="cloud c2" />
          </div>
          <div className="hero-stats">
            <div><span>💧</span><p>Rain</p><strong>{today.rain_chance}%</strong></div>
            <div><span>≋</span><p>Wind</p><strong>W 19 km/h</strong></div>
            <div><span>◉</span><p>Humidity</p><strong>63%</strong></div>
          </div>
        </section>

        <section className="panel">
          <div className="section-title"><div><h2>Today</h2><p>Hourly forecast</p></div><button>View details <span>›</span></button></div>
          <div className="hourly">
            {hourly.map(([time, icon, temp], i) => <div key={time} className={i === 0 ? "hour active" : "hour"}><strong>{time}</strong><span>{icon}</span><b>{unit === "C" ? temp : `${convert(parseInt(temp))}°`}</b>{i < 3 && <small>10%</small>}</div>)}
          </div>
        </section>

        <section className="panel week-panel">
          <div className="section-title"><div><h2>7-day forecast</h2><p>Plan the week ahead</p></div><span className={`data-status ${status}`}>{status === "live" ? "Live BOM data" : status === "loading" ? "Updating…" : "BOM demo data"}</span></div>
          <div className="week">
            {days.slice(0, 7).map((day, i) => {
              const label = i === 0 ? "Today" : dayLabel(day.date);
              return <div className="day" key={`${day.date}-${i}`}><strong>{label}</strong><span className="day-icon">{weatherIcon(day.icon_descriptor)}</span><p>{day.short_text}</p><span className="rain">💧 {day.rain_chance}%</span><div className="range"><b>{convert(day.temp_max)}°</b><i /><span>{convert(day.temp_min)}°</span></div></div>;
            })}
          </div>
        </section>

        <section className="details-grid">
          <article><span className="tile-icon">☀</span><p>UV index</p><h3>3 <small>Moderate</small></h3><div className="uv-scale"><i /></div><small>Protection recommended</small></article>
          <article><span className="tile-icon">◒</span><p>Sunrise & sunset</p><h3>7:11 am</h3><div className="sun-line"><i /></div><small>Sunset 5:38 pm</small></article>
          <article><span className="tile-icon">≋</span><p>Wind gusts</p><h3>28 <small>km/h</small></h3><div className="compass">W <i>➤</i></div><small>West-southwesterly</small></article>
        </section>

        <footer><p>Weather data supplied by the <strong>Australian Bureau of Meteorology</strong>.</p><span>Updated 12:20 pm AWST</span></footer>
      </div>
    </main>
  );
}
