package au.com.weatheraustralia.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
