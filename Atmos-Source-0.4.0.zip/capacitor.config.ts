import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'au.com.weatheraustralia.app',
  appName: 'Atmos',
  webDir: 'webapp',
  android: {
    backgroundColor: '#f7f7ff'
  }
};

export default config;
