# Atmos

Atmos is a lightweight Australian weather app using Bureau of Meteorology
forecast data. The Android app is built with Capacitor and its self-contained
interface lives in `webapp/`.

## Current version

`0.4.0`

Atmos remains pre-release until it is ready for a public release:

- Small fixes and refinements increase the patch number by `0.0.1`.
- Larger feature updates increase the minor number by `0.1.0`.
- Version `1.0.0` is reserved for the first release-ready build.

## Build an Android APK

```sh
npm ci
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK is created at:

`android/app/build/outputs/apk/debug/app-debug.apk`

Internet access is required for live Bureau of Meteorology data.
