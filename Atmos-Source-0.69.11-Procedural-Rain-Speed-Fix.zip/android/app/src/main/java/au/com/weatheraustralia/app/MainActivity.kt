package au.com.weatheraustralia.app

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.AudioManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings as AndroidSettings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.ListItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.zIndex
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.SupervisorJob
import kotlin.coroutines.resume
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.absoluteValue
import kotlin.math.acos
import kotlin.math.atan
import kotlin.math.floor
import kotlin.math.tan
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestHighestRefreshRate()
        setContent { AtmosNativeApp() }
    }

    override fun onResume() {
        super.onResume()
        requestHighestRefreshRate()
    }

    private fun requestHighestRefreshRate() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val display = display ?: return
        val fastestMode = display.supportedModes.maxWithOrNull(
            compareBy<android.view.Display.Mode> { it.refreshRate }
                .thenBy { it.physicalWidth * it.physicalHeight }
        ) ?: return
        window.attributes = window.attributes.apply {
            preferredDisplayModeId = fastestMode.modeId
        }
    }
}

private enum class Page { Home, Locations, Seasons, Settings, Radar, Help, About }
private enum class ThemeChoice { AutomaticLocation, System, Light, Dark }
private enum class WeatherAppearance { FollowLocation, FollowApp, Light, Dark }
private enum class HomeLayout { Card, Immersive, Dual }
private enum class LocationTransition { Standard, Immersive }
private enum class DensityChoice { Compact, Expanded }
private enum class SettingsCategory { AppearanceLayout, WeatherExperience, UpdatesNotifications, HomeScreen, Changelog }
private enum class TemperatureUnit { Celsius, Fahrenheit }
internal enum class AtmosIntensityChoice { Subtle, Balanced, Cinematic }
private enum class AtmosTransitionChoice { Instant, Smooth, Slow }
private enum class AccentColorChoice { Atmos, Wallpaper, Blue, Green, Orange, Purple, Red, Monochrome }
private enum class WindUnit { Kmh, Mph, Ms, Knots }
private enum class PressureUnit { Hpa, InHg, MmHg }
private enum class RainUnit { Millimetres, Inches }
private enum class VisibilityUnit { Kilometres, Miles }
private enum class StatusBarIconStyle { Temperature, Condition }
private enum class WidgetTextMode { Automatic, Light, Dark }
private enum class AtmosphereIntensity { Off, Performance, Static, Immersive, Ultra }
private val LocalOledCardMode = compositionLocalOf { false }
private val LocalAtmosIntensityChoice = compositionLocalOf { AtmosIntensityChoice.Balanced }
private val LocalAtmosTransitionChoice = compositionLocalOf { AtmosTransitionChoice.Smooth }

private const val WEATHER_REFRESH_INTERVAL_MS = 10 * 60 * 1000L
private const val AMBIENT_IDLE_DELAY_MS = 10_000L
private const val LEGACY_WEATHER_NOTIFICATION_CHANNEL_ID = "atmos_current_weather"
private const val WEATHER_NOTIFICATION_CHANNEL_ID = "atmos_current_weather_visible"
private const val WEATHER_NOTIFICATION_ID = 604

@Immutable
private data class AmbientDisplayUi(val active: Boolean = false, val controlsVisible: Boolean = true)
private val LocalAmbientDisplayUi = compositionLocalOf { AmbientDisplayUi() }

private val atmosphereClockScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
private val atmosphereMinuteClock = flow {
    while (true) {
        emit(System.currentTimeMillis())
        val wait = 60_000L - (System.currentTimeMillis() % 60_000L)
        delay(wait.coerceAtLeast(250L))
    }
}.stateIn(
    scope = atmosphereClockScope,
    started = SharingStarted.WhileSubscribed(stopTimeoutMillis = 5_000L),
    initialValue = System.currentTimeMillis()
)

@Composable
private fun sharedMinuteMillis(): Long = atmosphereMinuteClock.collectAsStateWithLifecycle().value

@Composable
private fun persistentStatusBarTopInset(): androidx.compose.ui.unit.Dp {
    val view = LocalView.current
    val density = LocalDensity.current
    val insetPx = ViewCompat.getRootWindowInsets(view)
        ?.getInsetsIgnoringVisibility(WindowInsetsCompat.Type.statusBars())
        ?.top
        ?: 0
    return with(density) { insetPx.toDp() }
}

@Immutable
internal data class Place(
    val id: String,
    val name: String,
    val state: String,
    val latitude: Double,
    val longitude: Double,
    val current: Boolean = false,
    val country: String = "Australia",
    val countryCode: String = "AU",
    val timeZoneId: String = ""
)

@Immutable
internal data class DayForecast(
    val date: String,
    val condition: String,
    val icon: String,
    val high: Int,
    val low: Int,
    val rainChance: Int,
    val rainAmount: Double,
    val uvMax: Double? = null
)

@Immutable
internal data class HourForecast(
    val time: Date,
    val temp: Int,
    val icon: String,
    val rainChance: Int,
    val humidity: Int,
    val wind: Int,
    val direction: String
)

private enum class TemperatureTrend(val symbol: String, val motionDirection: Float) {
    Rising("↗", -1f),
    Steady("→", 0f),
    Falling("↘", 1f)
}

private fun temperatureTrend(weather: WeatherState, now: Date = Date()): TemperatureTrend {
    val current = weather.observation.temp ?: return TemperatureTrend.Steady
    val targetTime = now.time + TimeUnit.HOURS.toMillis(3)
    val future = weather.hours
        .filter { it.time.time >= now.time }
        .minByOrNull { kotlin.math.abs(it.time.time - targetTime) }
        ?: return TemperatureTrend.Steady
    val difference = future.temp - current
    return when {
        difference >= 1 -> TemperatureTrend.Rising
        difference <= -1 -> TemperatureTrend.Falling
        else -> TemperatureTrend.Steady
    }
}

internal enum class PressureSource {
    BOM,
    OPEN_METEO,
    UNAVAILABLE
}

@Immutable
internal data class Observation(
    val temp: Int? = null,
    val feels: Int? = null,
    val humidity: Int? = null,
    val wind: Int? = null,
    val direction: String = "",
    val gust: Int? = null,
    val pressure: Double? = null,
    val pressureSource: PressureSource = PressureSource.UNAVAILABLE,
    val rainSince9: Double? = null,
    val currentPrecipitation: Double? = null,
    val precipitationProbability: Int? = null,
    val windBearing: Double? = null,
    val station: String = "Nearest observation"
)


@Immutable
private data class HistoricalObservation(
    val time: Date,
    val temp: Int,
    val rainSince9: Double? = null
)

@Immutable
internal data class WeatherState(
    val place: Place,
    val days: List<DayForecast>,
    val hours: List<HourForecast>,
    val observation: Observation,
    val live: Boolean,
    val warnings: List<String> = emptyList(),
    val updated: Date = Date()
)

private val places = listOf(
    Place("", "Forrestdale", "Western Australia", -32.155, 115.934),
    Place("qd66hr", "Fremantle", "Western Australia", -32.0569, 115.7439),
    Place("qd66hr", "Perth", "Western Australia", -31.9523, 115.8613),
    Place("qd65fp", "Mandurah", "Western Australia", -32.5269, 115.7217),
    Place("qd47rc", "Bunbury", "Western Australia", -33.3267, 115.6369),
    Place("qd6k4f", "Joondalup", "Western Australia", -31.745, 115.766),
    Place("qd5r1g", "Rockingham", "Western Australia", -32.281, 115.727),
    Place("qd4x4s", "Albany", "Western Australia", -35.0269, 117.8837),
    Place("", "Busselton", "Western Australia", -33.6516, 115.347),
    Place("", "Margaret River", "Western Australia", -33.953, 115.073),
    Place("", "Port Hedland", "Western Australia", -20.3107, 118.601),
    Place("qd1u2n", "Esperance", "Western Australia", -33.8608, 121.8896),
    Place("qdb3g6", "Geraldton", "Western Australia", -28.7774, 114.614),
    Place("qec32p", "Kalgoorlie", "Western Australia", -30.7489, 121.4658),
    Place("qg5k8c", "Broome", "Western Australia", -17.9614, 122.2359),
    Place("qgbx8x", "Karratha", "Western Australia", -20.7364, 116.8463),
    Place("r3gx2f", "Darwin", "Northern Territory", -12.4634, 130.8456),
    Place("r1r0fs", "Adelaide", "South Australia", -34.9285, 138.6007),
    Place("r1f93c", "Melbourne", "Victoria", -37.8136, 144.9631),
    Place("r3dp5h", "Hobart", "Tasmania", -42.8821, 147.3272),
    Place("r3gx2f", "Canberra", "Australian Capital Territory", -35.2809, 149.13),
    Place("r3gx2f", "Sydney", "New South Wales", -33.8688, 151.2093),
    Place("r7hg6k", "Brisbane", "Queensland", -27.4698, 153.0251),
    Place("r7k0yx", "Gold Coast", "Queensland", -28.0167, 153.4),
    Place("r7hx0w", "Sunshine Coast", "Queensland", -26.65, 153.0667),
    Place("r6n3xm", "Cairns", "Queensland", -16.9186, 145.7781),
    Place("r6kz2g", "Townsville", "Queensland", -19.2589, 146.8169),
    Place("r3gx2f", "Newcastle", "New South Wales", -32.9283, 151.7817),
    Place("r3gx2f", "Wollongong", "New South Wales", -34.4278, 150.8931),
    Place("", "Coffs Harbour", "New South Wales", -30.2963, 153.1135),
    Place("", "Dubbo", "New South Wales", -32.2569, 148.6011),
    Place("", "Wagga Wagga", "New South Wales", -35.1082, 147.3598),
    Place("", "Byron Bay", "New South Wales", -28.6474, 153.602),
    Place("", "Geelong", "Victoria", -38.1499, 144.3617),
    Place("", "Ballarat", "Victoria", -37.5622, 143.8503),
    Place("", "Bendigo", "Victoria", -36.757, 144.2794),
    Place("", "Mildura", "Victoria", -34.208, 142.1246),
    Place("", "Toowoomba", "Queensland", -27.5598, 151.9507),
    Place("", "Mackay", "Queensland", -21.1411, 149.186),
    Place("", "Rockhampton", "Queensland", -23.379, 150.51),
    Place("", "Mount Gambier", "South Australia", -37.8284, 140.7804),
    Place("", "Port Augusta", "South Australia", -32.4952, 137.7894),
    Place("", "Whyalla", "South Australia", -33.034, 137.585),
    Place("", "Launceston", "Tasmania", -41.4332, 147.1441),
    Place("", "Devonport", "Tasmania", -41.1769, 146.3515),
    Place("r1r0fs", "Alice Springs", "Northern Territory", -23.698, 133.8807),
    Place("", "Katherine", "Northern Territory", -14.4652, 132.2635)
)


private val defaultSavedPlaces: List<Place> = emptyList()

// Used only while first-run location selection is in progress. It is never persisted
// or shown as a saved location.
private val onboardingPlaceholder = Place(
    id = "onboarding-placeholder",
    name = "Choose a location",
    state = "Atmos setup",
    latitude = -31.9523,
    longitude = 115.8613,
    timeZoneId = "Australia/Perth"
)

private fun sameSavedPlace(a: Place, b: Place): Boolean {
    val sameName = a.name.equals(b.name, ignoreCase = true) && a.state.equals(b.state, ignoreCase = true)
    val closeCoordinates = distanceSquared(a.latitude, a.longitude, b.latitude, b.longitude) < 0.00008
    return sameName || closeCoordinates
}

private fun normaliseSavedPlaces(input: List<Place>, preferredFirst: Place? = null): List<Place> {
    val live = preferredFirst?.takeIf { it.current } ?: input.firstOrNull { it.current }
    val ordered = buildList {
        live?.let(::add)
        addAll(input.filterNot { it.current })
        preferredFirst?.takeUnless { it.current }?.let { if (none { saved -> sameSavedPlace(saved, it) }) add(it) }
    }
    val result = mutableListOf<Place>()
    ordered.filter { it.name.isNotBlank() && it.latitude.isFinite() && it.longitude.isFinite() }.forEach { candidate ->
        if (result.none { sameSavedPlace(it, candidate) }) result += candidate
    }
    return result
}

private val fallbackDays = listOf(
    DayForecast("", "Mostly sunny", "mostly_sunny", 21, 12, 5, 0.0),
    DayForecast("", "Partly cloudy", "partly_cloudy", 20, 11, 20, 0.4),
    DayForecast("", "Sunny", "sunny", 22, 10, 5, 0.0),
    DayForecast("", "Cloud increasing", "cloudy", 19, 12, 30, 0.8),
    DayForecast("", "Shower or two", "shower", 18, 11, 55, 3.0),
    DayForecast("", "Partly cloudy", "partly_cloudy", 19, 10, 20, 0.2),
    DayForecast("", "Mostly sunny", "mostly_sunny", 21, 11, 10, 0.0)
)


private fun coordinatesAreAustralian(latitude: Double, longitude: Double): Boolean =
    latitude in -44.5..-9.0 && longitude in 111.0..155.5

private fun Place.isAustralian(): Boolean {
    if (countryCode.isNotBlank()) return countryCode.equals("AU", ignoreCase = true)
    return coordinatesAreAustralian(latitude, longitude)
}

private object GlobalGeocodingRepository {
    suspend fun search(query: String): List<Place> = withContext(Dispatchers.IO) {
        if (query.trim().length < 2) return@withContext emptyList()
        runCatching {
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val connection = (URL("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=20&language=en&format=json").openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 10_000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "Atmos Android Weather App")
            }
            val json = try { JSONObject(connection.inputStream.bufferedReader().use { it.readText() }) } finally { connection.disconnect() }
            val results = json.optJSONArray("results") ?: JSONArray()
            (0 until results.length()).mapNotNull { index ->
                results.optJSONObject(index)?.let { item ->
                    val lat = item.optDouble("latitude", Double.NaN)
                    val lon = item.optDouble("longitude", Double.NaN)
                    if (!lat.isFinite() || !lon.isFinite()) return@let null
                    val country = item.optString("country", "")
                    val state = listOf(item.optString("admin1", ""), country).filter(String::isNotBlank).distinct().joinToString(", ")
                    Place(
                        id = "global:${item.optLong("id", 0L)}",
                        name = item.optString("name", "Location"),
                        state = state,
                        latitude = lat,
                        longitude = lon,
                        country = country,
                        countryCode = item.optString("country_code", ""),
                        timeZoneId = item.optString("timezone", "")
                    )
                }
            }.distinctBy { "${it.name.lowercase()}:${"%.3f".format(Locale.US, it.latitude)}:${"%.3f".format(Locale.US, it.longitude)}" }
        }.getOrDefault(emptyList())
    }
}

private object OpenMeteoRepository {
    suspend fun load(place: Place): WeatherState = withContext(Dispatchers.IO) {
        try {
            val url = buildString {
                append("https://api.open-meteo.com/v1/forecast?")
                append("latitude=${place.latitude}&longitude=${place.longitude}")
                append("&timezone=auto&timeformat=unixtime&forecast_days=10")
                append("&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,rain,weather_code,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m")
                append("&hourly=temperature_2m,relative_humidity_2m,precipitation_probability,weather_code,wind_speed_10m,wind_direction_10m")
                append("&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,sunrise,sunset,uv_index_max")
            }
            val json = get(url)
            val resolvedPlace = place.copy(timeZoneId = json.optString("timezone", place.timeZoneId))
            val daily = json.optJSONObject("daily") ?: JSONObject()
            val dailyTimes = daily.optJSONArray("time") ?: JSONArray()
            val days = (0 until minOf(dailyTimes.length(), 10)).map { i ->
                val code = daily.optJSONArray("weather_code")?.optInt(i, 3) ?: 3
                DayForecast(
                    date = epochDate(dailyTimes.optLong(i)),
                    condition = weatherCodeText(code),
                    icon = weatherCodeIcon(code),
                    high = daily.optJSONArray("temperature_2m_max")?.optDouble(i, 20.0)?.roundToInt() ?: 20,
                    low = daily.optJSONArray("temperature_2m_min")?.optDouble(i, 10.0)?.roundToInt() ?: 10,
                    rainChance = daily.optJSONArray("precipitation_probability_max")?.optInt(i, 0) ?: 0,
                    rainAmount = daily.optJSONArray("precipitation_sum")?.optDouble(i, 0.0) ?: 0.0,
                    uvMax = daily.optJSONArray("uv_index_max")?.optDouble(i, Double.NaN)?.takeIf { it.isFinite() }
                )
            }.ifEmpty { fallbackDays }
            val hourly = json.optJSONObject("hourly") ?: JSONObject()
            val hourTimes = hourly.optJSONArray("time") ?: JSONArray()
            val nowSeconds = System.currentTimeMillis() / 1000L - 3600L
            val hours = (0 until hourTimes.length()).mapNotNull { i ->
                val epoch = hourTimes.optLong(i)
                if (epoch < nowSeconds) return@mapNotNull null
                val code = hourly.optJSONArray("weather_code")?.optInt(i, 3) ?: 3
                HourForecast(
                    time = Date(epoch * 1000L),
                    temp = hourly.optJSONArray("temperature_2m")?.optDouble(i, 20.0)?.roundToInt() ?: 20,
                    icon = weatherCodeIcon(code),
                    rainChance = hourly.optJSONArray("precipitation_probability")?.optInt(i, 0) ?: 0,
                    humidity = hourly.optJSONArray("relative_humidity_2m")?.optInt(i, 0) ?: 0,
                    wind = hourly.optJSONArray("wind_speed_10m")?.optDouble(i, 0.0)?.roundToInt() ?: 0,
                    direction = compassDirection(hourly.optJSONArray("wind_direction_10m")?.optDouble(i, 0.0) ?: 0.0)
                )
            }.take(48)
            val current = json.optJSONObject("current") ?: JSONObject()
            val currentCode = current.optInt("weather_code", 3)
            val currentDirection = current.optDouble("wind_direction_10m", 0.0)
            WeatherState(
                place = resolvedPlace,
                days = days,
                hours = hours,
                observation = Observation(
                    temp = current.numberOrNull("temperature_2m")?.roundToInt(),
                    feels = current.numberOrNull("apparent_temperature")?.roundToInt(),
                    humidity = current.numberOrNull("relative_humidity_2m")?.roundToInt(),
                    wind = current.numberOrNull("wind_speed_10m")?.roundToInt(),
                    direction = compassDirection(currentDirection),
                    gust = current.numberOrNull("wind_gusts_10m")?.roundToInt(),
                    pressure = current.numberOrNull("pressure_msl") ?: current.numberOrNull("surface_pressure"),
                    pressureSource = if (current.numberOrNull("pressure_msl") != null || current.numberOrNull("surface_pressure") != null) PressureSource.OPEN_METEO else PressureSource.UNAVAILABLE,
                    // Open-Meteo current precipitation is an instantaneous/current interval value,
                    // not accumulated rain since 9am. Keep the legacy field empty so it
                    // cannot exaggerate the current visual rain intensity.
                    rainSince9 = null,
                    currentPrecipitation = current.numberOrNull("precipitation") ?: current.numberOrNull("rain"),
                    precipitationProbability = hours.firstOrNull()?.rainChance,
                    windBearing = currentDirection,
                    station = "Open-Meteo · ${place.country.ifBlank { "International" }}"
                ),
                live = true,
                warnings = emptyList()
            )
        } catch (_: Exception) {
            WeatherState(place, fallbackDays, emptyList(), Observation(), false)
        }
    }

    suspend fun loadUvMax(place: Place, days: Int = 7): List<Double?> = withContext(Dispatchers.IO) {
        runCatching {
            val url = buildString {
                append("https://api.open-meteo.com/v1/forecast?")
                append("latitude=${place.latitude}&longitude=${place.longitude}")
                append("&timezone=auto&forecast_days=${days.coerceIn(1, 10)}&daily=uv_index_max")
            }
            val values = get(url).optJSONObject("daily")?.optJSONArray("uv_index_max") ?: JSONArray()
            (0 until values.length()).map { index ->
                values.optDouble(index, Double.NaN).takeIf { it.isFinite() }
            }
        }.getOrDefault(emptyList())
    }

    suspend fun loadPressureMsl(place: Place): Double? = withContext(Dispatchers.IO) {
        runCatching {
            val url = buildString {
                append("https://api.open-meteo.com/v1/forecast?")
                append("latitude=${place.latitude}&longitude=${place.longitude}")
                append("&timezone=auto&forecast_days=1&current=pressure_msl")
            }
            get(url).optJSONObject("current")?.numberOrNull("pressure_msl")
        }.getOrNull()
    }

    private fun get(address: String): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 15_000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "Atmos Android Weather App")
        }
        return try { JSONObject(connection.inputStream.bufferedReader().use { it.readText() }) } finally { connection.disconnect() }
    }

    private fun epochDate(seconds: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(seconds * 1000L))
    private fun weatherCodeText(code: Int): String = when (code) {
        0 -> "Clear sky"; 1 -> "Mostly clear"; 2 -> "Partly cloudy"; 3 -> "Overcast"
        45, 48 -> "Fog"; 51, 53, 55, 56, 57 -> "Drizzle"; 61, 63, 65, 66, 67 -> "Rain"
        71, 73, 75, 77, 85, 86 -> "Snow"; 80, 81, 82 -> "Rain showers"; 95, 96, 99 -> "Thunderstorm"
        else -> "Current conditions"
    }
    private fun weatherCodeIcon(code: Int): String = when (code) {
        0 -> "sunny"; 1 -> "mostly_sunny"; 2 -> "partly_cloudy"; 3 -> "cloudy"
        45, 48 -> "fog"; 51, 53, 55, 56, 57 -> "drizzle"; 61, 63, 65, 66, 67, 80, 81, 82 -> "shower"
        71, 73, 75, 77, 85, 86 -> "snow"; 95, 96, 99 -> "thunderstorm"
        else -> "partly_cloudy"
    }
    private fun compassDirection(degrees: Double): String {
        val labels = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        return labels[((degrees / 45.0).roundToInt() % 8 + 8) % 8]
    }
}

private object WeatherRepository {
    suspend fun load(place: Place): WeatherState = if (place.isAustralian()) BomRepository.load(place) else OpenMeteoRepository.load(place)
}

private object BomRepository {
    suspend fun load(place: Place): WeatherState = withContext(Dispatchers.IO) {
        try {
            val locationId = geohash(place.latitude, place.longitude)
            val daily = get("https://api.weather.bom.gov.au/v1/locations/$locationId/forecasts/daily")
            val hourly = runCatching { get("https://api.weather.bom.gov.au/v1/locations/$locationId/forecasts/hourly") }.getOrNull()
            val observations = runCatching { get("https://api.weather.bom.gov.au/v1/locations/$locationId/observations") }.getOrNull()
            val warningData = runCatching { get("https://api.weather.bom.gov.au/v1/locations/$locationId/warnings") }.getOrNull()
            val dayArray = daily.optJSONArray("data") ?: JSONArray()
            val fallbackUv = OpenMeteoRepository.loadUvMax(place, minOf(dayArray.length().coerceAtLeast(1), 7))
            val days = (0 until minOf(dayArray.length(), 7)).map { i ->
                val d = dayArray.getJSONObject(i)
                val rain = d.optJSONObject("rain")
                DayForecast(
                    d.optString("date"), d.optString("short_text", "Current conditions"),
                    d.optString("icon_descriptor", "partly_cloudy"),
                    d.optInt("temp_max", 20), d.optInt("temp_min", 11),
                    rain?.optInt("chance", 0) ?: 0,
                    rain?.optJSONObject("amount")?.optDouble("max", 0.0) ?: 0.0,
                    uvMax = listOf("uv_index", "uv", "max_uv_index")
                        .firstNotNullOfOrNull { key -> d.numberOrNull(key) }
                        ?: fallbackUv.getOrNull(i)
                )
            }.ifEmpty { fallbackDays }
            val hourArray = hourly?.optJSONArray("data") ?: JSONArray()
            val hours = (0 until minOf(hourArray.length(), 24)).mapNotNull { i ->
                runCatching {
                    val h = hourArray.getJSONObject(i)
                    val rain = h.optJSONObject("rain")
                    val wind = h.optJSONObject("wind")
                    val temperature: Int = h.optInt("temp", days.first().high - 2)
                    HourForecast(
                        time = parseDate(h.optString("time", h.optString("date"))),
                        temp = temperature,
                        icon = h.optString("icon_descriptor", days.first().icon),
                        rainChance = rain?.optInt("chance", 0) ?: 0,
                        humidity = h.optInt("relative_humidity", 0),
                        wind = wind?.optInt("speed_kilometre", 0) ?: 0,
                        direction = wind?.optString("direction", "") ?: ""
                    )
                }.getOrNull()
            }
            val raw = observations?.opt("data")
            val o = when (raw) {
                is JSONArray -> raw.optJSONObject(0)
                is JSONObject -> raw.optJSONArray("observations")?.optJSONObject(0) ?: raw
                else -> null
            }
            val wind = o?.optJSONObject("wind")
            val gust = o?.optJSONObject("gust")
            val station = o?.optJSONObject("station")
            val bomPressure = o?.numberOrNull("pressure_msl")
            val fallbackPressure = if (bomPressure == null) OpenMeteoRepository.loadPressureMsl(place) else null
            WeatherState(
                place, days, hours,
                Observation(
                    temp = o?.numberOrNull("temp")?.roundToInt(),
                    feels = o?.numberOrNull("temp_feels_like")?.roundToInt(),
                    humidity = o?.numberOrNull("humidity")?.roundToInt(),
                    wind = wind?.numberOrNull("speed_kilometre")?.roundToInt(),
                    direction = wind?.optString("direction", "") ?: "",
                    gust = gust?.numberOrNull("speed_kilometre")?.roundToInt(),
                    pressure = bomPressure ?: fallbackPressure,
                    pressureSource = when {
                        bomPressure != null -> PressureSource.BOM
                        fallbackPressure != null -> PressureSource.OPEN_METEO
                        else -> PressureSource.UNAVAILABLE
                    },
                    rainSince9 = o?.numberOrNull("rain_since_9am"),
                    station = station?.optString("name", "Nearest observation") ?: "Nearest observation"
                ), true,
                warnings = warningData?.optJSONArray("data")?.let { array ->
                    (0 until array.length()).mapNotNull { array.optJSONObject(it)?.optString("title")?.takeIf(String::isNotBlank) }
                } ?: emptyList()
            )
        } catch (_: Exception) {
            WeatherState(place, fallbackDays, emptyList(), Observation(temp = 19, feels = 17, humidity = 54, wind = 9, direction = "W"), false)
        }
    }

    private fun get(address: String): JSONObject {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 12_000
        connection.readTimeout = 12_000
        connection.setRequestProperty("Accept", "application/json")
        return try {
            JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        } finally {
            connection.disconnect()
        }
    }
}

private fun JSONObject.numberOrNull(key: String): Double? =
    if (has(key) && !isNull(key)) optDouble(key).takeUnless { it.isNaN() } else null

private fun parseDate(value: String): Date =
    listOf("yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX").firstNotNullOfOrNull {
        runCatching { SimpleDateFormat(it, Locale.US).parse(value) }.getOrNull()
    } ?: Date()


private fun Place.cacheKey(): String = "${"%.4f".format(Locale.US, latitude)}:${"%.4f".format(Locale.US, longitude)}"

private fun WeatherState.toJson(): JSONObject = JSONObject().apply {
    put("place", JSONObject().apply {
        put("id", place.id); put("name", place.name); put("state", place.state)
        put("lat", place.latitude); put("lon", place.longitude); put("current", place.current); put("country", place.country); put("countryCode", place.countryCode); put("timeZoneId", place.timeZoneId)
    })
    put("days", JSONArray().apply { days.forEach { day -> put(JSONObject().apply {
        put("date", day.date); put("condition", day.condition); put("icon", day.icon)
        put("high", day.high); put("low", day.low); put("rainChance", day.rainChance); put("rainAmount", day.rainAmount); day.uvMax?.let { put("uvMax", it) }
    }) } })
    put("hours", JSONArray().apply { hours.forEach { hour -> put(JSONObject().apply {
        put("time", hour.time.time); put("temp", hour.temp); put("icon", hour.icon)
        put("rainChance", hour.rainChance); put("humidity", hour.humidity); put("wind", hour.wind); put("direction", hour.direction)
    }) } })
    put("observation", JSONObject().apply {
        observation.temp?.let { put("temp", it) }; observation.feels?.let { put("feels", it) }
        observation.humidity?.let { put("humidity", it) }; observation.wind?.let { put("wind", it) }
        put("direction", observation.direction); observation.gust?.let { put("gust", it) }
        observation.pressure?.let { put("pressure", it) }; put("pressureSource", observation.pressureSource.name)
        observation.rainSince9?.let { put("rainSince9", it) }
        observation.currentPrecipitation?.let { put("currentPrecipitation", it) }
        observation.precipitationProbability?.let { put("precipitationProbability", it) }
        observation.windBearing?.let { put("windBearing", it) }
        put("station", observation.station)
    })
    put("live", live); put("warnings", JSONArray(warnings)); put("updated", updated.time)
}

private fun weatherStateFromJson(json: JSONObject): WeatherState? = runCatching {
    val p = json.getJSONObject("place")
    val place = Place(p.optString("id"), p.optString("name"), p.optString("state"), p.optDouble("lat"), p.optDouble("lon"), p.optBoolean("current"), p.optString("country", "Australia"), p.optString("countryCode", "AU"), p.optString("timeZoneId", ""))
    val dayArray = json.optJSONArray("days") ?: JSONArray()
    val days = (0 until dayArray.length()).map { i -> dayArray.getJSONObject(i).let { d ->
        DayForecast(d.optString("date"), d.optString("condition"), d.optString("icon"), d.optInt("high"), d.optInt("low"), d.optInt("rainChance"), d.optDouble("rainAmount"), d.numberOrNull("uvMax"))
    } }.ifEmpty { fallbackDays }
    val hourArray = json.optJSONArray("hours") ?: JSONArray()
    val hours = (0 until hourArray.length()).map { i -> hourArray.getJSONObject(i).let { h ->
        HourForecast(Date(h.optLong("time")), h.optInt("temp"), h.optString("icon"), h.optInt("rainChance"), h.optInt("humidity"), h.optInt("wind"), h.optString("direction"))
    } }
    val o = json.optJSONObject("observation") ?: JSONObject()
    val observation = Observation(
        temp = o.optIntOrNull("temp"),
        feels = o.optIntOrNull("feels"),
        humidity = o.optIntOrNull("humidity"),
        wind = o.optIntOrNull("wind"),
        direction = o.optString("direction"),
        gust = o.optIntOrNull("gust"),
        pressure = o.numberOrNull("pressure"),
        pressureSource = runCatching { PressureSource.valueOf(o.optString("pressureSource", "UNAVAILABLE")) }.getOrDefault(PressureSource.UNAVAILABLE),
        rainSince9 = o.numberOrNull("rainSince9"),
        currentPrecipitation = o.numberOrNull("currentPrecipitation"),
        precipitationProbability = o.optIntOrNull("precipitationProbability"),
        windBearing = o.numberOrNull("windBearing"),
        station = o.optString("station", "Nearest observation")
    )
    val warningArray = json.optJSONArray("warnings") ?: JSONArray()
    val warnings = (0 until warningArray.length()).mapNotNull { warningArray.optString(it).takeIf(String::isNotBlank) }
    WeatherState(place, days, hours, observation, json.optBoolean("live"), warnings, Date(json.optLong("updated", System.currentTimeMillis())))
}.getOrNull()

private fun JSONObject.optIntOrNull(key: String): Int? = if (has(key) && !isNull(key)) optInt(key) else null

private class AtmosPreferences(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("atmos_native", Context.MODE_PRIVATE)
    var onboarded: Boolean
        get() = prefs.getBoolean("onboarded", false)
        set(value) = prefs.edit().putBoolean("onboarded", value).apply()
    var theme: ThemeChoice
        get() = runCatching { ThemeChoice.valueOf(prefs.getString("theme", "System")!!) }.getOrDefault(ThemeChoice.System)
        set(value) = prefs.edit().putString("theme", value.name).apply()
    var weatherAppearance: WeatherAppearance
        get() = runCatching { WeatherAppearance.valueOf(prefs.getString("weatherAppearance", "FollowApp")!!) }.getOrDefault(WeatherAppearance.FollowApp)
        set(value) = prefs.edit().putString("weatherAppearance", value.name).apply()
    var darkNightMode: Boolean
        get() = prefs.getBoolean("darkNightMode", true)
        set(value) = prefs.edit().putBoolean("darkNightMode", value).apply()
    var conditionAnimations: Boolean
        get() = prefs.getBoolean("conditionAnimations", true)
        set(value) = prefs.edit().putBoolean("conditionAnimations", value).apply()
    var atmosphereIntensity: AtmosphereIntensity
        get() {
            val stored = prefs.getString("atmosphereIntensity", "Immersive").orEmpty()
            return when (stored) {
                "Subtle", "Balanced" -> AtmosphereIntensity.Performance
                else -> runCatching { AtmosphereIntensity.valueOf(stored) }.getOrDefault(AtmosphereIntensity.Immersive)
            }
        }
        set(value) = prefs.edit().putString("atmosphereIntensity", value.name).apply()
    var seasonalAtmosphere: Boolean
        get() = prefs.getBoolean("seasonalAtmosphere", true)
        set(value) = prefs.edit().putBoolean("seasonalAtmosphere", value).apply()
    var temperatureAtmosphere: Boolean
        get() = prefs.getBoolean("temperatureAtmosphere", true)
        set(value) = prefs.edit().putBoolean("temperatureAtmosphere", value).apply()
    var solarAtmosphere: Boolean
        get() = prefs.getBoolean("solarAtmosphere", true)
        set(value) = prefs.edit().putBoolean("solarAtmosphere", value).apply()
    var ambientAtmosphere: Boolean
        get() = prefs.getBoolean("ambientAtmosphere", true)
        set(value) = prefs.edit().putBoolean("ambientAtmosphere", value).apply()
    var cloudsEnabled: Boolean
        get() = prefs.getBoolean("cloudsEnabled", false)
        set(value) = prefs.edit().putBoolean("cloudsEnabled", value).apply()
    var precipitationEnabled: Boolean
        get() = prefs.getBoolean("precipitationEnabled", true)
        set(value) = prefs.edit().putBoolean("precipitationEnabled", value).apply()
    var rainEffectEnabled: Boolean
        get() = prefs.getBoolean("rainEffectEnabled", false)
        set(value) = prefs.edit().putBoolean("rainEffectEnabled", value).apply()
    var snowEffectEnabled: Boolean
        get() = prefs.getBoolean("snowEffectEnabled", false)
        set(value) = prefs.edit().putBoolean("snowEffectEnabled", value).apply()
    var fogEffectEnabled: Boolean
        get() = prefs.getBoolean("fogEffectEnabled", false)
        set(value) = prefs.edit().putBoolean("fogEffectEnabled", value).apply()
    var hazeEnabled: Boolean
        get() = prefs.getBoolean("hazeEnabled", false)
        set(value) = prefs.edit().putBoolean("hazeEnabled", value).apply()
    var windMotionEnabled: Boolean
        get() = prefs.getBoolean("windMotionEnabled", false)
        set(value) = prefs.edit().putBoolean("windMotionEnabled", value).apply()
    var lightningEnabled: Boolean
        get() = prefs.getBoolean("lightningEnabled", false)
        set(value) = prefs.edit().putBoolean("lightningEnabled", value).apply()
    var sunRaysEnabled: Boolean
        get() = prefs.getBoolean("sunRaysEnabled", true)
        set(value) = prefs.edit().putBoolean("sunRaysEnabled", value).apply()
    var livingCloudsEnabled: Boolean
        get() = prefs.getBoolean("livingCloudsEnabled", true)
        set(value) = prefs.edit().putBoolean("livingCloudsEnabled", value).apply()
    var atmosphericSoundscapeEnabled: Boolean
        get() = prefs.getBoolean("atmosphericSoundscapeEnabled", false)
        set(value) = prefs.edit().putBoolean("atmosphericSoundscapeEnabled", value).apply()
    var widgetTextMode: WidgetTextMode
        get() = runCatching { WidgetTextMode.valueOf(prefs.getString("widgetTextMode", "Automatic")!!) }.getOrDefault(WidgetTextMode.Automatic)
        set(value) = prefs.edit().putString("widgetTextMode", value.name).apply()
    var widgetGradientTypography: Boolean
        get() = prefs.getBoolean("widgetGradientTypography", false)
        set(value) = prefs.edit().putBoolean("widgetGradientTypography", value).apply()
    var gradientHeroTypography: Boolean
        get() = prefs.getBoolean("gradientHeroTypography", true)
        set(value) = prefs.edit().putBoolean("gradientHeroTypography", value).apply()

    var backgroundUpdates: Boolean
        get() = prefs.getBoolean("backgroundUpdates", true)
        set(value) = prefs.edit().putBoolean("backgroundUpdates", value).apply()
    var weatherNotificationEnabled: Boolean
        get() = prefs.getBoolean("weatherNotificationEnabled", false)
        set(value) = prefs.edit().putBoolean("weatherNotificationEnabled", value).apply()
    var statusBarIconStyle: StatusBarIconStyle
        get() {
            val stored = prefs.getString("statusBarIconStyle", null)
            if (stored != null) {
                return runCatching { StatusBarIconStyle.valueOf(stored) }.getOrDefault(StatusBarIconStyle.Temperature)
            }
            // Migrate the 0.60.6–0.60.9 switch without changing the user's choice.
            return if (prefs.getBoolean("statusBarTemperatureEnabled", false)) {
                StatusBarIconStyle.Temperature
            } else {
                StatusBarIconStyle.Condition
            }
        }
        set(value) = prefs.edit()
            .putString("statusBarIconStyle", value.name)
            .remove("statusBarTemperatureEnabled")
            .apply()
    var heatShimmer: Boolean
        get() = prefs.getBoolean("heatShimmer", false)
        set(value) = prefs.edit().putBoolean("heatShimmer", value).apply()
    var coldFrost: Boolean
        get() = prefs.getBoolean("coldFrost", false)
        set(value) = prefs.edit().putBoolean("coldFrost", value).apply()
    var weatherEffects60Fps: Boolean
        get() = prefs.getBoolean("weatherEffects60Fps", false)
        set(value) = prefs.edit().putBoolean("weatherEffects60Fps", value).apply()
    var homeLayout: HomeLayout
        get() = runCatching { HomeLayout.valueOf(prefs.getString("homeLayout", "Immersive")!!) }.getOrDefault(HomeLayout.Immersive)
        set(value) = prefs.edit().putString("homeLayout", value.name).apply()
    var locationTransition: LocationTransition
        get() = runCatching { LocationTransition.valueOf(prefs.getString("locationTransition", "Standard")!!) }.getOrDefault(LocationTransition.Standard)
        set(value) = prefs.edit().putString("locationTransition", value.name).apply()
    var density: DensityChoice
        get() = runCatching { DensityChoice.valueOf(prefs.getString("density", "Expanded")!!) }.getOrDefault(DensityChoice.Expanded)
        set(value) = prefs.edit().putString("density", value.name).apply()
    var temperatureUnit: TemperatureUnit
        get() = runCatching { TemperatureUnit.valueOf(prefs.getString("temperatureUnit", "Celsius")!!) }.getOrDefault(TemperatureUnit.Celsius)
        set(value) = prefs.edit().putString("temperatureUnit", value.name).apply()
    var atmosIntensityChoice: AtmosIntensityChoice
        get() = runCatching { AtmosIntensityChoice.valueOf(prefs.getString("atmosIntensityChoice", "Balanced")!!) }.getOrDefault(AtmosIntensityChoice.Balanced)
        set(value) = prefs.edit().putString("atmosIntensityChoice", value.name).apply()
    var atmosTransitionChoice: AtmosTransitionChoice
        get() = runCatching { AtmosTransitionChoice.valueOf(prefs.getString("atmosTransitionChoice", "Smooth")!!) }.getOrDefault(AtmosTransitionChoice.Smooth)
        set(value) = prefs.edit().putString("atmosTransitionChoice", value.name).apply()
    var accentColorChoice: AccentColorChoice
        get() = runCatching { AccentColorChoice.valueOf(prefs.getString("accentColorChoice", "Atmos")!!) }.getOrDefault(AccentColorChoice.Atmos)
        set(value) = prefs.edit().putString("accentColorChoice", value.name).apply()
    var windUnit: WindUnit
        get() = runCatching { WindUnit.valueOf(prefs.getString("windUnit", "Kmh")!!) }.getOrDefault(WindUnit.Kmh)
        set(value) = prefs.edit().putString("windUnit", value.name).apply()
    var pressureUnit: PressureUnit
        get() = runCatching { PressureUnit.valueOf(prefs.getString("pressureUnit", "Hpa")!!) }.getOrDefault(PressureUnit.Hpa)
        set(value) = prefs.edit().putString("pressureUnit", value.name).apply()
    var rainUnit: RainUnit
        get() = runCatching { RainUnit.valueOf(prefs.getString("rainUnit", "Millimetres")!!) }.getOrDefault(RainUnit.Millimetres)
        set(value) = prefs.edit().putString("rainUnit", value.name).apply()
    var visibilityUnit: VisibilityUnit
        get() = runCatching { VisibilityUnit.valueOf(prefs.getString("visibilityUnit", "Kilometres")!!) }.getOrDefault(VisibilityUnit.Kilometres)
        set(value) = prefs.edit().putString("visibilityUnit", value.name).apply()
    var menuLeft: Boolean
        get() = prefs.getBoolean("menuLeft", false)
        set(value) = prefs.edit().putBoolean("menuLeft", value).apply()
    var ambientDisplayEnabled: Boolean
        get() = prefs.getBoolean("ambientDisplayEnabled", false)
        set(value) = prefs.edit().putBoolean("ambientDisplayEnabled", value).apply()
    var ambientDisplayDurationMinutes: Int
        get() = prefs.getInt("ambientDisplayDurationMinutes", 30).coerceIn(15, 120)
        set(value) = prefs.edit().putInt("ambientDisplayDurationMinutes", value.coerceIn(15, 120)).apply()
    var hiddenCards: Set<String>
        get() = prefs.getStringSet("hiddenCards", emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet("hiddenCards", value).apply()
    var cardOrder: List<String>
        get() = prefs.getString("cardOrder", null)?.split(",")?.filter { it.isNotBlank() } ?: detailCardIds
        set(value) = prefs.edit().putString("cardOrder", value.joinToString(",")).apply()
    fun cachedWeather(places: List<Place>): Map<String, WeatherState> {
        val root = runCatching { JSONObject(prefs.getString("weatherCache", "{}")) }.getOrDefault(JSONObject())
        return places.mapNotNull { place ->
            root.optJSONObject(place.cacheKey())?.let(::weatherStateFromJson)?.copy(place = place)?.let { place.cacheKey() to it }
        }.toMap()
    }
    fun saveWeatherCache(cache: Map<String, WeatherState>) {
        val root = JSONObject()
        cache.forEach { (key, state) -> root.put(key, state.toJson()) }
        // Keep the live wallpaper on the same refresh lifecycle as the app. A separate
        // monotonic key avoids devices/launchers missing a large weatherCache string change.
        prefs.edit()
            .putString("weatherCache", root.toString())
            .putLong("wallpaperWeatherVersion", System.currentTimeMillis())
            .apply()
        AtmosWallpaperSnapshotCache.invalidate(appContext)
    }

    fun observationHistory(place: Place): List<HistoricalObservation> {
        val root = runCatching { JSONObject(prefs.getString("observationHistory", "{}")) }.getOrDefault(JSONObject())
        val array = root.optJSONArray(place.cacheKey()) ?: JSONArray()
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        return (0 until array.length()).mapNotNull { index ->
            array.optJSONObject(index)?.let { item ->
                val time = item.optLong("time", 0L)
                val temp = item.optIntOrNull("temp")
                if (time >= today && temp != null) HistoricalObservation(Date(time), temp, item.numberOrNull("rainSince9")) else null
            }
        }.sortedBy { it.time.time }
    }

    fun recordObservation(state: WeatherState) {
        val temp = state.observation.temp ?: return
        val root = runCatching { JSONObject(prefs.getString("observationHistory", "{}")) }.getOrDefault(JSONObject())
        val key = state.place.cacheKey()
        val existing = observationHistory(state.place).toMutableList()
        val now = state.updated
        val hourStart = Calendar.getInstance().apply {
            time = now; set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.time
        existing.removeAll { kotlin.math.abs(it.time.time - hourStart.time) < 30L * 60L * 1000L }
        existing += HistoricalObservation(hourStart, temp, state.observation.rainSince9)
        val array = JSONArray()
        existing.sortedBy { it.time.time }.takeLast(25).forEach { point ->
            array.put(JSONObject().apply {
                put("time", point.time.time); put("temp", point.temp)
                point.rainSince9?.let { put("rainSince9", it) }
            })
        }
        root.put(key, array)
        prefs.edit().putString("observationHistory", root.toString()).apply()
    }

    var savedPlaces: List<Place>
        get() {
            if (!prefs.contains("savedPlaces")) return defaultSavedPlaces
            val json = runCatching { JSONArray(prefs.getString("savedPlaces", "[]")) }.getOrDefault(JSONArray())
            val parsed = (0 until json.length()).mapNotNull { i ->
                json.optJSONObject(i)?.let {
                    Place(
                        it.optString("id"),
                        it.optString("name"),
                        it.optString("state"),
                        it.optDouble("lat"),
                        it.optDouble("lon"),
                        it.optBoolean("current"),
                        it.optString("country", "Australia"),
                        it.optString("countryCode", "AU"),
                        it.optString("timeZoneId", "")
                    )
                }
            }
            return normaliseSavedPlaces(parsed)
        }
        set(value) {
            val normalised = normaliseSavedPlaces(value)
            val json = JSONArray()
            normalised.forEach {
                json.put(
                    JSONObject()
                        .put("id", it.id)
                        .put("name", it.name)
                        .put("state", it.state)
                        .put("lat", it.latitude)
                        .put("lon", it.longitude)
                        .put("current", it.current)
                        .put("country", it.country)
                        .put("countryCode", it.countryCode)
                        .put("timeZoneId", it.timeZoneId)
                )
            }
            prefs.edit().putString("savedPlaces", json.toString()).apply()
        }

}

private fun atmosColorScheme(accent: Color, secondaryAccent: Color, darkFraction: Float): ColorScheme {
    val fraction = darkFraction.coerceIn(0f, 1f)
    val light = lightColorScheme(
        primary = accent,
        secondary = secondaryAccent,
        background = Color(0xFFF7F8FD),
        surface = Color(0xFFFEFBFF),
        onBackground = Color(0xFF18223A),
        onSurface = Color(0xFF18223A)
    )
    val dark = darkColorScheme(
        primary = accent,
        secondary = secondaryAccent,
        background = Color(0xFF101827),
        surface = Color(0xFF192234),
        onBackground = Color(0xFFF5F7FF),
        onSurface = Color(0xFFF5F7FF)
    )
    return light.copy(
        primary = lerp(light.primary, dark.primary, fraction),
        onPrimary = lerp(light.onPrimary, dark.onPrimary, fraction),
        primaryContainer = lerp(light.primaryContainer, dark.primaryContainer, fraction),
        onPrimaryContainer = lerp(light.onPrimaryContainer, dark.onPrimaryContainer, fraction),
        secondary = lerp(light.secondary, dark.secondary, fraction),
        onSecondary = lerp(light.onSecondary, dark.onSecondary, fraction),
        secondaryContainer = lerp(light.secondaryContainer, dark.secondaryContainer, fraction),
        onSecondaryContainer = lerp(light.onSecondaryContainer, dark.onSecondaryContainer, fraction),
        tertiary = lerp(light.tertiary, dark.tertiary, fraction),
        onTertiary = lerp(light.onTertiary, dark.onTertiary, fraction),
        background = lerp(light.background, dark.background, fraction),
        onBackground = lerp(light.onBackground, dark.onBackground, fraction),
        surface = lerp(light.surface, dark.surface, fraction),
        onSurface = lerp(light.onSurface, dark.onSurface, fraction),
        surfaceVariant = lerp(light.surfaceVariant, dark.surfaceVariant, fraction),
        onSurfaceVariant = lerp(light.onSurfaceVariant, dark.onSurfaceVariant, fraction),
        outline = lerp(light.outline, dark.outline, fraction),
        outlineVariant = lerp(light.outlineVariant, dark.outlineVariant, fraction),
        inverseSurface = lerp(light.inverseSurface, dark.inverseSurface, fraction),
        inverseOnSurface = lerp(light.inverseOnSurface, dark.inverseOnSurface, fraction),
        surfaceTint = lerp(light.surfaceTint, dark.surfaceTint, fraction)
    )
}

@Composable
private fun AtmosNativeApp() {
    val context = LocalContext.current
    val preferences = remember { AtmosPreferences(context) }
    var launchVisible by remember { mutableStateOf(true) }
    var firstRunRevealActive by remember { mutableStateOf(false) }
    var onboarded by remember { mutableStateOf(preferences.onboarded) }
    var theme by remember { mutableStateOf(preferences.theme) }
    var weatherAppearance by remember { mutableStateOf(preferences.weatherAppearance) }
    var darkNightMode by remember { mutableStateOf(preferences.darkNightMode) }
    var conditionAnimations by remember { mutableStateOf(preferences.conditionAnimations) }
    var homeLayout by remember { mutableStateOf(HomeLayout.Immersive) }
    var locationTransition by remember { mutableStateOf(preferences.locationTransition) }
    // 0.30.8 retires the old rounded-card home. Existing installations are
    // migrated to Fullscreen Hero while preserving an Immersive selection.
    LaunchedEffect(Unit) {
        // Weather surfaces now always follow the single app appearance choice.
        if (preferences.weatherAppearance != WeatherAppearance.FollowApp) {
            preferences.weatherAppearance = WeatherAppearance.FollowApp
            weatherAppearance = WeatherAppearance.FollowApp
        }
        // 0.40.3 temporarily retires location-following weather appearance because
        // continuous day/night interpolation during paging can cause frame drops.
        if (preferences.weatherAppearance == WeatherAppearance.FollowLocation) {
            preferences.weatherAppearance = WeatherAppearance.FollowApp
            weatherAppearance = WeatherAppearance.FollowApp
        }
        // 0.30.14 separates stable app appearance from location-aware weather appearance.
        // Migrate the former Automatic (Location) root theme without changing the user's intent.
        if (preferences.theme == ThemeChoice.AutomaticLocation) {
            preferences.theme = ThemeChoice.System
            theme = ThemeChoice.System
            preferences.weatherAppearance = WeatherAppearance.FollowApp
            weatherAppearance = WeatherAppearance.FollowApp
        }
        if (preferences.homeLayout == HomeLayout.Card) {
            preferences.homeLayout = HomeLayout.Immersive
            preferences.locationTransition = LocationTransition.Standard
            locationTransition = LocationTransition.Standard
        }
    }
    var atmosphereIntensity by remember { mutableStateOf(preferences.atmosphereIntensity) }
    var immersiveHeroVisible by remember { mutableStateOf(homeLayout == HomeLayout.Immersive) }
    var showLayoutOnboarding by remember { mutableStateOf(false) }
    var awaitingManualLayoutChoice by remember { mutableStateOf(false) }
    var density by remember { mutableStateOf(preferences.density) }
    var menuLeft by remember { mutableStateOf(preferences.menuLeft) }
    var temperatureUnit by remember { mutableStateOf(preferences.temperatureUnit) }
    var atmosIntensityChoice by remember { mutableStateOf(preferences.atmosIntensityChoice) }
    var atmosTransitionChoice by remember { mutableStateOf(preferences.atmosTransitionChoice) }
    var accentColorChoice by remember { mutableStateOf(preferences.accentColorChoice) }
    var atmosphericSoundscapeEnabled by remember { mutableStateOf(preferences.atmosphericSoundscapeEnabled) }
    var ambientDisplayEnabled by remember { mutableStateOf(preferences.ambientDisplayEnabled) }
    var ambientDisplayDurationMinutes by remember { mutableStateOf(preferences.ambientDisplayDurationMinutes) }
    var ambientDisplayExpired by rememberSaveable { mutableStateOf(false) }
    var ambientDisplayRequested by rememberSaveable { mutableStateOf(false) }
    var ambientDisplayManuallyDisabled by rememberSaveable { mutableStateOf(false) }
    var ambientControlsVisible by remember { mutableStateOf(true) }
    var savedPlaces by remember { mutableStateOf(preferences.savedPlaces) }
    var currentPlace by remember { mutableStateOf(savedPlaces.firstOrNull() ?: onboardingPlaceholder) }
    val diskCache = remember(savedPlaces) { preferences.cachedWeather(savedPlaces) }
    var weather by remember { mutableStateOf(diskCache[currentPlace.cacheKey()] ?: WeatherState(currentPlace, fallbackDays, emptyList(), Observation(), false)) }
    val weatherCache = remember { mutableStateMapOf<String, WeatherState>().apply { putAll(diskCache) } }
    var refreshing by remember { mutableStateOf(false) }
    var loadingMessage by remember { mutableStateOf("Preparing your forecast…") }
    var page by rememberSaveable { mutableStateOf(Page.Home) }
    var selectedSeasonName by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedSeasonPlace by remember { mutableStateOf<Place?>(null) }
    val scope = rememberCoroutineScope()
    val appLifecycleOwner = LocalLifecycleOwner.current
    val systemDark = isSystemInDarkTheme()
    // App appearance is intentionally independent of forecast locations. The root
    // Material scheme changes only when the user changes this setting or Android's
    // device theme changes; location swipes are handled inside weather surfaces.
    val deviceLocationPlace = remember(savedPlaces) { savedPlaces.firstOrNull { it.current } }
    val deviceLocationNight = rememberLocationNight(deviceLocationPlace ?: onboardingPlaceholder)
    val themeDarkFraction = if (darkNightMode && deviceLocationPlace != null && deviceLocationNight) {
        1f
    } else when (theme) {
        ThemeChoice.Dark -> 1f
        ThemeChoice.Light -> 0f
        ThemeChoice.System, ThemeChoice.AutomaticLocation -> if (systemDark) 1f else 0f
    }.coerceIn(0f, 1f)
    val appNight = themeDarkFraction >= .5f
    val palette = remember(appNight) {
        if (appNight) Palette(Color(0xFF17213A), Color(0xFF241D36), Color(0xFF9AB7FF), Color(0xFFB58BEA))
        else Palette(Color(0xFFF4F7FF), Color(0xFFE9EEF9), Color(0xFF526FC8), Color(0xFF7B64B3))
    }
    val dark = themeDarkFraction >= .5f
    val ambientDisplayEligible = (ambientDisplayRequested || (ambientDisplayEnabled && !ambientDisplayManuallyDisabled)) && page == Page.Home && onboarded && !launchVisible
    val ambientDisplayActive = ambientDisplayEligible && !ambientDisplayExpired
    val ambientActivity = LocalContext.current as? Activity

    LaunchedEffect(ambientDisplayEligible, ambientDisplayDurationMinutes) {
        ambientDisplayExpired = false
        if (ambientDisplayEligible) {
            delay(ambientDisplayDurationMinutes * 60_000L)
            ambientDisplayExpired = true
            ambientDisplayRequested = false
        }
    }

    DisposableEffect(ambientActivity, ambientDisplayActive) {
        val window = ambientActivity?.window
        val controller = window?.let { WindowInsetsControllerCompat(it, it.decorView) }
        if (ambientDisplayActive && window != null && controller != null) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    val activity = context as? Activity
    val currentDayForSystemBars = weather.days.firstOrNull()
    val currentWeatherPalette = rememberSolarAwarePalette(
        currentDayForSystemBars?.icon ?: "clear",
        weather.place,
        weather.observation,
        currentDayForSystemBars?.condition ?: "Clear"
    )
    // Match the status-bar icon mode to the same single foreground decision used by
    // the current-condition text. Card style follows the app theme; Immersive follows
    // the active location's solar-aware hero palette.
    val currentConditionForeground = if (homeLayout == HomeLayout.Immersive) {
        solarLegibleForeground(currentWeatherPalette, if (appNight) Color(0xFF101827) else Color(0xFFF7F8FD))
    } else {
        if (appNight) Color.White else Color(0xFF1A1F2A)
    }
    val useDarkStatusBarIcons = colourBrightness(currentConditionForeground) < .5f
    SideEffect {
        activity?.window?.let { window ->
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = if (page == Page.Home) useDarkStatusBarIcons else !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }

    // Keep the transparent 4×4 widget on the same light/dark foreground mode as
    // the first saved location's immersive Hero. This also refreshes immediately when
    // the app theme changes, rather than waiting for the next weather update.
    LaunchedEffect(appNight, atmosIntensityChoice, preferences.widgetTextMode, preferences.widgetGradientTypography, savedPlaces, weatherCache) {
        val firstPlace = savedPlaces.firstOrNull()
        val firstWeather = firstPlace?.let { weatherCache[it.cacheKey()] }
        if (firstWeather != null) {
            updateWidgetTextMode(context, firstWeather, preferences, appNight)
        }
    }

    LaunchedEffect(Unit) {
        scheduleBackgroundUpdates(context, preferences.backgroundUpdates)
        publishCachedWeatherNotification(context, preferences)
    }

    suspend fun refreshAllLocations(force: Boolean = false, relocateCurrent: Boolean = true) {
        if (refreshing || savedPlaces.isEmpty()) return
        val cachedStates = savedPlaces.mapNotNull { weatherCache[it.cacheKey()] }
        val allFresh = cachedStates.size == savedPlaces.size && cachedStates.all {
            System.currentTimeMillis() - it.updated.time < WEATHER_REFRESH_INTERVAL_MS
        }
        if (!force && allFresh) return

        refreshing = true
        try {
            val placesBeforeRefresh = savedPlaces
            val oldLive = placesBeforeRefresh.firstOrNull { it.current }
            val locationsToRefresh = if (relocateCurrent && oldLive != null && hasForegroundLocationPermission(context)) {
                val coordinates = requestCurrentLocation(context)
                if (coordinates != null) {
                    val live = resolveDevicePlace(
                        context = context,
                        latitude = coordinates.first,
                        longitude = coordinates.second,
                        previous = oldLive
                    )
                    normaliseSavedPlaces(listOf(live) + placesBeforeRefresh.filterNot { it.current })
                } else placesBeforeRefresh
            } else placesBeforeRefresh

            val refreshed = coroutineScope {
                locationsToRefresh.map { place ->
                    async { runCatching { WeatherRepository.load(place) }.getOrNull() }
                }.mapNotNull { it.await() }
            }
            if (refreshed.isEmpty()) return

            if (oldLive != null) weatherCache.remove(oldLive.cacheKey())
            refreshed.forEach { loaded ->
                weatherCache[loaded.place.cacheKey()] = loaded
                preferences.recordObservation(loaded)
            }
            savedPlaces = locationsToRefresh
            preferences.savedPlaces = locationsToRefresh
            preferences.saveWeatherCache(weatherCache)

            // Refresh completion must never own pager selection. Resolve the place
            // the user is looking at at commit time, including a relocated live card.
            val selectionAtCommit = currentPlace
            val selectedWeather = if (selectionAtCommit.current) {
                refreshed.firstOrNull { it.place.current }
            } else {
                refreshed.firstOrNull { sameSavedPlace(it.place, selectionAtCommit) }
            }
            // Do not write currentPlace here. HorizontalPager is the sole owner of
            // location selection, so a network completion cannot interrupt a swipe.
            selectedWeather?.let { weather = it }

            refreshed.firstOrNull { loaded ->
                locationsToRefresh.firstOrNull()?.let { sameSavedPlace(it, loaded.place) } == true
            }?.let { firstWeather ->
                updateWidgets(context, firstWeather)
                publishWeatherNotification(context, firstWeather, preferences.temperatureUnit)
            }
        } finally {
            refreshing = false
        }
    }

    suspend fun loadSinglePlace(place: Place, selectAfterLoad: Boolean = true) {
        val loaded = WeatherRepository.load(place)
        weatherCache[place.cacheKey()] = loaded
        preferences.saveWeatherCache(weatherCache)
        preferences.recordObservation(loaded)
        if (selectAfterLoad) {
            currentPlace = place
            weather = loaded
        }
        if (preferences.savedPlaces.firstOrNull()?.let { sameSavedPlace(it, loaded.place) } == true) {
            updateWidgets(context, loaded)
            publishWeatherNotification(context, loaded, preferences.temperatureUnit)
        }
    }

    fun importNewerBackgroundCache() {
        val latestPlaces = preferences.savedPlaces
        if (latestPlaces.isEmpty()) return

        val latestCache = preferences.cachedWeather(latestPlaces)
        var cacheChanged = false
        latestCache.forEach { (key, cachedState) ->
            val inMemory = weatherCache[key]
            if (inMemory == null || cachedState.updated.after(inMemory.updated)) {
                weatherCache[key] = cachedState
                cacheChanged = true
            }
        }

        // A background location update can change the cache key for the live card.
        // Adopt the saved place list while retaining the user's currently selected card.
        val selectedBeforeImport = currentPlace
        val resolvedSelection = if (selectedBeforeImport.current) {
            latestPlaces.firstOrNull { it.current }
        } else {
            latestPlaces.firstOrNull { sameSavedPlace(it, selectedBeforeImport) }
        } ?: selectedBeforeImport

        if (latestPlaces != savedPlaces) savedPlaces = latestPlaces
        if (resolvedSelection != currentPlace) currentPlace = resolvedSelection

        val importedSelection = weatherCache[resolvedSelection.cacheKey()]
        if (importedSelection != null &&
            (cacheChanged || importedSelection.updated.after(weather.updated))) {
            weather = importedSelection
        }
    }

    DisposableEffect(appLifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                // WorkManager writes refreshed forecasts to the shared disk cache.
                // Import those results without starting another network request.
                importNewerBackgroundCache()
            }
        }
        appLifecycleOwner.lifecycle.addObserver(observer)
        onDispose { appLifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(ambientDisplayActive) {
        if (!ambientDisplayActive) return@LaunchedEffect
        while (true) {
            delay(WEATHER_REFRESH_INTERVAL_MS)
            refreshAllLocations(force = true, relocateCurrent = true)
        }
    }

    val onboardingLocation = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) {
            onboarded = true
            preferences.onboarded = true
            showLayoutOnboarding = false
            firstRunRevealActive = true
            launchVisible = true
            loadingMessage = "Finding your location…"
            scope.launch {
                val coordinates = requestCurrentLocation(context) ?: currentLocation(context)
                if (coordinates == null) {
                    launchVisible = false
                    awaitingManualLayoutChoice = true
                    page = Page.Locations
                    return@launch
                }
                val located = resolveDevicePlace(
                    context = context,
                    latitude = coordinates.first,
                    longitude = coordinates.second,
                    previous = savedPlaces.firstOrNull { it.current }
                )
                val orderedPlaces = normaliseSavedPlaces(listOf(located) + savedPlaces.filterNot { place -> place.current })
                loadingMessage = "Receiving your first forecast…"
                val loaded = runCatching { WeatherRepository.load(located) }.getOrNull()
                if (loaded == null) {
                    loadingMessage = "Unable to load that forecast"
                    delay(1_200L)
                    launchVisible = false
                    awaitingManualLayoutChoice = true
                    page = Page.Locations
                    return@launch
                }
                savedPlaces = orderedPlaces
                preferences.savedPlaces = orderedPlaces
                weatherCache[located.cacheKey()] = loaded
                preferences.saveWeatherCache(weatherCache)
                preferences.recordObservation(loaded)
                currentPlace = located
                weather = loaded
                loadingMessage = "Forecast ready"
                delay(350L)
                showLayoutOnboarding = true
                launchVisible = false
            }
        } else {
            onboarded = true
            preferences.onboarded = true
            awaitingManualLayoutChoice = true
            page = Page.Locations
        }
    }

    LaunchedEffect(Unit) {
        // This effect only runs for a new app process. Returning to an existing
        // task no longer triggers a foreground weather download; WorkManager is
        // the normal source of updates while Atmos is not visible.
        val minimumSplash = async { delay(700) }
        loadingMessage = "Loading saved locations…"
        weather = weatherCache[currentPlace.cacheKey()] ?: weather

        if (onboarded && savedPlaces.isNotEmpty()) {
            loadingMessage = "Checking your forecasts…"
            withTimeoutOrNull(8_000L) {
                refreshAllLocations(force = false, relocateCurrent = true)
            }
        }

        weather = weatherCache[currentPlace.cacheKey()] ?: weather
        weatherCache.values.forEach(preferences::recordObservation)
        if (weatherCache.isNotEmpty()) updateWidgets(context, weather)
        loadingMessage = "Forecast ready"
        minimumSplash.await()
        launchVisible = false
    }

    // Keep the application-wide Material theme stable while a location pager is moving.
    // Home applies its own lightweight interpolated scheme locally; the root only
    // animates when the settled location or explicit appearance setting changes.
    val atmosScheme = atmosColorScheme(palette.accent, palette.secondary, themeDarkFraction)
    // Use the phone's Material You palette for native Android chrome while the
    // weather canvas keeps Atmos's location-aware colour system.
    val scheme = remember(context, dark, atmosScheme, accentColorChoice) {
        val base = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        } else atmosScheme
        val accent = when (accentColorChoice) {
            AccentColorChoice.Atmos -> palette.accent
            AccentColorChoice.Wallpaper -> null
            AccentColorChoice.Blue -> Color(0xFF5B7CFA)
            AccentColorChoice.Green -> Color(0xFF2E8B68)
            AccentColorChoice.Orange -> Color(0xFFE77C32)
            AccentColorChoice.Purple -> Color(0xFF8667D7)
            AccentColorChoice.Red -> Color(0xFFD85C62)
            AccentColorChoice.Monochrome -> if (dark) Color(0xFFE5E5E5) else Color(0xFF333333)
        }
        if (accent == null) base else base.copy(
            primary = accent,
            secondary = accent,
            tertiary = accent,
            primaryContainer = lerp(accent, base.surface, if (dark) .68f else .82f),
            secondaryContainer = lerp(accent, base.surface, if (dark) .72f else .86f),
            surfaceTint = accent
        )
    }

    AtmosphericSoundscapeEffect(
        enabled = atmosphericSoundscapeEnabled,
        weather = weather,
        appVisible = !launchVisible
    )

    MaterialTheme(colorScheme = scheme) {
        // Persist the exact lower colour already used by the untouched 0.65.0
        // immersive overlay. The wallpaper snapshot uses this value without
        // changing the in-app renderer or its composition order.
        val wallpaperImmersiveBottom = MaterialTheme.colorScheme.background.toArgb()
        SideEffect {
            context.getSharedPreferences("atmos_native", Context.MODE_PRIVATE)
                .edit()
                .putInt("wallpaperImmersiveBottomArgb", wallpaperImmersiveBottom)
                .apply()
        }
        CompositionLocalProvider(
            LocalAtmosIntensityChoice provides atmosIntensityChoice,
            LocalAtmosTransitionChoice provides atmosTransitionChoice
        ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AnimatedContent(
                targetState = launchVisible,
                transitionSpec = {
                    if (firstRunRevealActive) {
                        fadeIn(tween(1_650)) togetherWith fadeOut(tween(1_450))
                    } else {
                        fadeIn(tween(650)) togetherWith fadeOut(tween(650))
                    }
                },
                label = "launch"
            ) { launching ->
                when {
                    launching -> FullScreenAtmosArtwork {
                        Box(Modifier.fillMaxSize()) {
                            Column(
                                Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = persistentStatusBarTopInset() + 56.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("ATMOS", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                                Text("THE WEATHER, ALIVE", Modifier.padding(top = 5.dp), color = Color.White.copy(.68f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.2.sp)
                            }
                            Column(
                                modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 34.dp, vertical = 68.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    loadingMessage,
                                    color = Color.White.copy(.9f),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center
                                )
                                if (firstRunRevealActive) {
                                    Text(
                                        "Setting the light, season and temperature for your location.",
                                        modifier = Modifier.padding(top = 7.dp),
                                        color = Color.White.copy(.62f),
                                        fontSize = 10.sp,
                                        lineHeight = 14.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    LinearProgressIndicator(
                                        modifier = Modifier.fillMaxWidth(.48f).padding(top = 16.dp).height(2.dp),
                                        color = Color.White.copy(.88f),
                                        trackColor = Color.White.copy(.18f)
                                    )
                                }
                            }
                        }
                    }
                    showLayoutOnboarding -> LayoutOnboarding(
                        selectedTransition = locationTransition,
                        selectedDensity = density,
                        selectedTheme = theme,
                        darkNightMode = darkNightMode,
                        onSelect = { transition ->
                            homeLayout = HomeLayout.Immersive
                            locationTransition = transition
                        },
                        onDensity = { selected -> density = selected; preferences.density = selected },
                        onTheme = { theme = it; preferences.theme = it },
                        onDarkNightMode = { darkNightMode = it; preferences.darkNightMode = it },
                        onContinue = {
                            preferences.homeLayout = HomeLayout.Immersive
                            preferences.locationTransition = locationTransition
                            preferences.atmosphereIntensity = AtmosphereIntensity.Immersive
                            preferences.conditionAnimations = true
                            preferences.cloudsEnabled = false
                            preferences.hazeEnabled = false
                            atmosphereIntensity = AtmosphereIntensity.Immersive
                            conditionAnimations = true
                            showLayoutOnboarding = false
                            firstRunRevealActive = true
                            launchVisible = true
                            loadingMessage = "Bringing ${currentPlace.name} into view…"
                            scope.launch {
                                // Keep the artwork fully covering Home until a complete first
                                // forecast is ready. Commit the final WeatherState before fading.
                                val cached = weatherCache[currentPlace.cacheKey()]
                                val usableCached = cached?.takeIf {
                                    it.live || it.observation.temp != null || it.hours.isNotEmpty()
                                }
                                val completed = usableCached ?: run {
                                    loadingMessage = "Receiving your first forecast…"
                                    runCatching { WeatherRepository.load(currentPlace) }.getOrNull()
                                }
                                if (completed == null) {
                                    loadingMessage = "Unable to load that forecast"
                                    delay(1_200L)
                                    launchVisible = false
                                    awaitingManualLayoutChoice = true
                                    page = Page.Locations
                                    return@launch
                                }
                                weatherCache[currentPlace.cacheKey()] = completed
                                preferences.saveWeatherCache(weatherCache)
                                preferences.recordObservation(completed)
                                weather = completed
                                page = Page.Home
                                loadingMessage = "Your forecast is ready"
                                delay(700L)
                                launchVisible = false
                            }
                        }
                    )
                    !onboarded -> Onboarding(
                        onUseLocation = {
                            onboardingLocation.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                        },
                        onChoose = {
                            onboarded = true
                            preferences.onboarded = true
                            awaitingManualLayoutChoice = true
                            page = Page.Locations
                        }
                    )
                    else -> {
                        BackHandler(page != Page.Home) { page = Page.Home }
                        Box(Modifier.fillMaxSize()) {
                            AnimatedContent(
                                targetState = page,
                                transitionSpec = {
                                    val forward = targetState.ordinal >= initialState.ordinal
                                    val enterMs = when (atmosTransitionChoice) { AtmosTransitionChoice.Instant -> 1; AtmosTransitionChoice.Smooth -> 380; AtmosTransitionChoice.Slow -> 600 }
                                    val exitMs = when (atmosTransitionChoice) { AtmosTransitionChoice.Instant -> 1; AtmosTransitionChoice.Smooth -> 320; AtmosTransitionChoice.Slow -> 520 }
                                    (fadeIn(tween(enterMs)) + slideInHorizontally(tween(enterMs)) { if (forward) it / 7 else -it / 7 }) togetherWith
                                        (fadeOut(tween(exitMs)) + slideOutHorizontally(tween(exitMs)) { if (forward) -it / 10 else it / 10 })
                                },
                                label = "atmosPage"
                            ) { target ->
                                when (target) {
                                    Page.Home -> HomePage(
                                        currentWeather = weather,
                                        weatherCache = weatherCache,
                                        savedPlaces = savedPlaces,
                                        currentPlace = currentPlace,
                                        refreshing = refreshing,
                                        density = density,
                                        preferences = preferences,
                                        temperatureUnit = temperatureUnit,
                                        conditionAnimations = conditionAnimations,
                                        homeLayout = homeLayout,
                                        locationTransition = locationTransition,
                                        weatherAppearance = weatherAppearance,
                                        appTheme = theme,
                                        systemDark = systemDark,
                                        appDarkFraction = themeDarkFraction,
                                        onTemperatureUnit = { temperatureUnit = it; preferences.temperatureUnit = it },
                                        onRefresh = { scope.launch { refreshAllLocations(force = true, relocateCurrent = true) } },
                                        onSelectPlace = { place ->
                                            currentPlace = place
                                            weather = weatherCache[place.cacheKey()]
                                                ?: WeatherState(place, fallbackDays, emptyList(), Observation(), false)
                                        },
                                        onSavedPlacesChanged = { updated ->
                                            val normalised = normaliseSavedPlaces(updated, updated.firstOrNull())
                                            savedPlaces = normalised
                                            preferences.savedPlaces = normalised
                                        },
                                        onAddLocation = { page = Page.Locations },
                                        onImmersiveHeroVisible = { immersiveHeroVisible = it },
                                        ambientDisplayActive = ambientDisplayActive,
                                        onAmbientControlsVisible = { ambientControlsVisible = it },
                                        onSeason = { _, _ -> page = Page.Seasons },
                                        onPage = { page = it }
                                    )
                                    Page.Radar -> RadarPage(currentPlace) { page = Page.Home }
                                    Page.Seasons -> SeasonsPage(
                                        dark = dark,
                                        userPlace = deviceLocationPlace ?: currentPlace,
                                        onBack = { page = Page.Home }
                                    )
                                    Page.Settings -> SettingsPage(
                                        theme, darkNightMode, conditionAnimations, homeLayout, locationTransition, density, menuLeft, temperatureUnit, atmosIntensityChoice, atmosTransitionChoice, accentColorChoice, atmosphericSoundscapeEnabled, ambientDisplayEnabled, ambientDisplayDurationMinutes, preferences,
                                        onTheme = { theme = it; preferences.theme = it },
                                        onDarkNightMode = { darkNightMode = it; preferences.darkNightMode = it },
                                        onConditionAnimations = { conditionAnimations = it; preferences.conditionAnimations = it },
                                        onHomeLayout = { homeLayout = it; preferences.homeLayout = it },
                                        onLocationTransition = { locationTransition = it; preferences.locationTransition = it },
                                        onDensity = { density = it; preferences.density = it },
                                        onMenuLeft = { menuLeft = it; preferences.menuLeft = it },
                                        onTemperatureUnit = { temperatureUnit = it; preferences.temperatureUnit = it },
                                        onAtmosIntensityChoice = {
                                            atmosIntensityChoice = it
                                            preferences.atmosIntensityChoice = it
                                            context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE)
                                                .edit().putString("atmos_intensity", it.name).apply()
                                            AtmosHeroWidgetProvider.updateAll(context)
                                        },
                                        onAtmosTransitionChoice = { atmosTransitionChoice = it; preferences.atmosTransitionChoice = it },
                                        onAccentColorChoice = { accentColorChoice = it; preferences.accentColorChoice = it },
                                        onAtmosphericSoundscapeEnabled = { atmosphericSoundscapeEnabled = it; preferences.atmosphericSoundscapeEnabled = it },
                                        onAmbientDisplayEnabled = { ambientDisplayEnabled = it; preferences.ambientDisplayEnabled = it },
                                        onAmbientDisplayDuration = { ambientDisplayDurationMinutes = it; preferences.ambientDisplayDurationMinutes = it },
                                        onBack = { page = Page.Home }
                                    )
                                    Page.Locations -> LocationsPage(
                                        preferences, currentPlace, weatherCache, temperatureUnit,
                                        onLocationAdded = { added ->
                                            savedPlaces = preferences.savedPlaces
                                            scope.launch {
                                                val loaded = runCatching { WeatherRepository.load(added) }.getOrNull() ?: return@launch
                                                weatherCache[added.cacheKey()] = loaded
                                                preferences.saveWeatherCache(weatherCache)
                                                preferences.recordObservation(loaded)
                                            }
                                        },
                                        onSelect = { selected ->
                                            savedPlaces = preferences.savedPlaces
                                            if (awaitingManualLayoutChoice) {
                                                val ordered = normaliseSavedPlaces(listOf(selected) + savedPlaces.filterNot { sameSavedPlace(it, selected) }, selected)
                                                savedPlaces = ordered
                                                preferences.savedPlaces = ordered
                                            }
                                            scope.launch {
                                                if (awaitingManualLayoutChoice) {
                                                    // Never expose the first location with fallback weather.
                                                    // Load it behind the full-screen artwork, then commit atomically.
                                                    firstRunRevealActive = true
                                                    launchVisible = true
                                                    loadingMessage = "Loading ${selected.name}…"
                                                    val cached = weatherCache[selected.cacheKey()]?.takeIf {
                                                        it.live || it.observation.temp != null || it.hours.isNotEmpty()
                                                    }
                                                    val completed = cached ?: runCatching { WeatherRepository.load(selected) }.getOrNull()
                                                    if (completed == null) {
                                                        loadingMessage = "Unable to load that forecast"
                                                        delay(1_200L)
                                                        launchVisible = false
                                                        return@launch
                                                    }
                                                    weatherCache[selected.cacheKey()] = completed
                                                    preferences.saveWeatherCache(weatherCache)
                                                    preferences.recordObservation(completed)
                                                    currentPlace = selected
                                                    weather = completed
                                                    awaitingManualLayoutChoice = false
                                                    loadingMessage = "Forecast ready"
                                                    delay(350L)
                                                    showLayoutOnboarding = true
                                                    launchVisible = false
                                                } else {
                                                    currentPlace = selected
                                                    weather = weatherCache[selected.cacheKey()]
                                                        ?: WeatherState(selected, fallbackDays, emptyList(), Observation(), false)
                                                    if (weatherCache[selected.cacheKey()] == null) loadSinglePlace(selected)
                                                    page = Page.Home
                                                }
                                            }
                                        },
                                        onBack = { savedPlaces = preferences.savedPlaces; page = Page.Home }
                                    )
                                    Page.Help -> HelpPage { page = Page.Home }
                                    Page.About -> AboutPage { page = Page.Home }
                                }
                            }
                            NativeNavigationChrome(
                                page = page,
                                visible = !ambientDisplayActive || ambientControlsVisible,
                                atmospherePalette = conditionPalette(
                                    weather.days.firstOrNull()?.condition.orEmpty(),
                                    isNight(Date(), currentPlace.timeZone())
                                ),
                                atmosphereCondition = weather.days.firstOrNull()?.icon.orEmpty(),
                                atmosphereNight = isNight(Date(), currentPlace.timeZone()),
                                homeLayout = homeLayout,
                                onToggleHomeLayout = {
                                    homeLayout = if (homeLayout == HomeLayout.Dual) HomeLayout.Immersive else HomeLayout.Dual
                                    preferences.homeLayout = homeLayout
                                },
                                onPage = { destination ->
                                    if (destination != page) page = destination
                                },
                                onAtmosDisplay = {
                                    if (ambientDisplayActive) {
                                        ambientDisplayRequested = false
                                        ambientDisplayManuallyDisabled = true
                                        ambientDisplayExpired = true
                                        ambientControlsVisible = true
                                    } else {
                                        ambientDisplayManuallyDisabled = false
                                        ambientDisplayRequested = true
                                        ambientDisplayExpired = false
                                        ambientControlsVisible = false
                                        page = Page.Home
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
}

@Immutable
internal data class Palette(val top: Color, val bottom: Color, val accent: Color, val secondary: Color)

private fun conditionPalette(icon: String, night: Boolean): Palette {
    val s = icon.lowercase()
    return when {
        night -> Palette(Color(0xFF263C60), Color(0xFF433657), Color(0xFF9AB7FF), Color(0xFFB58BEA))
        "storm" in s || "thunder" in s -> Palette(Color(0xFF62548D), Color(0xFF343B62), Color(0xFFB69FE9), Color(0xFF7E8DD6))
        "rain" in s || "shower" in s -> Palette(Color(0xFF4E83A7), Color(0xFF46638D), Color(0xFF65C8DB), Color(0xFF71A9D6))
        "cloud" in s || "overcast" in s -> Palette(Color(0xFF899AB9), Color(0xFF687A9F), Color(0xFF8DB5D3), Color(0xFFA5B7D2))
        else -> Palette(Color(0xFFFFC65A), Color(0xFFEE7D62), Color(0xFFF3A74E), Color(0xFF75CDE2))
    }
}

private fun blendColor(from: Color, to: Color, amount: Float): Color {
    val t = amount.coerceIn(0f, 1f)
    return Color(
        red = from.red + (to.red - from.red) * t,
        green = from.green + (to.green - from.green) * t,
        blue = from.blue + (to.blue - from.blue) * t,
        alpha = from.alpha + (to.alpha - from.alpha) * t
    )
}

private fun blendPalette(from: Palette, to: Palette, amount: Float): Palette = Palette(
    top = blendColor(from.top, to.top, amount),
    bottom = blendColor(from.bottom, to.bottom, amount),
    accent = blendColor(from.accent, to.accent, amount),
    secondary = blendColor(from.secondary, to.secondary, amount)
)

private fun australianTimeZoneId(place: Place): String = when {
    place.state.contains("Western Australia", true) -> "Australia/Perth"
    place.state.contains("Northern Territory", true) -> "Australia/Darwin"
    place.state.contains("South Australia", true) -> "Australia/Adelaide"
    place.state.contains("Queensland", true) -> "Australia/Brisbane"
    place.state.contains("Tasmania", true) -> "Australia/Hobart"
    place.state.contains("Victoria", true) -> "Australia/Melbourne"
    place.state.contains("New South Wales", true) -> "Australia/Sydney"
    place.state.contains("Australian Capital Territory", true) -> "Australia/Sydney"
    place.longitude < 129.0 -> "Australia/Perth"
    place.longitude < 138.0 -> "Australia/Darwin"
    place.longitude < 141.0 -> "Australia/Adelaide"
    place.latitude > -29.0 && place.longitude > 141.0 -> "Australia/Brisbane"
    else -> "Australia/Sydney"
}

internal fun Place.timeZone(): TimeZone {
    val zoneId = timeZoneId.takeIf { it.isNotBlank() } ?: if (isAustralian()) australianTimeZoneId(this) else TimeZone.getDefault().id
    return TimeZone.getTimeZone(zoneId)
}

private fun localFormatter(pattern: String, place: Place): SimpleDateFormat =
    SimpleDateFormat(pattern, Locale.ENGLISH).apply { timeZone = place.timeZone() }

internal fun solarAwarePalette(icon: String, place: Place, now: Date): Palette {
    val dayPalette = conditionPalette(icon, false)
    val nightPalette = conditionPalette(icon, true)
    // A near-black OLED palette is reserved for genuinely late night. The first
    // hours after sunset retain colour so the sunset transition does not collapse
    // immediately into black.
    val oledNightPalette = Palette(
        top = Color(0xFF010204),
        bottom = Color(0xFF030407),
        accent = Color(0xFF33476B),
        secondary = Color(0xFF292336)
    )
    val sunrisePalette = Palette(
        top = Color(0xFF5D6FA8),
        bottom = Color(0xFFFF8B72),
        accent = Color(0xFFFFD37A),
        secondary = Color(0xFF9CCFE5)
    )
    val sunsetPalette = Palette(
        top = Color(0xFF765C9E),
        bottom = Color(0xFFF16F63),
        accent = Color(0xFFFFC066),
        secondary = Color(0xFF435582)
    )
    val solar = calculateSolarTimes(now, place.latitude, place.longitude, place.timeZone())
        ?: return conditionPalette(icon, isNight(now))
    val sunrise = solar.first.time
    val sunset = solar.second.time
    val current = now.time
    val dawnStart = sunrise - 75L * 60_000L
    val sunriseEnd = sunrise + 60L * 60_000L
    val sunsetStart = sunset - 75L * 60_000L
    val duskEnd = sunset + 45L * 60_000L
    val oledTransitionStart = sunset + 45L * 60_000L
    val oledTransitionEnd = sunset + 60L * 60_000L

    fun progress(start: Long, end: Long): Float =
        ((current - start).toDouble() / (end - start).toDouble()).toFloat().coerceIn(0f, 1f)

    return when {
        // Before dawn it has already been dark for several hours, so use the
        // OLED palette and blend directly into the sunrise treatment.
        current < dawnStart -> oledNightPalette
        current < sunrise -> blendPalette(oledNightPalette, sunrisePalette, progress(dawnStart, sunrise))
        current < sunriseEnd -> blendPalette(sunrisePalette, dayPalette, progress(sunrise, sunriseEnd))
        current < sunsetStart -> dayPalette
        current < sunset -> blendPalette(dayPalette, sunsetPalette, progress(sunsetStart, sunset))
        current < duskEnd -> blendPalette(sunsetPalette, nightPalette, progress(sunset, duskEnd))
        current < oledTransitionStart -> nightPalette
        current < oledTransitionEnd -> blendPalette(nightPalette, oledNightPalette, progress(oledTransitionStart, oledTransitionEnd))
        else -> oledNightPalette
    }
}

internal fun applyAtmosphericPaletteVariables(
    base: Palette,
    observation: Observation,
    condition: String,
    place: Place,
    now: Date
): Palette {
    // Lean Atmos palette: local solar light establishes the base. Only apparent
    // temperature and season grade that base; humidity, pressure, precipitation,
    // cloud cover and atmospheric-density fields are intentionally excluded.
    val feels = (observation.feels ?: observation.temp ?: 18).toFloat()
    val warmth = ((feels - 18f) / 17f).coerceIn(-1f, 1f)
    val night = isLocationNight(place, now)
    val nightAttenuation = if (night) .28f else 1f

    val thermalColour = if (warmth >= 0f) Color(0xFFFFA24C) else Color(0xFF75CFFF)
    val thermalStrength = kotlin.math.abs(warmth) * .30f * nightAttenuation

    val seasonTint = when (seasonName(place)) {
        "Spring" -> Color(0xFFFFA8C8)
        "Summer" -> Color(0xFFFFC365)
        "Autumn" -> Color(0xFFD77B4B)
        "Winter" -> Color(0xFF9EDCFF)
        "Wet" -> Color(0xFF5EC9B5)
        "Dry" -> Color(0xFFE3A65D)
        else -> Color.Transparent
    }
    val seasonalStrength = .15f * nightAttenuation

    return Palette(
        top = blendColor(base.top, thermalColour, thermalStrength * .42f),
        bottom = blendColor(blendColor(base.bottom, seasonTint, seasonalStrength), thermalColour, thermalStrength),
        accent = blendColor(base.accent, thermalColour, thermalStrength * .78f),
        secondary = blendColor(base.secondary, seasonTint, seasonalStrength * .72f)
    )
}

@Composable
private fun rememberLocationNight(place: Place): Boolean {
    val nowMillis = sharedMinuteMillis()
    return remember(place.cacheKey(), nowMillis) { isLocationNight(place, Date(nowMillis)) }
}

@Composable
private fun rememberLocationOled(place: Place): Boolean {
    val nowMillis = sharedMinuteMillis()
    return remember(place.cacheKey(), nowMillis) {
        val now = Date(nowMillis)
        val solarTimes = calculateSolarTimes(now, place.latitude, place.longitude, place.timeZone())
        solarTimes?.let { (sunrise, sunset) ->
            nowMillis < sunrise.time || nowMillis >= sunset.time + 60L * 60_000L
        } ?: isLocationNight(place, now)
    }
}

@Composable
private fun rememberSolarAwarePalette(
    icon: String,
    place: Place,
    observation: Observation = Observation(),
    condition: String = icon,
    now: Date? = null,
    fastTransition: Boolean = false
): Palette {
    val nowMillis = now?.time ?: sharedMinuteMillis()
    val intensity = LocalAtmosIntensityChoice.current
    val transition = LocalAtmosTransitionChoice.current
    val target = remember(icon, condition, observation, place.latitude, place.longitude, nowMillis, intensity) {
        val balanced = applyAtmosphericPaletteVariables(
            solarAwarePalette(icon, place, Date(nowMillis)), observation, condition, place, Date(nowMillis)
        )
        applyAtmosIntensityToPalette(balanced, intensity)
    }
    val duration = if (fastTransition) {
        // Timeline scrubbing needs to feel attached to the finger while retaining a
        // short blend that prevents solar and weather palettes from flashing.
        when (transition) {
            AtmosTransitionChoice.Instant -> 1
            AtmosTransitionChoice.Smooth -> 150
            AtmosTransitionChoice.Slow -> 230
        }
    } else {
        when (transition) {
            AtmosTransitionChoice.Instant -> 1
            AtmosTransitionChoice.Smooth -> 1400
            AtmosTransitionChoice.Slow -> 2200
        }
    }
    val top by animateColorAsState(target.top, tween(duration), label = "solarTop")
    val bottom by animateColorAsState(target.bottom, tween(duration), label = "solarBottom")
    val accent by animateColorAsState(target.accent, tween(duration), label = "solarAccent")
    val secondary by animateColorAsState(target.secondary, tween(duration), label = "solarSecondary")
    return Palette(top, bottom, accent, secondary)
}

@Composable
private fun FullScreenAtmosArtwork(content: (@Composable () -> Unit)? = null) {
    val context = LocalContext.current
    val bitmap = remember {
        runCatching { BitmapFactory.decodeStream(context.assets.open("public/assets/atmos-sunrise.png")).asImageBitmap() }.getOrNull()
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF182878))) {
        bitmap?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        content?.invoke()
    }
}

@Composable
private fun Onboarding(onUseLocation: () -> Unit, onChoose: () -> Unit) {
    FullScreenAtmosArtwork {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Color(0xE8151E52)), startY = 450f)))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 25.dp)
                .padding(
                    top = persistentStatusBarTopInset() + 30.dp,
                    bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 24.dp
                )
        ) {
            Text("WEATHER, WHERE YOU ARE", color = Color.White.copy(.82f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.4.sp)
            Text("Weather that moves with you.", Modifier.padding(top = 5.dp), color = Color.White, fontSize = 38.sp, lineHeight = 42.sp, fontWeight = FontWeight.Bold)
            Text("Choose Fullscreen Hero or the new Immersive experience, powered by one living atmosphere.", Modifier.padding(top = 6.dp), color = Color(0xFFEAF0FF), fontSize = 14.sp)
            Spacer(Modifier.weight(1f))
            Button(onUseLocation, Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF263F91))) { Text("Use my location", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onChoose, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text("Choose a location manually") }
            Text("Atmos only uses your location to find the nearest forecast.", Modifier.fillMaxWidth().padding(top = 10.dp), color = Color.White.copy(.7f), fontSize = 10.sp, textAlign = TextAlign.Center)
        }
    }
}


@Composable
private fun LayoutOnboarding(
    selectedTransition: LocationTransition,
    selectedDensity: DensityChoice,
    selectedTheme: ThemeChoice,
    darkNightMode: Boolean,
    onSelect: (LocationTransition) -> Unit,
    onDensity: (DensityChoice) -> Unit,
    onTheme: (ThemeChoice) -> Unit,
    onDarkNightMode: (Boolean) -> Unit,
    onContinue: () -> Unit
) {
    val deepGradient = Brush.verticalGradient(listOf(Color(0xFF07101F), Color(0xFF10162D), Color(0xFF24133D), Color(0xFF0B1830)))
    Box(Modifier.fillMaxSize().background(deepGradient)) {
        Box(Modifier.size(280.dp).offset(x = 150.dp, y = (-75).dp).background(Brush.radialGradient(listOf(Color(0x665F8CFF), Color.Transparent)), CircleShape))
        Box(Modifier.size(250.dp).offset(x = (-115).dp, y = 470.dp).background(Brush.radialGradient(listOf(Color(0x55FF8A63), Color.Transparent)), CircleShape))
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp)
                .padding(top = persistentStatusBarTopInset() + 24.dp, bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 22.dp)
        ) {
            Text("PERSONALISE ATMOS", color = Color.White.copy(.62f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.2.sp)
            Text("Make it feel like yours.", color = Color.White, fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold)
            Text("Choose your app appearance and forecast layout. You can change both later in Settings.", Modifier.padding(top = 7.dp), color = Color.White.copy(.70f), fontSize = 12.sp, lineHeight = 18.sp)
            Spacer(Modifier.height(24.dp))
            Text("APP APPEARANCE", color = Color.White.copy(.56f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ThemePreviewCard(false, selectedTheme == ThemeChoice.System, Modifier.weight(1f), label = "Device", subtitle = "Matches Android") { onTheme(ThemeChoice.System) }
                ThemePreviewCard(false, selectedTheme == ThemeChoice.Light, Modifier.weight(1f), label = "Light") { onTheme(ThemeChoice.Light) }
                ThemePreviewCard(true, selectedTheme == ThemeChoice.Dark, Modifier.weight(1f), label = "Dark") { onTheme(ThemeChoice.Dark) }
            }
            Surface(Modifier.fillMaxWidth().padding(top = 12.dp), shape = RoundedCornerShape(18.dp), color = Color.White.copy(.07f), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(end = 12.dp)) {
                        Text("Dark mode at night", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("When Light or Device theme is active, use dark mode after sunset at your current device location.", color = Color.White.copy(.62f), fontSize = 9.sp, lineHeight = 13.sp)
                    }
                    Switch(checked = darkNightMode, onCheckedChange = onDarkNightMode)
                }
            }
            Spacer(Modifier.height(22.dp))
            Text("FORECAST EXPERIENCE", color = Color.White.copy(.56f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
            Text("Choose how saved locations move through the same Atmos colour scene.", Modifier.padding(top = 7.dp, bottom = 10.dp), color = Color.White.copy(.66f), fontSize = 11.sp, lineHeight = 16.sp)
            LayoutPreviewCard("Card style", "A complete card-style forecast for each location.", false, selectedTransition == LocationTransition.Standard) { onSelect(LocationTransition.Standard) }
            Spacer(Modifier.height(10.dp))
            LayoutPreviewCard("Immersive", "The colour atmosphere stays continuous while forecast content glides between locations.", true, selectedTransition == LocationTransition.Immersive) { onSelect(LocationTransition.Immersive) }
            Spacer(Modifier.height(22.dp))
            Text("CONTENT DENSITY", color = Color.White.copy(.56f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
            Text("Choose how much forecast content appears before you scroll.", Modifier.padding(top = 7.dp, bottom = 10.dp), color = Color.White.copy(.66f), fontSize = 11.sp, lineHeight = 16.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DensityPreviewCard(DensityChoice.Compact, selectedDensity == DensityChoice.Compact, Modifier.weight(1f)) { onDensity(DensityChoice.Compact) }
                DensityPreviewCard(DensityChoice.Expanded, selectedDensity == DensityChoice.Expanded, Modifier.weight(1f)) { onDensity(DensityChoice.Expanded) }
            }
            Spacer(Modifier.height(26.dp))
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF131A32))) {
                Text("Continue", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AtmosSelectionTick(selected: Boolean, modifier: Modifier = Modifier, darkInk: Boolean = false) {
    AnimatedVisibility(
        visible = selected,
        modifier = modifier,
        enter = scaleIn(tween(220, easing = FastOutSlowInEasing)) + fadeIn(tween(160)),
        exit = scaleOut(tween(140)) + fadeOut(tween(120))
    ) {
        Surface(
            Modifier.size(25.dp),
            shape = CircleShape,
            color = if (darkInk) Color(0xFF20314D) else Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, if (darkInk) Color.White.copy(.32f) else Color(0xFFBFD9FF))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("✓", color = if (darkInk) Color.White else Color(0xFF29476D), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun ThemePreviewCard(
    dark: Boolean,
    selected: Boolean,
    modifier: Modifier = Modifier,
    label: String = if (dark) "Dark" else "Light",
    subtitle: String? = null,
    automatic: Boolean = false,
    onClick: () -> Unit
) {
    val sky = when {
        automatic -> listOf(Color(0xFFBEE4FF), Color(0xFFFFD8B5), Color(0xFF17243D))
        dark -> listOf(Color(0xFF101B31), Color(0xFF293B5A))
        else -> listOf(Color(0xFFBEE4FF), Color(0xFFFFE0C7))
    }
    val ink = if (dark || automatic) Color.White else Color(0xFF20314D)
    Surface(
        modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            if (selected) Color(0xFF77BFFF) else ink.copy(.18f)
        )
    ) {
        Box(Modifier.height(112.dp).background(Brush.linearGradient(sky)).padding(13.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                if (automatic) {
                    drawCircle(Color(0xFFFFB85A), radius = 11.dp.toPx(), center = Offset(size.width - 34.dp.toPx(), 18.dp.toPx()))
                    drawCircle(Color(0xFFFFF3C4), radius = 8.dp.toPx(), center = Offset(size.width - 14.dp.toPx(), 18.dp.toPx()))
                } else {
                    drawCircle(if (dark) Color(0xFFFFF3C4) else Color(0xFFFFB85A), radius = 13.dp.toPx(), center = Offset(size.width - 19.dp.toPx(), 18.dp.toPx()))
                }
                drawRoundRect(ink.copy(.14f), Offset(0f,size.height*.56f), Size(size.width,size.height*.31f), CornerRadius(14.dp.toPx()))
                drawLine(ink.copy(.75f), Offset(12.dp.toPx(),size.height*.72f), Offset(size.width*.62f,size.height*.72f), strokeWidth=3.dp.toPx(), cap=StrokeCap.Round)
            }
            Column {
                Text(label, color=ink, fontWeight=FontWeight.Bold, fontSize=15.sp)
                subtitle?.let { Text(it, color = ink.copy(.70f), fontSize = 8.sp, lineHeight = 11.sp, modifier = Modifier.padding(top = 2.dp).width(82.dp)) }
            }
            AtmosSelectionTick(selected, Modifier.align(Alignment.TopEnd), darkInk = !dark && !automatic)
        }
    }
}

@Composable
private fun LayoutPreviewCard(
    title: String,
    subtitle: String,
    immersive: Boolean,
    selected: Boolean,
    dual: Boolean = false,
    onClick: () -> Unit
) {
    val borderColor = if (selected) Color.White else Color.White.copy(.28f)
    Surface(
        modifier = Modifier.fillMaxWidth().height(202.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(28.dp),
        color = if (selected) Color(0xFF344F78) else Color(0xFF233753),
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, borderColor)
    ) {
        Row(Modifier.fillMaxSize().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.width(112.dp).fillMaxHeight().clip(RoundedCornerShape(22.dp))
                    .background(
                        if (immersive) Brush.verticalGradient(
                            listOf(Color(0xFFFFB14E), Color(0xFFEE716D), Color(0xFF263247), Color(0xFF080D17)),
                            endY = 520f
                        ) else Brush.verticalGradient(
                            listOf(Color(0xFFFFB14E), Color(0xFFEE8A72), Color(0xFF9FD8E2)),
                            endY = 520f
                        )
                    )
            ) {
                if (dual) {
                    Column(
                        Modifier.fillMaxSize().padding(7.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            listOf(Color(0xFFFFB14E), Color(0xFFEE8A72), Color(0xFF7EC7D8)),
                            listOf(Color(0xFF263D6A), Color(0xFF4E6590), Color(0xFF171E32))
                        ).forEachIndexed { index, colors ->
                            Box(
                                Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(13.dp))
                                    .background(Brush.verticalGradient(colors))
                                    .padding(horizontal = 7.dp, vertical = 6.dp)
                            ) {
                                Column(Modifier.fillMaxSize()) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(if (index == 0) "Sydney" else "London", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                                        Text(if (index == 0) "Summer  2:34 pm" else "Summer  3:34 am", color = Color.White.copy(.76f), fontSize = 4.sp)
                                    }
                                    Text(if (index == 0) "24°" else "11°", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 19.sp)
                                    Text(if (index == 0) "Mostly sunny" else "Cloudy", color = Color.White, fontSize = 5.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.weight(1f))
                                    Text(if (index == 0) "Warm and bright this afternoon." else "Cloud remains through the morning.", color = Color.White.copy(.82f), fontSize = 3.8.sp, lineHeight = 5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                } else if (immersive) {
                    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 9.dp)) {
                        Text("Sydney", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("New South Wales", color = Color.White.copy(.68f), fontSize = 5.sp)
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.width(38.dp).height(12.dp).clip(CircleShape).background(Color(0xFFD9ECFF)))
                        Text("19°", Modifier.padding(top = 6.dp), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Mostly sunny", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Canvas(Modifier.fillMaxWidth().height(29.dp)) {
                            val path = Path().apply { moveTo(0f, size.height * .72f); lineTo(size.width * .28f, size.height * .50f); lineTo(size.width * .55f, size.height * .62f); lineTo(size.width, size.height * .22f) }
                            drawPath(path, Color.White.copy(.9f), style = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round))
                        }
                        Box(Modifier.fillMaxWidth().height(16.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x66101A30)))
                    }
                } else {
                    Column(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 9.dp)) {
                        Text("Sydney", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("New South Wales", color = Color.White.copy(.68f), fontSize = 5.sp)
                        Spacer(Modifier.height(9.dp))
                        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(.16f)).padding(9.dp)) {
                            Column {
                                Box(Modifier.width(35.dp).height(10.dp).clip(CircleShape).background(Color(0xFFD9ECFF)))
                                Text("19°", Modifier.padding(top = 5.dp), color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Mostly sunny", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.weight(1f))
                                Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(Color(0x66101A30)))
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Box(Modifier.fillMaxWidth().height(25.dp).clip(RoundedCornerShape(10.dp)).background(Color(0x44101A30)))
                    }
                }
                AtmosSelectionTick(selected, Modifier.align(Alignment.TopEnd).padding(7.dp))
            }
            Column(Modifier.weight(1f).padding(start = 16.dp)) {
                Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, Modifier.padding(top = 6.dp), color = Color.White.copy(.74f), fontSize = 11.sp, lineHeight = 16.sp)
                Spacer(Modifier.weight(1f))
                Text(if (selected) "Selected" else "Tap to choose", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun DensityPreviewCard(
    option: DensityChoice,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val compact = option == DensityChoice.Compact
    Surface(
        modifier = modifier.height(176.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = if (selected) Color(0xFF344F78) else Color(0xFF233753),
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Color.White else Color.White.copy(.25f))
    ) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Box(Modifier.fillMaxWidth().height(105.dp).clip(RoundedCornerShape(17.dp)).background(Brush.verticalGradient(listOf(Color(0xFFFFB264), Color(0xFFEE7B76), Color(0xFF263247))))) {
                Column(Modifier.fillMaxSize().padding(8.dp)) {
                    Text("Sydney", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                    Text("19°", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Mostly sunny", color = Color.White, fontSize = 6.sp)
                    Spacer(Modifier.height(if (compact) 5.dp else 9.dp))
                    if (!compact) {
                        Canvas(Modifier.fillMaxWidth().height(19.dp)) {
                            val path = Path().apply { moveTo(0f,size.height*.72f); lineTo(size.width*.34f,size.height*.38f); lineTo(size.width*.64f,size.height*.58f); lineTo(size.width,size.height*.20f) }
                            drawPath(path, Color.White.copy(.86f), style = Stroke(1.2.dp.toPx(), cap = StrokeCap.Round))
                        }
                    }
                    Box(Modifier.fillMaxWidth().height(if (compact) 17.dp else 22.dp).clip(RoundedCornerShape(7.dp)).background(Color.White.copy(.14f)))
                    if (!compact) Spacer(Modifier.height(4.dp))
                    if (!compact) Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(Color.White.copy(.10f)))
                }
                AtmosSelectionTick(selected, Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
            Text(option.name, Modifier.padding(top = 9.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(if (compact) "Key cards sooner" else "Chart and condition summary", color = Color.White.copy(.66f), fontSize = 8.sp, lineHeight = 11.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomePage(
    currentWeather: WeatherState,
    weatherCache: Map<String, WeatherState>,
    savedPlaces: List<Place>,
    currentPlace: Place,
    refreshing: Boolean,
    density: DensityChoice,
    preferences: AtmosPreferences,
    temperatureUnit: TemperatureUnit,
    conditionAnimations: Boolean,
    homeLayout: HomeLayout,
    locationTransition: LocationTransition,
    weatherAppearance: WeatherAppearance,
    appTheme: ThemeChoice,
    systemDark: Boolean,
    appDarkFraction: Float,
    onTemperatureUnit: (TemperatureUnit) -> Unit,
    onRefresh: () -> Unit,
    onSelectPlace: (Place) -> Unit,
    onSavedPlacesChanged: (List<Place>) -> Unit,
    onAddLocation: () -> Unit,
    onImmersiveHeroVisible: (Boolean) -> Unit,
    ambientDisplayActive: Boolean,
    onAmbientControlsVisible: (Boolean) -> Unit,
    onSeason: (String, Place) -> Unit,
    onPage: (Page) -> Unit
) {
    // Recreate the pager whenever the saved-page structure changes. This avoids a
    // transient out-of-range pager position when the final saved location is removed.
    val pagerStructureKey = remember(savedPlaces) {
        savedPlaces.mapIndexed { index, place -> place.pagerKey(index) }
    }
    key(pagerStructureKey) {
        var dualDetailPlaceKey by rememberSaveable { mutableStateOf<String?>(null) }
        var dualOverviewPage by rememberSaveable { mutableStateOf(0) }
        val showingDualOverview = homeLayout == HomeLayout.Dual && dualDetailPlaceKey == null
        val effectiveHomeLayout = if (homeLayout == HomeLayout.Dual && dualDetailPlaceKey != null) {
            HomeLayout.Immersive
        } else {
            homeLayout
        }
        BackHandler(enabled = homeLayout == HomeLayout.Dual && dualDetailPlaceKey != null) {
            dualDetailPlaceKey = null
        }
        LaunchedEffect(homeLayout) {
            if (homeLayout != HomeLayout.Dual) dualDetailPlaceKey = null
        }
        var ambientControlsVisible by remember(ambientDisplayActive) { mutableStateOf(true) }
        var ambientInteractionGeneration by remember { mutableStateOf(0) }
        LaunchedEffect(ambientDisplayActive, ambientInteractionGeneration) {
            ambientControlsVisible = true
            onAmbientControlsVisible(true)
            if (ambientDisplayActive) {
                delay(AMBIENT_IDLE_DELAY_MS)
                ambientControlsVisible = false
                onAmbientControlsVisible(false)
            }
        }
        DisposableEffect(ambientDisplayActive) {
            if (!ambientDisplayActive) onAmbientControlsVisible(true)
            onDispose { onAmbientControlsVisible(true) }
        }
        val ambientUi = AmbientDisplayUi(ambientDisplayActive, ambientControlsVisible)
        val firstForecastPage = 0
        val addLocationPage = savedPlaces.size
        val selectedPage = remember(savedPlaces, currentPlace, addLocationPage) {
            savedPlaces.indexOfFirst { it.matches(currentPlace) }
                .takeIf { it >= 0 }
                ?: firstForecastPage
        }
        val pagerState = rememberPagerState(
            initialPage = selectedPage.coerceIn(firstForecastPage, addLocationPage),
            pageCount = { savedPlaces.size + 1 }
        )

        LaunchedEffect(currentPlace, pagerStructureKey) {
            val target = savedPlaces.indexOfFirst { it.matches(currentPlace) }
                .takeIf { it >= 0 }
                ?: firstForecastPage
            if (target != pagerState.currentPage) pagerState.scrollToPage(target)
        }

        LaunchedEffect(pagerState, pagerStructureKey) {
            snapshotFlow { pagerState.settledPage to pagerState.isScrollInProgress }
                .collect { (selected, isScrolling) ->
                    if (isScrolling && ambientDisplayActive) {
                        ambientInteractionGeneration++
                    }
                    if (!isScrolling) {
                        savedPlaces.getOrNull(selected - firstForecastPage)?.let(onSelectPlace)
                    }
                    // The final page is deliberately the add-location page. It remains
                    // visible even when there are no saved locations at all.
                }
        }

        // Weather appearance is intentionally stable while paging. Location-following
        // day/night interpolation is retired for now to avoid recomposing the colour
        // scheme continuously during a swipe.
        // The root app theme already resolves Dark mode at night from the saved
        // live-device location. Home must use that same value rather than changing
        // appearance when the user swipes to a different forecast location.
        val homeDarkFraction = when (weatherAppearance) {
            WeatherAppearance.FollowLocation, WeatherAppearance.FollowApp -> appDarkFraction
            WeatherAppearance.Dark -> 1f
            WeatherAppearance.Light -> 0f
        }.coerceIn(0f, 1f)
        val homeNight = isLocationNight(currentPlace, Date())
        val homePalette = remember(currentWeather.days.firstOrNull()?.icon, homeNight) {
            conditionPalette(currentWeather.days.firstOrNull()?.icon.orEmpty(), homeNight)
        }
        val homeScheme = remember(homePalette.accent, homePalette.secondary, homeDarkFraction) {
            atmosColorScheme(homePalette.accent, homePalette.secondary, homeDarkFraction)
        }

        MaterialTheme(colorScheme = homeScheme) {
            val pagerScope = rememberCoroutineScope()
            Box(
                Modifier.fillMaxSize().pointerInput(ambientDisplayActive) {
                    if (ambientDisplayActive) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent(PointerEventPass.Initial)
                                if (event.changes.any { it.pressed && !it.previousPressed }) {
                                    ambientInteractionGeneration++
                                }
                            }
                        }
                    }
                }
            ) {
            if (showingDualOverview) {
                DualAtmosphereLayout(
                    savedPlaces = savedPlaces,
                    weatherCache = weatherCache,
                    temperatureUnit = temperatureUnit,
                    preferences = preferences,
                    conditionAnimations = conditionAnimations,
                    initialPage = dualOverviewPage,
                    onPageChanged = { dualOverviewPage = it },
                    onSelectLocation = { place ->
                        dualDetailPlaceKey = place.cacheKey()
                        onSelectPlace(place)
                    },
                    onOpenLocations = { onPage(Page.Locations) },
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (!showingDualOverview && density == DensityChoice.Expanded) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 18.dp)
                        .zIndex(20f)
                        .pointerInteropFilter { true }
                )
            }
            if (!showingDualOverview && locationTransition == LocationTransition.Immersive && effectiveHomeLayout == HomeLayout.Immersive && pagerState.currentPage >= firstForecastPage) {
                ImmersiveLocationAtmosphere(
                    pagerState = pagerState,
                    savedPlaces = savedPlaces,
                    weatherCache = weatherCache,
                    preferences = preferences,
                    conditionAnimations = conditionAnimations,
                    pageOffset = firstForecastPage,
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (!showingDualOverview) HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                pageSpacing = 12.dp,
                beyondViewportPageCount = 1,
                key = { index ->
                    when {
                        index == addLocationPage -> "add-location-page"
                        else -> savedPlaces.getOrNull(index)?.pagerKey(index) ?: "forecast-$index"
                    }
                }
            ) { index ->
                // Let HorizontalPager perform only its native translation. The previous
                // scale/fade effect read currentPageOffsetFraction during composition,
                // which caused both large forecast pages to recompose on every drag frame.
                Box(Modifier.fillMaxSize()) {
                    val settledPage = pagerState.settledPage
                    val place = savedPlaces.getOrNull(index)

                    // The hero is always the final, fully prepared hero for this location.
                    // Only below-the-fold forecast content is deferred on adjacent pages.
                    // This preserves a visually identical atmosphere before and after the
                    // pager settles, avoiding the static-to-live flash from earlier builds.
                    if (index == addLocationPage || place == null) {
                        AddLocationPage(index, savedPlaces.size + 1, onAddLocation)
                    } else {
                        val cachedWeather = weatherCache[place.cacheKey()]
                        val pageWeather = remember(place, cachedWeather) {
                            cachedWeather ?: WeatherState(place, fallbackDays, emptyList(), Observation(), false)
                        }
                        val oledCards = rememberLocationOled(place)
                        CompositionLocalProvider(LocalOledCardMode provides oledCards, LocalAmbientDisplayUi provides ambientUi) {
                        ForecastPage(
                            weather = pageWeather,
                            refreshing = refreshing && place.matches(currentPlace),
                            density = density,
                            preferences = preferences,
                            temperatureUnit = temperatureUnit,
                            conditionAnimations = conditionAnimations,
                            homeLayout = effectiveHomeLayout,
                            immersiveScene = locationTransition == LocationTransition.Immersive && effectiveHomeLayout == HomeLayout.Immersive,
                            onTemperatureUnit = onTemperatureUnit,
                            onRefresh = onRefresh,
                            onSavedPlacesChanged = onSavedPlacesChanged,
                            isActivePage = index == settledPage,
                            // Compact pages are short enough that the first forecast cards can
                            // enter the viewport during a location swipe. Precompose those cards
                            // for adjacent pages, while keeping the heavier forecast feed deferred
                            // until the pager settles.
                            showForecastFeed = index == settledPage || density == DensityChoice.Compact,
                            showFullForecastFeed = index == settledPage,
                            onImmersiveHeroVisible = onImmersiveHeroVisible,
                            forecastPage = index,
                            forecastPageCount = savedPlaces.size + 1,
                            onSeason = onSeason,
                            onPage = onPage
                        )
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = !showingDualOverview && pagerState.currentPage > firstForecastPage && (!ambientDisplayActive || ambientControlsVisible),
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut(),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(
                        top = persistentStatusBarTopInset() + 12.dp,
                        end = 19.dp
                    )
            ) {
                AtmosHomeButton {
                    pagerScope.launch { pagerState.animateScrollToPage(firstForecastPage) }
                }
            }
            if (ambientDisplayActive && !ambientControlsVisible) {
                AtmosDisplayOverlay(
                    weather = currentWeather,
                    preferences = preferences,
                    temperatureUnit = temperatureUnit,
                    conditionAnimations = conditionAnimations,
                    modifier = Modifier
                        .fillMaxSize()
                        .zIndex(50f)
                        .pointerInput(Unit) {
                            detectTapGestures { ambientInteractionGeneration++ }
                        }
                )
            }
        }
        }
    }
}



@Composable
private fun AtmosConditionGlyph(
    condition: String,
    night: Boolean,
    tint: Color,
    modifier: Modifier = Modifier
) {
    val key = condition.lowercase(Locale.ROOT)
    val cutoutColor = MaterialTheme.colorScheme.surfaceContainerHigh
    Canvas(modifier) {
        val stroke = Stroke(width = size.minDimension * .11f, cap = StrokeCap.Round)
        when {
            "storm" in key || "thunder" in key -> {
                val cloudY = size.height * .43f
                drawCircle(tint, size.minDimension * .18f, Offset(size.width * .38f, cloudY))
                drawCircle(tint, size.minDimension * .22f, Offset(size.width * .56f, cloudY * .93f))
                drawRoundRect(tint, Offset(size.width*.22f, size.height*.42f), Size(size.width*.58f, size.height*.22f), CornerRadius(size.minDimension*.12f))
                val bolt = Path().apply {
                    moveTo(size.width*.53f,size.height*.59f); lineTo(size.width*.40f,size.height*.82f)
                    lineTo(size.width*.54f,size.height*.78f); lineTo(size.width*.45f,size.height*.96f)
                }
                drawPath(bolt, tint, style = Stroke(size.minDimension*.10f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            "rain" in key || "shower" in key || "drizzle" in key -> {
                drawCircle(tint, size.minDimension * .18f, Offset(size.width * .38f, size.height*.42f))
                drawCircle(tint, size.minDimension * .22f, Offset(size.width * .56f, size.height*.39f))
                drawRoundRect(tint, Offset(size.width*.22f, size.height*.42f), Size(size.width*.58f, size.height*.22f), CornerRadius(size.minDimension*.12f))
                repeat(3) { i ->
                    val x=size.width*(.32f+i*.18f)
                    drawLine(tint, Offset(x,size.height*.72f), Offset(x-size.width*.04f,size.height*.86f), strokeWidth=size.minDimension*.08f, cap=StrokeCap.Round)
                }
            }
            "cloud" in key || "overcast" in key -> {
                drawCircle(tint, size.minDimension * .20f, Offset(size.width * .38f, size.height*.50f))
                drawCircle(tint, size.minDimension * .25f, Offset(size.width * .57f, size.height*.45f))
                drawRoundRect(tint, Offset(size.width*.18f, size.height*.48f), Size(size.width*.66f, size.height*.25f), CornerRadius(size.minDimension*.13f))
            }
            night -> {
                drawCircle(tint, size.minDimension*.34f, Offset(size.width*.48f,size.height*.48f))
                drawCircle(cutoutColor, size.minDimension*.31f, Offset(size.width*.62f,size.height*.35f))
            }
            else -> {
                drawCircle(tint, size.minDimension*.23f, center)
                repeat(8) { index ->
                    val angle=(index*45f)*PI.toFloat()/180f
                    val inner=size.minDimension*.34f; val outer=size.minDimension*.46f
                    drawLine(tint, Offset(center.x+cos(angle)*inner,center.y+sin(angle)*inner), Offset(center.x+cos(angle)*outer,center.y+sin(angle)*outer), strokeWidth=size.minDimension*.08f, cap=StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
private fun ConditionGradientLocationName(
    text: String,
    palette: Palette,
    foreground: Color,
    fontSize: androidx.compose.ui.unit.TextUnit,
    modifier: Modifier = Modifier
) {
    val brightAccent = remember(palette, foreground) {
        val first = blendColor(palette.accent, foreground, .32f)
        val second = blendColor(palette.secondary, foreground, .48f)
        Brush.linearGradient(listOf(first, foreground, second))
    }
    Text(
        text = text,
        modifier = modifier,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        style = TextStyle(
            brush = brightAccent,
            fontSize = fontSize,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-.6).sp
        )
    )
}

@Composable
private fun DualAtmosphereLayout(
    savedPlaces: List<Place>,
    weatherCache: Map<String, WeatherState>,
    temperatureUnit: TemperatureUnit,
    preferences: AtmosPreferences,
    conditionAnimations: Boolean,
    initialPage: Int,
    onPageChanged: (Int) -> Unit,
    onSelectLocation: (Place) -> Unit,
    onOpenLocations: () -> Unit,
    modifier: Modifier = Modifier
) {
    val locationPages = remember(savedPlaces) { savedPlaces.chunked(2) }
    val pageCount = locationPages.size.coerceAtLeast(1)
    val dualPagerState = rememberPagerState(
        initialPage = initialPage.coerceIn(0, pageCount - 1),
        pageCount = { pageCount }
    )
    LaunchedEffect(dualPagerState, pageCount) {
        snapshotFlow { dualPagerState.settledPage }.collect(onPageChanged)
    }

    Box(
        modifier
            .background(MaterialTheme.colorScheme.background)
            .padding(
                top = persistentStatusBarTopInset() + 10.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 88.dp
            )
    ) {
        HorizontalPager(
            state = dualPagerState,
            modifier = Modifier.fillMaxSize(),
            pageSpacing = 12.dp,
            beyondViewportPageCount = 1,
            key = { pageIndex ->
                locationPages.getOrNull(pageIndex)
                    ?.joinToString(prefix = "dual-", separator = "-") { it.cacheKey() }
                    ?: "dual-empty"
            }
        ) { pageIndex ->
            val pagePlaces = locationPages.getOrNull(pageIndex).orEmpty()
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(start = 12.dp, end = 12.dp, bottom = 22.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (pagePlaces.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        FilledTonalButton(onClick = onOpenLocations) { Text("Add Location") }
                    }
                } else {
                    pagePlaces.forEach { place ->
                        val weather = weatherCache[place.cacheKey()]
                            ?: WeatherState(place, fallbackDays, emptyList(), Observation(), false)
                        DualAtmosphereHero(
                            weather = weather,
                            temperatureUnit = temperatureUnit,
                            preferences = preferences,
                            conditionAnimations = conditionAnimations,
                            onClick = { onSelectLocation(place) },
                            modifier = Modifier.weight(1f).fillMaxWidth()
                        )
                    }
                    if (pagePlaces.size == 1) {
                        Box(
                            Modifier.weight(1f).fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            FilledTonalButton(onClick = onOpenLocations) { Text("Add Location") }
                        }
                    }
                }
            }
        }

        if (locationPages.size > 1) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(locationPages.size) { index ->
                    val selected = dualPagerState.currentPage == index
                    Box(
                        Modifier
                            .size(if (selected) 8.dp else 6.dp)
                            .clip(CircleShape)
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurface.copy(alpha = .28f)
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun DualAtmosphereHero(
    weather: WeatherState,
    temperatureUnit: TemperatureUnit,
    preferences: AtmosPreferences,
    conditionAnimations: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val day = weather.days.firstOrNull() ?: fallbackDays.first()
    val palette = rememberSolarAwarePalette(day.icon, weather.place, weather.observation, day.condition)
    val foreground = solarLegibleForeground(palette, MaterialTheme.colorScheme.background)
    val temp = weather.observation.temp ?: day.high
    val sharedNowMillis = sharedMinuteMillis()
    val localNow = remember(weather.place.cacheKey(), sharedNowMillis) { Date(sharedNowMillis) }
    val narrative = remember(
        weather.updated.time,
        weather.place.cacheKey(),
        temperatureUnit,
        weather.hours,
        weather.days,
        weather.observation
    ) {
        localForecastSummary(
            weather = weather,
            dayIndex = 0,
            temperatureUnit = temperatureUnit,
            maxSentences = 1
        )
    }
    Card(modifier, shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
        Box(Modifier.fillMaxSize()) {
            AtmosSceneRenderer(
                palette = palette,
                observation = weather.observation,
                condition = day.condition,
                temperatureC = weather.observation.feels ?: temp,
                place = weather.place,
                enabled = true,
                preferences = preferences,
                modifier = Modifier.fillMaxSize(),
                renderProfile = AtmosRenderProfile.Compact,
                simulationActive = conditionAnimations
            )
            Column(
                Modifier.fillMaxSize().clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 16.dp)
            ) {
                ConditionGradientLocationName(weather.place.name, palette, foreground, 25.sp)
                Text(weather.place.state.ifBlank { weather.place.country }, color = foreground.copy(.72f), fontSize = 12.sp)
                Row(
                    Modifier.padding(top = 9.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CompactSeasonPill(weather.place)
                    CompactLocalTimePill(weather.place, localNow, foreground)
                }
                Spacer(Modifier.weight(1f))
                Text("${displayTemperature(temp, temperatureUnit)}°", color = foreground, fontSize = 52.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-2).sp, lineHeight = 54.sp)
                Text(day.condition, color = foreground, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    narrative,
                    color = foreground.copy(.84f),
                    fontSize = 11.sp,
                    lineHeight = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 5.dp)
                )
                Text(
                    "Feels like ${displayTemperature(weather.observation.feels ?: temp, temperatureUnit)}°  •  H ${displayTemperature(day.high, temperatureUnit)}°  L ${displayTemperature(day.low, temperatureUnit)}°",
                    color = foreground.copy(.78f),
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 5.dp)
                )
            }
        }
    }
}

@Composable
private fun CompactSeasonPill(place: Place) {
    val season = seasonName(place)
    val (background, foreground) = seasonPillColours(season)
    Surface(
        shape = CircleShape,
        color = background.copy(alpha = .92f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.20f))
    ) {
        Text(
            season,
            Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            color = foreground,
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

@Composable
private fun CompactLocalTimePill(place: Place, now: Date, foreground: Color) {
    Surface(
        shape = CircleShape,
        color = foreground.copy(alpha = .13f),
        border = androidx.compose.foundation.BorderStroke(1.dp, foreground.copy(alpha = .28f))
    ) {
        Text(
            localFormatter("h:mm a", place).format(now).lowercase(Locale.getDefault()),
            Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            color = foreground,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun AtmosDisplayOverlay(
    weather: WeatherState,
    preferences: AtmosPreferences,
    temperatureUnit: TemperatureUnit,
    conditionAnimations: Boolean,
    modifier: Modifier = Modifier
) {
    var now by remember { mutableStateOf(Date()) }
    var positionIndex by remember { mutableStateOf(0) }
    var contentVisible by remember { mutableStateOf(true) }
    val positions = remember {
        listOf(
            Alignment.Center,
            Alignment.TopCenter,
            Alignment.CenterStart,
            Alignment.CenterEnd,
            Alignment.BottomCenter,
            Alignment.TopStart,
            Alignment.BottomEnd,
            Alignment.TopEnd,
            Alignment.BottomStart
        )
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1_000L)
            now = Date()
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(8_900L)
            contentVisible = false
            delay(1_100L)
            positionIndex = (positionIndex + 1) % positions.size
            contentVisible = true
        }
    }

    val displayAlpha by animateFloatAsState(
        targetValue = if (contentVisible) 1f else 0f,
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "atmos-display-fade"
    )
    val day = weather.days.firstOrNull() ?: fallbackDays.first()
    val foreground = solarLegibleForeground(
        rememberSolarAwarePalette(day.icon, weather.place, weather.observation, day.condition),
        MaterialTheme.colorScheme.background
    )
    val currentTemp = weather.observation.temp ?: weather.observation.feels ?: day.high
    val timeText = remember(now.time / 1_000L, weather.place.timeZoneId) {
        localFormatter("h:mm", weather.place).format(now)
    }

    Box(modifier.background(MaterialTheme.colorScheme.background)) {
        ImmersivePreloadedAtmosScene(
            weather = weather,
            preferences = preferences,
            conditionAnimations = conditionAnimations,
            modifier = Modifier.fillMaxSize(),
            simulationActive = true
        )
        Box(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 54.dp, vertical = 92.dp),
            contentAlignment = positions[positionIndex]
        ) {
            Column(
                modifier = Modifier.alpha(displayAlpha),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    timeText,
                    color = foreground,
                    fontSize = 64.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-2).sp
                )
                Text(
                    "${displayTemperature(currentTemp, temperatureUnit)}°",
                    modifier = Modifier.padding(top = 4.dp),
                    color = foreground.copy(alpha = .88f),
                    fontSize = 36.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-1).sp
                )
            }
        }
    }
}

@Composable
private fun AtmosHomeButton(onClick: () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    Surface(
        modifier = Modifier
            .size(48.dp)
            .atmosPress(onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .94f),
        shadowElevation = 10.dp,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.primary.copy(alpha = .30f)
        )
    ) {
        Canvas(Modifier.fillMaxSize().padding(12.dp)) {
            val stroke = 2.2.dp.toPx()
            val roof = Path().apply {
                moveTo(size.width * .12f, size.height * .48f)
                lineTo(size.width * .50f, size.height * .15f)
                lineTo(size.width * .88f, size.height * .48f)
            }
            drawPath(
                path = roof,
                color = accent,
                style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            val body = Path().apply {
                moveTo(size.width * .24f, size.height * .43f)
                lineTo(size.width * .24f, size.height * .84f)
                lineTo(size.width * .76f, size.height * .84f)
                lineTo(size.width * .76f, size.height * .43f)
            }
            drawPath(
                path = body,
                color = accent,
                style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            drawRoundRect(
                color = accent.copy(alpha = .22f),
                topLeft = Offset(size.width * .43f, size.height * .58f),
                size = Size(size.width * .14f, size.height * .26f),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
        }
    }
}

private fun Place.matches(other: Place): Boolean =
    if (current && other.current) true else sameSavedPlace(this, other)

private fun Place.pagerKey(index: Int): String =
    // A live location's coordinates can change on every foreground refresh, but it is
    // still the same first pager card. Its stable key prevents HorizontalPager from
    // being destroyed and recreated while GPS/weather data is updating.
    if (current) "location-current" else "location-$index-${name.lowercase(Locale.ROOT)}-${state.lowercase(Locale.ROOT)}"

private fun interpolateNullableDouble(from: Double?, to: Double?, progress: Float): Double? = when {
    from == null -> to
    to == null -> from
    else -> from + (to - from) * progress
}

@Composable
private fun ImmersiveLocationAtmosphere(
    pagerState: PagerState,
    savedPlaces: List<Place>,
    weatherCache: Map<String, WeatherState>,
    preferences: AtmosPreferences,
    conditionAnimations: Boolean,
    pageOffset: Int = 0,
    modifier: Modifier = Modifier
) {
    if (savedPlaces.isEmpty()) {
        Box(modifier.background(MaterialTheme.colorScheme.background))
        return
    }

    // Immersive uses complete, already-composed location scenes rather than rebuilding
    // one synthetic weather state on every drag frame. HorizontalPager keeps adjacent
    // forecast pages ready; this host does the same for their Atmos backgrounds.
    // Only the alpha of the destination scene follows the finger.
    // Always keep the last settled location as the opaque base scene. The page being
    // dragged toward is layered above it in either direction. This makes forward and
    // backward swipes use the same compositor and prevents a newly composed cloud
    // layer from flashing fully opaque when the pager changes currentPage mid-drag.
    val settledIndex = (pagerState.settledPage - pageOffset).coerceIn(0, savedPlaces.lastIndex)
    val pagePosition = (pagerState.currentPage + pagerState.currentPageOffsetFraction - pageOffset)
        .coerceIn(0f, savedPlaces.lastIndex.toFloat())
    val displacement = pagePosition - settledIndex.toFloat()
    val targetIndex = when {
        displacement > .001f -> (settledIndex + 1).coerceAtMost(savedPlaces.lastIndex)
        displacement < -.001f -> (settledIndex - 1).coerceAtLeast(0)
        else -> settledIndex
    }
    val transitionProgress = kotlin.math.abs(displacement).coerceIn(0f, 1f)

    val basePlace = savedPlaces[settledIndex]
    val targetPlace = savedPlaces[targetIndex]
    val baseWeather = weatherCache[basePlace.cacheKey()]
        ?: WeatherState(basePlace, fallbackDays, emptyList(), Observation(), false)
    val targetWeather = weatherCache[targetPlace.cacheKey()]
        ?: WeatherState(targetPlace, fallbackDays, emptyList(), Observation(), false)

    Box(modifier) {
        key(basePlace.cacheKey()) {
            ImmersivePreloadedAtmosScene(
                weather = baseWeather,
                preferences = preferences,
                conditionAnimations = conditionAnimations,
                modifier = Modifier.fillMaxSize(),
                simulationActive = true
            )
        }

        if (targetIndex != settledIndex && transitionProgress > 0f) {
            key(targetPlace.cacheKey()) {
                ImmersivePreloadedAtmosScene(
                    weather = targetWeather,
                    preferences = preferences,
                    conditionAnimations = conditionAnimations,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = transitionProgress },
                    renderProfile = AtmosRenderProfile.Transition,
                    simulationActive = true
                )
            }
        }

        // Keep Immersive's lower dark zone independent from either location scene so
        // it stays visually continuous while the two full atmospheres overlap.
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color.Transparent,
                        Color.Transparent,
                        MaterialTheme.colorScheme.background.copy(alpha = .30f),
                        MaterialTheme.colorScheme.background
                    ),
                    startY = 0f,
                    endY = 2100f
                )
            )
        )
    }
}

@Composable
private fun ImmersivePreloadedAtmosScene(
    weather: WeatherState,
    preferences: AtmosPreferences,
    conditionAnimations: Boolean,
    modifier: Modifier = Modifier,
    renderProfile: AtmosRenderProfile = AtmosRenderProfile.Full,
    simulationActive: Boolean = true
) {
    val day = weather.days.firstOrNull() ?: fallbackDays.first()
    val palette = rememberSolarAwarePalette(day.icon, weather.place, weather.observation, day.condition)
    val temperature = weather.observation.feels ?: weather.observation.temp ?: 18

    Box(modifier) {
        AtmosSceneRenderer(
            palette = palette,
            observation = weather.observation,
            condition = day.condition,
            temperatureC = temperature,
            place = weather.place,
            enabled = true,
            preferences = preferences,
            modifier = Modifier.fillMaxSize(),
            renderProfile = renderProfile,
            simulationActive = simulationActive
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ForecastPage(
    weather: WeatherState,
    refreshing: Boolean,
    density: DensityChoice,
    preferences: AtmosPreferences,
    temperatureUnit: TemperatureUnit,
    conditionAnimations: Boolean,
    homeLayout: HomeLayout,
    immersiveScene: Boolean = false,
    onTemperatureUnit: (TemperatureUnit) -> Unit,
    onRefresh: () -> Unit,
    onSavedPlacesChanged: (List<Place>) -> Unit,
    isActivePage: Boolean,
    showForecastFeed: Boolean,
    showFullForecastFeed: Boolean,
    onImmersiveHeroVisible: (Boolean) -> Unit,
    forecastPage: Int,
    forecastPageCount: Int,
    onSeason: (String, Place) -> Unit,
    onPage: (Page) -> Unit
) {
    val day = weather.days.first()
    val palette = rememberSolarAwarePalette(day.icon, weather.place, weather.observation, day.condition)
    val padding = if (density == DensityChoice.Compact) 12.dp else 17.dp
    val appBackground = MaterialTheme.colorScheme.background
    val pageBackground = remember(palette, appBackground) {
        Brush.verticalGradient(
            colors = listOf(
                palette.top.copy(alpha = .74f),
                palette.bottom.copy(alpha = .50f),
                palette.secondary.copy(alpha = .34f),
                palette.secondary.copy(alpha = .16f),
                appBackground
            ),
            endY = 1950f
        )
    }
    val listState = rememberLazyListState()
    val topInset = persistentStatusBarTopInset() + 15.dp
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 92.dp
    val cardSpacing = if (density == DensityChoice.Compact) 11.dp else 15.dp
    val immersiveHeroThresholdPx = with(LocalDensity.current) {
        LocalConfiguration.current.screenHeightDp.dp.toPx() * .72f
    }

    LaunchedEffect(homeLayout, isActivePage, listState, immersiveHeroThresholdPx) {
        if (homeLayout != HomeLayout.Immersive || !isActivePage) {
            if (isActivePage) onImmersiveHeroVisible(false)
        } else {
            snapshotFlow {
                listState.firstVisibleItemIndex == 0 &&
                    listState.firstVisibleItemScrollOffset < immersiveHeroThresholdPx
            }.collect { visible -> onImmersiveHeroVisible(visible) }
        }
    }

    PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = onRefresh,
        modifier = Modifier.fillMaxSize(),
        indicator = {}
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .then(if (immersiveScene) Modifier else Modifier.background(pageBackground)),
            contentPadding = PaddingValues(bottom = bottomInset),
            verticalArrangement = Arrangement.spacedBy(cardSpacing)
        ) {
            item(key = "hero:${weather.place.cacheKey()}", contentType = "hero") {
                if (homeLayout == HomeLayout.Immersive) {
                    HeroCard(
                        weather, palette, temperatureUnit, preferences, conditionAnimations,
                        forecastPage, forecastPageCount, onPage, onTemperatureUnit,
                        { onPage(Page.Locations) }, onSeason,
                        animateTemperature = isActivePage,
                        refreshing = refreshing,
                        immersive = true,
                        place = weather.place,
                        history = preferences.observationHistory(weather.place),
                        topInset = topInset,
                        renderAtmosphere = !immersiveScene,
                        darkLowerSection = immersiveScene,
                        atmosphereSimulationActive = isActivePage,
                        compact = density == DensityChoice.Compact
                    )
                } else {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(start = padding, end = padding, top = topInset),
                        verticalArrangement = Arrangement.spacedBy(cardSpacing)
                    ) {
                        LocationHeader(weather.place, palette) { onPage(Page.Locations) }
                        AnimatedVisibility(
                            visible = refreshing,
                            enter = fadeIn(tween(180)),
                            exit = fadeOut(tween(180))
                        ) {
                            AtmosRefreshIndicator(palette, compact = true)
                        }
                        HeroCard(
                            weather, palette, temperatureUnit, preferences, conditionAnimations,
                            forecastPage, forecastPageCount, onPage, onTemperatureUnit,
                            { onPage(Page.Locations) }, onSeason,
                            animateTemperature = isActivePage,
                            refreshing = false,
                            history = preferences.observationHistory(weather.place),
                            renderAtmosphere = !immersiveScene,
                            atmosphereSimulationActive = isActivePage,
                            compact = density == DensityChoice.Compact
                        )
                    }
                    ScrollDownCue(palette, Modifier.padding(vertical = 8.dp))
                }
            }

            if (density == DensityChoice.Compact) {
                item(key = "pager-handle:${weather.place.cacheKey()}", contentType = "pager-handle") {
                    val oledHandle = LocalOledCardMode.current
                    val lightInterface = MaterialTheme.colorScheme.background.luminance() >= .50f
                    val darkSceneHandle = palette.bottom.luminance() < .30f
                    val conditionHandle = blendColor(palette.accent, palette.secondary, .24f)
                    val lightModeHandle = Color(
                        red = (conditionHandle.red * .52f).coerceIn(0f, 1f),
                        green = (conditionHandle.green * .52f).coerceIn(0f, 1f),
                        blue = (conditionHandle.blue * .52f).coerceIn(0f, 1f),
                        alpha = 1f
                    )
                    val handleBase = when {
                        lightInterface -> lightModeHandle
                        darkSceneHandle -> blendColor(palette.accent, Color.White, .72f)
                        else -> palette.top
                    }
                    val compactHandleActive = if (oledHandle) {
                        Color(0xFFD7E7FA)
                    } else {
                        handleBase.copy(alpha = if (lightInterface) 1f else .98f)
                    }
                    val compactHandleInactive = if (oledHandle) {
                        Color(0xFFD7E7FA).copy(alpha = .42f)
                    } else {
                        handleBase.copy(alpha = when {
                            lightInterface -> .46f
                            darkSceneHandle -> .58f
                            else -> .42f
                        })
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = padding)
                            .height(30.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        ForecastPageIndicator(
                            current = forecastPage,
                            count = forecastPageCount,
                            selectedColour = compactHandleActive,
                            unselectedColour = compactHandleInactive
                        )
                    }
                }
            }

            // Compact adjacent pages precompose the first three forecast cards so they
            // are already present if the user reaches below the shorter Hero during a
            // swipe. Charts and the heavier detail feed remain deferred until settlement.
            if (showForecastFeed) {
                item(key = "current-conditions:${weather.place.cacheKey()}", contentType = "forecast-card") {
                    Box(Modifier.fillMaxWidth().padding(horizontal = padding)) {
                        CurrentConditionsCard(weather, palette, preferences)
                    }
                }
                item(key = "atmos-moments:${weather.place.cacheKey()}", contentType = "forecast-card") {
                    Box(Modifier.fillMaxWidth().padding(horizontal = padding)) {
                        AtmosMomentsCard(weather, palette, temperatureUnit) { onPage(Page.Home) }
                    }
                }
                item(key = "at-a-glance:${weather.place.cacheKey()}", contentType = "forecast-card") {
                    Box(Modifier.fillMaxWidth().padding(horizontal = padding)) {
                        AtAGlanceCard(weather, palette, temperatureUnit)
                    }
                }
                if (showFullForecastFeed) {
                item(key = "hourly:${weather.place.cacheKey()}", contentType = "forecast-card") {
                    Box(Modifier.fillMaxWidth().padding(horizontal = padding)) {
                        HourlyCard(weather, day, temperatureUnit, palette)
                    }
                }
                item(key = "seven-day:${weather.place.cacheKey()}", contentType = "forecast-card") {
                    Box(Modifier.fillMaxWidth().padding(horizontal = padding)) {
                        SevenDayCard(weather.days, temperatureUnit, palette)
                    }
                }
                item(key = "precipitation:${weather.place.cacheKey()}", contentType = "forecast-card") {
                    Box(Modifier.fillMaxWidth().padding(horizontal = padding)) {
                        PrecipitationCard(weather.hours, palette)
                    }
                }
                item(key = "wind-forecast:${weather.place.cacheKey()}", contentType = "forecast-card") {
                    Box(Modifier.fillMaxWidth().padding(horizontal = padding)) {
                        WindForecastCard(weather.hours, palette, weather.place)
                    }
                }
                if (weather.warnings.isNotEmpty()) {
                    item(key = "warnings:${weather.place.cacheKey()}", contentType = "forecast-card") {
                        Box(Modifier.fillMaxWidth().padding(horizontal = padding)) {
                            WarningCard(weather.warnings)
                        }
                    }
                }
                item(key = "details:${weather.place.cacheKey()}", contentType = "forecast-card") {
                    Box(Modifier.fillMaxWidth().padding(horizontal = padding)) {
                        DetailCards(weather, preferences)
                    }
                }
                item(key = "footer:${weather.place.cacheKey()}", contentType = "footer") {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = padding, vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            if (weather.place.isAustralian()) {
                                "Weather data supplied by the Australian Bureau of Meteorology."
                            } else {
                                "International forecast data supplied by Open-Meteo."
                            },
                            color = MaterialTheme.colorScheme.onSurface.copy(.66f),
                            fontSize = 10.sp
                        )
                        Text(
                            "Atmos was built by Josh Stanley",
                            color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                            fontSize = 10.sp
                        )
                        val context = LocalContext.current
                        Text(
                            "Contact Josh",
                            Modifier
                                .padding(top = 9.dp)
                                .clickable {
                                    context.startActivity(
                                        Intent(
                                            Intent.ACTION_SENDTO,
                                            Uri.parse("mailto:Josh.stanley@me.com")
                                        )
                                    )
                                },
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
                }
            }
        }
    }
}


@Composable
private fun AtmosRefreshIndicator(palette: Palette, compact: Boolean = false) {
    val transition = rememberInfiniteTransition(label = "atmosRefresh")
    val phase by transition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(1_650, easing = LinearEasing)), label = "refreshPhase"
    )
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .88f),
        border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(alpha = .35f)),
        shadowElevation = if (compact) 2.dp else 8.dp
    ) {
        Row(Modifier.padding(horizontal = if (compact) 11.dp else 14.dp, vertical = if (compact) 7.dp else 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Canvas(Modifier.size(if (compact) 18.dp else 24.dp)) {
                val centre = Offset(size.width / 2f, size.height / 2f)
                repeat(3) { index ->
                    val angle = (phase * 360f + index * 120f) * PI.toFloat() / 180f
                    val radius = size.minDimension * .30f
                    drawCircle(
                        color = listOf(palette.top, palette.secondary, palette.accent)[index].copy(alpha = .86f),
                        radius = 2.4.dp.toPx(),
                        center = Offset(centre.x + cos(angle) * radius, centre.y + sin(angle) * radius)
                    )
                }
            }
            Text("Refreshing the atmosphere", Modifier.padding(start = 8.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AtmosPageBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    // Static decorative surface: no infinite animation or frame invalidation while idle.
    val backgroundBrush = remember {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFF040814),
                Color(0xFF0A1530),
                Color(0xFF16244A),
                Color(0xFF291D4A),
                Color(0xFF102A43),
                Color(0xFF050A17)
            ),
            start = Offset.Zero,
            end = Offset(1080f, 1920f)
        )
    }
    Box(modifier.background(backgroundBrush)) { content() }
}

@Composable
private fun Modifier.atmosPress(onClick: () -> Unit): Modifier {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (pressed) .975f else 1f,
        spring(dampingRatio = .72f, stiffness = 520f),
        label = "atmosPressScale"
    )
    return graphicsLayer { scaleX = scale; scaleY = scale }
        .pointerInput(onClick) { detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false }, onTap = { onClick() }) }
}

@Composable
private fun AddLocationPage(page: Int, pageCount: Int, onAddLocation: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primary.copy(.18f), MaterialTheme.colorScheme.background))
        ).padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(38.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(.18f))
        ) {
            Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.15f)) {
                    Text("+", Modifier.padding(horizontal = 22.dp, vertical = 12.dp), fontSize = 38.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(22.dp))
                Text("Add another location", fontSize = 27.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text("Save a town or city, then swipe between forecasts from the home screen.", Modifier.padding(top = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(.68f), textAlign = TextAlign.Center, lineHeight = 20.sp)
                Button(onClick = onAddLocation, modifier = Modifier.padding(top = 24.dp).fillMaxWidth().height(52.dp)) {
                    Text("Choose a location", fontWeight = FontWeight.Bold)
                }
                ForecastPageIndicator(page, pageCount, Modifier.padding(top = 28.dp))
            }
        }
    }
}

@Composable
private fun ForecastPageIndicator(
    current: Int,
    count: Int,
    modifier: Modifier = Modifier,
    selectedColour: Color? = null,
    unselectedColour: Color? = null
) {
    val theme = MaterialTheme.colorScheme.primary
    val darkerTheme = Color(
        red = (theme.red * .58f).coerceIn(0f, 1f),
        green = (theme.green * .58f).coerceIn(0f, 1f),
        blue = (theme.blue * .58f).coerceIn(0f, 1f),
        alpha = 1f
    )
    val active = selectedColour ?: darkerTheme.copy(alpha = .88f)
    val inactive = unselectedColour ?: darkerTheme.copy(alpha = .46f)
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(count) { index ->
            val selected = index == current
            Box(
                Modifier
                    .height(7.dp)
                    .width(if (selected) 22.dp else 7.dp)
                    .clip(CircleShape)
                    .background(if (selected) active else inactive)
            )
        }
    }
}

@Composable
private fun LocationHeader(place: Place, palette: Palette, onClick: () -> Unit) {
    val liveAccent = MaterialTheme.colorScheme.primary
    val displayPlace = remember(place) {
        if (place.current) places.minByOrNull { distanceSquared(it.latitude, it.longitude, place.latitude, place.longitude) } ?: place else place
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(horizontal = 5.dp, vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ConditionGradientLocationName(displayPlace.name, palette, MaterialTheme.colorScheme.onSurface, 27.sp)
            if (place.current) {
                Surface(Modifier.padding(start = 9.dp), shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.16f), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(.42f))) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Canvas(Modifier.size(12.dp)) {
                            val marker = Path().apply { moveTo(size.width*.14f,size.height*.46f); lineTo(size.width*.86f,size.height*.12f); lineTo(size.width*.59f,size.height*.88f); lineTo(size.width*.46f,size.height*.57f); close() }
                            drawPath(marker, liveAccent)
                        }
                        Spacer(Modifier.width(5.dp))
                        Text("LIVE", color = MaterialTheme.colorScheme.primary, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        Text(displayPlace.state, color = MaterialTheme.colorScheme.onSurface.copy(.68f), fontSize = 13.sp)
    }
}



private enum class AtmosRenderProfile { Full, Transition, Compact }

/**
 * Atmos 0.50.5 lean renderer. It is entirely event-driven: no frame clock, weather layers, or idle animation loop. The scene redraws only while
 * its colours cross-fade, when weather/location inputs change, or on the minute solar tick.
 */

private fun compassBearing(direction: String): Double {
    return when (direction.trim().uppercase(Locale.ENGLISH)) {
        "N" -> 0.0; "NNE" -> 22.5; "NE" -> 45.0; "ENE" -> 67.5
        "E" -> 90.0; "ESE" -> 112.5; "SE" -> 135.0; "SSE" -> 157.5
        "S" -> 180.0; "SSW" -> 202.5; "SW" -> 225.0; "WSW" -> 247.5
        "W" -> 270.0; "WNW" -> 292.5; "NW" -> 315.0; "NNW" -> 337.5
        else -> 0.0
    }
}

@Composable
private fun AtmosWeatherEffectsLayer(
    observation: Observation,
    condition: String,
    temperatureC: Int,
    palette: Palette,
    preferences: AtmosPreferences,
    place: Place,
    renderTime: Date,
    modifier: Modifier = Modifier,
    active: Boolean = true
) {
    val lower = condition.lowercase(Locale.ENGLISH)
    val realism = remember(observation, condition, temperatureC) { buildWeatherRealismProfile(observation, condition, temperatureC) }
    val conditionIndicatesRain = lower.contains("rain") || lower.contains("shower") ||
        lower.contains("drizzle") || lower.contains("storm") || lower.contains("thunder")
    val measuredPrecipitation = (observation.currentPrecipitation ?: 0.0).coerceAtLeast(0.0)
    val rain = preferences.rainEffectEnabled && preferences.precipitationEnabled &&
        (conditionIndicatesRain || measuredPrecipitation >= 0.02)
    val snow = preferences.snowEffectEnabled && preferences.precipitationEnabled &&
        (lower.contains("snow") || lower.contains("sleet") || lower.contains("flurr"))
    val fog = preferences.fogEffectEnabled &&
        (lower.contains("fog") || lower.contains("mist"))
    val haze = preferences.hazeEnabled &&
        (lower.contains("haze") || lower.contains("smoke") || realism.moistureWeight >= .76f)
    val heat = preferences.heatShimmer && temperatureC >= 35
    val frost = preferences.coldFrost && temperatureC < 5
    val lightning = preferences.lightningEnabled &&
        (lower.contains("thunder") || lower.contains("lightning") || lower.contains("storm"))
    val windSpeed = (observation.wind ?: 0).coerceAtLeast(0)
    val wind = preferences.windMotionEnabled && windSpeed >= 18
    val cloudPresence = realism.cloudDepth.coerceIn(.18f, 1f)
    val livingClouds = preferences.livingCloudsEnabled && active && cloudPresence > .12f
    val solarTimesForRays = remember(place.cacheKey(), renderTime.time / 60_000L) {
        calculateSolarTimes(renderTime, place.latitude, place.longitude, place.timeZone())
    }
    val solarProgressForRays = solarTimesForRays?.let { (sunrise, sunset) ->
        if (renderTime.before(sunrise) || !renderTime.before(sunset)) null
        else ((renderTime.time - sunrise.time).toFloat() / (sunset.time - sunrise.time).toFloat()).coerceIn(0f, 1f)
    }
    // Rays remain visible in every daylight condition, but weather still controls their density and strength.
    val cloudRayFactor = when {
        lower.contains("thunder") || lower.contains("storm") -> .24f
        lower.contains("overcast") -> .32f
        lower.contains("rain") || lower.contains("shower") || lower.contains("drizzle") -> .38f
        lower.contains("fog") || lower.contains("mist") -> .42f
        lower.contains("cloud") -> .62f
        else -> 1f
    }
    val realismRayFactor = (realism.surfaceLight * (1f - realism.cloudDepth * .34f)).coerceIn(.24f, 1f)
    val hotRayBoost = (1f + ((temperatureC - 27f) / 15f).coerceIn(0f, 1f) * .72f)
    val solarRayEnergy = solarProgressForRays?.let { kotlin.math.sin(Math.PI * it).toFloat().coerceIn(0f, 1f) } ?: 0f
    // Daylight envelope: rays gradually reappear after sunrise, hold through the day,
    // then dissolve before sunset instead of switching abruptly at the horizon.
    val solarRayEnvelope = solarProgressForRays?.let { progress ->
        val edge = minOf(progress / .18f, (1f - progress) / .18f).coerceIn(0f, 1f)
        edge * edge * (3f - 2f * edge)
    } ?: 0f
    val sunRays = preferences.sunRaysEnabled && active && solarProgressForRays != null
    val rayTargetAlpha = if (sunRays) {
        ((.30f + solarRayEnergy * .24f) * cloudRayFactor * realismRayFactor * hotRayBoost * solarRayEnvelope).coerceIn(0f, .68f)
    } else 0f
    val rayAlpha by animateFloatAsState(
        targetValue = rayTargetAlpha,
        animationSpec = tween(if (rayTargetAlpha > 0f) 720 else 980, easing = FastOutSlowInEasing),
        label = "atmosSunRaysLifecycle"
    )
    val livingCloudAlpha by animateFloatAsState(
        targetValue = if (livingClouds) (cloudPresence * 1.18f).coerceAtMost(1f) else 0f,
        animationSpec = tween(if (livingClouds) 1800 else 2200, easing = FastOutSlowInEasing),
        label = "atmosLivingCloudLifecycle"
    )
    val hazeAlpha by animateFloatAsState(
        targetValue = if (active && haze) 1f else 0f,
        animationSpec = tween(if (active && haze) 1050 else 1350, easing = FastOutSlowInEasing),
        label = "atmosHazeLifecycle"
    )
    val fogAlpha by animateFloatAsState(
        targetValue = if (active && fog) 1f else 0f,
        animationSpec = tween(if (active && fog) 1050 else 1350, easing = FastOutSlowInEasing),
        label = "atmosFogLifecycle"
    )
    val rainAlpha by animateFloatAsState(
        targetValue = if (active && rain) 1f else 0f,
        animationSpec = tween(if (active && rain) 1800 else 2400, easing = FastOutSlowInEasing),
        label = "atmosRainLifecycle"
    )
    val smoothedRainIntensity by animateFloatAsState(
        targetValue = realism.precipitationIntensity,
        animationSpec = tween(1500, easing = FastOutSlowInEasing),
        label = "atmosRainIntensity"
    )
    val highMotionEffect = rainAlpha > .002f || snow || lightning || wind || heat
    val rayMotion = sunRays && rayAlpha > .002f
    val cloudMotion = livingClouds && livingCloudAlpha > .002f
    val anyEffect = active && (highMotionEffect || rayMotion || cloudMotion || frost || hazeAlpha > .002f || fogAlpha > .002f)

    val weatherEffects60Fps = preferences.weatherEffects60Fps
    var frameNanos by remember { mutableStateOf(0L) }
    LaunchedEffect(anyEffect, weatherEffects60Fps, highMotionEffect, rayMotion, cloudMotion) {
        if (!anyEffect) return@LaunchedEffect
        val frameDelayMs = when {
            weatherEffects60Fps && highMotionEffect -> 16L
            highMotionEffect -> 33L
            rayMotion && !frost && hazeAlpha <= .002f && fogAlpha <= .002f -> 125L // 8 fps: visible slow light drift while remaining lightweight.
            cloudMotion && !rayMotion && !frost && hazeAlpha <= .002f && fogAlpha <= .002f -> 250L // 4 fps is enough for slow cloud-light movement.
            else -> 50L
        }
        while (true) {
            frameNanos = System.nanoTime()
            delay(frameDelayMs)
        }
    }

    val bearing = observation.windBearing ?: compassBearing(observation.direction)
    // Meteorological bearing describes where wind comes from. Convert it into a
    // horizontal screen drift; calm northerly/southerly flow remains near vertical.
    val horizontalWind = (-kotlin.math.sin(Math.toRadians(bearing))).toFloat().coerceIn(-1f, 1f)
    val directionSign = if (horizontalWind < 0f) -1f else 1f
    val directionalStrength = kotlin.math.abs(horizontalWind)
    val speedFactor = (windSpeed / 45f).coerceIn(.15f, 2.2f)
    val t = frameNanos / 1_000_000_000f

    Canvas(modifier) {
        if (livingClouds && livingCloudAlpha > .002f) {
            // Living Clouds are lighting volumes, not literal cloud sprites. A tiny
            // number of enormous feathered forms drift slowly and reshape contrast.
            val cloudTime = t * .035f
            val cloudTint = androidx.compose.ui.graphics.lerp(
                palette.secondary,
                Color(0xFF5C667A),
                .42f
            )
            repeat(3) { index ->
                val phase = cloudTime * (.72f + index * .09f) + index * 2.1f
                val x = size.width * (-.28f + index * .42f) + kotlin.math.sin(phase) * size.width * .16f
                val y = size.height * (.08f + index * .18f) + kotlin.math.cos(phase * .74f) * size.height * .045f
                val w = size.width * (1.22f + index * .18f)
                val h = size.height * (.38f + index * .055f)
                val alpha = livingCloudAlpha * (.14f + index * .026f)
                drawOval(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            cloudTint.copy(alpha = alpha),
                            cloudTint.copy(alpha = alpha * .68f),
                            palette.top.copy(alpha = alpha * .20f),
                            Color.Transparent
                        ),
                        center = Offset(x + w * .50f, y + h * .50f),
                        radius = w * .55f
                    ),
                    topLeft = Offset(x, y),
                    size = Size(w, h)
                )
            }
        }
        if (sunRays && rayAlpha > .002f) {
            val progress = solarProgressForRays ?: .5f
            val solarHeight = kotlin.math.sin(Math.PI * progress).toFloat().coerceIn(0f, 1f)

            // Scene-shaping ray system: two enormous light volumes, with a third only
            // in the clearest / hottest scenes. The broad feathered halos intentionally
            // influence most of the composition rather than reading as small overlays.
            val rayCount = if (cloudRayFactor >= .82f || temperatureC >= 33f) 3 else 2
            val sourceCenterX = size.width * (-.30f + progress * 1.60f)
            val sourceY = -size.height * (.12f + solarHeight * .52f)
            val sourceBand = size.width * .24f
            val slowTime = t * .085f
            val warmAmount = (
                ((temperatureC - 18f) / 20f).coerceIn(0f, 1f) * .72f +
                    (1f - solarHeight) * .28f
                ).coerceIn(0f, 1f)
            val rayColour = androidx.compose.ui.graphics.lerp(
                Color(0xFFFFF9E8),
                Color(0xFFFFB65A),
                warmAmount
            )

            repeat(rayCount) { index ->
                val centred = index - (rayCount - 1) / 2f
                val seed = 1.9f + index * 2.7f
                // Movement is deliberately obvious but very slow: the shafts breathe,
                // widen and sweep across the scene over many seconds.
                val widthBreath = 1f + kotlin.math.sin(slowTime * (.56f + index * .05f) + seed) * .24f
                val positionDrift = kotlin.math.sin(slowTime * (.42f + index * .035f) + seed * .9f) * size.width * .085f
                val intensityBreath = .82f + kotlin.math.sin(slowTime * (.49f + index * .04f) + seed * 1.2f) * .18f

                val sourceX = sourceCenterX + centred * sourceBand + positionDrift
                val solarSlant = size.width * (.46f - progress * .92f)
                val fanSpread = centred * size.width * .34f
                val targetX = sourceX + solarSlant + fanSpread
                val targetY = size.height * (1.18f + (index % 2) * .08f)

                val sourceHalfWidth = size.width * (.035f + (index % 2) * .006f) * widthBreath
                val targetHalfWidth = size.width * (.42f + (index % 2) * .07f) * widthBreath
                val alpha = rayAlpha * intensityBreath
                val origin = Offset(sourceX, sourceY)
                val target = Offset(targetX, targetY)

                fun rayPath(scale: Float) = androidx.compose.ui.graphics.Path().apply {
                    moveTo(origin.x - sourceHalfWidth * scale, origin.y)
                    lineTo(target.x - targetHalfWidth * scale, target.y)
                    lineTo(target.x + targetHalfWidth * scale, target.y)
                    lineTo(origin.x + sourceHalfWidth * scale, origin.y)
                    close()
                }

                // A very broad, low-opacity halo supplies the blurred edge without an
                // expensive runtime blur. Two progressively tighter volumes retain a
                // well-defined centre while the outer light dissolves into the scene.
                drawPath(
                    path = rayPath(1.75f),
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            rayColour.copy(alpha = alpha * .030f),
                            rayColour.copy(alpha = alpha * .072f),
                            rayColour.copy(alpha = alpha * .030f),
                            Color.Transparent
                        ),
                        start = origin,
                        end = target
                    )
                )
                drawPath(
                    path = rayPath(1.12f),
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            rayColour.copy(alpha = alpha * .070f),
                            rayColour.copy(alpha = alpha * .145f),
                            rayColour.copy(alpha = alpha * .060f),
                            Color.Transparent
                        ),
                        start = origin,
                        end = target
                    )
                )
                drawPath(
                    path = rayPath(.58f),
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            rayColour.copy(alpha = alpha * .115f),
                            rayColour.copy(alpha = alpha * .245f),
                            rayColour.copy(alpha = alpha * .095f),
                            Color.Transparent
                        ),
                        start = origin,
                        end = target
                    )
                )
            }
        }

        if (rainAlpha > .002f) {
            val daylight = !isNight(renderTime, place.timeZone())
            val brightScene = paletteBrightness(palette) > .56f
            val intensity = smoothedRainIntensity.coerceIn(0f, 1f)
            val count = (14 + (intensity * 58f).toInt() + windSpeed / 4).coerceIn(16, 84)
            val rainCore = if (daylight && brightScene) Color(0xFF2B6E91) else Color(0xFFC9F3FF)
            val rainHighlight = if (daylight && brightScene) Color.White else Color(0xFF70D8FF)

            // Stable procedural noise gives every drop its own lifecycle. A drop receives
            // a new horizontal origin, depth, length and timing whenever it respawns,
            // preventing the short synchronised loop and repeated vertical groupings that
            // occurred when every particle shared one global modulo phase.
            fun rainNoise(seed: Float): Float {
                val value = kotlin.math.sin(seed * 12.9898f + 78.233f) * 43758.5453f
                return value - kotlin.math.floor(value)
            }

            repeat(count) { index ->
                val particleSeed = index * 17.173f + 3.71f
                val baseDepth = .50f + rainNoise(particleSeed + 1.4f) * .88f
                // Preserve the faster 0.69.9 fall rate while retaining independent
                // procedural lifetimes. The old renderer advanced each drop at this
                // rate; converting it to a duration keeps the same visual speed.
                val legacyFallRate = (.58f + intensity * .58f + speedFactor * .14f)
                    .coerceAtLeast(.58f)
                val baseDuration = 1f / legacyFallRate
                val duration = baseDuration * (.86f + rainNoise(particleSeed + 4.8f) * .28f)
                val timeOffset = rainNoise(particleSeed + 8.1f) * duration * 7f
                val lifetimePosition = (t + timeOffset) / duration
                val generation = kotlin.math.floor(lifetimePosition)
                val phase = lifetimePosition - generation
                val generationSeed = particleSeed + generation * 19.417f

                // Each respawn chooses a fresh origin across an area wider than the
                // display so wind-driven drops can enter naturally from either edge.
                val spawnX = (rainNoise(generationSeed + 2.2f) * 1.34f - .17f) * size.width
                val spawnY = -size.height * (.05f + rainNoise(generationSeed + 5.6f) * .22f)
                val localDepth = (baseDepth * (.82f + rainNoise(generationSeed + 7.9f) * .28f)).coerceIn(.48f, 1.38f)
                val stormVariation = if (realism.weatherInstability > .55f) {
                    .88f + rainNoise(generationSeed + 11.2f) * .28f
                } else 1f
                val fallDistance = size.height * (1.18f + rainNoise(generationSeed + 13.7f) * .28f)
                val windTravel = horizontalWind * size.width *
                    (.045f + speedFactor * .105f) * phase * stormVariation
                val turbulence = kotlin.math.sin(
                    phase * 6.28318f + generationSeed * .37f
                ) * size.width * (.0018f + realism.weatherInstability * .0035f)
                val x = spawnX + windTravel + turbulence
                val y = spawnY + phase * fallDistance

                val lengthVariation = .76f + rainNoise(generationSeed + 17.4f) * .52f
                val streakHeight = size.height * (.030f + intensity * .056f) * localDepth * lengthVariation
                val slant = horizontalWind * size.width *
                    (.009f + .022f * speedFactor) * lengthVariation
                val alphaVariation = .72f + rainNoise(generationSeed + 21.8f) * .28f
                val start = Offset(x, y)
                val end = Offset(x + slant, y + streakHeight)

                drawLine(
                    rainCore.copy(
                        alpha = rainAlpha * (if (daylight) .47f else .36f) *
                            localDepth.coerceAtMost(1f) * alphaVariation
                    ),
                    start,
                    end,
                    strokeWidth = (if (daylight) 1.7f else 1.45f) * localDepth,
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
                drawLine(
                    rainHighlight.copy(
                        alpha = rainAlpha * (if (daylight) .36f else .28f) * alphaVariation
                    ),
                    start,
                    end,
                    strokeWidth = .62f * localDepth,
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            }
        }

        if (snow) {
            repeat(28) { index ->
                val phase = ((t * (.055f + speedFactor * .018f) + index * .113f) % 1f)
                val x = (((index * 83) % 997) / 997f * size.width +
                    kotlin.math.sin(t * .5f + index) * size.width * .025f +
                    directionSign * phase * size.width * .08f) % size.width
                val y = phase * size.height
                val shimmer = .30f + .16f * (.5f + .5f * kotlin.math.sin(t * .9f + index * .7f))
                drawCircle(
                    Color.White.copy(alpha = shimmer),
                    radius = 1.7f + (index % 4) * .65f,
                    center = Offset(x, y)
                )
            }
        }

        if (heat) {
            repeat(7) { index ->
                val y = size.height * (.48f + index * .055f)
                val wave = kotlin.math.sin(t * (1.05f + index * .04f) + index * .8f) * size.width * .018f
                val alpha = .032f + .022f * (.5f + .5f * kotlin.math.sin(t * .65f + index))
                drawLine(
                    Color.White.copy(alpha = alpha),
                    Offset(size.width * .08f + wave, y),
                    Offset(size.width * .92f - wave, y - size.height * .009f),
                    strokeWidth = 1.8f + (index % 2) * .5f,
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            }
        }

        if (frost) {
            val frostColor = Color(0xFFE5FAFF)
            val pulse = .78f + .22f * (.5f + .5f * kotlin.math.sin(t * .18f))

            // A broad iced-glass bloom concentrated around the upper and side edges.
            drawRect(
                Brush.verticalGradient(
                    listOf(frostColor.copy(alpha = .15f * pulse), frostColor.copy(alpha = .045f), Color.Transparent),
                    endY = size.height * .46f
                )
            )
            drawRect(
                Brush.horizontalGradient(
                    listOf(frostColor.copy(alpha = .10f), Color.Transparent, frostColor.copy(alpha = .075f))
                )
            )

            // Larger deterministic frost grains, like crystals collecting on a windscreen.
            repeat(42) { index ->
                val edgeBias = index % 3
                val x = when (edgeBias) {
                    0 -> ((index * 97) % 260) / 1000f * size.width
                    1 -> size.width * (1f - ((index * 113) % 240) / 1000f)
                    else -> ((index * 149) % 1000) / 1000f * size.width
                }
                val y = ((index * 71) % 460) / 1000f * size.height
                val sparkle = (.5f + .5f * kotlin.math.sin(t * .38f + index * 1.37f)).coerceIn(0f, 1f)
                val radius = 2.2f + (index % 4) * 1.05f
                val alpha = .12f + sparkle * .24f
                drawCircle(frostColor.copy(alpha = alpha), radius = radius, center = Offset(x, y))

                if (index % 4 == 0) {
                    val branch = radius * 2.8f
                    drawLine(
                        frostColor.copy(alpha = alpha * .72f),
                        Offset(x - branch, y), Offset(x + branch, y),
                        strokeWidth = 1.15f, cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                    drawLine(
                        frostColor.copy(alpha = alpha * .62f),
                        Offset(x, y - branch), Offset(x, y + branch),
                        strokeWidth = 1.05f, cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                    drawLine(
                        frostColor.copy(alpha = alpha * .48f),
                        Offset(x - branch * .7f, y - branch * .7f),
                        Offset(x + branch * .7f, y + branch * .7f),
                        strokeWidth = .9f, cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                }
            }
        }

        if (lightning) {
            val cycle = ((t + 3.7f) % 13.7f)
            val flash = when {
                cycle < .07f -> .24f
                cycle in .13f..20f -> .10f
                cycle in .31f..36f -> .16f
                else -> 0f
            }
            if (flash > 0f) {
                drawRect(Color.White.copy(alpha = flash))
                drawOval(
                    brush = Brush.radialGradient(
                        listOf(Color.White.copy(alpha = flash * .65f), Color.Transparent),
                        center = Offset(size.width * .68f, size.height * .20f),
                        radius = size.width * .72f
                    ),
                    topLeft = Offset(-size.width * .04f, -size.height * .20f),
                    size = androidx.compose.ui.geometry.Size(size.width * 1.44f, size.height * .75f)
                )
            }
        }
    }
}

@Composable
private fun AtmosSceneRenderer(
    palette: Palette,
    observation: Observation,
    condition: String,
    temperatureC: Int,
    place: Place,
    enabled: Boolean,
    preferences: AtmosPreferences,
    modifier: Modifier = Modifier,
    renderProfile: AtmosRenderProfile = AtmosRenderProfile.Full,
    simulationActive: Boolean = true,
    sceneTime: Date? = null
) {
    var liveSolarClock by remember(place.cacheKey()) { mutableStateOf(Date()) }
    LaunchedEffect(place.cacheKey(), sceneTime == null) {
        if (sceneTime == null) {
            while (true) {
                val now = System.currentTimeMillis()
                delay(60_000L - (now % 60_000L))
                liveSolarClock = Date()
            }
        }
    }
    val solarClock = sceneTime ?: liveSolarClock

    val solarMinute = solarClock.time / 60_000L
    val night = remember(place.cacheKey(), solarMinute) { isNight(solarClock, place.timeZone()) }
    val solarTimes = remember(place.cacheKey(), solarClock.time / 86_400_000L) {
        calculateSolarTimes(solarClock, place.latitude, place.longitude, place.timeZone())
    }
    val solarProgress = remember(solarTimes, solarClock.time, night) {
        solarTimes?.let { (sunrise, sunset) ->
            if (solarClock.before(sunrise) || !solarClock.before(sunset)) null
            else ((solarClock.time - sunrise.time).toDouble() / (sunset.time - sunrise.time).toDouble())
                .coerceIn(0.0, 1.0)
                .toFloat()
        }
    }
    val solarEnergy = remember(solarProgress, night) {
        solarProgress?.let { progress ->
            kotlin.math.sin(Math.PI * progress).toFloat().coerceIn(0f, 1f)
        } ?: if (night) 0f else .72f
    }
    val localHour = remember(place.cacheKey(), solarMinute) {
        Calendar.getInstance(place.timeZone()).apply { time = solarClock }.get(Calendar.HOUR_OF_DAY)
    }
    val oledFraction = remember(solarTimes, solarClock.time, night, localHour) {
        when {
            !night -> 0f
            localHour < 6 -> 1f
            solarTimes == null -> 1f
            else -> {
                val start = solarTimes.second.time + 45L * 60_000L
                val end = solarTimes.second.time + 60L * 60_000L
                ((solarClock.time - start).toFloat() / (end - start).toFloat()).coerceIn(0f, 1f)
            }
        }
    }
    val lateNightAttenuation = 1f - oledFraction * .72f
    val season = remember(place.cacheKey(), solarMinute / (24L * 60L)) { seasonName(place) }
    val thermal = ((temperatureC - 18f) / 17f).coerceIn(-1f, 1f)

    // Unified Atmos Lighting inputs. These values are deliberately bounded and
    // combined into one scene pass so no environmental variable competes with
    // the established condition/solar palette.
    val humidity = (observation.humidity ?: 55).coerceIn(0, 100) / 100f
    val pressureNormalised = (((observation.pressure ?: 1013.25) - 1013.25) / 32.0)
        .toFloat().coerceIn(-1f, 1f)
    val conditionLower = condition.lowercase(Locale.ENGLISH)
    val cloudWeight = when {
        conditionLower.contains("thunder") || conditionLower.contains("storm") -> .92f
        conditionLower.contains("rain") || conditionLower.contains("shower") -> .78f
        conditionLower.contains("overcast") -> .84f
        conditionLower.contains("cloud") -> .58f
        conditionLower.contains("fog") || conditionLower.contains("mist") -> .72f
        else -> .10f
    }
    val visibilityClarity = (1f - humidity * .42f - cloudWeight * .24f).coerceIn(.25f, 1f)
    val atmosphericSoftness = (humidity * .58f + (1f - visibilityClarity) * .42f).coerceIn(0f, 1f)

    val seasonLight = remember(season) {
        when (season) {
            "Summer" -> Triple(1.08f, .92f, Color(0xFFFFF1C7))
            "Winter" -> Triple(.82f, 1.22f, Color(0xFFFFD6A1))
            "Spring" -> Triple(.98f, 1.00f, Color(0xFFFFE7B5))
            "Autumn" -> Triple(.88f, 1.16f, Color(0xFFFFC889))
            "Wet season" -> Triple(.92f, 1.05f, Color(0xFFFFE2B2))
            "Dry season" -> Triple(1.04f, .96f, Color(0xFFFFD99A))
            else -> Triple(1f, 1f, Color(0xFFFFE5A3))
        }
    }

    // Synodic moon phase approximation (0=new, 0.5=full). It is sufficient for
    // lighting character and avoids adding a network/data dependency.
    val moonPhase = remember(solarMinute / (24L * 60L)) {
        val knownNewMoon = 947182440000L // 2000-01-06 18:14 UTC
        val synodicMonthMs = 29.530588853 * 86_400_000.0
        (((solarClock.time - knownNewMoon) % synodicMonthMs + synodicMonthMs) % synodicMonthMs / synodicMonthMs).toFloat()
    }
    val moonIllumination = ((1f - kotlin.math.cos(2.0 * Math.PI * moonPhase).toFloat()) * .5f)
        .coerceIn(0f, 1f)
    val nightDepth = if (night) {
        solarTimes?.let { (_, sunset) ->
            ((solarClock.time - sunset.time).toFloat() / (150f * 60_000f)).coerceIn(0f, 1f)
        } ?: 1f
    } else 0f
    val starVisibility = (nightDepth * visibilityClarity * (1f - cloudWeight) * (1f - moonIllumination * .58f))
        .coerceIn(0f, 1f)
    val starField = remember(place.cacheKey()) {
        val seed = place.cacheKey().hashCode().toLong()
        List(34) { index ->
            val a = kotlin.math.abs((seed * 1103515245L + index * 12345L + 0x9E3779B9L).toInt())
            val b = kotlin.math.abs((seed * 1664525L + index * 1013904223L).toInt())
            Triple((a % 1000) / 1000f, .04f + (b % 510) / 1000f, .45f + ((a / 11) % 55) / 100f)
        }
    }

    // Palette changes are intentionally capped at roughly 30 fps. There is no reason
    // to drive a full-screen gradient at the display refresh rate when it only changes
    // after a weather/location update or solar-period transition.
    var displayedPalette by remember(place.cacheKey()) { mutableStateOf(palette) }
    LaunchedEffect(palette) {
        val startPalette = displayedPalette
        val steps = 27
        repeat(steps) { index ->
            val raw = (index + 1f) / steps.toFloat()
            val eased = FastOutSlowInEasing.transform(raw)
            displayedPalette = blendPalette(startPalette, palette, eased)
            delay(33L)
        }
        displayedPalette = palette
    }

    val seasonalColour = remember(season) {
        when (season) {
            "Spring" -> Color(0xFFFFAFCB)
            "Summer" -> Color(0xFFFFC765)
            "Autumn" -> Color(0xFFD97B45)
            "Winter" -> Color(0xFFB6E5FF)
            "Wet season" -> Color(0xFF63C8B2)
            "Dry season" -> Color(0xFFE0AD68)
            else -> Color.Transparent
        }
    }
    val thermalColour = if (thermal >= 0f) Color(0xFFFFB45E) else Color(0xFF8DDCFF)
    val thermalAlpha = kotlin.math.abs(thermal) * if (thermal >= 0f) .32f else .35f
    val solarColour = if (night) Color(0xFFB7CCFF) else seasonLight.third
    val humidityDiffusion = .78f + atmosphericSoftness * .48f
    val pressureLight = 1f + pressureNormalised * .08f
    val solarAlpha = if (solarProgress == null) 0f else
        ((.09f + solarEnergy * .21f) * seasonLight.first * humidityDiffusion * pressureLight * lateNightAttenuation)
            .coerceIn(0f, .36f)
    val solarX = solarProgress?.let { .08f + (.84f * it) } ?: .50f
    val solarY = solarProgress?.let { progress ->
        val arc = kotlin.math.sin(Math.PI * progress).toFloat().coerceIn(0f, 1f)
        val seasonalArcHeight = .34f * seasonLight.first.coerceIn(.76f, 1.10f)
        .47f - (seasonalArcHeight * arc)
    } ?: .18f
    val glareRadiusScale = seasonLight.second * (1f + atmosphericSoftness * .22f)
    val moonAlpha = (nightDepth * moonIllumination * visibilityClarity * (1f - cloudWeight * .62f) * .16f)
        .coerceIn(0f, .16f)
    val moonX = .82f - moonPhase * .64f
    val moonY = .19f + kotlin.math.abs(moonPhase - .5f) * .13f
    val cloudShadowAlpha = (cloudWeight * (.025f + (1f - pressureNormalised) * .018f) * if (night) .35f else 1f)
        .coerceIn(0f, .075f)

    val atmosIntensity = LocalAtmosIntensityChoice.current
    val sceneSpec = remember(
        displayedPalette, observation, condition, temperatureC, place.cacheKey(), solarMinute, enabled, atmosIntensity
    ) {
        buildAtmosSceneSpec(
            palette = displayedPalette,
            observation = observation,
            condition = condition,
            temperatureC = temperatureC,
            place = place,
            now = solarClock,
            enabled = enabled,
            intensity = atmosIntensity
        )
    }

    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            drawContext.canvas.nativeCanvas.let { nativeCanvas ->
                SharedAtmosSceneRenderer.render(
                    canvas = nativeCanvas,
                    width = size.width.toInt(),
                    height = size.height.toInt(),
                    spec = sceneSpec,
                    immersive = false
                )
            }
        }
        AtmosWeatherEffectsLayer(
            observation = observation,
            condition = condition,
            temperatureC = temperatureC,
            palette = displayedPalette,
            preferences = preferences,
            place = place,
            renderTime = solarClock,
            modifier = Modifier.fillMaxSize(),
            active = simulationActive
        )
    }
}

private fun buildAtmosStory(
    weather: WeatherState,
    temperatureUnit: TemperatureUnit,
    focusTime: Date? = null
): String {
    val now = focusTime ?: Date()
    val upcoming = weather.hours.filter { it.time.time >= now.time }.take(18)
    val day = weather.days.firstOrNull()
    if (upcoming.isEmpty() || day == null) {
        return localForecastSummary(weather, 0, temperatureUnit, maxSentences = 2)
    }
    val first = upcoming.first()
    val last = upcoming.last()
    val warmest = upcoming.maxByOrNull { it.temp } ?: first
    val wettest = upcoming.maxByOrNull { it.rainChance } ?: first
    val tempChange = last.temp - first.temp
    val conditionText = (day.condition + " " + upcoming.joinToString(" ") { it.icon }).lowercase(Locale.ENGLISH)
    val format = SimpleDateFormat("h a", Locale.getDefault()).apply { timeZone = weather.place.timeZone() }
    val opening = when {
        conditionText.contains("storm") || conditionText.contains("thunder") -> "The atmosphere feels charged today"
        conditionText.contains("fog") || conditionText.contains("mist") -> "The day begins wrapped in soft, muted air"
        wettest.rainChance >= 65 -> "Cloud and moisture gradually take control of the day"
        conditionText.contains("snow") -> "A cold, quiet atmosphere settles over the day"
        first.humidity >= 82 -> "The air starts heavy and close"
        first.wind >= 30 -> "Moving air defines the day from the beginning"
        else -> "The day opens with ${day.condition.lowercase(Locale.ENGLISH)}"
    }
    val middle = when {
        wettest.rainChance >= 65 -> "rain becomes most likely around ${format.format(wettest.time)}"
        warmest.temp >= 34 -> "the heat builds towards ${format.format(warmest.time)}"
        tempChange >= 5 -> "the warmth steadily builds as the hours unfold"
        tempChange <= -5 -> "cooler air gradually takes over"
        upcoming.any { it.wind >= 35 } -> "a stronger breeze adds movement later on"
        else -> "the atmosphere changes gently rather than dramatically"
    }
    val ending = when {
        last.rainChance >= 55 -> "The later hours remain unsettled."
        last.temp <= first.temp - 4 -> "A noticeably cooler finish follows."
        conditionText.contains("clear") || conditionText.contains("sunny") -> "Light and colour should remain the defining feature."
        else -> "The day eases away without a sharp change."
    }
    return "$opening; $middle. $ending"
}

@Composable
private fun HeroCard(
    weather: WeatherState,
    palette: Palette,
    temperatureUnit: TemperatureUnit,
    preferences: AtmosPreferences,
    conditionAnimations: Boolean,
    forecastPage: Int,
    forecastPageCount: Int,
    onPage: (Page) -> Unit,
    onTemperatureUnit: (TemperatureUnit) -> Unit,
    onOpenLocations: () -> Unit,
    onSeason: (String, Place) -> Unit,
    animateTemperature: Boolean = true,
    refreshing: Boolean = false,
    immersive: Boolean = false,
    place: Place? = null,
    history: List<HistoricalObservation> = emptyList(),
    topInset: androidx.compose.ui.unit.Dp = 0.dp,
    renderAtmosphere: Boolean = true,
    darkLowerSection: Boolean = false,
    atmosphereSimulationActive: Boolean = true,
    compact: Boolean = false
) {
    val ambientDisplayUi = LocalAmbientDisplayUi.current
    val ambientControlsAlpha by animateFloatAsState(
        targetValue = if (!ambientDisplayUi.active || ambientDisplayUi.controlsVisible) 1f else 0f,
        animationSpec = tween(durationMillis = if (ambientDisplayUi.controlsVisible) 600 else 900, easing = FastOutSlowInEasing),
        label = "ambient-controls"
    )

    var ambientDriftStep by remember { mutableStateOf(0) }
    LaunchedEffect(ambientDisplayUi.active, ambientDisplayUi.controlsVisible) {
        ambientDriftStep = 0
        if (ambientDisplayUi.active && !ambientDisplayUi.controlsVisible) {
            while (true) {
                delay(60_000L)
                ambientDriftStep = (ambientDriftStep + 1) % 8
            }
        }
    }
    val driftTargets = listOf(0.dp to 0.dp, 1.dp to 0.dp, 1.dp to 1.dp, 0.dp to 1.dp, (-1).dp to 1.dp, (-1).dp to 0.dp, (-1).dp to (-1).dp, 0.dp to (-1).dp)
    val driftTarget = if (ambientDisplayUi.active && !ambientDisplayUi.controlsVisible) driftTargets[ambientDriftStep] else 0.dp to 0.dp
    val ambientDriftX by animateDpAsState(driftTarget.first, tween(1_600), label = "ambient-drift-x")
    val ambientDriftY by animateDpAsState(driftTarget.second, tween(1_600), label = "ambient-drift-y")

    val day = weather.days.first()
    val sharedNowMillis = sharedMinuteMillis()
    val clockNow = remember(weather.place.cacheKey(), sharedNowMillis) { Date(sharedNowMillis) }
    val temp = weather.observation.temp ?: day.high - 2
    var scrubTargetHours by remember(weather.place.cacheKey()) { mutableStateOf<Float?>(null) }
    val scrubHours by animateFloatAsState(
        targetValue = scrubTargetHours ?: 0f,
        animationSpec = tween(
            durationMillis = if (scrubTargetHours == null) 900 else 75,
            easing = FastOutSlowInEasing
        ),
        label = "hero-timeline-scrub"
    )
    val scrubActive = scrubTargetHours != null || scrubHours > .02f
    val scrubTime = remember(clockNow.time, scrubHours) { Date(clockNow.time + (scrubHours * 60f * 60f * 1000f).toLong()) }
    val scrubHour = remember(weather.hours, scrubTime.time) { interpolateHourForecast(weather.hours, scrubTime) }
    val displayedTemp = if (scrubActive) scrubHour?.temp ?: temp else temp
    val displayedCondition = if (scrubActive) scrubHour?.let { hourConditionLabel(it.icon) } ?: day.condition else day.condition
    val displayedObservation = if (scrubActive && scrubHour != null) weather.observation.copy(
        temp = scrubHour.temp,
        feels = scrubHour.temp,
        humidity = scrubHour.humidity,
        wind = scrubHour.wind,
        direction = scrubHour.direction
    ) else weather.observation
    // The settled Hero must consume the exact same palette already prepared by
    // ForecastPage and used as the source of truth for the location scene. Previous
    // builds always supplied scrubHour.icon here, even when scrubbing was inactive,
    // which made the card use the nearest hourly forecast icon while Immersive used
    // the current/day icon. It also created a second independent palette animation.
    // Only create a dedicated scene while the user is actively scrubbing.
    val scrubbedPalette = rememberSolarAwarePalette(
        if (scrubActive) scrubHour?.icon ?: day.icon else day.icon,
        weather.place,
        displayedObservation,
        displayedCondition,
        now = if (scrubActive) scrubTime else null,
        fastTransition = scrubActive
    )
    val displayedPalette = if (scrubActive) scrubbedPalette else palette
    val night = isNight(if (scrubActive) scrubTime else Date(), weather.place.timeZone())
    val narrative = remember(
        weather.updated.time,
        weather.place.cacheKey(),
        temperatureUnit,
        weather.hours,
        weather.days,
        weather.observation,
        scrubActive,
        scrubTime.time / 1_800_000L
    ) {
        buildAtmosStory(
            weather = weather,
            temperatureUnit = temperatureUnit,
            focusTime = if (scrubActive) scrubTime else null
        )
    }
    // Compact mode intentionally omits the secondary condition narrative because the
    // same day summary is presented immediately below in Today at a glance. Expanded
    // and immersive-expanded layouts retain the richer narrative treatment.
    val nativeNavigationInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val nativeNavigationHeight = 80.dp + nativeNavigationInset
    val heroHeight = if (immersive) {
        if (compact) 498.dp else (LocalConfiguration.current.screenHeightDp.dp - nativeNavigationHeight).coerceAtLeast(560.dp)
    } else if (compact) {
        413.dp
    } else 535.dp
    val heroShape = RoundedCornerShape(if (immersive) 0.dp else 38.dp)
    Card(
        Modifier
            .fillMaxWidth()
            .height(heroHeight)
            .then(
                if (compact && !immersive) Modifier.shadow(
                    elevation = 12.dp,
                    shape = heroShape,
                    clip = false,
                    ambientColor = displayedPalette.bottom.copy(alpha = .16f),
                    spotColor = Color.Black.copy(alpha = .18f)
                ) else Modifier
            ),
        shape = heroShape,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(Modifier.fillMaxSize()) {
            if (renderAtmosphere || scrubActive) {
                AtmosSceneRenderer(
                    palette = displayedPalette,
                    observation = displayedObservation,
                    condition = displayedCondition,
                    temperatureC = displayedObservation.feels ?: displayedTemp,
                    place = weather.place,
                    enabled = true,
                    preferences = preferences,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            alpha = if (renderAtmosphere) 1f else (scrubHours / .18f).coerceIn(0f, 1f)
                        },
                    renderProfile = if (atmosphereSimulationActive) AtmosRenderProfile.Full else AtmosRenderProfile.Compact,
                    simulationActive = atmosphereSimulationActive,
                    sceneTime = if (scrubActive) scrubTime else null
                )
            }
            Column(
                Modifier.fillMaxSize().offset(x = ambientDriftX, y = ambientDriftY).padding(
                    start = if (immersive) 28.dp else 28.dp,
                    end = if (immersive) 28.dp else 28.dp,
                    top = if (immersive) topInset + 4.dp else 28.dp,
                    bottom = if (immersive) 18.dp else 28.dp
                )
            ) {
                if (immersive && place != null) {
                    val displayPlace = place
                    val overlayText = solarLegibleForeground(displayedPalette, MaterialTheme.colorScheme.background)
                    Row(Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onOpenLocations).padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        ConditionGradientLocationName(displayPlace.name, displayedPalette, overlayText, 31.sp)
                        if (place.current) {
                            Surface(
                                Modifier.padding(start = 10.dp),
                                shape = CircleShape,
                                color = overlayText.copy(alpha = .16f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, overlayText.copy(alpha = .46f))
                            ) {
                                Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                                    Canvas(Modifier.size(12.dp)) {
                                        val marker = Path().apply {
                                            moveTo(size.width * .14f, size.height * .46f)
                                            lineTo(size.width * .86f, size.height * .12f)
                                            lineTo(size.width * .59f, size.height * .88f)
                                            lineTo(size.width * .46f, size.height * .57f)
                                            close()
                                        }
                                        drawPath(marker, overlayText)
                                    }
                                    Spacer(Modifier.width(5.dp))
                                    Text("LIVE", color = overlayText, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                    Text(displayPlace.state, color = overlayText.copy(.74f), fontSize = 14.sp)
                    if (place.current && weather.observation.station.isNotBlank()) {
                        Text("Weather from ${weather.observation.station}", color = overlayText.copy(.62f), fontSize = 11.sp)
                    }
                    AnimatedVisibility(
                        visible = refreshing,
                        enter = fadeIn(tween(180)) + expandVertically(tween(220)),
                        exit = fadeOut(tween(180)) + shrinkVertically(tween(220))
                    ) {
                        Box(Modifier.padding(top = 10.dp, bottom = 2.dp)) {
                            AtmosRefreshIndicator(palette, compact = true)
                        }
                    }
                    Spacer(Modifier.height(if (refreshing) 12.dp else 22.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    SeasonPill(place = weather.place, onClick = { onSeason(seasonName(weather.place), weather.place) })
                    when {
                        !weather.place.isAustralian() -> CountryPill(weather.place, clockNow)
                        else -> AustralianTimePill(weather.place, clockNow)
                    }
                }
                Spacer(Modifier.height(18.dp))
                // Card style uses one contrast decision for the complete hero rather than
                // allowing upper and lower regions to switch independently.
                val heroText = if (immersive) {
                    // Follow the currently displayed (including scrubbed) Atmos scene so
                    // typography flips cleanly between light and dark across day/night.
                    solarLegibleForeground(displayedPalette, MaterialTheme.colorScheme.background)
                } else {
                    // Card style follows the app's single foreground mode so the Hero,
                    // forecast cards, labels and charts never disagree about light/dark.
                    MaterialTheme.colorScheme.onSurface
                }
                Text(localFormatter("EEEE d MMMM", weather.place).format(if (scrubActive) scrubTime else clockNow), color = heroText.copy(.78f), fontWeight = FontWeight.Bold)
                val apparentTemperature = displayedObservation.feels ?: displayedTemp
                val temperatureAccent = when {
                    apparentTemperature <= 5 -> Color(0xFFB9E7FF)
                    apparentTemperature >= 28 -> Color(0xFFFFC079)
                    else -> heroText
                }
                val animatedTemperature by animateIntAsState(
                    targetValue = displayTemperature(displayedTemp, temperatureUnit),
                    animationSpec = tween(durationMillis = if (animateTemperature) 560 else 0),
                    label = "heroTemperature"
                )
                val trend = remember(weather.updated.time, weather.place.cacheKey(), temp) {
                    temperatureTrend(weather)
                }
                var trendMotionTarget by remember(weather.place.cacheKey()) { mutableStateOf(0f) }
                LaunchedEffect(weather.updated.time, trend) {
                    if (animateTemperature && trend != TemperatureTrend.Steady) {
                        trendMotionTarget = trend.motionDirection * 4f
                        delay(120L)
                        trendMotionTarget = 0f
                    } else {
                        trendMotionTarget = 0f
                    }
                }
                val trendMotion by animateFloatAsState(
                    targetValue = trendMotionTarget,
                    animationSpec = tween(durationMillis = 620, easing = FastOutSlowInEasing),
                    label = "heroTemperatureTrendMotion"
                )
                val temperatureDigits = animatedTemperature.toString().length
                val compactTemperatureSize = when {
                    !compact -> 90.sp
                    LocalConfiguration.current.screenWidthDp >= 430 && temperatureDigits <= 2 -> 114.sp
                    LocalConfiguration.current.screenWidthDp >= 390 && temperatureDigits <= 2 -> 108.sp
                    temperatureDigits <= 2 -> 102.sp
                    else -> 94.sp
                }
                val compactDegreeSize = if (compact) (compactTemperatureSize.value * .36f).sp else 34.sp
                val heroGradientBrush = remember(displayedPalette, heroText) {
                    Brush.linearGradient(
                        listOf(
                            blendColor(displayedPalette.accent, heroText, .24f),
                            heroText,
                            blendColor(displayedPalette.secondary, heroText, .38f)
                        )
                    )
                }
                val useGradientHeroTypography = preferences.gradientHeroTypography
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AnimatedContent(
                        targetState = temperatureUnit,
                        transitionSpec = {
                            if (animateTemperature) {
                                (fadeIn(tween(300)) + scaleIn(initialScale = .94f, animationSpec = tween(440))) togetherWith
                                    (fadeOut(tween(180)) + scaleOut(targetScale = 1.04f, animationSpec = tween(240)))
                            } else {
                                fadeIn(tween(0)) togetherWith fadeOut(tween(0))
                            }
                        },
                        label = "heroTemperatureUnit"
                    ) {
                        Text(
                            text = buildAnnotatedString {
                                append(animatedTemperature.toString())
                                withStyle(
                                    SpanStyle(
                                        fontSize = compactDegreeSize,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 0.sp,
                                        baselineShift = BaselineShift.Superscript
                                    )
                                ) {
                                    append("°${trend.symbol}")
                                }
                            },
                            modifier = Modifier
                                .graphicsLayer { translationY = trendMotion }
                                .clip(RoundedCornerShape(20.dp))
                                .clickable {
                                    onTemperatureUnit(if (temperatureUnit == TemperatureUnit.Celsius) TemperatureUnit.Fahrenheit else TemperatureUnit.Celsius)
                                }
                                .padding(end = 8.dp),
                            color = if (useGradientHeroTypography) Color.Unspecified else blendColor(heroText, temperatureAccent, if (temp <= 5 || temp >= 28) .16f else 0f),
                            style = TextStyle(
                                brush = if (useGradientHeroTypography) heroGradientBrush else null,
                                fontSize = compactTemperatureSize,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = (-5).sp
                            )
                        )
                    }
                    AnimatedVisibility(
                        visible = temperatureUnit == TemperatureUnit.Fahrenheit,
                        enter = fadeIn(tween(220)) + scaleIn(initialScale = .88f, animationSpec = tween(280)),
                        exit = fadeOut(tween(150)) + scaleOut(targetScale = .90f, animationSpec = tween(180))
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = heroText.copy(alpha = .15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, heroText.copy(alpha = .34f))
                        ) {
                            Text(
                                "°F",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                color = heroText,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = .5.sp
                            )
                        }
                    }
                }
                Text(
                    nightCondition(displayedCondition),
                    color = if (useGradientHeroTypography) Color.Unspecified else heroText,
                    style = TextStyle(
                        brush = if (useGradientHeroTypography) heroGradientBrush else null,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text("Feels like ${displayTemperature(displayedObservation.feels ?: displayedTemp - 1, temperatureUnit)}° · H ${displayTemperature(day.high, temperatureUnit)}° · L ${displayTemperature(day.low, temperatureUnit)}°", color = heroText.copy(.82f), fontSize = 16.sp)
                if (!compact) {
                    Text(
                        narrative,
                        Modifier.padding(top = 22.dp).widthIn(max = 310.dp).alpha(ambientControlsAlpha),
                        color = heroText.copy(.84f),
                        fontSize = 14.sp,
                        lineHeight = 21.sp
                    )
                }
                if (immersive && !compact) {
                    ImmersiveDayChart(
                        hours = weather.hours,
                        temperatureUnit = temperatureUnit,
                        palette = displayedPalette,
                        place = place ?: weather.place,
                        history = history,
                        darkLowerSection = darkLowerSection,
                        scrubPositionHours = scrubTargetHours,
                        scrubReferenceTime = clockNow,
                        onScrub = { scrubTargetHours = it },
                        modifier = Modifier.padding(top = 16.dp, bottom = 12.dp).weight(1f).alpha(ambientControlsAlpha)
                    )
                } else if (compact) {
                    Spacer(Modifier.height(18.dp))
                } else {
                    Spacer(Modifier.weight(1f))
                }
                if (!compact) {
                    // Expanded keeps the original in-hero handle position: between the
                    // flexible hero content and the condition details strip.
                    val indicatorForeground = if (immersive) {
                        if (darkLowerSection) immersiveLowerForeground(displayedPalette, MaterialTheme.colorScheme.background) else heroLowerForeground(displayedPalette)
                    } else heroText
                    val oledHandle = LocalOledCardMode.current
                    val lightInterface = MaterialTheme.colorScheme.background.luminance() >= .50f
                    val conditionHandle = blendColor(displayedPalette.accent, displayedPalette.secondary, .24f)
                    val lightModeHandle = Color(
                        red = (conditionHandle.red * .52f).coerceIn(0f, 1f),
                        green = (conditionHandle.green * .52f).coerceIn(0f, 1f),
                        blue = (conditionHandle.blue * .52f).coerceIn(0f, 1f),
                        alpha = 1f
                    )
                    val visibleIndicatorForeground = if (lightInterface) {
                        lightModeHandle
                    } else indicatorForeground?.let { foreground ->
                        if (foreground.luminance() < .34f || displayedPalette.bottom.luminance() < .26f) {
                            blendColor(displayedPalette.accent, Color.White, .74f)
                        } else foreground
                    }
                    ForecastPageIndicator(
                        current = forecastPage,
                        count = forecastPageCount,
                        modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 13.dp).alpha(ambientControlsAlpha),
                        selectedColour = if (oledHandle) Color(0xFFD7E7FA) else visibleIndicatorForeground?.copy(alpha = .98f),
                        unselectedColour = if (oledHandle) Color(0xFFD7E7FA).copy(alpha = .40f) else visibleIndicatorForeground?.copy(alpha = .54f)
                    )
                }
            }
        }
    }
}

private fun interpolateHourForecast(hours: List<HourForecast>, target: Date): HourForecast? {
    val sorted = hours.sortedBy { it.time.time }
    if (sorted.isEmpty()) return null
    val before = sorted.lastOrNull { it.time.time <= target.time } ?: sorted.first()
    val after = sorted.firstOrNull { it.time.time >= target.time } ?: sorted.last()
    if (before.time.time == after.time.time) return before
    val progress = ((target.time - before.time.time).toFloat() / (after.time.time - before.time.time).toFloat()).coerceIn(0f, 1f)
    fun lerpInt(a: Int, b: Int) = (a + (b - a) * progress).toInt()
    return HourForecast(
        time = target,
        temp = lerpInt(before.temp, after.temp),
        icon = if (progress < .5f) before.icon else after.icon,
        rainChance = lerpInt(before.rainChance, after.rainChance),
        humidity = lerpInt(before.humidity, after.humidity),
        wind = lerpInt(before.wind, after.wind),
        direction = if (progress < .5f) before.direction else after.direction
    )
}

private fun hourConditionLabel(icon: String): String {
    val value = icon.lowercase(Locale.ENGLISH)
    return when {
        value.contains("thunder") || value.contains("storm") -> "Thunderstorms"
        value.contains("snow") -> "Snow"
        value.contains("rain") || value.contains("shower") -> "Showers"
        value.contains("fog") || value.contains("mist") || value.contains("haze") -> "Foggy"
        value.contains("cloud") || value.contains("overcast") -> "Cloudy"
        value.contains("clear") || value.contains("sun") -> "Clear"
        else -> icon.replace('-', ' ').replaceFirstChar { it.uppercase() }
    }
}

@Composable
private fun ImmersiveDayChart(
    hours: List<HourForecast>,
    temperatureUnit: TemperatureUnit,
    palette: Palette,
    place: Place,
    history: List<HistoricalObservation>,
    darkLowerSection: Boolean,
    scrubPositionHours: Float? = null,
    scrubReferenceTime: Date = Date(),
    onScrub: (Float?) -> Unit = {},
    modifier: Modifier = Modifier
) {
    // This chart is intentionally forecast-only: it begins at the current hour and
    // continues for the following 24 hours. Historical observations are not mixed in.
    val window = remember(hours, place.timeZoneId) {
        val now = Calendar.getInstance(place.timeZone())
        val start = (now.clone() as Calendar).apply {
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.time
        val end = Calendar.getInstance(place.timeZone()).apply {
            time = start
            add(Calendar.HOUR_OF_DAY, 24)
        }.time
        start to end
    }
    val forecastWindow = remember(hours, window) {
        val sorted = hours
            .filter { it.time.time >= window.first.time && it.time.time <= window.second.time }
            .sortedBy { it.time.time }

        // Keep one point for every hour across the complete 24-hour window. BOM normally
        // supplies hourly points; nearest-neighbour filling only protects against a gap.
        (0..24).mapNotNull { offset ->
            val target = Calendar.getInstance(place.timeZone()).apply {
                time = window.first
                add(Calendar.HOUR_OF_DAY, offset)
            }.time
            sorted.minByOrNull { kotlin.math.abs(it.time.time - target.time) }
                ?.takeIf { kotlin.math.abs(it.time.time - target.time) <= 90L * 60L * 1000L }
                ?.copy(time = target)
        }
    }
    if (forecastWindow.size < 2) return

    val temperatures = remember(forecastWindow, temperatureUnit) {
        forecastWindow.map { displayTemperature(it.temp, temperatureUnit) }
    }
    val minimum = temperatures.minOrNull() ?: 0
    val maximum = temperatures.maxOrNull() ?: minimum + 1
    val range = (maximum - minimum).coerceAtLeast(1)
    val axisFormatter = remember(place.timeZoneId) { localFormatter("ha", place) }
    val scrubLabelFormatter = remember(place.timeZoneId) { localFormatter("h:mm a", place) }
    val activeScrubTime = remember(scrubPositionHours, scrubReferenceTime.time) {
        scrubPositionHours?.let { Date(scrubReferenceTime.time + (it * 60f * 60f * 1000f).toLong()) }
    }
    val firstTime = window.first.time
    val lastTime = window.second.time
    val appBackground = MaterialTheme.colorScheme.background
    val lowerBackdrop = remember(palette, appBackground, darkLowerSection) {
        if (darkLowerSection) immersiveLowerBackdrop(palette, appBackground) else heroLowerBackdrop(palette)
    }
    val lowerForeground = remember(lowerBackdrop, appBackground) { contrastForeground(lowerBackdrop, appBackground) }
    val chartColours = remember(palette, lowerBackdrop, lowerForeground) { immersiveChartColours(palette, lowerBackdrop, lowerForeground) }

    // Solar events can cross midnight, so calculate both the starting day and next day.
    val solarEvents = remember(place.latitude, place.longitude, window) {
        listOf(window.first, window.second).flatMap { date ->
            calculateSolarTimes(date, place.latitude, place.longitude, place.timeZone())?.let { times ->
                listOf(
                    Triple(times.first, true, "Sunrise"),
                    Triple(times.second, false, "Sunset")
                )
            } ?: emptyList()
        }.distinctBy { it.first.time }
            .filter { it.first.time in firstTime..lastTime }
            .sortedBy { it.first.time }
    }

    Column(modifier.fillMaxWidth().fillMaxHeight()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "NEXT 24 HOURS",
                    color = chartColours.label,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.4.sp
                )
                Text(
                    activeScrubTime?.let { scrubLabelFormatter.format(it) } ?: "From now",
                    color = chartColours.primaryText,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                "${maximum}° / ${minimum}°",
                color = chartColours.primaryText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(top = 6.dp, bottom = 2.dp)
                .pointerInput(forecastWindow) {
                    fun scrubAt(x: Float) {
                        val fraction = (x / size.width.toFloat().coerceAtLeast(1f)).coerceIn(0f, 1f)
                        onScrub(fraction * 24f)
                    }
                    detectDragGesturesAfterLongPress(
                        onDragStart = { scrubAt(it.x) },
                        onDragEnd = { onScrub(null) },
                        onDragCancel = { onScrub(null) },
                        onDrag = { change, _ ->
                            change.consume()
                            scrubAt(change.position.x)
                        }
                    )
                }
        ) {
            val chartWidth = maxWidth
            val chartHeight = maxHeight
            val horizontalInset = 5.dp
            val chartTopInset = 9.dp
            val chartBottomInset = 18.dp

            Canvas(Modifier.fillMaxSize()) {
                val left = horizontalInset.toPx()
                val right = size.width - horizontalInset.toPx()
                val top = chartTopInset.toPx()
                val bottom = size.height - chartBottomInset.toPx()
                val step = (right - left) / (forecastWindow.size - 1).coerceAtLeast(1)

                fun temperatureY(index: Int): Float {
                    val normalised = (temperatures[index] - minimum).toFloat() / range
                    return bottom - (bottom - top) * (.18f + normalised * .72f)
                }

                forecastWindow.forEachIndexed { index, hour ->
                    val x = left + index * step
                    val barHeight = (bottom - top) * .40f * hour.rainChance.coerceIn(0, 100) / 100f
                    drawLine(
                        chartColours.precipitation,
                        Offset(x, bottom),
                        Offset(x, bottom - barHeight),
                        (step * .58f).coerceAtLeast(1.8.dp.toPx()),
                        StrokeCap.Round
                    )
                }

                val linePath = Path()
                temperatures.forEachIndexed { index, _ ->
                    val x = left + index * step
                    val y = temperatureY(index)
                    if (index == 0) linePath.moveTo(x, y) else linePath.lineTo(x, y)
                }
                drawPath(
                    linePath,
                    chartColours.line,
                    style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )

                temperatures.forEachIndexed { index, _ ->
                    if (index % 6 == 0 || index == temperatures.lastIndex) {
                        val x = left + index * step
                        val y = temperatureY(index)
                        drawCircle(chartColours.pointGlow, 5.dp.toPx(), Offset(x, y))
                        drawCircle(chartColours.point, 2.4.dp.toPx(), Offset(x, y))
                    }
                }
            }

            // During a long-press scrub the indicator is attached directly to the
            // finger. The Atmos scene follows through a short blend, but the marker and
            // time label remain exact so users always know which hour they selected.
            val indicatorFraction = (scrubPositionHours?.div(24f) ?: 0f).coerceIn(0f, 1f)
            val indicatorLabel = activeScrubTime?.let { scrubLabelFormatter.format(it) } ?: "NOW"
            Column(
                Modifier
                    .align(Alignment.TopStart)
                    .offset(x = (chartWidth - 40.dp) * indicatorFraction, y = 0.dp)
                    .width(40.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = chartColours.primaryText.copy(alpha = .18f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, chartColours.primaryText.copy(alpha = .38f))
                ) {
                    Text(
                        indicatorLabel.uppercase(Locale.ENGLISH),
                        Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        color = chartColours.primaryText,
                        fontSize = 7.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1
                    )
                }
                Box(Modifier.width(1.dp).height((chartHeight - 24.dp).coerceAtLeast(0.dp)).background(chartColours.primaryText.copy(alpha = .34f)))
            }

            solarEvents.forEach { (time, sunrise, _) ->
                val rawFraction = (time.time - firstTime).toFloat() / (lastTime - firstTime).toFloat()
                val fraction = rawFraction.coerceIn(.05f, .95f)
                val exactIndex = fraction * temperatures.lastIndex.coerceAtLeast(1)
                val lowerIndex = exactIndex.toInt().coerceIn(0, temperatures.lastIndex)
                val upperIndex = (lowerIndex + 1).coerceAtMost(temperatures.lastIndex)
                val blend = exactIndex - lowerIndex
                val eventTemperature = temperatures[lowerIndex] +
                    (temperatures[upperIndex] - temperatures[lowerIndex]) * blend
                val normalised = (eventTemperature - minimum).toFloat() / range
                val lineYFraction = 1f - (.18f + normalised * .72f)
                val placeAbove = lineYFraction > .48f
                val markerY = if (placeAbove) {
                    (chartHeight * lineYFraction - 76.dp).coerceAtLeast(0.dp)
                } else {
                    (chartHeight * lineYFraction + 20.dp).coerceAtMost(chartHeight - 58.dp)
                }

                SolarChartMarker(
                    sunrise = sunrise,
                    colours = chartColours,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = chartWidth * fraction - 28.dp, y = markerY)
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf(0, 6, 12, 18, 24).forEachIndexed { index, offset ->
                val labelTime = Calendar.getInstance().apply {
                    time = window.first
                    add(Calendar.HOUR_OF_DAY, offset)
                }.time
                Text(
                    if (index == 0) "Now" else axisFormatter.format(labelTime).lowercase(),
                    color = chartColours.label,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    style = androidx.compose.ui.text.TextStyle(
                        shadow = androidx.compose.ui.graphics.Shadow(
                            color = Color.Black.copy(alpha = .32f),
                            offset = Offset(0f, 1f),
                            blurRadius = 2f
                        )
                    )
                )
            }
        }
    }
}

private data class ImmersiveChartColours(
    val line: Color,
    val precipitation: Color,
    val point: Color,
    val pointGlow: Color,
    val primaryText: Color,
    val label: Color,
    val progressTop: Color,
    val progressBottom: Color
)

private fun paletteBrightness(palette: Palette): Float {
    fun brightness(colour: Color): Float = colour.red * .299f + colour.green * .587f + colour.blue * .114f
    return brightness(palette.top) * .46f + brightness(palette.bottom) * .34f + brightness(palette.secondary) * .20f
}

private fun contrastForeground(backdrop: Color, appBackground: Color? = null): Color {
    val appIsDark = appBackground?.let { colourBrightness(it) < .45f } ?: false
    val threshold = if (appIsDark) .64f else .52f
    return if (colourBrightness(backdrop) > threshold) Color(0xFF142038) else Color.White
}

private fun solarLegibleForeground(palette: Palette, appBackground: Color? = null): Color {
    val upperBackdrop = blendColor(palette.top, palette.secondary, .30f)
    return contrastForeground(upperBackdrop, appBackground)
}

private fun colourBrightness(colour: Color): Float =
    colour.red * .299f + colour.green * .587f + colour.blue * .114f

private fun heroLowerBackdrop(palette: Palette): Color = blendColor(palette.bottom, palette.secondary, .30f)
private fun immersiveLowerBackdrop(palette: Palette, appBackground: Color): Color = blendColor(palette.bottom, appBackground, .88f)

private fun heroLowerForeground(palette: Palette): Color = contrastForeground(heroLowerBackdrop(palette))

private fun immersiveLowerForeground(palette: Palette, appBackground: Color): Color =
    contrastForeground(immersiveLowerBackdrop(palette, appBackground), appBackground)

private fun immersiveChartColours(palette: Palette, backdrop: Color, textForeground: Color): ImmersiveChartColours {
    val backdropBright = colourBrightness(backdrop) > .54f
    // Chart strokes choose their own contrast independently from surrounding text.
    val line = if (backdropBright) blendColor(Color(0xFF17263E), palette.accent, .18f) else blendColor(Color.White, palette.accent, .14f)
    val rain = if (backdropBright) Color(0xFF006B99).copy(alpha = .96f) else Color(0xFF73DDFF).copy(alpha = .98f)
    return ImmersiveChartColours(
        line = line,
        precipitation = rain,
        point = line,
        pointGlow = if (backdropBright) Color.White.copy(alpha = .48f) else palette.accent.copy(alpha = .70f),
        primaryText = textForeground,
        label = textForeground.copy(alpha = .92f),
        progressTop = line.copy(alpha = .20f),
        progressBottom = line.copy(alpha = .05f)
    )
}

@Composable
private fun SolarChartMarker(
    sunrise: Boolean,
    colours: ImmersiveChartColours,
    modifier: Modifier = Modifier
) {
    val iconColour = colours.primaryText.copy(alpha = .92f)
    Column(modifier.width(56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(28.dp)) {
            val horizon = size.height * .62f
            val centreX = size.width * .5f
            drawLine(
                iconColour.copy(alpha = .72f),
                Offset(size.width * .12f, horizon),
                Offset(size.width * .88f, horizon),
                1.2.dp.toPx(),
                StrokeCap.Round
            )
            drawArc(
                color = iconColour,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(size.width * .32f, horizon - size.height * .18f),
                size = Size(size.width * .36f, size.height * .36f),
                style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round)
            )
            repeat(3) { index ->
                val x = size.width * (.28f + index * .22f)
                drawLine(
                    iconColour.copy(alpha = .55f),
                    Offset(x - 2.dp.toPx(), horizon + 4.dp.toPx()),
                    Offset(x + 2.dp.toPx(), horizon + 4.dp.toPx()),
                    1.dp.toPx(),
                    StrokeCap.Round
                )
            }

            val arrowTop = if (sunrise) size.height * .08f else size.height * .18f
            val arrowBottom = if (sunrise) size.height * .38f else size.height * .48f
            drawLine(
                iconColour,
                Offset(centreX, arrowBottom),
                Offset(centreX, arrowTop),
                1.7.dp.toPx(),
                StrokeCap.Round
            )
            val arrowDirection = if (sunrise) 1f else -1f
            val tipY = if (sunrise) arrowTop else arrowBottom
            val wingY = tipY + 4.dp.toPx() * arrowDirection
            drawLine(iconColour, Offset(centreX, tipY), Offset(centreX - 3.5.dp.toPx(), wingY), 1.7.dp.toPx(), StrokeCap.Round)
            drawLine(iconColour, Offset(centreX, tipY), Offset(centreX + 3.5.dp.toPx(), wingY), 1.7.dp.toPx(), StrokeCap.Round)
        }
    }
}

@Composable
private fun ImmersiveOutlookPill(
    weather: WeatherState,
    temperatureUnit: TemperatureUnit,
    modifier: Modifier = Modifier
) {
    val day = weather.days.first()
    val outlook = when {
        day.rainChance >= 70 -> "Rain likely today"
        day.rainChance >= 35 -> "A chance of showers"
        day.condition.contains("cloud", true) -> "Clouds through the day"
        day.condition.contains("sun", true) || day.condition.contains("clear", true) -> "Bright conditions ahead"
        else -> day.condition
    }
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White.copy(alpha = .13f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .18f))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            WeatherArtwork(day.icon, night = isNight(), modifier = Modifier.size(46.dp))
            Column(Modifier.weight(1f).padding(start = 11.dp)) {
                Text("TODAY'S OUTLOOK", color = Color.White.copy(.64f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text(outlook, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                "${displayTemperature(day.high, temperatureUnit)}° / ${displayTemperature(day.low, temperatureUnit)}°",
                color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun ScrollDownCue(palette: Palette, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Scroll for your forecast", color = MaterialTheme.colorScheme.onSurface.copy(.54f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Canvas(Modifier.padding(top = 5.dp).size(width = 28.dp, height = 13.dp)) {
            val stroke = 2.dp.toPx()
            drawLine(palette.secondary.copy(.78f), Offset(size.width * .18f, size.height * .25f), Offset(size.width * .5f, size.height * .72f), stroke, StrokeCap.Round)
            drawLine(palette.secondary.copy(.78f), Offset(size.width * .82f, size.height * .25f), Offset(size.width * .5f, size.height * .72f), stroke, StrokeCap.Round)
        }
    }
}

@Composable private fun HeroStat(label: String, value: String, modifier: Modifier, foreground: Color) =
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = foreground.copy(.70f), fontSize = 10.sp)
        Text(value, color = foreground, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }

@Composable
private fun SeasonPill(place: Place, onClick: () -> Unit) {
    val season = seasonName(place)
    val (background, foreground) = seasonPillColours(season)
    Surface(Modifier.clickable(onClick = onClick), shape = CircleShape, color = background, shadowElevation = 8.dp) {
        Text("●  $season", Modifier.padding(horizontal = 15.dp, vertical = 10.dp), color = foreground, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

private fun seasonPillColours(season: String): Pair<Color, Color> = when (season) {
    "Summer" -> Color(0xFF70421E) to Color(0xFFFFE2A8)
    "Autumn" -> Color(0xFF6A382E) to Color(0xFFFFCFB0)
    "Winter" -> Color(0xFF23486D) to Color(0xFFDDF1FF)
    "Wet season" -> Color(0xFF15564D) to Color(0xFFCCF5E8)
    "Dry season" -> Color(0xFF67471F) to Color(0xFFFFE0A5)
    else -> Color(0xFF285B3D) to Color(0xFFDDF6D8)
}

@Composable
private fun LocationSeasonPill(place: Place) {
    val season = seasonName(place)
    val (background, foreground) = seasonPillColours(season)
    Surface(
        shape = CircleShape,
        color = background,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.26f))
    ) {
        Text(
            season,
            Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            color = foreground,
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = .35.sp
        )
    }
}

@Composable
private fun CountryPill(place: Place, now: Date) {
    val code = place.countryCode.uppercase(Locale.US)
    val flag = if (code.length == 2) code.map { String(Character.toChars(127397 + it.code)) }.joinToString("") else "⌖"
    val localTime = remember(place.timeZoneId, now.time / 60_000L) {
        localFormatter("h:mm a", place).format(now).lowercase(Locale.ENGLISH)
    }
    Surface(shape = CircleShape, color = Color(0x33203355), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.28f))) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("$flag  ${place.country.ifBlank { "International" }}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.padding(horizontal = 8.dp).width(1.dp).height(12.dp).background(Color.White.copy(.28f)))
            Text(localTime, color = Color.White.copy(.82f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}


@Composable
private fun AustralianTimePill(place: Place, now: Date) {
    val localTime = remember(place.timeZoneId, now.time / 60_000L) {
        localFormatter("h:mm a", place).format(now).lowercase(Locale.ENGLISH)
    }
    Surface(
        shape = CircleShape,
        color = Color(0x33203355),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.28f))
    ) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!place.current) {
                Text(place.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.padding(horizontal = 8.dp).width(1.dp).height(12.dp).background(Color.White.copy(.28f)))
            }
            Text(localTime, color = Color.White.copy(.82f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ConditionAtmosphere(icon: String, night: Boolean) {
    val drawable = remember(icon, night) {
        when {
            icon.contains("storm", true) || icon.contains("thunder", true) -> R.drawable.ic_weather_storm
            icon.contains("rain", true) || icon.contains("shower", true) -> R.drawable.ic_weather_rain
            icon.contains("cloud", true) -> R.drawable.ic_weather_cloudy
            night -> R.drawable.ic_weather_night
            else -> R.drawable.ic_weather_sunny
        }
    }
    Image(
        painter = painterResource(drawable),
        contentDescription = null,
        modifier = Modifier
            .fillMaxSize()
            .padding(start = 150.dp, top = 26.dp, end = 12.dp, bottom = 245.dp)
            .alpha(.16f),
        contentScale = ContentScale.Fit
    )
}

@Composable
private fun WeatherArtwork(icon: String, night: Boolean, modifier: Modifier = Modifier) {
    AnimatedContent(
        targetState = icon to night,
        transitionSpec = {
            (fadeIn(tween(520)) + scaleIn(tween(620), initialScale = .92f)) togetherWith
                (fadeOut(tween(360)) + scaleOut(tween(420), targetScale = 1.05f))
        },
        label = "atmosWeatherArtwork"
    ) { state ->
        WeatherArtworkCanvas(state.first, state.second, modifier)
    }
}

@Composable
private fun WeatherArtworkCanvas(icon: String, night: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier.padding(7.dp)) {
        val w = size.width
        val h = size.height
        val rainy = icon.contains("rain", true) || icon.contains("shower", true)
        val stormy = icon.contains("storm", true) || icon.contains("thunder", true)
        val snowy = icon.contains("snow", true) || icon.contains("sleet", true) || icon.contains("hail", true)
        val foggy = icon.contains("fog", true) || icon.contains("mist", true) || icon.contains("haze", true)
        val cloudy = rainy || stormy || snowy || foggy || icon.contains("cloud", true) || icon.contains("overcast", true)
        val accent = if (night) Color(0xFFB9C8FF) else Color(0xFFFFB94E)
        val cloudTop = if (stormy) Color(0xFF65728D) else Color(0xFFE7EDF7)
        val cloudBottom = if (stormy) Color(0xFF303B54) else Color(0xFF8EA2BE)

        if (!cloudy) {
            val centre = Offset(w * .5f, h * .48f)
            val r = size.minDimension * .23f
            drawCircle(accent.copy(.16f), r * 1.36f, centre)
            drawCircle(accent, r, centre)
            if (night) {
                drawCircle(Color(0xFF253858), r * .92f, centre + Offset(r * .48f, -r * .16f))
            } else {
                repeat(8) { index ->
                    val angle = index * PI.toFloat() / 4f
                    val inner = r * 1.32f
                    val outer = r * 1.66f
                    drawLine(
                        accent.copy(.82f),
                        Offset(centre.x + cos(angle) * inner, centre.y + sin(angle) * inner),
                        Offset(centre.x + cos(angle) * outer, centre.y + sin(angle) * outer),
                        strokeWidth = 2.2.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }
            return@Canvas
        }

        val orbCentre = Offset(w * .68f, h * .31f)
        val orbR = size.minDimension * .15f
        if (!stormy) {
            drawCircle(accent.copy(.14f), orbR * 1.35f, orbCentre)
            drawCircle(accent, orbR, orbCentre)
            if (night) drawCircle(Color(0xFF293B5D), orbR * .86f, orbCentre + Offset(orbR * .48f, -orbR * .14f))
        }

        val cloud = Path().apply {
            moveTo(w * .12f, h * .64f)
            cubicTo(w * .12f, h * .51f, w * .25f, h * .48f, w * .34f, h * .48f)
            cubicTo(w * .39f, h * .34f, w * .59f, h * .34f, w * .66f, h * .50f)
            cubicTo(w * .84f, h * .48f, w * .91f, h * .60f, w * .84f, h * .70f)
            cubicTo(w * .80f, h * .75f, w * .73f, h * .76f, w * .64f, h * .76f)
            lineTo(w * .28f, h * .76f)
            cubicTo(w * .17f, h * .76f, w * .11f, h * .71f, w * .12f, h * .64f)
            close()
        }
        drawPath(cloud, Brush.verticalGradient(listOf(cloudTop, cloudBottom)))
        drawPath(cloud, Color.White.copy(if (stormy) .04f else .10f), style = Stroke(width = 1.dp.toPx()))

        if (foggy) {
            repeat(3) { index ->
                val y = h * (.81f + index * .075f)
                drawLine(
                    Color(0xFFDCE7F4).copy(alpha = .78f - index * .14f),
                    Offset(w * (.20f + index * .04f), y),
                    Offset(w * (.80f - index * .03f), y),
                    1.45.dp.toPx(),
                    StrokeCap.Round
                )
            }
        }
        if (snowy) {
            repeat(3) { i ->
                val centre = Offset(w * (.30f + i * .20f), h * (.85f + (i % 2) * .06f))
                val r = size.minDimension * .045f
                drawLine(Color(0xFFE8F7FF), centre - Offset(r, 0f), centre + Offset(r, 0f), 1.2.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFFE8F7FF), centre - Offset(0f, r), centre + Offset(0f, r), 1.2.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFFE8F7FF), centre - Offset(r * .7f, r * .7f), centre + Offset(r * .7f, r * .7f), 1.1.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFFE8F7FF), centre - Offset(r * .7f, -r * .7f), centre + Offset(r * .7f, -r * .7f), 1.1.dp.toPx(), StrokeCap.Round)
            }
        }
        if ((rainy || stormy) && !snowy && !foggy) {
            repeat(3) { i ->
                val x = w * (.31f + i * .19f)
                drawLine(
                    color = Color(0xFF62D5EA),
                    start = Offset(x, h * .82f),
                    end = Offset(x - w * .035f, h * .96f),
                    strokeWidth = 1.75.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
        if (stormy) {
            val bolt = Path().apply {
                moveTo(w * .59f, h * .70f)
                lineTo(w * .49f, h * .85f)
                lineTo(w * .57f, h * .84f)
                lineTo(w * .50f, h * .98f)
                lineTo(w * .69f, h * .78f)
                lineTo(w * .60f, h * .79f)
                close()
            }
            drawPath(bolt, Color(0xFFFFC84F))
        }
    }
}

@Composable
private fun oledAwareCardOutline(default: Color): Color =
    if (LocalOledCardMode.current) Color(0xFF9FB7D8).copy(alpha = .24f) else default

@Composable
private fun AtmosCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, oledAwareCardOutline(MaterialTheme.colorScheme.primary.copy(.15f)))
    ) { Column(Modifier.padding(21.dp), content = content) }
}

@Composable
private fun ThemedForecastCard(
    palette: Palette,
    content: @Composable ColumnScope.() -> Unit
) {
    val oledCardMode = LocalOledCardMode.current
    val outlineBrush = remember(palette, oledCardMode) {
        Brush.horizontalGradient(
            listOf(
                if (oledCardMode) Color(0xFF8FA9CC).copy(alpha = .18f) else palette.top.copy(alpha = .22f),
                if (oledCardMode) Color(0xFFB4C9E6).copy(alpha = .30f) else palette.secondary.copy(alpha = .46f),
                if (oledCardMode) Color(0xFF8FA9CC).copy(alpha = .18f) else palette.bottom.copy(alpha = .25f)
            )
        )
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = androidx.compose.foundation.BorderStroke(1.dp, oledAwareCardOutline(palette.secondary.copy(alpha = .30f)))
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, outlineBrush, RoundedCornerShape(29.dp))
                .padding(21.dp),
            content = content
        )
    }
}

@Composable
private fun AtmosphericSoundscapeEffect(
    enabled: Boolean,
    weather: WeatherState,
    appVisible: Boolean
) {
    val condition = weather.days.firstOrNull()?.condition.orEmpty()
    val icon = weather.days.firstOrNull()?.icon.orEmpty()
    val wind = (weather.observation.wind ?: 0).coerceAtLeast(0).toDouble()
    val rain = (weather.observation.rainSince9 ?: weather.days.firstOrNull()?.rainAmount ?: 0.0).coerceAtLeast(0.0)
    DisposableEffect(enabled, appVisible, condition, icon, (wind / 5.0).roundToInt(), (rain * 2.0).roundToInt()) {
        if (!enabled || !appVisible) return@DisposableEffect onDispose { }
        val engine = AtmosSoundscapeEngine(condition, icon, wind.toFloat(), rain.toFloat())
        engine.start()
        onDispose { engine.stop() }
    }
}

private class AtmosSoundscapeEngine(
    private val condition: String,
    private val icon: String,
    private val windKmh: Float,
    private val rainMm: Float
) {
    @Volatile private var running = false
    private var track: AudioTrack? = null
    private var worker: Thread? = null

    fun start() {
        if (running) return
        val sampleRate = 16_000
        val minimum = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minimum <= 0) return
        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minimum * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = audioTrack
        running = true
        audioTrack.setVolume(0.075f)
        audioTrack.play()
        worker = Thread({ render(audioTrack, sampleRate, minimum) }, "AtmosSoundscape").apply {
            isDaemon = true
            start()
        }
    }

    private fun render(audioTrack: AudioTrack, sampleRate: Int, bufferBytes: Int) {
        val samples = ShortArray((bufferBytes / 2).coerceAtLeast(512))
        val lower = (condition + " " + icon).lowercase()
        val rainy = "rain" in lower || "shower" in lower || "storm" in lower || rainMm > 0.05f
        val stormy = "storm" in lower || "thunder" in lower
        val windAmount = (windKmh / 45f).coerceIn(.08f, .75f)
        val rainAmount = if (rainy) (.18f + rainMm / 8f).coerceIn(.18f, .62f) else 0f
        val toneAmount = if (stormy) .16f else .07f
        var seed = System.nanoTime().toInt()
        var smoothNoise = 0f
        var phase = 0.0
        var slowPhase = 0.0
        while (running) {
            for (i in samples.indices) {
                seed = seed * 1664525 + 1013904223
                val white = (((seed ushr 9) and 0x7FFFFF) / 4194304f) - 1f
                smoothNoise += (white - smoothNoise) * .018f
                phase += 2.0 * PI * (if (stormy) 47.0 else 62.0) / sampleRate
                slowPhase += 2.0 * PI * .075 / sampleRate
                val breathing = (.72 + .28 * sin(slowPhase)).toFloat()
                val windLayer = smoothNoise * windAmount * breathing
                val rainLayer = if (rainy) white * white.absoluteValue * rainAmount else 0f
                val distantTone = sin(phase).toFloat() * toneAmount * breathing
                val mixed = (windLayer + rainLayer + distantTone).coerceIn(-1f, 1f)
                samples[i] = (mixed * 32767f).roundToInt().toShort()
            }
            if (audioTrack.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING) < 0) break
        }
    }

    fun stop() {
        running = false
        worker?.interrupt()
        worker = null
        runCatching { track?.pause() }
        runCatching { track?.flush() }
        runCatching { track?.release() }
        track = null
    }
}

private data class AtmosMoment(
    val title: String,
    val detail: String,
    val time: Date,
    val symbol: String
)

private fun formatMomentDuration(milliseconds: Long): String {
    val totalMinutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds.coerceAtLeast(0L))
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return when {
        hours > 0 && minutes > 0 -> "${hours}h ${minutes}m"
        hours > 0 -> "${hours}h"
        else -> "${minutes}m"
    }
}

private fun buildAtmosMoments(weather: WeatherState, temperatureUnit: TemperatureUnit, now: Date = Date()): List<AtmosMoment> {
    val horizon = now.time + TimeUnit.HOURS.toMillis(24)
    val upcoming = weather.hours
        .filter { it.time.time in now.time..horizon }
        .sortedBy { it.time.time }
    if (upcoming.isEmpty()) return emptyList()

    val solar = calculateSolarTimes(now, weather.place.latitude, weather.place.longitude, weather.place.timeZone())
    val daylightMoment = solar?.let { (sunrise, sunset) ->
        when {
            now.before(sunrise) -> AtmosMoment(
                title = "Until sunrise",
                detail = "Morning light returns in ${formatMomentDuration(sunrise.time - now.time)}.",
                time = sunrise,
                symbol = "☼"
            )
            now.before(sunset) -> AtmosMoment(
                title = "Remaining daylight",
                detail = "${formatMomentDuration(sunset.time - now.time)} of daylight remains.",
                time = sunset,
                symbol = "◐"
            )
            else -> {
                val tomorrow = Date(now.time + TimeUnit.DAYS.toMillis(1))
                val nextSolar = calculateSolarTimes(tomorrow, weather.place.latitude, weather.place.longitude, weather.place.timeZone())
                nextSolar?.first?.let { nextSunrise ->
                    AtmosMoment(
                        title = "Until sunrise",
                        detail = "Morning light returns in ${formatMomentDuration(nextSunrise.time - now.time)}.",
                        time = nextSunrise,
                        symbol = "☼"
                    )
                }
            }
        }
    }

    val moments = mutableListOf<AtmosMoment>()
    solar?.let { (sunrise, sunset) ->
        val goldenTime = Date(sunset.time - TimeUnit.MINUTES.toMillis(42))
        if (goldenTime.after(now) && goldenTime.time <= horizon) {
            val goldenHour = upcoming.minByOrNull { kotlin.math.abs(it.time.time - goldenTime.time) }
            if (goldenHour != null) {
                moments += AtmosMoment(
                    title = "Golden light",
                    detail = "The atmosphere should warm and soften near sunset.",
                    time = goldenHour.time,
                    symbol = "✦"
                )
            }
        } else {
            val morningLight = Date(sunrise.time + TimeUnit.MINUTES.toMillis(35))
            if (morningLight.after(now) && morningLight.time <= horizon) {
                val morningHour = upcoming.minByOrNull { kotlin.math.abs(it.time.time - morningLight.time) }
                if (morningHour != null) {
                    moments += AtmosMoment(
                        title = "First light",
                        detail = "A gentle lift in colour and clarity after sunrise.",
                        time = morningHour.time,
                        symbol = "☼"
                    )
                }
            }
        }
    }

    val clearest = upcoming
        .filterNot { it.icon.contains("rain", true) || it.icon.contains("storm", true) || it.icon.contains("snow", true) }
        .minByOrNull { it.humidity + it.rainChance * 2 }
    if (clearest != null) {
        moments += AtmosMoment(
            title = "Best outside",
            detail = "The clearest-feeling window, around ${displayTemperature(clearest.temp, temperatureUnit)}°.",
            time = clearest.time,
            symbol = "○"
        )
    }

    val rainArrival = upcoming.firstOrNull { it.rainChance >= 55 || it.icon.contains("rain", true) || it.icon.contains("storm", true) }
    if (rainArrival != null) {
        moments += AtmosMoment(
            title = if (rainArrival.icon.contains("storm", true)) "Storm atmosphere" else "Rain arrives",
            detail = "The scene should deepen as moisture and cloud build.",
            time = rainArrival.time,
            symbol = if (rainArrival.icon.contains("storm", true)) "ϟ" else "⌁"
        )
    } else {
        val warmest = upcoming.maxByOrNull { it.temp }
        if (warmest != null) {
            moments += AtmosMoment(
                title = "Warmest point",
                detail = "The day reaches about ${displayTemperature(warmest.temp, temperatureUnit)}°.",
                time = warmest.time,
                symbol = "↑"
            )
        }
    }

    val supportingMoments = moments
        .distinctBy { it.title }
        .filterNot { it.title == daylightMoment?.title }
        .sortedBy { it.time.time }
        .take(if (daylightMoment != null) 2 else 3)

    return listOfNotNull(daylightMoment) + supportingMoments
}


@Composable
private fun cardContentAccent(palette: Palette): Color {
    val darkSurface = MaterialTheme.colorScheme.surface.luminance() < .32f
    val darkAtmosphere = palette.bottom.luminance() < .30f
    return if (darkSurface || darkAtmosphere) {
        blendColor(palette.accent, Color.White, .62f)
    } else {
        palette.accent
    }
}

@Composable
private fun CurrentConditionsCard(
    weather: WeatherState,
    palette: Palette,
    preferences: AtmosPreferences
) {
    val now = Date()
    val currentHour = remember(weather.updated.time, weather.hours, weather.place.cacheKey()) {
        weather.hours.minByOrNull { kotlin.math.abs(it.time.time - now.time) }
    }
    val windKmh = weather.observation.wind ?: currentHour?.wind ?: 0
    val windText = when (preferences.windUnit) {
        WindUnit.Kmh -> "$windKmh km/h"
        WindUnit.Mph -> "${(windKmh * 0.621371f).roundToInt()} mph"
        WindUnit.Ms -> "${String.format(Locale.ENGLISH, "%.1f", windKmh / 3.6f)} m/s"
        WindUnit.Knots -> "${(windKmh * 0.539957f).roundToInt()} knots"
    }
    val humidity = weather.observation.humidity ?: currentHour?.humidity ?: 0
    val rainChance = currentHour?.rainChance ?: weather.days.firstOrNull()?.rainChance ?: 0
    val contentAccent = cardContentAccent(palette)

    ThemedForecastCard(palette) {
        Text("Right now", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
        Text(
            "The conditions shaping the atmosphere around you.",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f),
            fontSize = 12.sp
        )
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CurrentConditionMetric("Wind", windText, "↗", palette, contentAccent, Modifier.weight(1f))
            CurrentConditionMetric("Humidity", "$humidity%", "☁", palette, contentAccent, Modifier.weight(1f))
            CurrentConditionMetric("Rain", "$rainChance%", "●", palette, contentAccent, Modifier.weight(1f))
        }
    }
}

@Composable
private fun CurrentConditionMetric(
    label: String,
    value: String,
    symbol: String,
    palette: Palette,
    contentAccent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.height(112.dp),
        shape = RoundedCornerShape(18.dp),
        color = palette.accent.copy(alpha = .09f),
        border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(alpha = .16f))
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            if (label == "Humidity") {
                // Compact filled cloud glyph: deliberately the same visual scale as
                // the wind arrow and rain mark used by the neighbouring metrics.
                Canvas(modifier = Modifier.size(width = 25.dp, height = 20.dp)) {
                    val tint = contentAccent
                    drawCircle(tint, radius = size.minDimension * .22f, center = Offset(size.width * .38f, size.height * .48f))
                    drawCircle(tint, radius = size.minDimension * .29f, center = Offset(size.width * .57f, size.height * .39f))
                    drawCircle(tint, radius = size.minDimension * .19f, center = Offset(size.width * .75f, size.height * .51f))
                    drawRoundRect(
                        color = tint,
                        topLeft = Offset(size.width * .20f, size.height * .49f),
                        size = Size(size.width * .68f, size.height * .25f),
                        cornerRadius = CornerRadius(size.height * .13f, size.height * .13f)
                    )
                    drawRoundRect(
                        color = tint.copy(alpha = .72f),
                        topLeft = Offset(size.width * .30f, size.height * .84f),
                        size = Size(size.width * .48f, size.height * .10f),
                        cornerRadius = CornerRadius(size.height * .05f, size.height * .05f)
                    )
                }
            } else {
                Text(
                    symbol,
                    modifier = Modifier.fillMaxWidth(),
                    color = contentAccent,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
            Text(
                value,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                textAlign = TextAlign.Center
            )
            Text(
                label,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f),
                fontSize = 10.sp,
                maxLines = 1,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun AtmosMomentsCard(
    weather: WeatherState,
    palette: Palette,
    temperatureUnit: TemperatureUnit,
    onOpenTimeline: () -> Unit
) {
    var momentClock by remember(weather.place.cacheKey()) { mutableStateOf(Date()) }
    LaunchedEffect(weather.place.cacheKey()) {
        while (true) {
            val now = Date()
            momentClock = now
            val untilNextMinute = 60_000L - (now.time % 60_000L)
            delay(untilNextMinute.coerceAtLeast(1_000L))
        }
    }
    val moments = remember(
        weather.updated.time,
        weather.hours,
        weather.place.cacheKey(),
        temperatureUnit,
        momentClock.time / 60_000L
    ) {
        buildAtmosMoments(weather, temperatureUnit, momentClock)
    }
    if (moments.isEmpty()) return
    val formatter = remember(weather.place.timeZoneId) { localFormatter("h:mm a", weather.place) }
    val momentAccent = cardContentAccent(palette)
    val oledCardMode = LocalOledCardMode.current
    val borderBrush = remember(palette, oledCardMode) {
        Brush.horizontalGradient(
            listOf(
                if (oledCardMode) Color(0xFF8FA9CC).copy(alpha = .16f) else palette.top.copy(alpha = .10f),
                if (oledCardMode) Color(0xFFB4C9E6).copy(alpha = .28f) else palette.secondary.copy(alpha = .28f),
                if (oledCardMode) Color(0xFF8FA9CC).copy(alpha = .16f) else palette.bottom.copy(alpha = .10f)
            )
        )
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = androidx.compose.foundation.BorderStroke(1.dp, oledAwareCardOutline(palette.secondary.copy(.30f)))
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, borderBrush, RoundedCornerShape(29.dp))
                .padding(20.dp)
        ) {
            Column(Modifier.fillMaxWidth()) {
                Text("Atmos Moments", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    text = buildAnnotatedString {
                        append("The moments most likely to shape how today feels in ")
                        withStyle(
                            SpanStyle(
                                color = momentAccent,
                                fontWeight = FontWeight.Bold
                            )
                        ) {
                            append("Timeline")
                        }
                        append(".")
                    },
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
            Spacer(Modifier.height(15.dp))
            moments.forEachIndexed { index, moment ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        modifier = Modifier.size(42.dp),
                        shape = CircleShape,
                        color = momentAccent.copy(alpha = .16f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(moment.symbol, color = momentAccent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(moment.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(
                                formatter.format(moment.time),
                                modifier = Modifier.padding(start = 8.dp),
                                color = momentAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            moment.detail,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .66f),
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
                if (index != moments.lastIndex) {
                    androidx.compose.material3.Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = .08f))
                }
            }
        }
    }
}

@Composable
private fun AtAGlanceCard(weather: WeatherState, palette: Palette, temperatureUnit: TemperatureUnit) {
    var page by rememberSaveable(weather.place.name) { mutableStateOf(0) }
    val maxPage = if (weather.days.size > 1) 1 else 0
    val oledCardMode = LocalOledCardMode.current
    val borderBrush = remember(palette, oledCardMode) {
        Brush.horizontalGradient(
            listOf(
                if (oledCardMode) Color(0xFF8FA9CC).copy(alpha = .16f) else palette.top.copy(alpha = .10f),
                if (oledCardMode) Color(0xFFB4C9E6).copy(alpha = .28f) else palette.secondary.copy(alpha = .28f),
                if (oledCardMode) Color(0xFF8FA9CC).copy(alpha = .16f) else palette.bottom.copy(alpha = .10f)
            )
        )
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = androidx.compose.foundation.BorderStroke(1.dp, oledAwareCardOutline(palette.secondary.copy(.30f)))
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .border(
                    width = 1.dp,
                    brush = borderBrush,
                    shape = RoundedCornerShape(29.dp)
                )
                .padding(21.dp)
        ) {
        Column(
            Modifier.pointerInput(maxPage) {
                var drag = 0f
                detectHorizontalDragGestures(
                    onDragStart = { drag = 0f },
                    onHorizontalDrag = { _, amount -> drag += amount },
                    onDragEnd = {
                        if (drag < -45f) page = maxPage
                        if (drag > 45f) page = 0
                    }
                )
            }
        ) {
            AnimatedContent(page, label = "glance-page") { selected ->
                val glanceDay = weather.days.getOrElse(selected) { weather.days.first() }
                Column {
                    Text(
                        if (selected == 0) "Today at a glance" else "Tomorrow at a glance",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        WeatherArtwork(
                            icon = glanceDay.icon,
                            night = false,
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            localForecastSummary(weather, selected, temperatureUnit),
                            modifier = Modifier.padding(start = 13.dp).weight(1f),
                            color = MaterialTheme.colorScheme.onSurface.copy(.76f),
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )
                    }
                }
            }
        }
        if (maxPage > 0) {
            ForecastPageIndicator(
                current = page,
                count = maxPage + 1,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 14.dp)
            )
        }
        }
    }
}

@Composable
private fun HourlyCard(weather: WeatherState, day: DayForecast, temperatureUnit: TemperatureUnit, palette: Palette) = ThemedForecastCard(palette) {
    val place = weather.place
    Text("Today", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Hourly forecast", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
    val rawHours = remember(weather.hours, day) {
        weather.hours.ifEmpty {
            (0 until 12).map { HourForecast(Date(System.currentTimeMillis() + it * 3_600_000L), day.high - 2 - it / 4, day.icon, day.rainChance, 50, 10, "W") }
        }
    }
    val solarTimes = remember(place.latitude, place.longitude, place.timeZoneId) {
        calculateSolarTimes(Date(), place.latitude, place.longitude, place.timeZone())
    }
    var nowMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            nowMillis = System.currentTimeMillis()
        }
    }
    val source = remember(rawHours, weather.observation, day, nowMillis) {
        val futureHours = rawHours.filter { it.time.time > nowMillis }.take(17)
        val nearestForecast = rawHours.minByOrNull { kotlin.math.abs(it.time.time - nowMillis) }
        val nowForecast = HourForecast(
            time = Date(nowMillis),
            temp = weather.observation.temp ?: nearestForecast?.temp ?: day.high,
            icon = nearestForecast?.icon ?: day.icon,
            rainChance = nearestForecast?.rainChance ?: day.rainChance,
            humidity = weather.observation.humidity ?: nearestForecast?.humidity ?: 0,
            wind = weather.observation.wind ?: nearestForecast?.wind ?: 0,
            direction = weather.observation.direction.ifBlank { nearestForecast?.direction.orEmpty() }
        )
        listOf(nowForecast) + futureHours
    }
    val timeline = remember(source, solarTimes, nowMillis) {
        buildList {
            source.forEach { add(TodayTimelineItem.Hour(it)) }
            solarTimes?.let { times ->
                if (times.first.time > nowMillis) add(TodayTimelineItem.Sunrise(times.first))
                if (times.second.time > nowMillis) add(TodayTimelineItem.Sunset(times.second))
            }
        }.sortedBy { it.time.time }
    }
    val hourFormatter = remember(place.timeZoneId) { localFormatter("h a", place) }
    val eventFormatter = remember(place.timeZoneId) { localFormatter("h:mm a", place) }
    val sunriseGradient = remember { Brush.verticalGradient(listOf(Color(0xFFFFD58A), Color(0xFFF18A5B).copy(.48f), Color(0xFFFFC76A).copy(.16f))) }
    val sunsetGradient = remember { Brush.verticalGradient(listOf(Color(0xFF9B70E8).copy(.72f), Color(0xFFF07B63).copy(.52f), Color(0xFF633E91).copy(.24f))) }
    LazyRow(
        Modifier.fillMaxWidth().padding(top = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(
            items = timeline,
            key = { item ->
            when (item) {
                is TodayTimelineItem.Hour -> "hour-${item.time.time}"
                is TodayTimelineItem.Sunrise -> "sunrise-${item.time.time}"
                is TodayTimelineItem.Sunset -> "sunset-${item.time.time}"
            }
        },
            contentType = { item ->
                when (item) {
                    is TodayTimelineItem.Hour -> "hour"
                    is TodayTimelineItem.Sunrise -> "solar"
                    is TodayTimelineItem.Sunset -> "solar"
                }
            }
        ) { item ->
            when (item) {
                is TodayTimelineItem.Hour -> {
                    val hour = item.forecast
                    val isNow = source.firstOrNull() === hour
                    Column(
                        Modifier.width(78.dp).height(164.dp).clip(RoundedCornerShape(22.dp))
                            .background(if (isNow) MaterialTheme.colorScheme.primary.copy(.14f) else Color.Transparent)
                            .padding(horizontal = 7.dp, vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (isNow) "Now" else hourFormatter.format(hour.time).lowercase(), fontWeight = FontWeight.Bold)
                        WeatherArtwork(hour.icon, isNight(hour.time, place.timeZone()), Modifier.size(50.dp))
                        Text("${displayTemperature(hour.temp, temperatureUnit)}°", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("${hour.rainChance}%", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp)
                    }
                }
                is TodayTimelineItem.Sunrise -> SolarEventCard(
                    title = "Sunrise",
                    time = eventFormatter.format(item.time).lowercase(),
                    caption = "Day begins",
                    sunrise = true,
                    gradient = sunriseGradient
                )
                is TodayTimelineItem.Sunset -> SolarEventCard(
                    title = "Sunset",
                    time = eventFormatter.format(item.time).lowercase(),
                    caption = "Day ends",
                    sunrise = false,
                    gradient = sunsetGradient
                )
            }
        }
    }
}

private sealed class TodayTimelineItem(open val time: Date) {
    data class Hour(val forecast: HourForecast) : TodayTimelineItem(forecast.time)
    data class Sunrise(override val time: Date) : TodayTimelineItem(time)
    data class Sunset(override val time: Date) : TodayTimelineItem(time)
}

@Composable
private fun SolarEventCard(title: String, time: String, caption: String, sunrise: Boolean, gradient: Brush) {
    val primary = MaterialTheme.colorScheme.primary
    Column(
        Modifier.width(78.dp).height(164.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.primary.copy(.10f))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(.22f), RoundedCornerShape(22.dp))
            .padding(horizontal = 7.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Canvas(Modifier.size(48.dp)) {
            val horizonY = size.height * .67f
            drawLine(
                color = primary.copy(.35f),
                start = Offset(size.width * .12f, horizonY),
                end = Offset(size.width * .88f, horizonY),
                strokeWidth = 1.5.dp.toPx(),
                cap = StrokeCap.Round
            )
            val centre = Offset(size.width * .5f, horizonY)
            val orbCentre = if (sunrise) centre - Offset(0f, size.height * .18f) else centre - Offset(0f, size.height * .12f)
            drawCircle(Color(0xFFFFB94E).copy(.18f), size.minDimension * .23f, orbCentre)
            drawCircle(Color(0xFFFFB94E), size.minDimension * .14f, orbCentre)
            repeat(5) { index ->
                val x = size.width * (.28f + index * .11f)
                val spread = (index - 2).absoluteValue * 1.5.dp.toPx()
                drawLine(
                    Color(0xFFFFB94E).copy(.50f),
                    Offset(x - spread, horizonY + 4.dp.toPx()),
                    Offset(x + spread, horizonY + 4.dp.toPx()),
                    1.3.dp.toPx(),
                    StrokeCap.Round
                )
            }
        }
        Text(time, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(caption, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f), textAlign = TextAlign.Center)
    }
}

internal fun calculateSolarTimes(date: Date, latitude: Double, longitude: Double, timeZone: TimeZone = TimeZone.getDefault()): Pair<Date, Date>? {
    val calendar = Calendar.getInstance(timeZone).apply { time = date }
    val dayOfYear = calendar.get(Calendar.DAY_OF_YEAR)
    val timezoneOffsetHours = timeZone.getOffset(date.time) / 3_600_000.0

    fun event(sunrise: Boolean): Date? {
        val lngHour = longitude / 15.0
        val approximateTime = dayOfYear + ((if (sunrise) 6.0 else 18.0) - lngHour) / 24.0
        val meanAnomaly = (0.9856 * approximateTime) - 3.289
        var trueLongitude = meanAnomaly + (1.916 * sin(Math.toRadians(meanAnomaly))) +
            (0.020 * sin(Math.toRadians(2 * meanAnomaly))) + 282.634
        trueLongitude = (trueLongitude + 360.0) % 360.0
        var rightAscension = Math.toDegrees(atan(0.91764 * tan(Math.toRadians(trueLongitude))))
        rightAscension = (rightAscension + 360.0) % 360.0
        val longitudeQuadrant = floor(trueLongitude / 90.0) * 90.0
        val rightAscensionQuadrant = floor(rightAscension / 90.0) * 90.0
        rightAscension = (rightAscension + longitudeQuadrant - rightAscensionQuadrant) / 15.0
        val sinDeclination = 0.39782 * sin(Math.toRadians(trueLongitude))
        val cosDeclination = cos(kotlin.math.asin(sinDeclination))
        val cosHourAngle = (cos(Math.toRadians(90.833)) - sinDeclination * sin(Math.toRadians(latitude))) /
            (cosDeclination * cos(Math.toRadians(latitude)))
        if (cosHourAngle !in -1.0..1.0) return null
        var localHour = if (sunrise) 360.0 - Math.toDegrees(acos(cosHourAngle)) else Math.toDegrees(acos(cosHourAngle))
        localHour /= 15.0
        val localMeanTime = localHour + rightAscension - (0.06571 * approximateTime) - 6.622
        val utcHour = (localMeanTime - lngHour + 24.0) % 24.0
        val localHourDecimal = (utcHour + timezoneOffsetHours + 24.0) % 24.0
        val hour = floor(localHourDecimal).toInt()
        val minute = ((localHourDecimal - hour) * 60.0).roundToInt().coerceIn(0, 59)
        return Calendar.getInstance(timeZone).apply {
            time = date
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.time
    }

    val sunrise = event(true) ?: return null
    val sunset = event(false) ?: return null
    return sunrise to sunset
}

@Composable
private fun SevenDayCard(days: List<DayForecast>, temperatureUnit: TemperatureUnit, palette: Palette) = ThemedForecastCard(palette) {
    Text("${days.size}-day forecast", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Tap a day for more detail", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
    days.forEachIndexed { index, day ->
        var expanded by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (index == 0) "Today" else dayName(index), Modifier.width(64.dp), fontWeight = FontWeight.Bold)
                WeatherArtwork(day.icon, false, Modifier.size(43.dp))
                Text("${day.condition}\nRain ${day.rainChance}%", Modifier.weight(1f).padding(start = 9.dp), color = MaterialTheme.colorScheme.onSurface.copy(.73f), fontSize = 11.sp)
                Text("${displayTemperature(day.high, temperatureUnit)}°  ${displayTemperature(day.low, temperatureUnit)}°", fontWeight = FontWeight.Bold)
            }
            AnimatedVisibility(expanded) {
                Surface(Modifier.fillMaxWidth().padding(top = 10.dp), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primary.copy(.08f)) {
                    Text("Low ${displayTemperature(day.low, temperatureUnit)}° · High ${displayTemperature(day.high, temperatureUnit)}°\n${day.rainChance}% chance of rain · Up to ${day.rainAmount} mm possible.", Modifier.padding(15.dp), fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
        }
    }
}

@Composable
private fun PrecipitationCard(hours: List<HourForecast>, palette: Palette) = ThemedForecastCard(palette) {
    Text("Hourly precipitation", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Chance of rain over the hours ahead", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
    val source = remember(hours) {
        hours.take(18).ifEmpty { List(12) { HourForecast(Date(System.currentTimeMillis() + it * 3_600_000L), 18, "", it * 3, 0, 0, "") } }
    }
    val hourFormatter = remember { SimpleDateFormat("h", Locale.ENGLISH) }
    val barBrush = remember { Brush.verticalGradient(listOf(Color(0xFF79DCE5), Color(0xFF478ED1))) }
    LazyRow(
        Modifier.fillMaxWidth().height(132.dp).padding(top = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(
            items = source,
            key = { it.time.time },
            contentType = { "precipitation-hour" }
        ) { h ->
            Column(Modifier.width(46.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${h.rainChance}%", Modifier.height(18.dp).fillMaxWidth(), fontSize = 9.sp, textAlign = TextAlign.Center)
                Box(Modifier.height(78.dp).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier.width(16.dp)
                            .height((18 + h.rainChance.coerceIn(0, 100) * .58).dp)
                            .clip(CircleShape)
                            .background(barBrush)
                    )
                }
                Text(hourFormatter.format(h.time), Modifier.height(20.dp).fillMaxWidth(), fontSize = 9.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun WindForecastCard(hours: List<HourForecast>, palette: Palette, place: Place) = ThemedForecastCard(palette) {
    Text("Hourly wind", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Wind intensity and direction over the hours ahead", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
    val source = remember(hours) { hours.take(18) }
    val formatter = remember(place.timeZoneId) { localFormatter("ha", place) }
    val maximum = (source.maxOfOrNull { it.wind } ?: 1).coerceAtLeast(10)
    val windBrush = remember(palette.secondary, palette.accent) {
        Brush.verticalGradient(listOf(palette.secondary.copy(.95f), palette.accent.copy(.72f)))
    }
    if (source.isEmpty()) {
        Text("Wind forecast unavailable", Modifier.padding(top = 24.dp, bottom = 18.dp), color = MaterialTheme.colorScheme.onSurface.copy(.62f))
    } else {
        LazyRow(
            Modifier.fillMaxWidth().height(150.dp).padding(top = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(source, key = { it.time.time }, contentType = { "wind-hour" }) { hour ->
                Column(Modifier.width(52.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${hour.wind}", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("km/h", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                    Box(Modifier.height(76.dp).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                        Box(
                            Modifier.width(18.dp)
                                .height((16f + 58f * hour.wind.coerceAtLeast(0) / maximum.toFloat()).dp)
                                .clip(RoundedCornerShape(9.dp))
                                .background(windBrush)
                        )
                    }
                    Text(hour.direction.ifBlank { "—" }, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = palette.secondary)
                    Text(formatter.format(hour.time).lowercase(), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f))
                }
            }
        }
    }
}

@Composable
private fun WarningCard(warnings: List<String>) {
    val context = LocalContext.current
    Card(
        Modifier.fillMaxWidth().clickable { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bom.gov.au/australia/warnings/"))) },
        shape = RoundedCornerShape(25.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE7C2)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE9A850))
    ) {
        Row(Modifier.padding(18.dp)) {
            Text("⚠", fontSize = 25.sp)
            Column(Modifier.padding(start = 13.dp)) {
                Text("Weather warning", color = Color(0xFF704212), fontWeight = FontWeight.Bold)
                Text(warnings.first(), color = Color(0xFF704212), fontSize = 11.sp)
                if (warnings.size > 1) Text("+${warnings.size - 1} more warning${if (warnings.size > 2) "s" else ""}", color = Color(0xFF704212), fontSize = 10.sp)
            }
        }
    }
}

private fun pressureSourceDescription(observation: Observation): String = when (observation.pressureSource) {
    PressureSource.BOM -> "BOM mean sea-level pressure"
    PressureSource.OPEN_METEO -> "Open-Meteo estimate · not BOM sourced"
    PressureSource.UNAVAILABLE -> "Mean sea-level pressure unavailable"
}

private val detailCardIds = listOf("sun", "wind", "moon", "rain", "uv", "pressure", "humidity", "season", "tide")

@Composable
private fun DetailCards(weather: WeatherState, preferences: AtmosPreferences) {
    val context = LocalContext.current
    var order by remember { mutableStateOf(preferences.cardOrder) }
    val hidden by remember { mutableStateOf(preferences.hiddenCards) }
    var draggingId by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    val density = LocalDensity.current
    val configuration = LocalConfiguration.current
    val cardWidthPx = with(density) { ((configuration.screenWidthDp.dp - 58.dp) / 2f).toPx() }
    val cardHeightPx = with(density) { 207.dp.toPx() }

    fun moveVisibleCard(id: String, visibleDelta: Int) {
        val visible = order.filterNot { it in hidden }
        val fromVisible = visible.indexOf(id)
        val targetVisible = (fromVisible + visibleDelta).coerceIn(visible.indices)
        if (fromVisible < 0 || targetVisible == fromVisible) return
        val targetId = visible[targetVisible]
        val from = order.indexOf(id)
        val target = order.indexOf(targetId)
        if (from < 0 || target < 0) return
        val changed = order.toMutableList().apply {
            removeAt(from)
            add(target, id)
        }
        order = changed
        preferences.cardOrder = changed
    }

    Column {
        Text("Weather details", Modifier.padding(start = 4.dp, top = 8.dp), fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Hold the grip and drag to rearrange · tap to expand", Modifier.padding(start = 4.dp, bottom = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(.6f), fontSize = 11.sp)
        val visible = order.filterNot { it in hidden }
        visible.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                row.forEach { id ->
                    var expanded by remember(id) { mutableStateOf(false) }
                    val isDragging = draggingId == id
                    DetailCard(
                        id = id,
                        weather = weather,
                        expanded = expanded,
                        modifier = Modifier
                            .weight(1f)
                            .zIndex(if (isDragging) 20f else 0f)
                            .graphicsLayer {
                                translationX = if (isDragging) dragOffset.x else 0f
                                translationY = if (isDragging) dragOffset.y else 0f
                                scaleX = if (isDragging) 1.035f else 1f
                                scaleY = if (isDragging) 1.035f else 1f
                                shadowElevation = if (isDragging) 22.dp.toPx() else 0f
                            }
                            .pointerInput(id, order, hidden) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { draggingId = id; dragOffset = Offset.Zero },
                                    onDragCancel = { draggingId = null; dragOffset = Offset.Zero },
                                    onDragEnd = { draggingId = null; dragOffset = Offset.Zero; preferences.cardOrder = order },
                                    onDrag = { change, amount ->
                                        change.consume()
                                        dragOffset += amount
                                        val horizontal = when {
                                            dragOffset.x > cardWidthPx * .42f -> 1
                                            dragOffset.x < -cardWidthPx * .42f -> -1
                                            else -> 0
                                        }
                                        val vertical = when {
                                            dragOffset.y > cardHeightPx * .45f -> 2
                                            dragOffset.y < -cardHeightPx * .45f -> -2
                                            else -> 0
                                        }
                                        val delta = if (vertical != 0) vertical else horizontal
                                        if (delta != 0) {
                                            moveVisibleCard(id, delta)
                                            dragOffset = Offset(
                                                dragOffset.x - horizontal * cardWidthPx,
                                                dragOffset.y - (vertical / 2) * cardHeightPx
                                            )
                                        }
                                    }
                                )
                            },
                        dragging = isDragging
                    ) {
                        if (expanded && id == "tide") {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bom.gov.au/australia/tides/")))
                        } else {
                            expanded = !expanded
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(11.dp))
        }
    }
}

private data class DetailValue(val title: String, val value: String, val detail: String, val color: Color)

@Composable
private fun DetailCard(id: String, weather: WeatherState, expanded: Boolean, modifier: Modifier, dragging: Boolean, onClick: () -> Unit) {
    val day = weather.days.first()
    val detailValue = remember(id, weather.observation, day, weather.place.latitude, weather.place.longitude, weather.place.timeZoneId) {
        when (id) {
            "sun" -> {
                val solar = calculateSolarTimes(Date(), weather.place.latitude, weather.place.longitude, weather.place.timeZone())
                val formatter = localFormatter("h:mm a", weather.place)
                if (solar != null) {
                    DetailValue(
                        "Sun & daylight",
                        "Sunset ${formatter.format(solar.second).lowercase(Locale.getDefault())}",
                        "Sunrise ${formatter.format(solar.first).lowercase(Locale.getDefault())}",
                        Color(0xFFFFB52E)
                    )
                } else {
                    DetailValue("Sun & daylight", "Solar cycle", "No sunrise or sunset today", Color(0xFFFFB52E))
                }
            }
            "wind" -> DetailValue("Wind", weather.observation.wind?.let { "$it km/h" } ?: "Not available", "${weather.observation.direction} · gusts ${weather.observation.gust ?: "—"} km/h", Color(0xFF49A8FF))
            "moon" -> DetailValue("Moon", moonName(), "${moonIllumination()}% illuminated", Color(0xFF9B86FF))
            "rain" -> DetailValue("Rain", "${day.rainChance}%", "Up to ${day.rainAmount} mm expected", Color(0xFF27D2F2))
            "uv" -> {
                val uv = day.uvMax
                DetailValue(
                    "UV index",
                    uv?.let { formatUvIndex(it) } ?: "Not available",
                    uv?.let { uvIndexDescription(it) } ?: "Daily UV forecast unavailable",
                    Color(0xFFFF775E)
                )
            }
            "pressure" -> DetailValue("Pressure", weather.observation.pressure?.let { "${it.roundToInt()} hPa" } ?: "Not available", pressureSourceDescription(weather.observation), Color(0xFF7D82FF))
            "humidity" -> DetailValue("Humidity", weather.observation.humidity?.let { "$it%" } ?: "Not available", "Current observation", Color(0xFF35D3AE))
            "season" -> DetailValue("Season", seasonName(weather.place), daysToNextSeason(weather.place), Color(0xFFFF9B55))
            else -> DetailValue("Tides", "BOM tides", "Official coastal predictions", Color(0xFF3F9FFF))
        }
    }
    val (title, value, detail, color) = detailValue
    val isDarkDetailSurface = colourBrightness(MaterialTheme.colorScheme.surface) < .45f
    val detailCardFill = blendColor(
        MaterialTheme.colorScheme.surface,
        color,
        if (isDarkDetailSurface) .14f else .075f
    )
    val detailIconBackground = blendColor(detailCardFill, color, if (isDarkDetailSurface) .32f else .22f)
    val detailIconForeground = color.copy(alpha = if (isDarkDetailSurface) .98f else .92f)
    Card(
        modifier.height(if (expanded) 304.dp else 196.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = detailCardFill),
        border = androidx.compose.foundation.BorderStroke(1.25.dp, oledAwareCardOutline(color.copy(.68f)))
    ) {
        Box(Modifier.fillMaxSize().padding(16.dp)) {
            Surface(
                modifier = Modifier.align(Alignment.TopCenter).size(50.dp),
                shape = CircleShape,
                color = detailIconBackground
            ) {
                Box(contentAlignment = Alignment.Center) {
                    AtmosDetailIcon(id, detailIconForeground, Modifier.size(30.dp))
                }
            }
            Text(
                "⠿",
                modifier = Modifier.align(Alignment.TopStart).padding(top = 3.dp, start = 2.dp),
                color = MaterialTheme.colorScheme.onSurface.copy(if (dragging) .9f else .42f),
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                if (expanded) "⌄" else "›",
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 2.dp, end = 2.dp),
                color = MaterialTheme.colorScheme.onSurface.copy(.52f),
                fontSize = 23.sp
            )
            Column(
                modifier = Modifier.align(Alignment.Center).fillMaxWidth().padding(top = 35.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(title, color = MaterialTheme.colorScheme.onSurface.copy(.64f), fontSize = 11.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(5.dp))
                Text(value, fontSize = 22.sp, lineHeight = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                AnimatedVisibility(expanded) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(Modifier.height(8.dp))
                        Text(detail, color = MaterialTheme.colorScheme.onSurface.copy(.68f), fontSize = 10.sp, lineHeight = 14.sp, textAlign = TextAlign.Center)
                        Text(
                            detailDescription(id),
                            Modifier.padding(top = 14.dp),
                            color = MaterialTheme.colorScheme.onSurface.copy(.76f),
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConditionsDayChart(hours: List<HourForecast>, temperatureUnit: TemperatureUnit, palette: Palette, place: Place) {
    val surfaceColor = MaterialTheme.colorScheme.surface
    val gridColor = MaterialTheme.colorScheme.onSurface.copy(.08f)
    val fullDay = remember(hours) { hours.take(24) }
    if (fullDay.size < 2) return
    val temperatures = fullDay.map { displayTemperature(it.temp, temperatureUnit) }
    val minTemp = temperatures.minOrNull() ?: 0
    val maxTemp = temperatures.maxOrNull() ?: minTemp + 1
    val range = (maxTemp - minTemp).coerceAtLeast(1)
    val formatter = remember(place.timeZoneId) { localFormatter("ha", place) }
    Card(
        Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 22.dp),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(.88f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(.35f))
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Today’s temperature & rain", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Full-day outlook", color = MaterialTheme.colorScheme.onSurface.copy(.60f), fontSize = 10.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${maxTemp}° / ${minTemp}°", fontWeight = FontWeight.Bold)
                    Text("Peak / low", color = MaterialTheme.colorScheme.onSurface.copy(.55f), fontSize = 9.sp)
                }
            }
            Canvas(Modifier.fillMaxWidth().height(190.dp).padding(top = 20.dp, bottom = 14.dp)) {
                val left = 4.dp.toPx()
                val right = size.width - 4.dp.toPx()
                val top = 8.dp.toPx()
                val bottom = size.height - 8.dp.toPx()
                repeat(4) { index ->
                    val y = top + (bottom - top) * index / 3f
                    drawLine(gridColor, Offset(left, y), Offset(right, y), 1.dp.toPx())
                }
                val step = (right - left) / (fullDay.size - 1).coerceAtLeast(1)
                fullDay.forEachIndexed { index, hour ->
                    val barMax = (bottom - top) * .40f
                    val barHeight = barMax * hour.rainChance.coerceIn(0, 100) / 100f
                    val x = left + index * step
                    drawLine(
                        palette.accent.copy(.34f),
                        Offset(x, bottom),
                        Offset(x, bottom - barHeight),
                        strokeWidth = (step * .55f).coerceAtLeast(2.dp.toPx()),
                        cap = StrokeCap.Round
                    )
                }
                val path = Path()
                temperatures.forEachIndexed { index, temp ->
                    val x = left + index * step
                    val normalised = (temp - minTemp).toFloat() / range
                    val y = bottom - (bottom - top) * (.25f + normalised * .67f)
                    if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, palette.secondary, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
                temperatures.forEachIndexed { index, temp ->
                    if (index % 4 == 0 || index == temperatures.lastIndex) {
                        val x = left + index * step
                        val normalised = (temp - minTemp).toFloat() / range
                        val y = bottom - (bottom - top) * (.25f + normalised * .67f)
                        drawCircle(surfaceColor, 4.3.dp.toPx(), Offset(x, y))
                        drawCircle(palette.secondary, 2.5.dp.toPx(), Offset(x, y))
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf(0, fullDay.size / 3, (fullDay.size * 2) / 3, fullDay.lastIndex).distinct().forEach { index ->
                    Text(formatter.format(fullDay[index].time).lowercase(), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                }
            }
            Row(Modifier.padding(top = 13.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(palette.secondary))
                    Text(" Temperature", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(palette.accent.copy(.55f)))
                    Text(" Precipitation", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f))
                }
            }
        }
    }
}

@Composable
private fun ConditionsPage(weather: WeatherState, temperatureUnit: TemperatureUnit, onBack: () -> Unit) {
    val day = weather.days.first()
    val palette = conditionPalette(day.icon, isNight())
    LazyColumn(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(palette.top.copy(.7f), MaterialTheme.colorScheme.background), endY = 1200f)),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = persistentStatusBarTopInset() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 25.dp
        )
    ) {
        item { PageHeader("Current conditions", onBack) }
        item {
            Box(Modifier.fillMaxWidth().height(350.dp)) {
                Column(Modifier.padding(top = 38.dp)) {
                    Text("${displayTemperature(weather.observation.temp ?: day.high - 2, temperatureUnit)}°", fontSize = 88.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-5).sp)
                    Text(nightCondition(day.condition), fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("Feels like ${displayTemperature(weather.observation.feels ?: day.high - 3, temperatureUnit)}° · H ${displayTemperature(day.high, temperatureUnit)}° · L ${displayTemperature(day.low, temperatureUnit)}°", color = MaterialTheme.colorScheme.onSurface.copy(.65f))
                    Surface(Modifier.fillMaxWidth().padding(top = 34.dp), shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface.copy(.22f), border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(.26f))) {
                        Text(conditionNarrative(weather), Modifier.padding(17.dp), fontSize = 14.sp, lineHeight = 22.sp)
                    }
                }
            }
        }
        item {
            ConditionsDayChart(weather.hours, temperatureUnit, palette, weather.place)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text(if (weather.live) "LIVE BOM DATA" else "ESTIMATED DATA", Modifier.clip(CircleShape).background(palette.secondary.copy(.2f)).padding(horizontal = 11.dp, vertical = 7.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Text("Updated ${localFormatter("h:mm a", weather.place).format(weather.updated).lowercase()}", Modifier.padding(8.dp), fontSize = 9.sp)
            }
        }
        item { Text("${weather.place.name}, ${weather.place.state}", Modifier.padding(top = 22.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item { Text("Current observations and today’s forecast", color = MaterialTheme.colorScheme.onSurface.copy(.72f), fontSize = 11.sp) }
        val observations = listOf(
            Triple("Humidity", weather.observation.humidity?.let { "$it%" } ?: "Not available", "Current observation"),
            Triple("Wind", weather.observation.wind?.let { "${weather.observation.direction} $it km/h" } ?: "Not available", "Gusts ${weather.observation.gust ?: "—"} km/h"),
            Triple("Pressure", weather.observation.pressure?.let { "${it.roundToInt()} hPa" } ?: "Not available", pressureSourceDescription(weather.observation)),
            Triple("Rain chance", "${day.rainChance}%", "${day.rainAmount} mm possible"),
            Triple("UV index", day.uvMax?.let { formatUvIndex(it) } ?: "Not available", day.uvMax?.let { uvIndexBand(it) } ?: "Daily forecast"),
            Triple("Visibility", "Not available", "Nearest observation"),
            Triple("Rain since 9am", weather.observation.rainSince9?.let { "$it mm" } ?: "Not available", weather.observation.station),
            Triple("Moon phase", moonName(), "${moonIllumination()}% illuminated")
        )
        items(observations.chunked(2)) { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { item ->
                    Column(Modifier.weight(1f).padding(vertical = 20.dp).border(width = 0.dp, color = Color.Transparent).drawBehind { drawLine(palette.secondary.copy(.35f), Offset.Zero, Offset(size.width, 0f), 1.dp.toPx()) }) {
                        Text(item.first, color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 10.sp)
                        Text(item.second, Modifier.padding(vertical = 7.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text(item.third, color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SeasonsPage(dark: Boolean, userPlace: Place, onBack: () -> Unit) {
    val southern = listOf(
        Season("Autumn", "Warmth softens.", "Long summer light gives way to cooler evenings and changing colour.", "1 March – 31 May", "Southern Hemisphere", "8–22°C", Color(0xFFE5A17D), Color(0xFFF6C8A5), Color(0xFF543638)),
        Season("Winter", "Cool, quiet light.", "Shorter days, crisp mornings and the year’s longest nights.", "1 June – 31 August", "Southern Hemisphere", "3–16°C", Color(0xFF9DBBDD), Color(0xFFCFE9F7), Color(0xFF173A68)),
        Season("Spring", "Colour returns.", "Days lengthen, landscapes brighten and warmth begins to build.", "1 September – 30 November", "Southern Hemisphere", "9–23°C", Color(0xFFA9D69E), Color(0xFFD8EDB8), Color(0xFF24563B)),
        Season("Summer", "Light lingers.", "Long, bright days bring warmth, clear evenings and vivid skies.", "1 December – 28 February", "Southern Hemisphere", "18–32°C", Color(0xFFF0A36F), Color(0xFFF9D98F), Color(0xFF6A3B24))
    )
    val northern = listOf(
        Season("Spring", "The year opens.", "Daylight grows, temperatures lift and landscapes return to colour.", "1 March – 31 May", "Northern Hemisphere", "8–22°C", Color(0xFFA9D69E), Color(0xFFD8EDB8), Color(0xFF24563B)),
        Season("Summer", "Light reaches its peak.", "The longest days bring sustained warmth and bright evening skies.", "1 June – 31 August", "Northern Hemisphere", "18–32°C", Color(0xFFF0A36F), Color(0xFFF9D98F), Color(0xFF6A3B24)),
        Season("Autumn", "Light begins to settle.", "Days shorten, warmth eases and the landscape shifts toward deeper colour.", "1 September – 30 November", "Northern Hemisphere", "8–22°C", Color(0xFFE5A17D), Color(0xFFF6C8A5), Color(0xFF543638)),
        Season("Winter", "The quiet season.", "Low sun, long nights and colder air define the close of the year.", "1 December – 28 February", "Northern Hemisphere", "-2–12°C", Color(0xFF9DBBDD), Color(0xFFCFE9F7), Color(0xFF173A68))
    )
    val tropical = listOf(
        Season("Wet season", "Rain shapes the year.", "Humidity builds, rainfall becomes more frequent and landscapes turn intensely green.", "Timing varies by latitude", "Tropical cycle", "24–32°C", Color(0xFF4FAF9B), Color(0xFFA7E0C5), Color(0xFF123F3A)),
        Season("Dry season", "Clearer, calmer air.", "Rainfall eases, humidity falls and brighter, more stable days become common.", "Timing varies by latitude", "Tropical cycle", "20–31°C", Color(0xFFD49A52), Color(0xFFF2D28A), Color(0xFF533918))
    )
    val currentSeason = seasonName(userPlace)
    val currentMonth = Calendar.getInstance().get(Calendar.MONTH) + 1
    val currentSouthernSeason = when (currentMonth) {
        12, 1, 2 -> "Summer"
        3, 4, 5 -> "Autumn"
        6, 7, 8 -> "Winter"
        else -> "Spring"
    }
    val currentNorthernSeason = when (currentMonth) {
        12, 1, 2 -> "Winter"
        3, 4, 5 -> "Spring"
        6, 7, 8 -> "Summer"
        else -> "Autumn"
    }
    val foreground = if (dark) Color.White else Color(0xFF25313A)

    fun LazyListScope.seasonSection(title: String, subtitle: String, seasons: List<Season>, highlightedSeason: String?) {
        item {
            Column(Modifier.padding(top = 22.dp, bottom = 4.dp)) {
                Text(title.uppercase(Locale.ROOT), color = foreground.copy(.72f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(subtitle, color = foreground, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }
        items(seasons) { season -> SeasonInformationCard(season, season.name == highlightedSeason) }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = persistentStatusBarTopInset() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 112.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHeader("Seasons", onBack, foreground = foreground) }
        item {
            AtmosPageIntro(
                title = "Seasons around the world",
                subtitle = "Atmos highlights ${currentSeason.lowercase(Locale.ROOT)} for ${userPlace.name} using local latitude and time.",
                foreground = foreground
            )
        }
        seasonSection("Southern Hemisphere", "Australia and locations south of the equator", southern, currentSouthernSeason)
        seasonSection("Northern Hemisphere", "Locations north of the equator", northern, currentNorthernSeason)
        seasonSection(
            "Wet and dry seasons",
            "A tropical cycle near the equator",
            tropical,
            currentSeason.takeIf { it == "Wet season" || it == "Dry season" }
        )
        item {
            Text(
                "Meteorological seasons use three-month blocks. Near the equator, Atmos uses a simplified wet/dry cycle because four temperature seasons are often less meaningful.",
                Modifier.padding(15.dp), color = foreground.copy(.76f), fontSize = 11.sp, lineHeight = 17.sp, textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun SeasonInformationCard(season: Season, current: Boolean) {
    Card(
        Modifier.fillMaxWidth().height(245.dp),
        shape = RoundedCornerShape(34.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.72f))
    ) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(season.one, season.two))).padding(24.dp)) {
            Column(Modifier.fillMaxHeight()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = CircleShape, color = season.textColor.copy(alpha = .14f)) {
                        Text(season.name, Modifier.padding(horizontal = 13.dp, vertical = 8.dp), color = season.textColor, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.weight(1f))
                    if (current) {
                        Surface(
                            shape = CircleShape,
                            color = season.textColor.copy(alpha = .90f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.22f))
                        ) {
                            Text("Current season", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = contrastForeground(season.textColor.copy(alpha = .90f), season.textColor), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(23.dp))
                Text(season.headline, color = season.textColor, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(season.description, Modifier.widthIn(max = 285.dp).padding(top = 6.dp), color = season.textColor.copy(.78f), fontSize = 12.sp, lineHeight = 18.sp)
                Spacer(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = CircleShape, color = season.textColor.copy(alpha = .13f)) {
                        Text(season.dates, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = season.textColor, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                    Surface(shape = CircleShape, color = season.textColor.copy(alpha = .18f)) {
                        Text(season.temperatureRange, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = season.textColor, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SeasonAtmosSun(season: Season, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val centre = Offset(size.width / 2f, size.height / 2f)
        drawCircle(season.one.copy(.20f), radius = size.minDimension * .49f, center = centre)
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(.97f), season.two.copy(.95f), season.one),
                center = centre,
                radius = size.minDimension * .36f
            ),
            radius = size.minDimension * .36f,
            center = centre
        )
        drawCircle(Color.White.copy(.20f), radius = size.minDimension * .29f, center = centre, style = Stroke(width = 1.3.dp.toPx()))
    }
}


private data class SeasonDetailContent(
    val headline: String,
    val introduction: String,
    val dates: String,
    val temperature: String,
    val precipitation: String,
    val daylight: String,
    val landscape: String,
    val nextSeason: String,
    val colours: List<Color>,
    val foreground: Color
)

private fun seasonDetailContent(name: String, place: Place): SeasonDetailContent {
    val tropical = kotlin.math.abs(place.latitude) < 8.0 || name.contains("season", ignoreCase = true)
    val southern = place.latitude < 0.0
    val cycle = if (tropical) "Tropical cycle" else if (southern) "Southern Hemisphere" else "Northern Hemisphere"
    val dateRange = when {
        tropical && name == "Wet season" -> if (place.latitude >= 0) "May – October (approx.)" else "November – April (approx.)"
        tropical -> if (place.latitude >= 0) "November – April (approx.)" else "May – October (approx.)"
        southern && name == "Summer" -> "1 December – 28 February"
        southern && name == "Autumn" -> "1 March – 31 May"
        southern && name == "Winter" -> "1 June – 31 August"
        southern && name == "Spring" -> "1 September – 30 November"
        !southern && name == "Winter" -> "1 December – 28 February"
        !southern && name == "Spring" -> "1 March – 31 May"
        !southern && name == "Summer" -> "1 June – 31 August"
        else -> "1 September – 30 November"
    }
    val latitudeBand = kotlin.math.abs(place.latitude)
    val temp = when (name) {
        "Summer" -> when { latitudeBand < 18 -> "24–34°C"; latitudeBand < 35 -> "18–32°C"; else -> "14–28°C" }
        "Winter" -> when { latitudeBand < 18 -> "17–28°C"; latitudeBand < 35 -> "5–18°C"; else -> "−3–12°C" }
        "Spring" -> when { latitudeBand < 18 -> "21–31°C"; latitudeBand < 35 -> "10–24°C"; else -> "6–20°C" }
        "Autumn" -> when { latitudeBand < 18 -> "21–31°C"; latitudeBand < 35 -> "10–24°C"; else -> "5–19°C" }
        "Wet season" -> "24–32°C"
        else -> "20–31°C"
    }
    val rain = when (name) {
        "Wet season" -> "Frequent showers and thunderstorms, with humidity and rainfall at their annual peak."
        "Dry season" -> "Longer dry spells, lower humidity and generally more stable skies."
        "Winter" -> if (latitudeBand < 35) "Rainfall varies locally; frontal rain is common in many temperate regions." else "Rain, frost or snow become more likely as cold systems pass."
        "Summer" -> "Rainfall is often more episodic, with showers or storms interrupting longer bright periods."
        "Spring" -> "Changeable rainfall is common as warmer and cooler air masses compete."
        else -> "Rainfall patterns gradually shift as summer warmth eases and weather systems strengthen."
    }
    val daylight = when (name) {
        "Summer" -> "The longest daylight and highest sun angle of the year."
        "Winter" -> "The shortest daylight and lowest sun angle of the year."
        "Spring" -> "Daylight increases quickly and the sun climbs higher each week."
        "Autumn" -> "Daylight contracts steadily and evenings arrive earlier."
        "Wet season" -> "Day length changes little; cloud build-up shapes the daily light cycle."
        else -> "Day length changes little, with clearer skies often producing stronger daytime light."
    }
    val landscape = when (name) {
        "Summer" -> "Warmth, dry ground and vivid late light define much of the season."
        "Autumn" -> "Colour deepens, nights cool and the atmosphere becomes calmer and softer."
        "Winter" -> "Low-angle light, crisp air and longer shadows give the landscape a quieter character."
        "Spring" -> "Growth, flowering and rapidly changing light bring renewed colour."
        "Wet season" -> "Water, humidity and dense green growth transform the landscape."
        else -> "Clear air, pale grasses and strong day–night temperature contrasts become more noticeable."
    }
    val visual = when (name) {
        "Summer" -> Triple(listOf(Color(0xFFFFD48A), Color(0xFFF39A66), Color(0xFF76558D), Color(0xFF183A5A)), Color(0xFF2A2330), "Light reaches its fullest expression.")
        "Autumn" -> Triple(listOf(Color(0xFFF6C49C), Color(0xFFC97862), Color(0xFF68475B), Color(0xFF1E3447)), Color(0xFF2D2530), "Warmth settles into deeper colour.")
        "Winter" -> Triple(listOf(Color(0xFFD8F1FF), Color(0xFF8FB8D8), Color(0xFF496886), Color(0xFF15243D)), Color(0xFF17253A), "Cool light, long shadows, quiet air.")
        "Spring" -> Triple(listOf(Color(0xFFE9F5B7), Color(0xFFA7D9A6), Color(0xFF6BB7B1), Color(0xFF315B78)), Color(0xFF203E35), "The year opens into colour again.")
        "Wet season" -> Triple(listOf(Color(0xFFBFEBCB), Color(0xFF56B9A6), Color(0xFF287487), Color(0xFF15344A)), Color(0xFF123B39), "Rain becomes the rhythm of the year.")
        else -> Triple(listOf(Color(0xFFFFE3A1), Color(0xFFD7A55F), Color(0xFF877053), Color(0xFF253C4D)), Color(0xFF40321D), "Clearer air and steadier light return.")
    }
    val next = daysToNextSeason(place)
    return SeasonDetailContent(visual.third, "$name in ${place.name} follows the $cycle pattern. These ranges describe the broad seasonal character rather than a formal climate normal.", dateRange, temp, rain, daylight, landscape, next, visual.first, visual.second)
}

@Composable
private fun SeasonDetailPage(seasonName: String, place: Place, onBack: () -> Unit) {
    val detail = remember(seasonName, place) { seasonDetailContent(seasonName, place) }
    val foreground = detail.foreground
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(detail.colours))) {
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color.White.copy(.08f), Color.Transparent, Color.Black.copy(.18f)))))
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = persistentStatusBarTopInset() + 15.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 30.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { PageHeader(place.name, onBack, foreground = foreground) }
            item {
                Column(Modifier.padding(top = 28.dp, bottom = 20.dp)) {
                    Text("THE SEASON IN ${place.name.uppercase(Locale.ROOT)}", color = foreground.copy(.70f), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                    Text(seasonName, Modifier.padding(top = 6.dp), color = foreground, fontSize = 66.sp, lineHeight = 68.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-2).sp)
                    Text(detail.headline, Modifier.padding(top = 10.dp).widthIn(max = 330.dp), color = foreground.copy(.82f), fontSize = 20.sp, lineHeight = 27.sp, fontWeight = FontWeight.Bold)
                    Text(detail.introduction, Modifier.padding(top = 13.dp).widthIn(max = 350.dp), color = foreground.copy(.72f), fontSize = 13.sp, lineHeight = 20.sp)
                }
            }
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(34.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(.17f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.38f))
                ) {
                    Column(Modifier.padding(24.dp)) {
                        Text(detail.nextSeason.uppercase(Locale.ROOT), color = foreground.copy(.65f), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
                        Text("The next shift in light", Modifier.padding(top = 7.dp), color = foreground, fontSize = 26.sp, lineHeight = 30.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Atmos counts down using ${place.name}’s local calendar and seasonal cycle.", Modifier.padding(top = 7.dp), color = foreground.copy(.70f), fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }
            item { SeasonDetailMetric("Date range", detail.dates, "Meteorological timing for this location", foreground) }
            item { SeasonDetailMetric("Typical temperature", detail.temperature, "Broad daytime and overnight range", foreground) }
            item { SeasonDetailMetric("Precipitation", detail.precipitation, "What rainfall usually feels like", foreground) }
            item { SeasonDetailMetric("Light", detail.daylight, "How the season changes the sky", foreground) }
            item { SeasonDetailMetric("Landscape", detail.landscape, "The season beyond the forecast", foreground) }
            item {
                Text(
                    "Seasonal conditions vary from year to year and between nearby landscapes. Atmos presents an expressive location-aware guide, not an official climate record.",
                    Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    color = foreground.copy(.66f),
                    fontSize = 11.sp,
                    lineHeight = 17.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun SeasonDetailMetric(label: String, value: String, caption: String, foreground: Color) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = Color.White.copy(.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.30f))
    ) {
        Column(Modifier.padding(22.dp)) {
            Text(label.uppercase(Locale.ROOT), color = foreground.copy(.62f), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
            Text(value, Modifier.padding(top = 7.dp), color = foreground, fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text(caption, Modifier.padding(top = 5.dp), color = foreground.copy(.66f), fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

private data class Season(
    val name: String,
    val headline: String,
    val description: String,
    val dates: String,
    val cycle: String,
    val temperatureRange: String,
    val one: Color,
    val two: Color,
    val textColor: Color = Color(0xFF4D3135)
)

private fun displayTemperature(celsius: Int, unit: TemperatureUnit): Int =
    if (unit == TemperatureUnit.Celsius) celsius else (celsius * 9f / 5f + 32f).roundToInt()


@Composable
private fun AtmosGradientHeading(
    text: String,
    modifier: Modifier = Modifier,
    fontSize: androidx.compose.ui.unit.TextUnit = 34.sp,
    lineHeight: androidx.compose.ui.unit.TextUnit = 39.sp
) {
    val scheme = MaterialTheme.colorScheme
    val headingBrush = remember(scheme.primary, scheme.tertiary, scheme.secondary) {
        Brush.linearGradient(
            colors = listOf(
                scheme.primary,
                blendColor(scheme.primary, scheme.tertiary, .52f),
                scheme.secondary
            )
        )
    }
    Text(
        text = text,
        modifier = modifier,
        style = TextStyle(
            brush = headingBrush,
            fontSize = fontSize,
            lineHeight = lineHeight,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-1.1).sp
        )
    )
}

@Composable
private fun AtmosPageIntro(
    title: String,
    subtitle: String,
    foreground: Color = MaterialTheme.colorScheme.onBackground
) {
    Column(Modifier.padding(top = 22.dp, bottom = 4.dp)) {
        AtmosGradientHeading(
            text = title,
            fontSize = 34.sp,
            lineHeight = 39.sp
        )
        Text(
            subtitle,
            Modifier.padding(top = 8.dp),
            color = foreground.copy(alpha = .68f),
            fontSize = 12.sp,
            lineHeight = 18.sp
        )
    }
}

@Composable
private fun SettingsPage(
    theme: ThemeChoice,
    darkNightMode: Boolean,
    conditionAnimations: Boolean,
    homeLayout: HomeLayout,
    locationTransition: LocationTransition,
    density: DensityChoice,
    menuLeft: Boolean,
    temperatureUnit: TemperatureUnit,
    atmosIntensityChoice: AtmosIntensityChoice,
    atmosTransitionChoice: AtmosTransitionChoice,
    accentColorChoice: AccentColorChoice,
    atmosphericSoundscapeEnabled: Boolean,
    ambientDisplayEnabled: Boolean,
    ambientDisplayDurationMinutes: Int,
    preferences: AtmosPreferences,
    onTheme: (ThemeChoice) -> Unit,
    onDarkNightMode: (Boolean) -> Unit,
    onConditionAnimations: (Boolean) -> Unit,
    onHomeLayout: (HomeLayout) -> Unit,
    onLocationTransition: (LocationTransition) -> Unit,
    onDensity: (DensityChoice) -> Unit,
    onMenuLeft: (Boolean) -> Unit,
    onTemperatureUnit: (TemperatureUnit) -> Unit,
    onAtmosIntensityChoice: (AtmosIntensityChoice) -> Unit,
    onAtmosTransitionChoice: (AtmosTransitionChoice) -> Unit,
    onAccentColorChoice: (AccentColorChoice) -> Unit,
    onAtmosphericSoundscapeEnabled: (Boolean) -> Unit,
    onAmbientDisplayEnabled: (Boolean) -> Unit,
    onAmbientDisplayDuration: (Int) -> Unit,
    onBack: () -> Unit
) {
    var settingsCategory by remember { mutableStateOf<SettingsCategory?>(null) }
    BackHandler(enabled = settingsCategory != null) { settingsCategory = null }
    var hidden by remember { mutableStateOf(preferences.hiddenCards) }
    var backgroundUpdates by remember { mutableStateOf(preferences.backgroundUpdates) }
    var weatherNotificationEnabled by remember { mutableStateOf(preferences.weatherNotificationEnabled) }
    var statusBarIconStyle by remember { mutableStateOf(preferences.statusBarIconStyle) }
    var widgetTextMode by remember { mutableStateOf(preferences.widgetTextMode) }
    var widgetGradientTypography by remember { mutableStateOf(preferences.widgetGradientTypography) }
    var gradientHeroTypography by remember { mutableStateOf(preferences.gradientHeroTypography) }
    var windUnit by remember { mutableStateOf(preferences.windUnit) }
    var pressureUnit by remember { mutableStateOf(preferences.pressureUnit) }
    var rainUnit by remember { mutableStateOf(preferences.rainUnit) }
    var visibilityUnit by remember { mutableStateOf(preferences.visibilityUnit) }
    val settingsContext = LocalContext.current
    var backgroundLocationGranted by remember { mutableStateOf(hasBackgroundLocationPermission(settingsContext)) }
    var requestBackgroundAfterForeground by remember { mutableStateOf(false) }
    val lifecycleOwner = LocalLifecycleOwner.current

    val backgroundLocationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        backgroundLocationGranted = granted || hasBackgroundLocationPermission(settingsContext)
        if (backgroundLocationGranted) scheduleBackgroundUpdates(settingsContext, backgroundUpdates)
    }
    val foregroundLocationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.any { it } && requestBackgroundAfterForeground) {
            requestBackgroundAfterForeground = false
            when {
                Build.VERSION.SDK_INT < Build.VERSION_CODES.Q -> backgroundLocationGranted = true
                Build.VERSION.SDK_INT == Build.VERSION_CODES.Q ->
                    backgroundLocationPermissionLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                else -> openAtmosLocationSettings(settingsContext)
            }
        } else {
            requestBackgroundAfterForeground = false
        }
    }
    DisposableEffect(lifecycleOwner, settingsContext) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                backgroundLocationGranted = hasBackgroundLocationPermission(settingsContext)
                if (backgroundLocationGranted && backgroundUpdates) {
                    scheduleBackgroundUpdates(settingsContext, true)
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            weatherNotificationEnabled = true
            preferences.weatherNotificationEnabled = true
            publishCachedWeatherNotification(settingsContext, preferences)
        } else {
            weatherNotificationEnabled = false
            preferences.weatherNotificationEnabled = false
        }
    }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        AnimatedContent(
            targetState = settingsCategory,
            transitionSpec = {
                val enteringCategory = targetState != null
                (fadeIn(tween(330)) + slideInHorizontally(tween(380)) { if (enteringCategory) it / 8 else -it / 8 }) togetherWith
                    (fadeOut(tween(260)) + slideOutHorizontally(tween(320)) { if (enteringCategory) -it / 10 else it / 10 })
            },
            label = "settingsCategoryTransition"
        ) { visibleCategory ->
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = persistentStatusBarTopInset() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 112.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHeader(if (visibleCategory == null) "Settings" else settingsCategoryTitle(visibleCategory!!), if (visibleCategory == null) onBack else ({ settingsCategory = null })) }
        item {
            AtmosPageIntro(
                title = if (visibleCategory == null) "Make Atmos yours" else settingsCategoryTitle(visibleCategory!!),
                subtitle = if (visibleCategory == null) "Appearance, layout and forecast preferences." else settingsCategorySubtitle(visibleCategory!!)
            )
        }
        if (visibleCategory == null) {
            item { SettingsMenuRow("Appearance & layout", "Theme, Atmos character, accent colour and forecast layout.", Icons.Filled.WbSunny) { settingsCategory = SettingsCategory.AppearanceLayout } }
            item { SettingsMenuRow("Weather experience", "Animated effects, units and weather-detail cards.", Icons.Filled.Info) { settingsCategory = SettingsCategory.WeatherExperience } }
            item { SettingsMenuRow("Updates & notifications", "Background refresh, location access and persistent notification.", Icons.Filled.MyLocation) { settingsCategory = SettingsCategory.UpdatesNotifications } }
            item { SettingsMenuRow("Home screen", "Atmos Display and the live wallpaper experience.", Icons.Filled.DisplaySettings) { settingsCategory = SettingsCategory.HomeScreen } }
            item { SettingsMenuRow("What's new", "Changes from the latest three Atmos versions.", Icons.Filled.Info) { settingsCategory = SettingsCategory.Changelog } }
        }
        if (visibleCategory == SettingsCategory.Changelog) {
            item { ChangelogVersionCard("0.69.11", listOf("Restored the faster natural rain fall speed from the previous Rain Engine", "Kept independent procedural drop lifetimes and randomised respawning", "Retained varied drop position, depth, length, opacity and subtle turbulence"), current = true) }
            item { ChangelogVersionCard("0.69.10", listOf("Rebuilt rain particles with individual procedural lifecycles", "Removed repeated grouped lines and short synchronised rain loops", "Drops now respawn with varied position, depth, speed, length and opacity", "Added subtle per-drop wind turbulence while preserving performance")) }
            item { ChangelogVersionCard("0.69.9", listOf("Rain now activates from measured precipitation as well as weather conditions", "Separated current precipitation from accumulated rainfall for provider-consistent intensity", "Rain angle now follows actual wind bearing and wind strength", "Added smoother rain fade-in, fade-out and intensity transitions", "Improved foreground and background rain depth")) }
        }
        if (visibleCategory == SettingsCategory.AppearanceLayout) {
        item {
            SettingsSection("Appearance", "Choose one colour mode for the entire app.") {
                Text("App appearance", Modifier.padding(bottom = 3.dp), fontWeight = FontWeight.Bold)
                Text("Used consistently across Atmos, forecasts, charts, Settings and dialogs.", color = MaterialTheme.colorScheme.onSurface.copy(.60f), fontSize = 10.sp, lineHeight = 14.sp)
                ChoiceRow("Follow Device", theme == ThemeChoice.System || theme == ThemeChoice.AutomaticLocation) { onTheme(ThemeChoice.System) }
                ChoiceRow("Light", theme == ThemeChoice.Light) { onTheme(ThemeChoice.Light) }
                ChoiceRow("Dark", theme == ThemeChoice.Dark) { onTheme(ThemeChoice.Dark) }
                AtmosSettingsToggle(
                    "Dark mode at night",
                    "Uses the current device location’s sunrise and sunset times to switch the entire app between light and dark mode.",
                    darkNightMode,
                    onChange = onDarkNightMode
                )
                AtmosSettingsToggle(
                    "Gradient Hero typography",
                    "Apply the location-name Atmos gradient to the temperature, degree symbol and large condition text.",
                    gradientHeroTypography,
                    onChange = { enabled ->
                        gradientHeroTypography = enabled
                        preferences.gradientHeroTypography = enabled
                    }
                )
            }
        }
        }
        if (visibleCategory == SettingsCategory.UpdatesNotifications) {
        item {
            SettingsSection("Weather updates", "Control automatic forecast refreshes.") {
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(end = 14.dp)) {
                        Text("Background updates", fontWeight = FontWeight.Bold)
                        Text("Refresh all saved locations together, then update widgets and the weather notification about every 15 minutes. Android may delay work to protect battery.", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    Switch(checked = backgroundUpdates, onCheckedChange = { enabled ->
                        backgroundUpdates = enabled
                        preferences.backgroundUpdates = enabled
                        scheduleBackgroundUpdates(settingsContext, enabled)
                    })
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(end = 14.dp)) {
                        Text("Update current location in background", fontWeight = FontWeight.Bold)
                        Text(
                            if (backgroundLocationGranted) "Allowed all the time. Atmos can follow the device while the app is closed."
                            else "Allow all the time so the current-location forecast and notification can follow the device while Atmos is closed.",
                            color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp
                        )
                    }
                    Switch(
                        checked = backgroundLocationGranted,
                        enabled = backgroundUpdates,
                        onCheckedChange = { enabled ->
                            if (enabled) {
                                if (!hasForegroundLocationPermission(settingsContext)) {
                                    requestBackgroundAfterForeground = true
                                    foregroundLocationPermissionLauncher.launch(
                                        arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
                                    )
                                } else when {
                                    Build.VERSION.SDK_INT < Build.VERSION_CODES.Q -> backgroundLocationGranted = true
                                    Build.VERSION.SDK_INT == Build.VERSION_CODES.Q ->
                                        backgroundLocationPermissionLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                                    else -> openAtmosLocationSettings(settingsContext)
                                }
                            } else {
                                // Android only lets users revoke background access from system settings.
                                openAtmosLocationSettings(settingsContext)
                            }
                        }
                    )
                }
                Text("Returning to an open Atmos session does not download weather again. A cold launch checks the shared cache, while pull-to-refresh updates every saved location together.", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
        }
        if (visibleCategory == SettingsCategory.UpdatesNotifications) {
        item {
            SettingsSection("Notifications", "Keep the first saved location visible at a glance.") {
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(end = 14.dp)) {
                        Text("Current weather notification", fontWeight = FontWeight.Bold)
                        Text("Shows the first saved location’s current temperature, today’s high and low, and a brief forecast.", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    Switch(checked = weatherNotificationEnabled, onCheckedChange = { enabled ->
                        if (!enabled) {
                            weatherNotificationEnabled = false
                            preferences.weatherNotificationEnabled = false
                            cancelWeatherNotification(settingsContext)
                        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            ContextCompat.checkSelfPermission(settingsContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            weatherNotificationEnabled = true
                            preferences.weatherNotificationEnabled = true
                            publishCachedWeatherNotification(settingsContext, preferences)
                        }
                    })
                }
                Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 6.dp)) {
                    Text("Status bar icon", fontWeight = FontWeight.Bold)
                    Text(
                        "Choose what Atmos shows in the Android status bar. Android may hide icons when space is limited.",
                        color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp
                    )
                    Spacer(Modifier.height(7.dp))
                    StatusBarIconStyle.values().forEach { style ->
                        val title = if (style == StatusBarIconStyle.Temperature) "Temperature" else "Weather condition"
                        val description = if (style == StatusBarIconStyle.Temperature) {
                            "Bold temperature with a raised degree mark and no surrounding circle."
                        } else {
                            "A solid icon for clear, cloudy, rainy or stormy conditions."
                        }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable(enabled = weatherNotificationEnabled) {
                                    statusBarIconStyle = style
                                    preferences.statusBarIconStyle = style
                                    publishCachedWeatherNotification(settingsContext, preferences)
                                }
                                .padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = statusBarIconStyle == style,
                                enabled = weatherNotificationEnabled,
                                onClick = {
                                    statusBarIconStyle = style
                                    preferences.statusBarIconStyle = style
                                    publishCachedWeatherNotification(settingsContext, preferences)
                                }
                            )
                            Column(Modifier.padding(start = 4.dp)) {
                                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(description, color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp)
                            }
                        }
                    }
                }
                Text("Atmos updates this notification whenever the first location refreshes. Background timing remains subject to Android battery management.", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
        }
        if (visibleCategory == SettingsCategory.AppearanceLayout) {
        item {
            SettingsSection("Atmos", "Adjust the character and movement of the Atmos experience.") {
                Text("Atmos intensity", fontWeight = FontWeight.Bold)
                Text("Balanced preserves the current Atmos render.", color = MaterialTheme.colorScheme.onSurface.copy(.60f), fontSize = 10.sp)
                AtmosIntensityChoice.values().forEach { choice ->
                    val label = choice.name
                    val description = when (choice) {
                        AtmosIntensityChoice.Subtle -> "Softer colour, light and atmospheric depth."
                        AtmosIntensityChoice.Balanced -> "The established Atmos appearance."
                        AtmosIntensityChoice.Cinematic -> "Richer colour, light and depth."
                    }
                    Row(Modifier.fillMaxWidth().clickable { onAtmosIntensityChoice(choice) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = atmosIntensityChoice == choice, onClick = { onAtmosIntensityChoice(choice) })
                        Column(Modifier.padding(start = 4.dp)) { Text(label, fontWeight = FontWeight.SemiBold); Text(description, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f)) }
                    }
                }
                Text("Atmos transitions", Modifier.padding(top = 14.dp), fontWeight = FontWeight.Bold)
                AtmosTransitionChoice.values().forEach { choice -> ChoiceRow(choice.name, atmosTransitionChoice == choice) { onAtmosTransitionChoice(choice) } }
            }
        }
        }
        if (visibleCategory == SettingsCategory.WeatherExperience) {
        item {
            SettingsSection("Weather effects", "Choose which condition-aware effects can appear over the Atmos scene.") {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .62f)
                ) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onTertiaryContainer)
                        Text(
                            "Animated weather effects may increase battery use and can affect performance, especially when several effects are active. Sun god rays and Living clouds are enabled by default; the other motion effects remain off by default.",
                            modifier = Modifier.padding(start = 10.dp),
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
                var rainEffect by remember { mutableStateOf(preferences.rainEffectEnabled) }
                var snowEffect by remember { mutableStateOf(preferences.snowEffectEnabled) }
                var windEffect by remember { mutableStateOf(preferences.windMotionEnabled) }
                var hazeEffect by remember { mutableStateOf(preferences.hazeEnabled) }
                var fogEffect by remember { mutableStateOf(preferences.fogEffectEnabled) }
                var heatEffect by remember { mutableStateOf(preferences.heatShimmer) }
                var frostEffect by remember { mutableStateOf(preferences.coldFrost) }
                var lightningEffect by remember { mutableStateOf(preferences.lightningEnabled) }
                var sunRaysEffect by remember { mutableStateOf(preferences.sunRaysEnabled) }
                var livingCloudsEffect by remember { mutableStateOf(preferences.livingCloudsEnabled) }
                var effects60Fps by remember { mutableStateOf(preferences.weatherEffects60Fps) }
                AtmosSettingsToggle(
                    "60 FPS weather effects",
                    "Runs active weather effects at a higher frame rate for smoother motion. Uses more battery and graphics performance.",
                    effects60Fps
                ) { effects60Fps = it; preferences.weatherEffects60Fps = it }
                Spacer(Modifier.height(6.dp))
                AtmosSettingsToggle(
                    "Sun god rays",
                    "Soft off-screen sunlight shafts that follow the sun across the day. Strongest in clear and hot weather; restrained beneath cloud.",
                    sunRaysEffect
                ) { sunRaysEffect = it; preferences.sunRaysEnabled = it }
                AtmosSettingsToggle(
                    "Living clouds",
                    "Large, clearly visible cloud-light forms that drift slowly and reshape contrast, depth and sunlight across the entire scene.",
                    livingCloudsEffect
                ) { livingCloudsEffect = it; preferences.livingCloudsEnabled = it }
                AtmosSettingsToggle("Rain", "Fine wind-driven rain streaks for rain, showers and storms.", rainEffect) { rainEffect=it; preferences.rainEffectEnabled=it }
                AtmosSettingsToggle("Wind streaks", "Wispy feathered lines that respond to wind speed and direction.", windEffect) { windEffect=it; preferences.windMotionEnabled=it }
                AtmosSettingsToggle("Snow", "Soft drifting flakes shaped by the observed wind.", snowEffect) { snowEffect=it; preferences.snowEffectEnabled=it }
                AtmosSettingsToggle("Haze", "A restrained atmospheric veil for hazy or very humid conditions.", hazeEffect) { hazeEffect=it; preferences.hazeEnabled=it }
                AtmosSettingsToggle("Fog", "Layered low-contrast fog for fog and mist conditions.", fogEffect) { fogEffect=it; preferences.fogEffectEnabled=it }
                AtmosSettingsToggle("Heat haze", "Subtle heat distortion at 35°C and above.", heatEffect) { heatEffect=it; preferences.heatShimmer=it }
                AtmosSettingsToggle("Frost", "A delicate crystalline edge treatment below 5°C.", frostEffect) { frostEffect=it; preferences.coldFrost=it }
                AtmosSettingsToggle("Lightning", "Brief atmospheric illumination during thunderstorms.", lightningEffect) { lightningEffect=it; preferences.lightningEnabled=it }
                Text("Effects appear only when the weather and temperature support them. Balanced intensity remains the reference presentation.", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
        }
        if (visibleCategory == SettingsCategory.AppearanceLayout) {
        item {
            SettingsSection("Accent colour", "Choose the colour used by native Android controls. Atmos follows the current sky and shifts naturally with time and weather.") {
                AccentColorChoice.values().forEach { choice ->
                    val label = when (choice) {
                        AccentColorChoice.Atmos -> "Atmos — dynamic colour temperature"
                        AccentColorChoice.Wallpaper -> "Follow wallpaper"
                        else -> choice.name
                    }
                    ChoiceRow(label, accentColorChoice == choice) { onAccentColorChoice(choice) }
                }
            }
        }
        }
        if (visibleCategory == SettingsCategory.WeatherExperience) {
        item {
            SettingsSection("Atmospheric soundscape", "An optional, subtle audio layer that changes with the current atmosphere.") {
                AtmosSettingsToggle(
                    "Atmospheric soundscape",
                    "A quiet procedural blend of wind, rain texture and distant atmospheric tone. It plays only while Atmos is open and uses no downloaded audio files.",
                    atmosphericSoundscapeEnabled
                ) { onAtmosphericSoundscapeEnabled(it) }
                Text(
                    "Designed to sit beneath the visual experience rather than behave like a music track. Off by default.",
                    color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }
        }
        item {
            SettingsSection("Units", "Choose how measurements are displayed throughout Atmos.") {
                Text("Temperature", fontWeight = FontWeight.Bold)
                ChoiceRow("Celsius (°C)", temperatureUnit == TemperatureUnit.Celsius) { onTemperatureUnit(TemperatureUnit.Celsius) }
                ChoiceRow("Fahrenheit (°F)", temperatureUnit == TemperatureUnit.Fahrenheit) { onTemperatureUnit(TemperatureUnit.Fahrenheit) }
                Text("Wind", Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold)
                listOf(WindUnit.Kmh to "km/h", WindUnit.Mph to "mph", WindUnit.Ms to "m/s", WindUnit.Knots to "knots").forEach { (unit, label) -> ChoiceRow(label, windUnit == unit) { windUnit = unit; preferences.windUnit = unit } }
                Text("Pressure", Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold)
                listOf(PressureUnit.Hpa to "hPa", PressureUnit.InHg to "inHg", PressureUnit.MmHg to "mmHg").forEach { (unit, label) -> ChoiceRow(label, pressureUnit == unit) { pressureUnit = unit; preferences.pressureUnit = unit } }
                Text("Rainfall", Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold)
                listOf(RainUnit.Millimetres to "Millimetres", RainUnit.Inches to "Inches").forEach { (unit, label) -> ChoiceRow(label, rainUnit == unit) { rainUnit = unit; preferences.rainUnit = unit } }
                Text("Visibility", Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold)
                listOf(VisibilityUnit.Kilometres to "Kilometres", VisibilityUnit.Miles to "Miles").forEach { (unit, label) -> ChoiceRow(label, visibilityUnit == unit) { visibilityUnit = unit; preferences.visibilityUnit = unit } }
            }
        }
        }
        if (visibleCategory == SettingsCategory.AppearanceLayout) {
        item {
            SettingsSection("Layout", "Choose how forecasts move and how much information fits before scrolling.") {
                Text("Forecast experience", Modifier.padding(bottom = 3.dp), fontWeight = FontWeight.Bold)
                Text("Choose between separate forecast cards or one continuous colour environment.", color = MaterialTheme.colorScheme.onSurface.copy(.60f), fontSize = 10.sp, lineHeight = 14.sp)
                Spacer(Modifier.height(10.dp))
                LayoutPreviewCard(
                    title = "Card style",
                    subtitle = "A complete card-style forecast for each saved location.",
                    immersive = false,
                    selected = homeLayout != HomeLayout.Dual && locationTransition == LocationTransition.Standard,
                    onClick = { onHomeLayout(HomeLayout.Immersive); onLocationTransition(LocationTransition.Standard) }
                )
                Spacer(Modifier.height(10.dp))
                LayoutPreviewCard(
                    title = "Immersive",
                    subtitle = "The Atmos background changes continuously from the instant you swipe.",
                    immersive = true,
                    selected = locationTransition == LocationTransition.Immersive,
                    onClick = { onHomeLayout(HomeLayout.Immersive); onLocationTransition(LocationTransition.Immersive) }
                )
                Spacer(Modifier.height(10.dp))
                LayoutPreviewCard(
                    title = "Dual atmosphere",
                    subtitle = "Show every saved location in swipeable pages of two compact Atmos cards.",
                    immersive = false,
                    selected = homeLayout == HomeLayout.Dual,
                    dual = true,
                    onClick = { onHomeLayout(HomeLayout.Dual); onLocationTransition(LocationTransition.Standard) }
                )
                Text("Content density", Modifier.padding(top = 18.dp, bottom = 8.dp), fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DensityPreviewCard(DensityChoice.Compact, density == DensityChoice.Compact, Modifier.weight(1f)) { onDensity(DensityChoice.Compact) }
                    DensityPreviewCard(DensityChoice.Expanded, density == DensityChoice.Expanded, Modifier.weight(1f)) { onDensity(DensityChoice.Expanded) }
                }
            }
        }
        }
        if (visibleCategory == SettingsCategory.HomeScreen) {
        item {
            SettingsSection("Atmos Display", "Keep Atmos awake as a calm, minimal full-screen weather display.") {
                AtmosSettingsToggle(
                    "Enable Atmos Display",
                    if (density == DensityChoice.Expanded) "Keeps the screen active, hides Android system bars and fades forecast controls after 10 seconds." else "Available when Content density is set to Expanded.",
                    ambientDisplayEnabled,
                    enabled = density == DensityChoice.Expanded,
                    onChange = onAmbientDisplayEnabled
                )
                Text("Display duration", Modifier.padding(top = 16.dp, bottom = 4.dp), fontWeight = FontWeight.Bold)
                listOf(15 to "15 minutes", 30 to "30 minutes", 60 to "1 hour", 120 to "2 hours").forEach { (minutes, label) ->
                    ChoiceRow(label, ambientDisplayDurationMinutes == minutes) { onAmbientDisplayDuration(minutes) }
                }
                Text(
                    "While active, Atmos refreshes weather every 10 minutes. The solar gradient continues to change from the clock between weather updates.",
                    color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }
        }
        }
        if (visibleCategory == SettingsCategory.HomeScreen) {
        item {
            SettingsSection("Widget text", "Choose how all transparent Atmos widgets display their typography.") {
                Text(
                    "Automatic follows the device and Atmos contrast so every widget remains readable. Light or Dark applies to all Atmos widgets.",
                    color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
                Spacer(Modifier.height(8.dp))
                WidgetTextMode.values().forEach { mode ->
                    val label = when (mode) {
                        WidgetTextMode.Automatic -> "Automatic"
                        WidgetTextMode.Light -> "Light text"
                        WidgetTextMode.Dark -> "Dark text"
                    }
                    ChoiceRow(label, widgetTextMode == mode) {
                        widgetTextMode = mode
                        preferences.widgetTextMode = mode
                        loadFirstWallpaperWeather(settingsContext)?.let { weather ->
                            updateWidgetTextMode(settingsContext, weather, preferences)
                        } ?: AtmosHeroWidgetProvider.updateAll(settingsContext)
                        AtmosRightNowWidgetProvider.updateAll(settingsContext)
                        AtmosMomentsWidgetProvider.updateAll(settingsContext)
                        AtmosTodayGlanceWidgetProvider.updateAll(settingsContext)
                    }
                }
                Spacer(Modifier.height(8.dp))
                AtmosSettingsToggle(
                    "Gradient typography",
                    "Apply the main Atmos Hero gradient to the widget temperature, degree symbol and large condition text.",
                    widgetGradientTypography,
                    onChange = { enabled ->
                        widgetGradientTypography = enabled
                        preferences.widgetGradientTypography = enabled
                        settingsContext.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE)
                            .edit()
                            .putBoolean("gradient_typography", enabled)
                            .apply()
                        AtmosHeroWidgetProvider.updateAll(settingsContext)
                        AtmosRightNowWidgetProvider.updateAll(settingsContext)
                        AtmosMomentsWidgetProvider.updateAll(settingsContext)
                        AtmosTodayGlanceWidgetProvider.updateAll(settingsContext)
                    }
                )
            }
        }
        }
        if (visibleCategory == SettingsCategory.HomeScreen) {
        item {
            SettingsSection("Live wallpaper", "Use the Atmos gradient and weather lighting from your first saved location.") {
                Text(
                    "The wallpaper contains only the Atmos scene—no location name, temperature, clock, cards or controls.",
                    color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
                FilledTonalButton(
                    onClick = {
                        val intent = android.content.Intent(android.app.WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                            putExtra(
                                android.app.WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                android.content.ComponentName(settingsContext, AtmosWallpaperService::class.java)
                            )
                        }
                        runCatching { settingsContext.startActivity(intent) }.onFailure {
                            settingsContext.startActivity(android.content.Intent(android.app.WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 14.dp)
                ) {
                    Text("Set Atmos live wallpaper")
                }
                Text(
                    "Reorder saved locations on the Locations page to choose which atmosphere appears. Background weather updates automatically refresh the wallpaper.",
                    modifier = Modifier.padding(top = 10.dp),
                    color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }
        }
        }
        if (visibleCategory == SettingsCategory.WeatherExperience) {
        item {
            SettingsSection("Weather detail cards", "Choose which cards appear. Hold and drag cards on the forecast to rearrange them.") {
                detailCardIds.forEach { id ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(detailTitle(id), fontWeight = FontWeight.Bold); Text("Show on the main forecast", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f)) }
                        Switch(id !in hidden, onCheckedChange = { show ->
                            hidden = if (show) hidden - id else hidden + id
                            preferences.hiddenCards = hidden
                        })
                    }
                }
                FilledTonalButton(onClick = { preferences.cardOrder = detailCardIds }, Modifier.fillMaxWidth()) { Text("Restore default order") }
            }
        }
        }
    }
        }
    }
}




private fun settingsCategoryTitle(category: SettingsCategory): String = when (category) {
    SettingsCategory.AppearanceLayout -> "Appearance & layout"
    SettingsCategory.WeatherExperience -> "Weather experience"
    SettingsCategory.UpdatesNotifications -> "Updates & notifications"
    SettingsCategory.HomeScreen -> "Home screen"
    SettingsCategory.Changelog -> "What's new"
}

private fun settingsCategorySubtitle(category: SettingsCategory): String = when (category) {
    SettingsCategory.AppearanceLayout -> "Personalise how Atmos looks, feels and moves."
    SettingsCategory.WeatherExperience -> "Choose effects, measurement units and forecast details."
    SettingsCategory.UpdatesNotifications -> "Control background weather, location and notification behaviour."
    SettingsCategory.HomeScreen -> "Configure Atmos Display and the live wallpaper."
    SettingsCategory.Changelog -> "See the latest improvements and refinements in Atmos."
}

@Composable
private fun ChangelogVersionCard(version: String, changes: List<String>, current: Boolean = false) {
    SettingsSection("Atmos $version", if (current) "Current version" else "Recent release") {
        changes.forEach { change ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 5.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(Modifier.width(14.dp).padding(top = 6.dp), contentAlignment = Alignment.TopCenter) {
                    Box(Modifier.size(5.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                }
                Text(
                    change,
                    Modifier.weight(1f).padding(start = 7.dp),
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .78f),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }
    }
}

@Composable
private fun SettingsMenuRow(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer) {
                Icon(icon, contentDescription = null, modifier = Modifier.padding(10.dp).size(22.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
            }
            Column(Modifier.weight(1f).padding(horizontal = 15.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurface.copy(.60f), fontSize = 11.sp, lineHeight = 15.sp)
            }
            Icon(Icons.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(19.dp).graphicsLayer { rotationZ = 180f }, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AtmosSettingsToggle(title: String, subtitle: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 3.dp).alpha(if (enabled) 1f else .48f),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 14.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun SettingsSection(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    val icon = when (title) {
        "Appearance", "Accent colour", "Atmos" -> Icons.Filled.WbSunny
        "Weather updates", "Location" -> Icons.Filled.MyLocation
        "Notifications" -> Icons.Filled.Info
        "Layout", "Atmos Display", "Live wallpaper" -> Icons.Filled.DisplaySettings
        "Weather detail cards", "Units" -> Icons.Filled.Settings
        else -> Icons.Filled.Settings
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.padding(bottom = 18.dp)) {
            ListItem(
                headlineContent = { Text(title, fontWeight = FontWeight.SemiBold) },
                supportingContent = { Text(subtitle) },
                leadingContent = { Icon(icon, contentDescription = null) },
                colors = androidx.compose.material3.ListItemDefaults.colors(
                    containerColor = Color.Transparent
                )
            )
            Column(Modifier.padding(horizontal = 20.dp)) { content() }
        }
    }
}


@Composable
private fun AtmosSettingsGlyph(title: String, accent: Color, modifier: Modifier = Modifier) {
    // Decorative settings glyphs are deliberately static to avoid an idle render loop.
    val phase = .5f
    Canvas(modifier) {
        drawCircle(accent.copy(alpha = .14f), size.minDimension * .48f)
        when (title) {
            "Appearance" -> {
                drawCircle(accent, size.minDimension * .20f, Offset(size.width * (.46f + phase * .08f), size.height * .48f))
                drawArc(accent.copy(.52f), 205f, 230f, false, style = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round))
            }
            "Layout" -> {
                drawRoundRect(accent.copy(.72f), Offset(size.width * .20f, size.height * .22f), Size(size.width * .60f, size.height * .24f), CornerRadius(4.dp.toPx()))
                drawRoundRect(accent.copy(.42f), Offset(size.width * .20f, size.height * .54f), Size(size.width * .27f, size.height * .22f), CornerRadius(4.dp.toPx()))
                drawRoundRect(accent.copy(.42f), Offset(size.width * .53f, size.height * .54f), Size(size.width * .27f, size.height * .22f), CornerRadius(4.dp.toPx()))
            }
            else -> {
                drawCircle(accent.copy(.82f), size.minDimension * .15f, Offset(size.width * .38f, size.height * .44f))
                drawCircle(accent.copy(.48f), size.minDimension * .11f, Offset(size.width * .64f, size.height * (.56f - phase * .06f)))
            }
        }
    }
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).atmosPress(onClick),
        shape = RoundedCornerShape(17.dp),
        color = if (selected) MaterialTheme.colorScheme.primary.copy(.15f) else Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary.copy(.45f) else MaterialTheme.colorScheme.onSurface.copy(.1f))
    ) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f), fontWeight = FontWeight.Bold); Text(if (selected) "●" else "○", color = MaterialTheme.colorScheme.primary) } }
}

@Composable
private fun LocationsPage(
    preferences: AtmosPreferences,
    current: Place,
    weatherCache: Map<String, WeatherState>,
    temperatureUnit: TemperatureUnit,
    onLocationAdded: (Place) -> Unit,
    onSelect: (Place) -> Unit,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<Place>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(preferences.savedPlaces) }
    var draggingKey by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(0f) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(query) {
        val clean = query.trim()
        if (clean.length < 2) {
            searchResults = emptyList()
            searching = false
        } else {
            searching = true
            delay(320)
            val local = places.filter { "${it.name} ${it.state}".contains(clean, true) }.take(8)
            val global = GlobalGeocodingRepository.search(clean)
            searchResults = (local + global)
                .distinctBy { "${it.name.lowercase()}:${"%.3f".format(Locale.US, it.latitude)}:${"%.3f".format(Locale.US, it.longitude)}" }
                .take(20)
            searching = false
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) scope.launch {
            val location = requestCurrentLocation(context) ?: currentLocation(context)
            location?.let {
                val live = resolveDevicePlace(
                    context = context,
                    latitude = it.first,
                    longitude = it.second,
                    previous = saved.firstOrNull { place -> place.current }
                )
                saved = normaliseSavedPlaces(listOf(live) + saved.filterNot { place -> place.current })
                preferences.savedPlaces = saved
                onSelect(live)
            }
        }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 18.dp,
                end = 18.dp,
                top = persistentStatusBarTopInset() + 15.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 116.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PageHeader("Locations", onBack) }
            item {
                AtmosPageIntro(
                    title = "Your atmospheres",
                    subtitle = "Live conditions from every saved place. Hold a card and move it exactly where you want it."
                )
            }
            item {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search Australia or the world") },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                            cursorColor = MaterialTheme.colorScheme.primary,
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            disabledBorderColor = Color.Transparent,
                            errorBorderColor = Color.Transparent,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        )
                    )
                }
            }
            item {
                FilledTonalButton(
                    onClick = { launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(20.dp)
                ) { Text(if (saved.any { it.current }) "Refresh current location" else "Use my current location", fontWeight = FontWeight.Bold) }
            }
            if (searching) item {
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.primary)
                    Text("Searching worldwide…", Modifier.padding(start = 10.dp), color = MaterialTheme.colorScheme.onBackground.copy(.68f), fontSize = 12.sp)
                }
            }
            if (query.length > 1) items(searchResults, key = { "search:${it.cacheKey()}:${it.name}" }) { place ->
                Surface(
                    Modifier.fillMaxWidth().atmosPress {
                        if (saved.none { sameSavedPlace(it, place) }) {
                            saved = normaliseSavedPlaces(saved + place)
                            preferences.savedPlaces = saved
                            onLocationAdded(place)
                        }
                        query = ""
                    },
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(place.name, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                            Text(place.state.ifBlank { place.country }, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                        }
                        Text(if (saved.any { sameSavedPlace(it, place) }) "Added" else "+ Add", color = Color(0xFF8FD7FF), fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (query.length < 2) item {
                Text("SAVED LOCATIONS", Modifier.padding(top = 8.dp, bottom = 2.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            }
            if (query.length < 2) itemsIndexed(saved, key = { _, place -> place.pagerKey(0) }) { _, place ->
                val key = place.pagerKey(0)
                val canDrag = !place.current
                val weather = weatherCache[place.cacheKey()]
                val day = weather?.days?.firstOrNull()
                val temperature = weather?.observation?.temp ?: weather?.hours?.firstOrNull()?.temp ?: day?.high
                val condition = day?.condition ?: if (weather == null) "Forecast loading" else "Current conditions"
                val icon = day?.icon.orEmpty()
                // Use the exact same solar-aware palette as the full hero. This preserves
                // dawn, daytime, sunset, twilight and true-night colour transitions for
                // every saved location instead of collapsing previews into one generic
                // day/night palette.
                val palette = rememberSolarAwarePalette(icon, place, weather?.observation ?: Observation(), weather?.days?.firstOrNull()?.condition ?: icon)
                val cardForeground = solarLegibleForeground(palette, MaterialTheme.colorScheme.background)
                val isDragging = draggingKey == key
                val cardHeightPx = with(LocalDensity.current) { 174.dp.toPx() }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(174.dp)
                        .clickable { onSelect(place) }
                        .zIndex(if (isDragging) 10f else 0f)
                        .graphicsLayer {
                            translationY = if (isDragging) dragOffset else 0f
                            scaleX = if (isDragging) 1.025f else 1f
                            scaleY = if (isDragging) 1.025f else 1f
                            shadowElevation = if (isDragging) 24.dp.toPx() else 0f
                        }
                        .pointerInput(saved, key, canDrag) {
                            if (canDrag) detectDragGesturesAfterLongPress(
                                onDragStart = { draggingKey = key; dragOffset = 0f },
                                onDragCancel = { draggingKey = null; dragOffset = 0f },
                                onDragEnd = { draggingKey = null; dragOffset = 0f; preferences.savedPlaces = saved },
                                onDrag = { change, amount ->
                                    change.consume()
                                    dragOffset += amount.y
                                    val from = saved.indexOfFirst { it.pagerKey(0) == key }
                                    if (from >= 0) {
                                        val direction = when {
                                            dragOffset > cardHeightPx * .52f -> 1
                                            dragOffset < -cardHeightPx * .52f -> -1
                                            else -> 0
                                        }
                                        val target = from + direction
                                        if (direction != 0 && target in saved.indices && !saved[target].current) {
                                            val mutable = saved.toMutableList()
                                            val moved = mutable.removeAt(from)
                                            mutable.add(target, moved)
                                            saved = normaliseSavedPlaces(mutable)
                                            preferences.savedPlaces = saved
                                            dragOffset -= direction * cardHeightPx
                                        }
                                    }
                                }
                            )
                        },
                    shape = RoundedCornerShape(30.dp),
                    color = Color.Transparent,
                    border = androidx.compose.foundation.BorderStroke(1.dp, cardForeground.copy(if (isDragging) .34f else .18f))
                ) {
                    Box(Modifier.fillMaxSize()) {
                        if (weather != null) {
                            AtmosSceneRenderer(
                                palette = palette,
                                observation = weather.observation,
                                condition = condition,
                                temperatureC = weather.observation.feels ?: temperature ?: 18,
                                place = place,
                                enabled = true,
                                preferences = preferences,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(
                                Modifier.fillMaxSize().background(
                                    Brush.linearGradient(listOf(palette.top, palette.secondary, palette.bottom))
                                )
                            )
                        }
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, cardForeground.copy(alpha = .025f), if (cardForeground == Color.White) Color.Black.copy(.20f) else Color.White.copy(.10f))
                                    )
                                )
                        )
                        Column(Modifier.fillMaxSize().padding(20.dp)) {
                            Row(verticalAlignment = Alignment.Top) {
                                Column(Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(place.name, color = cardForeground, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Spacer(Modifier.width(8.dp))
                                        LocationSeasonPill(place)
                                        if (place.current) Text("  LIVE", color = cardForeground.copy(.78f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                    }
                                    Text(place.state.ifBlank { place.country }, color = cardForeground.copy(.68f), fontSize = 10.sp, maxLines = 1)
                                }
                                if (!place.current) Spacer(Modifier.width(38.dp))
                            }
                            Spacer(Modifier.weight(1f))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        temperature?.let { "${displayTemperature(it, temperatureUnit)}°${if (temperatureUnit == TemperatureUnit.Fahrenheit) "F" else ""}" } ?: "—°",
                                        color = cardForeground,
                                        fontSize = 48.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = (-2).sp,
                                        lineHeight = 50.sp
                                    )
                                    Text(condition, color = cardForeground.copy(.82f), fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(SimpleDateFormat("h:mm a", Locale.getDefault()).apply { timeZone = place.timeZone() }.format(Date()), color = cardForeground, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text(if (sameSavedPlace(place, current)) "CURRENTLY VIEWING" else "LOCAL TIME", color = cardForeground.copy(.55f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                            }
                        }
                        if (!place.current) {
                            Surface(
                                Modifier.align(Alignment.TopEnd).padding(top = 12.dp, end = 12.dp).clickable {
                                    saved = normaliseSavedPlaces(saved.filterNot { sameSavedPlace(it, place) })
                                    preferences.savedPlaces = saved
                                },
                                shape = CircleShape,
                                color = palette.secondary.copy(alpha = .22f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, cardForeground.copy(.30f)),
                                shadowElevation = 5.dp
                            ) {
                                Text(
                                    "×",
                                    Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                                    color = cardForeground,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class RadarSite(
    val id: Int,
    val name: String,
    val latitude: Double,
    val longitude: Double
) {
    val productCode: String get() = "IDR${id.toString().padStart(2, '0')}3"
}

private val radarSites = listOf(
    RadarSite(70, "Perth (Serpentine)", -32.39, 115.87),
    RadarSite(31, "Albany", -34.94, 117.80),
    RadarSite(6, "Geraldton", -28.80, 114.70),
    RadarSite(32, "Esperance", -33.83, 121.89),
    RadarSite(48, "Kalgoorlie", -30.78, 121.45),
    RadarSite(17, "Broome", -17.95, 122.24),
    RadarSite(111, "Karratha", -20.71, 116.77),
    RadarSite(2, "Melbourne", -37.86, 144.76),
    RadarSite(71, "Sydney (Terrey Hills)", -33.70, 151.21),
    RadarSite(3, "Wollongong (Appin)", -34.26, 150.88),
    RadarSite(40, "Canberra (Captains Flat)", -35.66, 149.51),
    RadarSite(66, "Brisbane (Mt Stapylton)", -27.72, 153.24),
    RadarSite(19, "Cairns", -16.82, 145.68),
    RadarSite(64, "Adelaide (Buckland Park)", -34.62, 138.47),
    RadarSite(76, "Hobart (Mt Koonya)", -43.11, 147.81),
    RadarSite(63, "Darwin (Berrimah)", -12.46, 130.93),
    RadarSite(25, "Alice Springs", -23.82, 133.90)
)

private object BomRadarRepository {
    suspend fun load(context: Context, site: RadarSite, force: Boolean = false): Pair<Bitmap?, Date?> = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "radar").apply { mkdirs() }
        val imageFile = File(dir, "${site.productCode}.gif")
        val timestampFile = File(dir, "${site.productCode}.time")
        val freshEnough = imageFile.exists() && System.currentTimeMillis() - imageFile.lastModified() < 4 * 60 * 1000
        if (!force && freshEnough) {
            return@withContext BitmapFactory.decodeFile(imageFile.absolutePath) to Date(imageFile.lastModified())
        }
        val address = "https://www.bom.gov.au/radar/${site.productCode}.gif?t=${System.currentTimeMillis()}"
        val downloaded = runCatching {
            val connection = (URL(address).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 15_000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Atmos Android Weather App")
            }
            connection.inputStream.use { input ->
                imageFile.outputStream().use { output -> input.copyTo(output) }
            }
            connection.disconnect()
            imageFile.setLastModified(System.currentTimeMillis())
            timestampFile.writeText(System.currentTimeMillis().toString())
            BitmapFactory.decodeFile(imageFile.absolutePath)
        }.getOrNull()
        val bitmap = downloaded ?: imageFile.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) }
        bitmap to imageFile.takeIf { it.exists() }?.let { Date(it.lastModified()) }
    }
}

@Composable
private fun RadarPage(place: Place, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val site = remember(place.latitude, place.longitude) {
        radarSites.minByOrNull { distanceSquared(it.latitude, it.longitude, place.latitude, place.longitude) } ?: radarSites.first()
    }
    var radarBitmap by remember(site.id) { mutableStateOf<Bitmap?>(null) }
    var updated by remember(site.id) { mutableStateOf<Date?>(null) }
    var loading by remember(site.id) { mutableStateOf(true) }
    var failed by remember(site.id) { mutableStateOf(false) }

    fun request(force: Boolean) {
        scope.launch {
            loading = true
            failed = false
            val result = BomRadarRepository.load(context, site, force)
            radarBitmap = result.first
            updated = result.second
            failed = result.first == null
            loading = false
        }
    }

    LaunchedEffect(site.id) { request(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = persistentStatusBarTopInset() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 30.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHeader("Rain radar", onBack) }
        item {
            Column {
                Text(place.name, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                Text("Nearest radar · ${site.name} · 128 km", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
            }
        }
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101A2A)),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Box(
                    Modifier.fillMaxWidth().height(390.dp)
                        .background(Brush.verticalGradient(listOf(Color(0xFF17263E), Color(0xFF0B1423)))),
                    contentAlignment = Alignment.Center
                ) {
                    radarBitmap?.let { bitmap ->
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Bureau rain radar for ${site.name}",
                            modifier = Modifier.fillMaxSize().padding(8.dp).clip(RoundedCornerShape(24.dp)),
                            contentScale = ContentScale.Fit
                        )
                    }
                    if (loading) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                            Text("Loading latest radar…", Modifier.padding(top = 12.dp), color = Color.White.copy(.78f), fontSize = 12.sp)
                        }
                    } else if (failed) {
                        Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Radar unavailable", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text("The nearest Bureau radar image could not be loaded. It may be temporarily offline.", Modifier.padding(top = 8.dp), color = Color.White.copy(.7f), textAlign = TextAlign.Center, fontSize = 12.sp)
                        }
                    }
                    Box(Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(13.dp).clip(CircleShape).background(Color.White).border(3.dp, Color(0xFF5DA9FF), CircleShape))
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Latest observation", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(updated?.let { SimpleDateFormat("h:mm a", Locale.getDefault()).format(it) } ?: "Not available", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 11.sp)
                }
                Button(onClick = { request(true) }, enabled = !loading) { Text("Refresh") }
            }
        }
        item {
            Card(
                Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.primary.copy(.22f), RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(.82f))
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("Rain intensity", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        listOf(
                            Color(0xFFB8E5FF) to "Light",
                            Color(0xFF57C8A9) to "Moderate",
                            Color(0xFFFFD75A) to "Heavy",
                            Color(0xFFF06161) to "Intense"
                        ).forEach { (colour, label) ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.width(48.dp).height(8.dp).clip(CircleShape).background(colour))
                                Text(label, Modifier.padding(top = 6.dp), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f))
                            }
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Radar shows observed precipitation, not a forecast. Coverage and accuracy can reduce farther from the radar site. Data © Commonwealth of Australia, Bureau of Meteorology. Atmos is independent and is not endorsed by the Bureau.",
                color = MaterialTheme.colorScheme.onSurface.copy(.55f), fontSize = 10.sp, lineHeight = 15.sp
            )
        }
    }
}

@Composable
private fun AtmosAboutFeatureCard(symbol: String, title: String, description: String, accent: Color) {
    Surface(
        Modifier.fillMaxWidth().padding(top = 14.dp),
        shape = RoundedCornerShape(28.dp),
        color = Color.White.copy(.08f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.Top) {
            Surface(Modifier.size(48.dp), shape = CircleShape, color = accent.copy(.16f), border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(.38f))) {
                Box(contentAlignment = Alignment.Center) { Text(symbol, color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            }
            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(description, Modifier.padding(top = 5.dp), color = Color.White.copy(.66f), fontSize = 11.sp, lineHeight = 17.sp)
            }
        }
    }
}

@Composable
private fun HelpPage(onBack: () -> Unit) {
    val foreground = MaterialTheme.colorScheme.onBackground
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PageHeader("Help & gestures", onBack, foreground)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Discover Atmos", color = foreground, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp)
                Text("Small gestures reveal more without adding clutter to the forecast.", Modifier.padding(top = 6.dp), color = foreground.copy(alpha = .68f), fontSize = 14.sp, lineHeight = 21.sp)
            }
            item { HelpFeatureCard("Scrub through today", "Press and hold the Next 24 Hours timeline on the main Hero, then drag. The complete atmosphere, temperature and condition follow the hour beneath your finger. Release to return smoothly to now.") }
            item { HelpFeatureCard("Change temperature units", "Tap the large temperature on the Hero to switch instantly between Celsius and Fahrenheit.") }
            item { HelpFeatureCard("Explore the seasons", "Tap the season pill beside a location to open Seasons and see how Atmos interprets the year for that place.") }
            item { HelpFeatureCard("Manage locations", "Tap the gradient location name on the Hero to open Your atmospheres, add places, reorder them or choose another forecast.") }
            item { HelpFeatureCard("Local time everywhere", "Every saved location uses its own local clock. Times, sunrise, sunset, hourly forecasts and day/night lighting all follow that location—not your phone's timezone.") }
            item { HelpFeatureCard("Swipe between atmospheres", "In single-atmosphere mode, swipe horizontally to move between saved places. Atmos blends the scenes so the transition feels continuous.") }
            item { HelpFeatureCard("Atmos Display", "Open the floating Atmos menu and choose Atmos Display for a distraction-free clock and temperature view that keeps the current atmosphere alive on screen.") }
            item { HelpFeatureCard("Widgets and wallpaper", "Atmos widgets use your saved weather data, while the live wallpaper displays a cached Atmos scene so your home screen and app remain visually connected.") }
        }
    }
}

@Composable
private fun HelpFeatureCard(title: String, body: String) {
    Surface(
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f))
    ) {
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(body, Modifier.padding(top = 7.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .70f), fontSize = 13.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun AboutPage(onBack: () -> Unit) {
    val context = LocalContext.current
    val versionName = BuildConfig.VERSION_NAME
    val buildNumber = BuildConfig.VERSION_CODE
    val deepGradient = Brush.verticalGradient(
        listOf(
            Color(0xFF07101F),
            Color(0xFF10162D),
            Color(0xFF24133D),
            Color(0xFF0B1830)
        )
    )

    Box(Modifier.fillMaxSize().background(deepGradient)) {
        Box(
            Modifier
                .size(280.dp)
                .offset(x = 150.dp, y = (-75).dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0x665F8CFF), Color.Transparent)
                    ),
                    CircleShape
                )
        )
        Box(
            Modifier
                .size(250.dp)
                .offset(x = (-115).dp, y = 470.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0x55FF8A63), Color.Transparent)
                    ),
                    CircleShape
                )
        )

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 22.dp,
                end = 22.dp,
                top = persistentStatusBarTopInset() + 15.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 34.dp
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        Modifier.size(46.dp).clickable(onClick = onBack),
                        shape = CircleShape,
                        color = Color.White.copy(.10f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("‹", color = Color.White, fontSize = 36.sp)
                        }
                    }
                    Text(
                        "About Atmos",
                        Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Spacer(Modifier.width(46.dp))
                }
            }
            item {
                Spacer(Modifier.height(34.dp))
                Box(
                    Modifier
                        .size(162.dp)
                        .shadow(28.dp, RoundedCornerShape(48.dp), ambientColor = Color(0x885A79FF), spotColor = Color(0x885A79FF))
                        .clip(RoundedCornerShape(48.dp))
                        .border(1.dp, Color.White.copy(.22f), RoundedCornerShape(48.dp))
                ) { FullScreenAtmosArtwork() }
            }
            item {
                Text(
                    "Atmos",
                    Modifier.padding(top = 24.dp),
                    color = Color.White,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            item {
                Text(
                    "Weather transformed into an experience.",
                    color = Color.White.copy(.72f),
                    textAlign = TextAlign.Center
                )
            }
            item {
                Row(
                    Modifier.padding(top = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(.12f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.16f))
                    ) {
                        Text(
                            "VERSION $versionName",
                            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF826BFF).copy(.32f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFB9AEFF).copy(.42f))
                    ) {
                        Text(
                            "BUILD $buildNumber",
                            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            item {
                Surface(
                    Modifier.fillMaxWidth().padding(top = 28.dp),
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White.copy(.08f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Atmos transforms weather into an experience", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "By combining live meteorological data with a dynamic atmospheric rendering engine, Atmos recreates the feeling of the sky around you—not just the forecast.",
                            Modifier.padding(top = 8.dp),
                            color = Color.White.copy(.68f),
                            fontSize = 12.sp,
                            lineHeight = 19.sp
                        )
                    }
                }
            }
            item {
                Surface(
                    Modifier.fillMaxWidth().padding(top = 14.dp),
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White.copy(.08f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Weather data & licences", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Australian forecasts, observations and warnings are sourced from the Australian Bureau of Meteorology where available. Bureau material remains © Commonwealth of Australia and is subject to the Bureau’s copyright notice and the licence conditions attached to each dataset. Atmos is independent and is not affiliated with or endorsed by the Bureau.",
                            Modifier.padding(top = 8.dp),
                            color = Color.White.copy(.68f),
                            fontSize = 12.sp,
                            lineHeight = 19.sp
                        )
                        Text(
                            "Bureau copyright and data licensing ›",
                            Modifier
                                .padding(top = 10.dp)
                                .clickable {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bom.gov.au/copyright")))
                                },
                            color = Color(0xFF9FC7FF),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Open-Meteo provides international forecast data. Open-Meteo API data is licensed under the Creative Commons Attribution 4.0 International licence (CC BY 4.0), which permits reuse with attribution.",
                            Modifier.padding(top = 18.dp),
                            color = Color.White.copy(.68f),
                            fontSize = 12.sp,
                            lineHeight = 19.sp
                        )
                        Text(
                            "Open-Meteo and CC BY 4.0 licence ›",
                            Modifier
                                .padding(top = 10.dp)
                                .clickable {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://open-meteo.com/")))
                                },
                            color = Color(0xFF9FC7FF),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Forecasts are provided for general information and may differ from local observations. Always follow official emergency warnings and advice.",
                            Modifier.padding(top = 18.dp),
                            color = Color.White.copy(.52f),
                            fontSize = 11.sp,
                            lineHeight = 17.sp
                        )
                    }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(top = 28.dp)) {
                    Text("THE ATMOS SYSTEM", color = Color.White.copy(.58f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("One atmosphere, shaped by every location.", Modifier.padding(top = 6.dp), color = Color.White, fontSize = 25.sp, lineHeight = 29.sp, fontWeight = FontWeight.Bold)
                    Text("The Atmos renderer combines condition, solar position, season, apparent temperature, humidity, visibility and pressure into a cohesive scene. Forecasts, widgets, notifications and live wallpaper use the same coordinated local weather pipeline.", Modifier.padding(top = 9.dp), color = Color.White.copy(.72f), fontSize = 12.sp, lineHeight = 19.sp)
                }
            }
            item { AtmosAboutFeatureCard("↻", "Coordinated updates", "Background work refreshes every saved location together, then updates the local cache, widgets and persistent notification without interrupting the location you are viewing.", Color(0xFF8FCBFF)) }
            item { AtmosAboutFeatureCard("☼", "Location-aware light", "Sunrise, daylight, sunset, twilight and night are calculated independently for each location and shape its atmosphere and solar details.", Color(0xFFFFC66D)) }
            item { AtmosAboutFeatureCard("≈", "Weather-driven atmosphere", "Condition, apparent temperature, rain, wind, cloud and local time influence a restrained atmospheric scene rather than a fixed decorative background.", Color(0xFF7ED8FF)) }
            item { AtmosAboutFeatureCard("▣", "Native and responsive", "Jetpack Compose layouts adapt between compact, expanded and immersive presentations while keeping gestures, contrast and typography consistent.", Color(0xFFB7A4FF)) }
            item {
                Surface(Modifier.fillMaxWidth().padding(top = 14.dp), shape = RoundedCornerShape(28.dp), color = Color.White.copy(.08f), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))) {
                    Column(Modifier.padding(20.dp)) {
                        Text("What makes Atmos different", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Atmos does not treat weather as a list of numbers placed over a generic wallpaper. Data, light, colour, motion, charts and summaries are resolved as one system for each location, with adaptive contrast keeping information readable as the atmosphere changes.", Modifier.padding(top = 8.dp), color = Color.White.copy(.72f), fontSize = 12.sp, lineHeight = 19.sp)
                    }
                }
            }
            item {
                Text("Built by Josh Stanley", Modifier.padding(top = 24.dp), color = Color.White.copy(.92f), fontWeight = FontWeight.Bold)
            }
            item {
                Button(
                    onClick = { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:Josh.stanley@me.com"))) },
                    modifier = Modifier.padding(top = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF131A32))
                ) { Text("Contact Josh", fontWeight = FontWeight.Bold) }
            }
            item {
                Text(
                    "Atmos $versionName · Build $buildNumber",
                    Modifier.padding(top = 28.dp),
                    color = Color.White.copy(.48f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PageHeader(
    title: String,
    onBack: () -> Unit,
    foreground: Color = MaterialTheme.colorScheme.onSurface
) {
    CenterAlignedTopAppBar(
        title = { Text(title, fontWeight = FontWeight.SemiBold) },
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = Color.Transparent,
            titleContentColor = foreground,
            navigationIconContentColor = foreground
        )
    )
}

@Composable
private fun NativeNavigationChrome(
    page: Page,
    visible: Boolean,
    atmospherePalette: Palette,
    atmosphereCondition: String,
    atmosphereNight: Boolean,
    homeLayout: HomeLayout,
    onToggleHomeLayout: () -> Unit,
    onPage: (Page) -> Unit,
    onAtmosDisplay: () -> Unit
) {
    if (!visible) return
    var menuOpen by remember { mutableStateOf(false) }
    val showPrimaryNavigation = page == Page.Home || page == Page.Locations || page == Page.Seasons || page == Page.Settings
    val navigationTintTarget = blendColor(
        MaterialTheme.colorScheme.surfaceContainer,
        blendColor(atmospherePalette.bottom, atmospherePalette.secondary, .42f),
        if (MaterialTheme.colorScheme.background.luminance() < .45f) .20f else .14f
    )
    val navigationTint by animateColorAsState(
        targetValue = navigationTintTarget,
        animationSpec = tween(620, easing = FastOutSlowInEasing),
        label = "atmosNavigationTint"
    )

    Box(Modifier.fillMaxSize()) {
        if (showPrimaryNavigation) {
            // Cast the menu shadow upward onto the app content so the navigation
            // surface reads as a layer floating above the Hero/page.
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 78.dp)
                    .height(38.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                atmospherePalette.bottom.copy(alpha = .085f),
                                Color.Black.copy(alpha = .21f)
                            )
                        )
                    )
            )
            val selectedNavigationColor = blendColor(atmospherePalette.accent, atmospherePalette.secondary, .28f)
            val navigationItemColors = NavigationBarItemDefaults.colors(
                selectedIconColor = selectedNavigationColor,
                selectedTextColor = selectedNavigationColor,
                indicatorColor = atmospherePalette.accent.copy(alpha = .18f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f),
                unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f)
            )
            NavigationBar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth(),
                containerColor = navigationTint,
                tonalElevation = 2.dp
            ) {
                NavigationBarItem(
                    selected = page == Page.Home,
                    onClick = { onPage(Page.Home) },
                    icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                    label = { Text("Weather") },
                    colors = navigationItemColors
                )
                NavigationBarItem(
                    selected = page == Page.Locations,
                    onClick = { onPage(Page.Locations) },
                    icon = { Icon(Icons.Filled.LocationOn, contentDescription = null) },
                    label = { Text("Locations") },
                    colors = navigationItemColors
                )
                NavigationBarItem(
                    selected = page == Page.Seasons,
                    onClick = { onPage(Page.Seasons) },
                    icon = { Icon(Icons.Filled.WbSunny, contentDescription = null) },
                    label = { Text("Seasons") },
                    colors = navigationItemColors
                )
                NavigationBarItem(
                    selected = page == Page.Settings,
                    onClick = { onPage(Page.Settings) },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    label = { Text("Settings") },
                    colors = navigationItemColors
                )
            }
        }

        if (page == Page.Home) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(
                        end = 18.dp,
                        bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 92.dp
                    )
            ) {

                FloatingActionButton(
                    onClick = { menuOpen = true },
                    modifier = Modifier.size(58.dp),
                    shape = CircleShape,
                    containerColor = navigationTint,
                    contentColor = atmospherePalette.accent,
                    elevation = FloatingActionButtonDefaults.elevation(
                        defaultElevation = 14.dp,
                        pressedElevation = 18.dp,
                        focusedElevation = 16.dp,
                        hoveredElevation = 16.dp
                    )
                ) {
                    AtmosConditionGlyph(
                        condition = atmosphereCondition,
                        night = atmosphereNight,
                        tint = atmospherePalette.accent,
                        modifier = Modifier.size(26.dp)
                    )
                }
                DropdownMenu(
                    expanded = menuOpen,
                    onDismissRequest = { menuOpen = false },
                    offset = DpOffset(0.dp, (-14).dp),
                    containerColor = Color.Transparent,
                    tonalElevation = 0.dp,
                    shadowElevation = 0.dp,
                    modifier = Modifier
                        .widthIn(min = 238.dp)
                        .shadow(
                            elevation = 20.dp,
                            shape = RoundedCornerShape(26.dp),
                            clip = false,
                            ambientColor = atmospherePalette.bottom.copy(alpha = .28f),
                            spotColor = Color.Black.copy(alpha = .34f)
                        )
                        .clip(RoundedCornerShape(26.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    navigationTint,
                                    blendColor(navigationTint, atmospherePalette.secondary, .16f)
                                )
                            )
                        )
                        .border(
                            1.dp,
                            atmospherePalette.accent.copy(alpha = .34f),
                            RoundedCornerShape(26.dp)
                        )
                        .padding(vertical = 8.dp)
                ) {
                    DropdownMenuItem(
                        text = { Text(if (homeLayout == HomeLayout.Dual) "Use single atmosphere" else "Use dual atmosphere", color = MaterialTheme.colorScheme.onSurface) },
                        leadingIcon = {
                            Icon(
                                if (homeLayout == HomeLayout.Dual) Icons.Filled.Home else Icons.Filled.LocationOn,
                                contentDescription = null,
                                tint = atmospherePalette.accent
                            )
                        },
                        onClick = { menuOpen = false; onToggleHomeLayout() }
                    )
                    DropdownMenuItem(
                        text = { Text("Atmos Display", color = MaterialTheme.colorScheme.onSurface) },
                        leadingIcon = { Icon(Icons.Filled.DisplaySettings, contentDescription = null, tint = atmospherePalette.accent) },
                        onClick = { menuOpen = false; onAtmosDisplay() }
                    )
                    DropdownMenuItem(
                        text = { Text("Rain radar", color = MaterialTheme.colorScheme.onSurface) },
                        leadingIcon = { Icon(Icons.Filled.Radar, contentDescription = null, tint = atmospherePalette.accent) },
                        onClick = { menuOpen = false; onPage(Page.Radar) }
                    )
                    DropdownMenuItem(
                        text = { Text("Help & gestures", color = MaterialTheme.colorScheme.onSurface) },
                        leadingIcon = { Icon(Icons.Filled.Info, contentDescription = null, tint = atmospherePalette.accent) },
                        onClick = { menuOpen = false; onPage(Page.Help) }
                    )
                    DropdownMenuItem(
                        text = { Text("About Atmos", color = MaterialTheme.colorScheme.onSurface) },
                        leadingIcon = { Icon(Icons.Filled.Info, contentDescription = null, tint = atmospherePalette.accent) },
                        onClick = { menuOpen = false; onPage(Page.About) }
                    )
                }
            }
        }
    }
}

private fun localForecastSummary(
    weather: WeatherState,
    dayIndex: Int,
    temperatureUnit: TemperatureUnit,
    now: Date = Date(),
    maxSentences: Int = 3
): String {
    val day = weather.days.getOrElse(dayIndex) { weather.days.first() }
    val high = displayTemperature(day.high, temperatureUnit)
    val low = displayTemperature(day.low, temperatureUnit)

    if (dayIndex > 0) {
        val condition = day.condition.trim().ifBlank { "Mixed conditions" }
        val rainText = when {
            day.rainChance >= 70 -> "Rain is likely"
            day.rainChance >= 40 -> "A shower is possible"
            day.rainChance >= 20 -> "There is a slight chance of rain"
            else -> "Dry conditions are expected"
        }
        val amountText = if (day.rainAmount >= 5.0) ", with around ${formatRainAmount(day.rainAmount)} possible" else ""
        return "$condition tomorrow. $rainText$amountText, with a high of $high° and a low of $low°."
    }

    val placeZone = weather.place.timeZone()
    val futureHours = weather.hours
        .filter { it.time.time >= now.time - TimeUnit.MINUTES.toMillis(30) }
        .sortedBy { it.time.time }
        .takeWhile { it.time.time <= now.time + TimeUnit.HOURS.toMillis(12) }
        .take(13)

    val sentences = mutableListOf<String>()
    val currentTemp = weather.observation.temp ?: futureHours.firstOrNull()?.temp
    val threeHour = futureHours.minByOrNull {
        kotlin.math.abs(it.time.time - (now.time + TimeUnit.HOURS.toMillis(3)))
    }
    val sixHour = futureHours.minByOrNull {
        kotlin.math.abs(it.time.time - (now.time + TimeUnit.HOURS.toMillis(6)))
    }

    val condition = day.condition.trim().ifBlank { "Current conditions" }
    val timeLead = when (Calendar.getInstance(placeZone).apply { time = now }.get(Calendar.HOUR_OF_DAY)) {
        in 5..10 -> "This morning"
        in 11..15 -> "This afternoon"
        in 16..20 -> "This evening"
        else -> "Overnight"
    }

    val tempTarget = sixHour ?: threeHour
    val tempDelta = if (currentTemp != null && tempTarget != null) tempTarget.temp - currentTemp else 0
    val tempSentence = when {
        currentTemp == null -> "$condition ${timeLead.lowercase()}."
        tempDelta >= 3 -> "$condition ${timeLead.lowercase()}, becoming noticeably warmer as temperatures rise toward $high°."
        tempDelta >= 1 -> "$condition ${timeLead.lowercase()}, with temperatures gradually rising toward $high°."
        tempDelta <= -3 -> "$condition ${timeLead.lowercase()}, becoming noticeably cooler as temperatures fall toward $low°."
        tempDelta <= -1 -> "$condition ${timeLead.lowercase()}, with temperatures gradually easing toward $low°."
        else -> "$condition ${timeLead.lowercase()}, with temperatures remaining fairly steady."
    }
    sentences += tempSentence.replaceFirstChar { it.uppercase() }

    val wetHours = futureHours.filter { it.rainChance >= 40 }
    val firstWet = wetHours.firstOrNull()
    val lastWet = wetHours.lastOrNull()
    val currentRainChance = futureHours.firstOrNull()?.rainChance ?: day.rainChance
    val maxRainChance = futureHours.maxOfOrNull { it.rainChance } ?: day.rainChance
    val rainSentence = when {
        firstWet != null && currentRainChance < 40 -> {
            val start = localTimeLabel(firstWet.time, placeZone)
            if (maxRainChance >= 70) "Rain becomes likely around $start."
            else "A shower becomes possible around $start."
        }
        firstWet != null && lastWet != null && currentRainChance >= 40 && lastWet.time.time < now.time + TimeUnit.HOURS.toMillis(8) -> {
            "Showers should ease by ${localTimeLabel(lastWet.time, placeZone)}."
        }
        maxRainChance >= 70 -> "Rain remains likely during the next several hours."
        maxRainChance >= 40 -> "A shower remains possible during the next several hours."
        day.rainChance < 20 -> "Little rain is expected."
        else -> "Only a slight chance of rain is expected."
    }
    sentences += rainSentence

    val currentWind = weather.observation.wind ?: futureHours.firstOrNull()?.wind
    val peakWind = futureHours.maxOfOrNull { it.wind } ?: currentWind
    val windSentence = when {
        peakWind != null && currentWind != null && peakWind >= 35 && peakWind - currentWind >= 10 -> "Winds strengthen later, reaching around $peakWind km/h."
        peakWind != null && peakWind >= 45 -> "Strong winds around $peakWind km/h are possible."
        currentWind != null && currentWind >= 30 -> "It remains breezy, with winds around $currentWind km/h."
        else -> null
    }
    windSentence?.let { sentences += it }

    if (sentences.size < maxSentences) {
        sentences += "Today's range is $low° to $high°."
    }
    return sentences.take(maxSentences.coerceAtLeast(1)).joinToString(" ")
}

private fun localTimeLabel(date: Date, timeZone: TimeZone): String =
    SimpleDateFormat("h a", Locale.getDefault()).apply { this.timeZone = timeZone }.format(date)
        .lowercase(Locale.getDefault())

private fun formatRainAmount(amount: Double): String =
    if (amount >= 10.0) "${amount.toInt()} mm" else String.format(Locale.getDefault(), "%.1f mm", amount)

private fun conditionNarrative(weather: WeatherState): String {
    val day = weather.days.first()
    val place = if (weather.place.current) weather.place.state else weather.place.name
    val condition = nightCondition(day.condition).replaceFirstChar { it.lowercase() }
    val rain = when {
        day.rainChance < 20 -> "Little rain is expected."
        day.rainChance < 50 -> "There is a ${day.rainChance}% chance of rain."
        else -> "Rain is likely, with a ${day.rainChance}% chance."
    }
    val wind = weather.observation.wind?.let { if (it < 15) "Winds remain light." else if (it < 30) "A moderate breeze is present." else "Strong winds are being observed." } ?: ""
    return "${if (isNight()) "A $condition evening" else day.condition} across $place. $rain $wind".trim()
}

private fun nightCondition(condition: String): String =
    if (!isNight()) condition else when {
        condition.contains("sunny", true) || condition.contains("clear", true) -> "Clear night"
        condition.contains("cloud", true) -> "Cloudy night"
        condition.contains("shower", true) -> "Evening showers"
        else -> condition
    }

private fun isLocationNight(place: Place, date: Date = Date()): Boolean {
    val timeZone = place.timeZone()
    val solar = calculateSolarTimes(date, place.latitude, place.longitude, timeZone)
    if (solar != null) {
        val (sunrise, sunset) = solar
        return date.before(sunrise) || !date.before(sunset)
    }
    // Polar-day/night fallback when a sunrise or sunset cannot be calculated.
    return isNight(date, timeZone)
}

internal fun isNight(date: Date = Date(), timeZone: TimeZone = TimeZone.getDefault()): Boolean {
    val hour = Calendar.getInstance(timeZone).apply { time = date }.get(Calendar.HOUR_OF_DAY)
    return hour < 6 || hour >= 18
}

private fun Place.hasDifferentLocalTime(now: Date = Date()): Boolean {
    val device = TimeZone.getDefault()
    val location = timeZone()
    return device.getOffset(now.time) != location.getOffset(now.time)
}

internal fun seasonName(place: Place, date: Date = Date()): String {
    val calendar = Calendar.getInstance(place.timeZone()).apply { time = date }
    val month = calendar.get(Calendar.MONTH) + 1
    val latitude = place.latitude

    // Very low latitudes do not experience four meaningful temperature seasons.
    // Atmos uses a simple tropical wet/dry convention rather than displaying a
    // misleading northern or southern season.
    if (kotlin.math.abs(latitude) < 8.0) {
        val wet = if (latitude >= 0.0) month in 5..10 else month >= 11 || month <= 4
        return if (wet) "Wet season" else "Dry season"
    }

    val southern = latitude < 0.0
    return if (southern) {
        when (month) {
            12, 1, 2 -> "Summer"
            3, 4, 5 -> "Autumn"
            6, 7, 8 -> "Winter"
            else -> "Spring"
        }
    } else {
        when (month) {
            12, 1, 2 -> "Winter"
            3, 4, 5 -> "Spring"
            6, 7, 8 -> "Summer"
            else -> "Autumn"
        }
    }
}

private fun daysToNextSeason(place: Place, date: Date = Date()): String {
    val calendar = Calendar.getInstance(place.timeZone()).apply { time = date }
    val month = calendar.get(Calendar.MONTH) + 1
    val latitude = place.latitude

    if (kotlin.math.abs(latitude) < 8.0) {
        val wetNow = if (latitude >= 0.0) month in 5..10 else month >= 11 || month <= 4
        val nextMonth = if (latitude >= 0.0) {
            if (wetNow) 11 else 5
        } else {
            if (wetNow) 5 else 11
        }
        val nextName = if (wetNow) "Dry season" else "Wet season"
        val next = Calendar.getInstance(place.timeZone()).apply {
            time = date
            set(Calendar.MONTH, nextMonth - 1)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (!time.after(date)) add(Calendar.YEAR, 1)
        }
        return "${((next.timeInMillis - date.time) / 86_400_000L).coerceAtLeast(0)} days until $nextName"
    }

    val southern = latitude < 0.0
    val (nextMonth, nextName) = if (southern) {
        when (month) {
            12, 1, 2 -> 3 to "Autumn"
            3, 4, 5 -> 6 to "Winter"
            6, 7, 8 -> 9 to "Spring"
            else -> 12 to "Summer"
        }
    } else {
        when (month) {
            12, 1, 2 -> 3 to "Spring"
            3, 4, 5 -> 6 to "Summer"
            6, 7, 8 -> 9 to "Autumn"
            else -> 12 to "Winter"
        }
    }
    val next = Calendar.getInstance(place.timeZone()).apply {
        time = date
        set(Calendar.MONTH, nextMonth - 1)
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        if (!time.after(date)) add(Calendar.YEAR, 1)
    }
    return "${((next.timeInMillis - date.time) / 86_400_000L).coerceAtLeast(0)} days until $nextName"
}

private fun moonPhase(): Double {
    val known = 947182440000L
    val cycle = 2_551_443_000L
    return (((System.currentTimeMillis() - known) % cycle + cycle) % cycle).toDouble() / cycle
}

private fun moonIllumination(): Int = ((1 - cos(moonPhase() * 2 * PI)) / 2 * 100).roundToInt()
private fun moonName(): String = when (moonPhase()) {
    in 0.0..0.03, in 0.97..1.0 -> "New moon"
    in 0.03..0.22 -> "Waxing crescent"
    in 0.22..0.28 -> "First quarter"
    in 0.28..0.47 -> "Waxing gibbous"
    in 0.47..0.53 -> "Full moon"
    in 0.53..0.72 -> "Waning gibbous"
    in 0.72..0.78 -> "Last quarter"
    else -> "Waning crescent"
}

private fun dayName(offset: Int): String =
    SimpleDateFormat("EEE", Locale.ENGLISH).format(Date(System.currentTimeMillis() + offset * 86_400_000L))

private fun formatUvIndex(value: Double): String = if (kotlin.math.abs(value - value.roundToInt()) < .05) {
    value.roundToInt().toString()
} else {
    String.format(Locale.US, "%.1f", value)
}

private fun uvIndexBand(value: Double): String = when {
    value < 3.0 -> "Low"
    value < 6.0 -> "Moderate"
    value < 8.0 -> "High"
    value < 11.0 -> "Very high"
    else -> "Extreme"
}

private fun uvIndexDescription(value: Double): String = when {
    value < 3.0 -> "Low · protection usually optional"
    value < 6.0 -> "Moderate · protection advised"
    value < 8.0 -> "High · protection essential"
    value < 11.0 -> "Very high · minimise exposure"
    else -> "Extreme · avoid direct exposure"
}

@Composable
private fun AtmosDetailIcon(id: String, color: Color, modifier: Modifier = Modifier) {
    val cutoutColor = MaterialTheme.colorScheme.surface
    Canvas(modifier) {
        val stroke = 2.1.dp.toPx()
        val centre = Offset(size.width / 2f, size.height / 2f)
        when (id) {
            "sun", "uv" -> {
                drawCircle(color, size.minDimension * .18f, centre)
                repeat(8) { index ->
                    val angle = index * (PI / 4.0)
                    val start = Offset(centre.x + cos(angle).toFloat() * size.minDimension * .29f, centre.y + sin(angle).toFloat() * size.minDimension * .29f)
                    val end = Offset(centre.x + cos(angle).toFloat() * size.minDimension * .43f, centre.y + sin(angle).toFloat() * size.minDimension * .43f)
                    drawLine(color, start, end, stroke, cap = StrokeCap.Round)
                }
            }
            "wind" -> {
                listOf(.30f, .50f, .70f).forEachIndexed { index, y ->
                    val end = if (index == 1) .88f else .74f
                    drawLine(color, Offset(size.width * .12f, size.height * y), Offset(size.width * end, size.height * y), stroke, cap = StrokeCap.Round)
                    drawCircle(color, stroke * .58f, Offset(size.width * end, size.height * y))
                }
            }
            "moon" -> {
                drawCircle(color, size.minDimension * .34f, centre)
                drawCircle(cutoutColor, size.minDimension * .30f, Offset(centre.x + size.width * .17f, centre.y - size.height * .08f))
            }
            "rain" -> {
                val cloudY = size.height * .38f
                drawCircle(color, size.minDimension * .16f, Offset(size.width * .38f, cloudY))
                drawCircle(color, size.minDimension * .20f, Offset(size.width * .55f, cloudY - size.height * .06f))
                drawRoundRect(color, Offset(size.width * .22f, cloudY), Size(size.width * .58f, size.height * .17f), CornerRadius(size.height * .08f))
                listOf(.34f, .52f, .70f).forEach { x ->
                    drawLine(color, Offset(size.width * x, size.height * .65f), Offset(size.width * (x - .05f), size.height * .86f), stroke, cap = StrokeCap.Round)
                }
            }
            "pressure" -> {
                drawCircle(color, size.minDimension * .34f, centre, style = Stroke(stroke))
                drawLine(color, centre, Offset(size.width * .68f, size.height * .34f), stroke, cap = StrokeCap.Round)
                drawCircle(color, stroke, centre)
            }
            "humidity" -> {
                val drop = Path().apply {
                    moveTo(centre.x, size.height * .10f)
                    cubicTo(size.width * .68f, size.height * .38f, size.width * .77f, size.height * .58f, centre.x, size.height * .88f)
                    cubicTo(size.width * .23f, size.height * .58f, size.width * .32f, size.height * .38f, centre.x, size.height * .10f)
                    close()
                }
                drawPath(drop, color, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            "season" -> {
                repeat(4) { index ->
                    val angle = index * PI / 2.0
                    val petal = Offset(centre.x + cos(angle).toFloat() * size.width * .19f, centre.y + sin(angle).toFloat() * size.height * .19f)
                    drawCircle(color.copy(.86f), size.minDimension * .15f, petal)
                }
                drawCircle(color, size.minDimension * .10f, centre)
            }
            else -> {
                repeat(3) { index ->
                    val y = size.height * (.30f + index * .20f)
                    drawLine(color, Offset(size.width * .12f, y), Offset(size.width * .88f, y), stroke, cap = StrokeCap.Round)
                }
            }
        }
    }
}

private fun atmosGlyph(id: String): String = when (id) {
    "sun" -> "☀"; "wind" -> "≋"; "moon" -> "☾"; "rain" -> "◉"; "uv" -> "✹"
    "pressure" -> "◴"; "humidity" -> "♢"; "season", "seasons" -> "❋"; "tide" -> "≈"
    "conditions" -> "◉"; "locations" -> "⌖"; "about" -> "☼"; "settings" -> "⚙"
    else -> "✦"
}

private fun detailTitle(id: String): String = when (id) {
    "sun" -> "Sun & daylight"; "wind" -> "Wind"; "moon" -> "Moon"; "rain" -> "Rain"
    "uv" -> "UV index"; "pressure" -> "Pressure"; "humidity" -> "Humidity"
    "season" -> "Season"; else -> "Tides"
}

private fun detailDescription(id: String): String = when (id) {
    "sun" -> "Sunrise, sunset and remaining daylight are calculated for the selected location."
    "wind" -> "Current direction, speed and observed gusts from the nearest available station."
    "moon" -> "The current lunar phase and illumination are calculated locally."
    "rain" -> "Forecast precipitation chance and possible accumulation for today."
    "uv" -> "Protection is recommended when the UV index reaches 3 or higher."
    "pressure" -> "Pressure trends can help indicate changing weather."
    "humidity" -> "Relative humidity describes how much moisture is currently in the air."
    "season" -> "Atmos uses Southern Hemisphere meteorological seasons."
    else -> "Official tide predictions are available from the Bureau of Meteorology."
}


private suspend fun reverseGeocode(context: Context, latitude: Double, longitude: Double): List<Address> {
    if (!Geocoder.isPresent()) return emptyList()
    val geocoder = Geocoder(context, Locale.ENGLISH)
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        withTimeoutOrNull(8_000L) {
            suspendCancellableCoroutine { continuation ->
                geocoder.getFromLocation(latitude, longitude, 5, object : Geocoder.GeocodeListener {
                    override fun onGeocode(addresses: MutableList<Address>) {
                        if (continuation.isActive) continuation.resume(addresses)
                    }
                    override fun onError(errorMessage: String?) {
                        if (continuation.isActive) continuation.resume(emptyList())
                    }
                })
            }
        } ?: emptyList()
    } else {
        withContext(Dispatchers.IO) {
            @Suppress("DEPRECATION")
            runCatching { geocoder.getFromLocation(latitude, longitude, 5).orEmpty() }.getOrDefault(emptyList())
        }
    }
}

private fun usefulLocality(address: Address): String? {
    val candidates = listOf(address.subLocality, address.locality, address.subAdminArea)
    return candidates.firstOrNull { value ->
        !value.isNullOrBlank() &&
            !value.equals(address.adminArea, true) &&
            !value.equals(address.countryName, true)
    }?.trim()
}

private suspend fun resolveDevicePlace(
    context: Context,
    latitude: Double,
    longitude: Double,
    previous: Place? = null
): Place {
    val addresses = runCatching { reverseGeocode(context, latitude, longitude) }.getOrDefault(emptyList())
    val best = addresses.firstOrNull { !usefulLocality(it).isNullOrBlank() }
        ?: addresses.firstOrNull()
    val countryCode = best?.countryCode?.uppercase(Locale.ENGLISH).orEmpty()
    val australian = countryCode == "AU" || (countryCode.isBlank() && coordinatesAreAustralian(latitude, longitude))
    val nearest = places.minByOrNull { place ->
        distanceSquared(place.latitude, place.longitude, latitude, longitude)
    }

    if (australian) {
        val locality = best?.let(::usefulLocality)
            ?: previous?.name?.takeUnless { it.equals("Current location", true) }
            ?: nearest?.name
            ?: "Current location"
        val state = best?.adminArea?.takeIf { it.isNotBlank() }
            ?: previous?.state?.takeIf { it.isNotBlank() && !it.startsWith("Near ") }
            ?: nearest?.state.orEmpty()
        val zoneReference = nearest ?: previous
        return Place(
            id = geohash(latitude, longitude),
            name = locality,
            state = state,
            latitude = latitude,
            longitude = longitude,
            current = true,
            country = "Australia",
            countryCode = "AU",
            timeZoneId = zoneReference?.timeZoneId?.takeIf { it.isNotBlank() }
                ?: zoneReference?.let(::australianTimeZoneId).orEmpty()
        )
    }

    val locality = best?.let(::usefulLocality)
        ?: best?.adminArea?.takeIf { it.isNotBlank() }
        ?: previous?.name?.takeUnless { it.equals("Current location", true) }
        ?: "Current location"
    val state = best?.adminArea?.takeIf { it.isNotBlank() }
        ?: best?.countryName?.takeIf { it.isNotBlank() }
        ?: previous?.state.orEmpty()
    val country = best?.countryName?.takeIf { it.isNotBlank() }
        ?: previous?.country?.takeIf { it.isNotBlank() && it != "Australia" }
        ?: "International"
    return Place(
        id = geohash(latitude, longitude),
        name = locality,
        state = state,
        latitude = latitude,
        longitude = longitude,
        current = true,
        country = country,
        countryCode = countryCode,
        timeZoneId = previous?.timeZoneId.orEmpty()
    )
}

private suspend fun requestCurrentLocation(context: Context): Pair<Double, Double>? {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!fine && !coarse) return null
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    val provider = when {
        fine && manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
        manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
        else -> manager.getProviders(true).firstOrNull()
    } ?: return currentLocation(context)
    return withTimeoutOrNull(12_000) {
        suspendCancellableCoroutine { continuation ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                runCatching { manager.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(context)) { location -> if (continuation.isActive) continuation.resume(location?.let { it.latitude to it.longitude }) } }
                    .onFailure { if (continuation.isActive) continuation.resume(currentLocation(context)) }
            } else {
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) { manager.removeUpdates(this); if (continuation.isActive) continuation.resume(location.latitude to location.longitude) }
                    @Deprecated("Deprecated in Java") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
                    override fun onProviderEnabled(provider: String) = Unit
                    override fun onProviderDisabled(provider: String) = Unit
                }
                runCatching { manager.requestSingleUpdate(provider, listener, context.mainLooper) }.onFailure { if (continuation.isActive) continuation.resume(currentLocation(context)) }
                continuation.invokeOnCancellation { runCatching { manager.removeUpdates(listener) } }
            }
        }
    } ?: currentLocation(context)
}

private fun currentLocation(context: Context): Pair<Double, Double>? {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    val candidates = manager.getProviders(true)
        .mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }
    val recentCutoff = System.currentTimeMillis() - 15 * 60 * 1000L
    val best = candidates.filter { it.time >= recentCutoff }
        .minByOrNull { it.accuracy }
        ?: candidates.maxByOrNull { it.time }
    return best?.let { it.latitude to it.longitude }
}

private fun distanceSquared(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
    val x = (aLon - bLon) * cos(aLat * PI / 180)
    val y = aLat - bLat
    return x * x + y * y
}

private fun geohash(latitude: Double, longitude: Double, precision: Int = 6): String {
    val alphabet = "0123456789bcdefghjkmnpqrstuvwxyz"
    var latMin = -90.0
    var latMax = 90.0
    var lonMin = -180.0
    var lonMax = 180.0
    var even = true
    var bit = 0
    var value = 0
    val result = StringBuilder()
    while (result.length < precision) {
        if (even) {
            val mid = (lonMin + lonMax) / 2
            if (longitude >= mid) { value = value or (1 shl (4 - bit)); lonMin = mid } else lonMax = mid
        } else {
            val mid = (latMin + latMax) / 2
            if (latitude >= mid) { value = value or (1 shl (4 - bit)); latMin = mid } else latMax = mid
        }
        even = !even
        if (bit < 4) bit++ else {
            result.append(alphabet[value])
            bit = 0
            value = 0
        }
    }
    return result.toString()
}

private fun hasForegroundLocationPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

private fun hasBackgroundLocationPermission(context: Context): Boolean =
    Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

private fun openAtmosLocationSettings(context: Context) {
    context.startActivity(
        Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private suspend fun updateCurrentSavedPlaceForBackground(
    context: Context,
    preferences: AtmosPreferences,
    locations: List<Place>
): List<Place> {
    val current = locations.firstOrNull { it.current } ?: return locations
    if (!hasForegroundLocationPermission(context) || !hasBackgroundLocationPermission(context)) return locations
    val coordinates = requestCurrentLocation(context) ?: return locations
    if (distanceSquared(current.latitude, current.longitude, coordinates.first, coordinates.second) < 0.000004) return locations

    val relocated = resolveDevicePlace(
        context = context,
        latitude = coordinates.first,
        longitude = coordinates.second,
        previous = current
    )
    val updated = normaliseSavedPlaces(listOf(relocated) + locations.filterNot { it.current })
    preferences.savedPlaces = updated
    return updated
}

private const val BACKGROUND_WORK_NAME = "atmos_weather_background_refresh"

private fun scheduleBackgroundUpdates(context: Context, enabled: Boolean) {
    val manager = WorkManager.getInstance(context)
    if (!enabled) {
        manager.cancelUniqueWork(BACKGROUND_WORK_NAME)
        return
    }
    val request = PeriodicWorkRequestBuilder<AtmosBackgroundWorker>(15, TimeUnit.MINUTES)
        .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
        .build()
    manager.enqueueUniquePeriodicWork(BACKGROUND_WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
}

class AtmosBackgroundWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            val preferences = AtmosPreferences(applicationContext)
            if (!preferences.backgroundUpdates) {
                return Result.success()
            }

            var locations = preferences.savedPlaces
            if (locations.isEmpty()) {
                return Result.success()
            }

            // When the user has granted "Allow all the time", reposition the saved
            // current-location entry before downloading its forecast. If permission is
            // unavailable, Atmos safely falls back to the last saved coordinates.
            locations = updateCurrentSavedPlaceForBackground(applicationContext, preferences, locations)

            val refreshed = coroutineScope {
                locations
                    .map { place -> async { runCatching { WeatherRepository.load(place) }.getOrNull() } }
                    .mapNotNull { it.await() }
            }

            if (refreshed.isNotEmpty()) {
                val cache = preferences.cachedWeather(locations).toMutableMap()
                refreshed.forEach { state -> cache[state.place.cacheKey()] = state }
                preferences.saveWeatherCache(cache)
                refreshed.firstOrNull()?.let {
                    updateWidgets(applicationContext, it)
                    publishWeatherNotification(applicationContext, it, preferences.temperatureUnit)
                }
            }

            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}

private fun createWeatherNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val manager = context.getSystemService(NotificationManager::class.java) ?: return
    val channel = NotificationChannel(
        WEATHER_NOTIFICATION_CHANNEL_ID,
        "Current weather",
        NotificationManager.IMPORTANCE_DEFAULT
    ).apply {
        description = "Persistent weather for your first saved Atmos location"
        setShowBadge(false)
        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
    }
    manager.createNotificationChannel(channel)
    // 0.60.5–0.60.6 used a LOW-importance channel. Channel importance cannot be
    // raised after creation, so migrate to the new visible channel and remove the old entry.
    manager.deleteNotificationChannel(LEGACY_WEATHER_NOTIFICATION_CHANNEL_ID)
}

private fun weatherStatusIcon(temperature: Int): Icon {
    // Android treats the notification small icon as a monochrome alpha mask.
    // Fill almost the entire mask with bold, text-only numerals so the
    // temperature is as legible as possible in the status bar. Keep the degree
    // mark raised and compact; do not add a circle or alter condition-icon mode.
    val bitmap = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    val label = temperature.coerceIn(-99, 99).toString()
    val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
        color = AndroidColor.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        textSize = when (label.length) {
            1 -> 104f
            2 -> 88f
            else -> 68f
        }
    }
    val degreePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
        color = AndroidColor.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        textSize = 31f
    }
    val numberCentreX = when (label.length) {
        1 -> 49f
        2 -> 50f
        else -> 48f
    }
    val visualCentreY = 67f
    val baseline = visualCentreY - (numberPaint.ascent() + numberPaint.descent()) / 2f
    canvas.drawText(label, numberCentreX, baseline, numberPaint)
    canvas.drawText("°", 105f, 35f, degreePaint)
    return Icon.createWithBitmap(bitmap)
}

private fun weatherConditionStatusIcon(condition: String, night: Boolean): Icon {
    // Small notification icons are monochrome masks. Keep the condition glyph
    // bold and uncluttered so Android can tint it with the other status icons.
    val bitmap = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.WHITE
        style = Paint.Style.FILL
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    val normalized = condition.lowercase()
    val rainy = listOf("rain", "shower", "drizzle").any(normalized::contains)
    val stormy = listOf("storm", "thunder").any(normalized::contains)
    val cloudy = listOf("cloud", "overcast", "fog", "mist", "haze").any(normalized::contains)

    fun drawCloud(top: Float = 53f) {
        canvas.drawCircle(43f, top + 13f, 17f, paint)
        canvas.drawCircle(65f, top, 24f, paint)
        canvas.drawCircle(88f, top + 14f, 18f, paint)
        canvas.drawRoundRect(27f, top + 12f, 106f, top + 37f, 13f, 13f, paint)
    }

    when {
        stormy -> {
            drawCloud(40f)
            val bolt = android.graphics.Path().apply {
                moveTo(68f, 76f); lineTo(51f, 101f); lineTo(66f, 98f)
                lineTo(58f, 119f); lineTo(86f, 88f); lineTo(70f, 91f); close()
            }
            canvas.drawPath(bolt, paint)
        }
        rainy -> {
            drawCloud(37f)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 9f
            canvas.drawLine(43f, 88f, 36f, 108f, paint)
            canvas.drawLine(66f, 88f, 59f, 108f, paint)
            canvas.drawLine(89f, 88f, 82f, 108f, paint)
        }
        cloudy -> drawCloud(45f)
        night -> {
            val moon = android.graphics.Path().apply {
                addCircle(59f, 62f, 39f, android.graphics.Path.Direction.CW)
                addCircle(79f, 45f, 39f, android.graphics.Path.Direction.CCW)
            }
            canvas.drawPath(moon, paint)
        }
        else -> {
            canvas.drawCircle(64f, 64f, 27f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 10f
            for (index in 0 until 8) {
                val angle = Math.toRadians(index * 45.0)
                val x1 = 64f + kotlin.math.cos(angle).toFloat() * 40f
                val y1 = 64f + kotlin.math.sin(angle).toFloat() * 40f
                val x2 = 64f + kotlin.math.cos(angle).toFloat() * 52f
                val y2 = 64f + kotlin.math.sin(angle).toFloat() * 52f
                canvas.drawLine(x1, y1, x2, y2, paint)
            }
        }
    }
    return Icon.createWithBitmap(bitmap)
}


private fun publishCachedWeatherNotification(context: Context, preferences: AtmosPreferences) {
    if (!preferences.weatherNotificationEnabled) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    ) return
    val firstPlace = preferences.savedPlaces.firstOrNull() ?: return
    val state = preferences.cachedWeather(listOf(firstPlace))[firstPlace.cacheKey()] ?: return
    publishWeatherNotification(context, state, preferences.temperatureUnit)
}

private fun publishWeatherNotification(context: Context, weather: WeatherState, unit: TemperatureUnit) {
    val preferences = AtmosPreferences(context)
    if (!preferences.weatherNotificationEnabled) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    ) return
    val firstPlace = preferences.savedPlaces.firstOrNull() ?: return
    if (!sameSavedPlace(firstPlace, weather.place)) return
    val day = weather.days.firstOrNull() ?: return
    val currentCelsius = weather.observation.temp ?: weather.hours.firstOrNull()?.temp ?: day.high
    val current = displayTemperature(currentCelsius, unit)
    val high = displayTemperature(day.high, unit)
    val low = displayTemperature(day.low, unit)
    val degree = if (unit == TemperatureUnit.Celsius) "°C" else "°F"
    val condition = day.condition.trim().ifBlank { "Current conditions" }
    val intelligentSummary = localForecastSummary(
        weather = weather,
        dayIndex = 0,
        temperatureUnit = unit,
        maxSentences = 2
    )
    val collapsedSummary = intelligentSummary
        .substringBefore('.')
        .trim()
        .ifBlank { condition }
    val details = "$intelligentSummary High $high°, low $low°."
    createWeatherNotificationChannel(context)
    val openApp = PendingIntent.getActivity(
        context,
        604,
        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Notification.Builder(context, WEATHER_NOTIFICATION_CHANNEL_ID)
    } else {
        Notification.Builder(context)
    }
    when (preferences.statusBarIconStyle) {
        StatusBarIconStyle.Temperature -> builder.setSmallIcon(weatherStatusIcon(current))
        StatusBarIconStyle.Condition -> builder.setSmallIcon(
            weatherConditionStatusIcon("${day.icon} ${day.condition}", isNight())
        )
    }
    val notification = builder
        .setContentTitle("${weather.place.name}  •  $current$degree")
        .setContentText("High $high°  •  Low $low°  •  $collapsedSummary")
        .setStyle(Notification.BigTextStyle().bigText(details))
        .setContentIntent(openApp)
        .setCategory(Notification.CATEGORY_STATUS)
        .setVisibility(Notification.VISIBILITY_PUBLIC)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setShowWhen(false)
        .build()
    context.getSystemService(NotificationManager::class.java)?.notify(WEATHER_NOTIFICATION_ID, notification)
}

private fun cancelWeatherNotification(context: Context) {
    context.getSystemService(NotificationManager::class.java)?.cancel(WEATHER_NOTIFICATION_ID)
}

class AtmosBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val preferences = AtmosPreferences(context)
            scheduleBackgroundUpdates(context, preferences.backgroundUpdates)
            publishCachedWeatherNotification(context, preferences)
        }
    }
}

private fun widgetUsesDarkText(weather: WeatherState, appNight: Boolean, intensity: AtmosIntensityChoice): Boolean {
    val day = weather.days.firstOrNull()
    val icon = day?.icon ?: "clear"
    val condition = day?.condition ?: icon
    val now = Date()
    val palette = applyAtmosIntensityToPalette(
        applyAtmosphericPaletteVariables(
            solarAwarePalette(icon, weather.place, now),
            weather.observation,
            condition,
            weather.place,
            now
        ),
        intensity
    )
    val appBackground = if (appNight) Color(0xFF101827) else Color(0xFFF7F8FD)
    return colourBrightness(solarLegibleForeground(palette, appBackground)) < .5f
}

private fun widgetAppNight(context: Context, weather: WeatherState, preferences: AtmosPreferences): Boolean {
    if (preferences.darkNightMode && isLocationNight(weather.place, Date())) return true
    val systemDark = (context.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
        android.content.res.Configuration.UI_MODE_NIGHT_YES
    return when (preferences.theme) {
        ThemeChoice.Dark -> true
        ThemeChoice.Light -> false
        ThemeChoice.System, ThemeChoice.AutomaticLocation -> systemDark
    }
}

private fun resolvedWidgetDarkText(
    context: Context,
    weather: WeatherState,
    preferences: AtmosPreferences,
    appNightOverride: Boolean? = null
): Boolean = when (preferences.widgetTextMode) {
    WidgetTextMode.Light -> false
    WidgetTextMode.Dark -> true
    WidgetTextMode.Automatic -> widgetUsesDarkText(
        weather,
        appNightOverride ?: widgetAppNight(context, weather, preferences),
        preferences.atmosIntensityChoice
    )
}

private fun updateWidgetTextMode(
    context: Context,
    weather: WeatherState,
    preferences: AtmosPreferences,
    appNightOverride: Boolean? = null
) {
    val useDarkText = resolvedWidgetDarkText(context, weather, preferences, appNightOverride)
    val widgetPrefs = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE)
    val useGradientTypography = preferences.widgetGradientTypography
    if (widgetPrefs.getBoolean("use_dark_text", false) != useDarkText ||
        widgetPrefs.getBoolean("gradient_typography", false) != useGradientTypography
    ) {
        widgetPrefs.edit()
            .putBoolean("use_dark_text", useDarkText)
            .putBoolean("gradient_typography", useGradientTypography)
            .apply()
        AtmosHeroWidgetProvider.updateAll(context)
    }
}

private fun updateWidgets(context: Context, weather: WeatherState) {
    val day = weather.days.first()
    val prefs = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE)
    prefs.edit()
        .putString("location", weather.place.name)
        .putString("state", weather.place.state)
        .putBoolean("current", weather.place.current)
        .putString("time_zone", weather.place.timeZone().id)
        .putString("feels", (weather.observation.feels ?: weather.observation.temp ?: day.high - 2).toString())
        .putString("summary", localForecastSummary(weather, 0, TemperatureUnit.Celsius, maxSentences = 2))
        .putString("location_id", geohash(weather.place.latitude, weather.place.longitude))
        .putString("temp", (weather.observation.temp ?: day.high - 2).toString())
        .putString("condition", nightCondition(day.condition))
        .putString("high", day.high.toString())
        .putString("low", day.low.toString())
        .putString("rain", day.rainChance.toString())
        .putString("wind", (weather.observation.wind ?: weather.hours.firstOrNull()?.wind ?: 0).toString())
        .putString("humidity", (weather.observation.humidity ?: weather.hours.firstOrNull()?.humidity ?: 0).toString())
        .putString("icon", if (isNight()) "night" else day.icon)
        .putString("season", seasonName(weather.place))
        .putBoolean("use_dark_text", resolvedWidgetDarkText(context, weather, AtmosPreferences(context)))
        .putBoolean("gradient_typography", AtmosPreferences(context).widgetGradientTypography)
        .putLong("updated_at", System.currentTimeMillis())
        .also { editor ->
            weather.hours.take(3).forEachIndexed { index, forecast ->
                val label = if (index == 0) "NOW" else java.text.SimpleDateFormat("ha", java.util.Locale.ENGLISH)
                    .format(forecast.time).uppercase(java.util.Locale.ENGLISH)
                editor.putString("hour_time_$index", label)
                editor.putString("hour_temp_$index", forecast.temp.toString())
            }
            weather.days.take(7).forEachIndexed { index, forecast ->
                val label = if (index == 0) "TODAY" else try {
                    java.text.SimpleDateFormat("EEE", java.util.Locale.ENGLISH).format(
                        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(forecast.date)!!
                    ).uppercase(java.util.Locale.ENGLISH)
                } catch (_: Exception) { "—" }
                editor.putString("day_name_$index", label)
                editor.putString("day_high_$index", forecast.high.toString())
                editor.putString("day_low_$index", forecast.low.toString())
                editor.putString("day_icon_$index", forecast.icon)
            }
        }
        .apply()
    AtmosWidgetProvider.updateAll(context)
    AtmosHeroWidgetProvider.updateAll(context)
    AtmosRightNowWidgetProvider.updateAll(context)
    AtmosMomentsWidgetProvider.updateAll(context)
    AtmosTodayGlanceWidgetProvider.updateAll(context)
    AtmosWidgetUpdater.schedule(context)
}


internal fun loadFirstWallpaperWeather(context: Context): WeatherState? {
    val preferences = AtmosPreferences(context)
    val first = preferences.savedPlaces.firstOrNull() ?: return null
    return preferences.cachedWeather(listOf(first))[first.cacheKey()]
}
