# Atmos 0.30.6

Experimental immersive location transitions.

- Adds Settings > Appearance > Location transition: Standard or Immersive (Experimental).
- Standard retains the existing page swipe.
- Immersive anchors one Atmos scene behind the forecast pages while swiping.
- The scene blends hero palettes and live temperature, feels-like, humidity, pressure, rain and wind inputs according to pager progress.
- Seasonal and condition state hand over at the midpoint while the gradient continuously interpolates.
- Hero cards suppress their duplicate atmosphere renderer in immersive mode, avoiding two full hero backgrounds per page.
- Existing users default to Standard for a safe A/B test.

Version: 0.30.6 (101)
