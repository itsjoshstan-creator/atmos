# Atmos 0.69.21

- Restored the original minimal single-pixel degree mark for Glyph temperature and feels-like displays.
- Removed Celsius and Fahrenheit letters from the 13×13 Glyph Matrix display.
- The Celsius/Fahrenheit setting still converts the displayed numeric temperature.
- Preserved the working native Nothing Glyph service and all display options from 0.69.20.
