# Atmos 0.69.30

- Replaced wall-clock Auto Glyph Rotation with a dedicated stateful sequence.
- Temperature, Living Sky and Next Solar Event now each receive a full 10-second display period.
- Separated the rotation timer from the 5 FPS Living Sky animation timer.
- AOD events, weather refreshes and frame redraws no longer advance, skip or restart the active rotation slot.
- Preserved the working Nothing Glyph integration and minimalist static condition icon set.
