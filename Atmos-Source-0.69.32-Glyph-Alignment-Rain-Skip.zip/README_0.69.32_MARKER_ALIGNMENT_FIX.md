# Atmos 0.69.32 — Glyph marker alignment refinement

- Aligned the 2×2 precipitation marker with the top row of the large numeric glyphs, matching the temperature degree marker.
- Kept the 1×2 battery marker aligned with the top row of the large numeric glyphs.
- Auto Glyph Rotation now omits Chance of Rain whenever the displayed precipitation chance is 0%.
- Rotation remains stateful, and every included screen still receives a full 10-second interval.
