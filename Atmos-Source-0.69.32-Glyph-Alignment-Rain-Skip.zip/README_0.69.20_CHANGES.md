# Atmos 0.69.20

- Fixed the Glyph display settings build failure on the project's current Compose runtime.
- Replaced unsupported `mutableFloatStateOf` calls with compatible typed `mutableStateOf` values.
- Retains all Nothing Glyph Matrix display modes and the confirmed-working native Glyph service from 0.69.18.
