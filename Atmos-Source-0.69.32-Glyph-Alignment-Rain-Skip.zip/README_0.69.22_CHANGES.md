# Atmos 0.69.22

## Nothing Glyph Matrix

- Increased active weather-symbol animation smoothness to approximately 5 frames per second.
- Added live Glyph preference observation so display mode, animation, units, location, brightness, alternation and interval changes redraw immediately while the toy is active.
- Preserved the proven native Glyph Matrix SDK connection, Phone (4a) Pro registration and structured 13×13 frame renderer from 0.69.21.
- Solar countdown values remain minute-based.
