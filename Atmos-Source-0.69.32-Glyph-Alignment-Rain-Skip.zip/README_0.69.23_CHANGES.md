# Atmos 0.69.23

## Nothing Glyph Matrix

- Auto Weather now shows temperature for the first 50 seconds of every minute and the current condition for the final 10 seconds.
- Next Solar Event shows normal weather until sunrise or sunset is within two hours.
- Auto Weather temporarily prioritises the same solar countdown during that two-hour window.
- Solar countdowns show whole hours when more than one hour remains, then exact minutes during the final hour.
- Existing native Glyph connection, live settings updates, brightness, units and animation controls remain unchanged.
