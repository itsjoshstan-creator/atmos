# Atmos 0.69.28

- Auto Glyph Rotation now changes every 10 seconds: Temperature, Living Sky, then Next Solar Event.
- Next Solar Event remains in the rotation regardless of how far away it is.
- Static Living Sky is now the default for new installs.
- Added purpose-built 13×13 still artwork for clear, cloud, rain, snow, fog, storm and night conditions.
- Animated Living Sky remains available at the stable 5 FPS rate.
