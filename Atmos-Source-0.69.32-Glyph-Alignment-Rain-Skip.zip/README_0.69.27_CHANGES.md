# Atmos 0.69.27

## Nothing Glyph Matrix

- Returned animated Glyph experiences to approximately 5 FPS for cleaner motion on the Phone (4a) Pro.
- Added **Auto Glyph Rotation** as a selectable Glyph experience.
- Auto Glyph Rotation cycles through Temperature, Living Sky and Next Solar Event every 30 seconds.
- Rotation uses wall-clock timing, so it remains consistent after service reconnects and settings changes.
- Preserved the working native Nothing SDK service, live settings updates, rain renderer and countdown alignment.
