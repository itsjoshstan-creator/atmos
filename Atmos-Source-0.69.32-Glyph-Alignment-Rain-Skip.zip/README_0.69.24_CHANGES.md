# Atmos 0.69.24

## Nothing Glyph Matrix

- Consolidated the Glyph display menu into six focused experiences: Temperature, Living Sky, Next Solar Event, Approaching Weather, Moon Phase and Atmos Mood.
- Removed Temperature + Conditions, separate Sunrise and Sunset countdowns, Precipitation, Feels Like and Auto Weather from the selectable menu.
- Added Living Sky, which renders current conditions and transitions into an animated sunrise or sunset horizon within two hours of the next solar event.
- Added Approaching Weather, driven by the next significant hourly rain, snow, storm or strong-wind forecast.
- Added a date-derived Moon Phase display.
- Added Atmos Mood, which combines current conditions, rain chance, humidity, wind and temperature into a compact ambient state.
- Preserved the proven native Nothing SDK service, live settings updates, brightness control, unit selection, location selection and smooth animation loop.
