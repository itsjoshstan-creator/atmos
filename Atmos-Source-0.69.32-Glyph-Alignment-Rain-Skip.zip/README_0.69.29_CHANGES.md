# Atmos 0.69.29

- Redesigned every static Living Sky condition as a cohesive minimalist 13×13 icon.
- Replaced the static rain image with a filled water-drop symbol.
- Balanced the visual size, weight and alignment of sun, cloud, rain, snow, fog, storm and night icons.
- Preserved the working Nothing Glyph service, 5 FPS animated mode and 10-second Auto Glyph Rotation.
