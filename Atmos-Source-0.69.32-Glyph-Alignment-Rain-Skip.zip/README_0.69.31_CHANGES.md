# Atmos 0.69.31

- Redesigned the Living Sky sunrise and sunset Glyph icons as distinct minimalist horizon scenes.
- Forecast low temperatures now use the overnight minimum from 6 pm through 9 am the following morning.
- Retains the fixed stateful Auto Glyph Rotation from 0.69.30.
