# Atmos 0.69.26

- Increased Nothing Glyph Matrix weather animation rate from approximately 5 FPS to 10 FPS.
- Centred one-digit Next Solar Event countdowns together with their unit indicator.
- Changed countdown unit indicators from uppercase H/M to lowercase h/m.
- Preserved the working native Nothing Glyph service and all existing 0.69.25 display behaviour.
