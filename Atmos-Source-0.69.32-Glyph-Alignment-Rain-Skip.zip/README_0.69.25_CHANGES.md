# Atmos 0.69.25

- Added an Actual temperature / Feels like selector for Glyph temperature displays.
- Reworked rain into a full 13×13 matrix animation with short trailing drops.
- Rain now falls diagonally when wind is sufficiently strong, otherwise straight down.
- Removed Moon Phase and Atmos Mood Glyph experiences.
- Simplified Next Solar Event to show whole hours until the next sunrise or sunset.
