# Atmos 0.50.4

Lean Atmos renderer update. See `README_0.50.4_CHANGES.md` for details.
