# Atmos 0.68.2 — Automatic GitHub Build Workflow

The GitHub Actions workflow now:

- Automatically selects the highest-versioned `Atmos-Source-*.zip` in the repository root.
- Extracts the selected source without requiring a manual YAML filename update.
- Reads `versionName` directly from `android/app/build.gradle`.
- Builds the Performance APK.
- Renames the APK to `Atmos-<version>.apk`, such as `Atmos-0.68.2.apk`.
- Names the downloadable Actions artifact `Atmos-<version>`.
- Keeps new artifacts for one day and removes older artifacts beyond the five newest.
- Only starts a push build when an Atmos source ZIP or the workflow itself changes.

## New workflow

1. Upload the new `Atmos-Source-<version>-description.zip` to the repository root.
2. Commit the upload.
3. Open GitHub Actions and wait for the single build run.
4. Download the `Atmos-<version>` artifact.
5. Extract it to obtain `Atmos-<version>.apk`.

There is no longer any need to edit the workflow for each version.
