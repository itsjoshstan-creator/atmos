# Atmos 0.50.5

Lean Atmos renderer update. See `README_0.50.5_CHANGES.md` for details.
