# Atmos 0.69.35

- Aligned Next Solar Event digits to the same vertical and horizontal number position used by Temperature, Chance of Rain and Battery.
- Moved the sunrise and sunset LED marks to retain one blank row between each mark and the shared numeric display.
- Preserved the existing solar countdown and automatic hours-to-minutes behaviour.
