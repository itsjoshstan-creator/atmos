# Atmos 0.69.36

- Dimmed the three-pixel horizontal horizon line in both the sunrise and sunset Glyph icons.
- Horizon brightness now matches the dim temperature degree LED.
- Kept the single sun LED bright.
- Preserved solar number position, icon spacing, countdown logic and auto rotation behaviour.
