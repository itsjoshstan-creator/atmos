# Atmos 0.69.34

## Nothing Glyph Matrix — Next Solar Event

- Removed the `h` and `m` unit letters from the next solar event display.
- Centred the countdown number using the same Atmos numeric layout.
- Added a minimal sunrise mark above the number: a three-LED horizon with one centred LED above it.
- Added a mirrored sunset mark below the number: a three-LED horizon with one centred LED below it.
- Kept exactly one blank LED row between the icon and the numeric display.
- Preserved the existing behaviour of showing hours until the final hour, then minutes.
