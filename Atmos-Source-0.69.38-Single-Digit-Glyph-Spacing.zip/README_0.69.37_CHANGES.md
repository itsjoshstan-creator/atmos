# Atmos 0.69.37

## Nothing Glyph Matrix

- Removed Chance of Rain from Auto Glyph Rotation.
- Auto Glyph Rotation now cycles Temperature, Next Solar Event and Battery Percentage.
- Each active display still receives a genuine 10-second interval.
- Chance of Rain remains available as a standalone Glyph display in Settings.
- No changes were made to Glyph artwork, alignment, countdown behaviour or SDK integration.
