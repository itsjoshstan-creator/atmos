# Atmos 0.69.33 — Glyph precipitation centring

- Centred one- and two-digit Chance of Rain values using the same numeric positioning as Temperature and Battery.
- Preserved the top-aligned 2×2 precipitation marker.
- Preserved automatic skipping of Chance of Rain when the displayed value is 0%.
- Bumped the Android version to 0.69.33 (version code 423).
