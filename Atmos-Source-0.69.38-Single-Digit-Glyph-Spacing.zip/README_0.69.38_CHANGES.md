# Atmos 0.69.38

- Ensured single-digit Temperature and Battery Glyph values remain centred on the 13×13 matrix.
- Kept the full-battery `F` centred.
- Moved the 1×2 battery marker inward for single digits and `F`, leaving exactly one blank LED between the character and marker.
- Left two-digit layouts and all other Glyph behaviour unchanged.
