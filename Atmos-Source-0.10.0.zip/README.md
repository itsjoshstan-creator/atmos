# Atmos

Atmos is a lightweight native Android weather app using Bureau of Meteorology
forecast data. Its primary interface is written in Kotlin with Jetpack Compose.

## Current version

`0.10.0`

Atmos 0.10.0 begins the native Android preview. The primary interface is now
written in Kotlin with Jetpack Compose; the 0.9.4 web interface remains in
`webapp/` as a fallback reference during migration.

- Small fixes and refinements increase the patch number by `0.0.1`.
- Larger feature updates increase the minor number by `0.1.0`.
- Version `1.0.0` is reserved for the first release-ready build.

## Build an Android APK

```sh
cd android
./gradlew assembleDebug
```

The debug APK is created at:

`android/app/build/outputs/apk/debug/app-debug.apk`

Internet access is required for live Bureau of Meteorology data.

## Android widgets

Atmos includes compact current-conditions, wide hourly, and slim At a Glance
home-screen widgets. Their artwork and gradients follow the current weather,
and Android schedules lightweight BOM refreshes approximately every 30 minutes.
