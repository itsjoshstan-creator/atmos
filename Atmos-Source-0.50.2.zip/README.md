# Atmos 0.50.2

Atmos performance and static-rendering update. See `README_0.50.2_CHANGES.md` for details.
