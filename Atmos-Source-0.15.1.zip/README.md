# Atmos 0.12.3

Performance-focused update based directly on Atmos 0.12.2.

Changes:
- Preserves the 0.12.2 interface and ambient condition animations without altering their appearance or behaviour.
- Caches the home-page condition palette and large background brush instead of rebuilding them during unrelated recompositions.
- Caches the saved-location pager structure and selected page calculations.
- Reuses placeholder weather state for unloaded location pages instead of allocating it repeatedly.
- Adds stable content types to the hourly and precipitation rows so Compose can reuse item compositions more effectively.
- Keeps the existing stable keys and lazy-list structure.
- Updated to versionCode 43 and versionName 0.12.3.

The source archive passed a ZIP integrity check. Android compilation must still be confirmed by GitHub Actions.

## Atmos 0.14.0 performance pass
- Requests the highest refresh-rate display mode supported by the device while Atmos is foregrounded.
- Keeps the neighbouring location page warm for smoother horizontal swipes.
- Places expensive static home cards in reusable graphics layers so scrolling can move cached GPU textures.
- Enables R8 code shrinking and resource shrinking for release builds.
- Explicitly keeps hardware acceleration enabled without requesting an oversized heap.

## 0.15.0
- Widgets now use condition-matched Atmos gradients, including clear, cloudy, rain, storm, fog, snow, sunrise, sunset and night.
- Added a configurable transparent widget style with no background or border.
- Added a new 4x2 weekly widget with current conditions and a seven-day forecast.
- All widgets now show the selected location, last update time and Southern Hemisphere season pill.
