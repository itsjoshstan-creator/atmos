package au.com.weatheraustralia.app

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.absoluteValue
import kotlin.math.acos
import kotlin.math.atan
import kotlin.math.floor
import kotlin.math.tan
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AtmosNativeApp() }
    }
}

private enum class Page { Home, Conditions, Seasons, Settings, Locations, About }
private enum class ThemeChoice { System, Light, Dark }
private enum class DensityChoice { Compact, Expanded }
private enum class TemperatureUnit { Celsius, Fahrenheit }

private data class Place(
    val id: String,
    val name: String,
    val state: String,
    val latitude: Double,
    val longitude: Double,
    val current: Boolean = false
)

private data class DayForecast(
    val date: String,
    val condition: String,
    val icon: String,
    val high: Int,
    val low: Int,
    val rainChance: Int,
    val rainAmount: Double
)

private data class HourForecast(
    val time: Date,
    val temp: Int,
    val icon: String,
    val rainChance: Int,
    val humidity: Int,
    val wind: Int,
    val direction: String
)

private data class Observation(
    val temp: Int? = null,
    val feels: Int? = null,
    val humidity: Int? = null,
    val wind: Int? = null,
    val direction: String = "",
    val gust: Int? = null,
    val pressure: Double? = null,
    val rainSince9: Double? = null,
    val station: String = "Nearest observation"
)

private data class WeatherState(
    val place: Place,
    val days: List<DayForecast>,
    val hours: List<HourForecast>,
    val observation: Observation,
    val live: Boolean,
    val warnings: List<String> = emptyList(),
    val updated: Date = Date()
)

private val places = listOf(
    Place("", "Forrestdale", "Western Australia", -32.155, 115.934),
    Place("qd66hr", "Fremantle", "Western Australia", -32.0569, 115.7439),
    Place("qd66hr", "Perth", "Western Australia", -31.9523, 115.8613),
    Place("qd65fp", "Mandurah", "Western Australia", -32.5269, 115.7217),
    Place("qd47rc", "Bunbury", "Western Australia", -33.3267, 115.6369),
    Place("qd6k4f", "Joondalup", "Western Australia", -31.745, 115.766),
    Place("qd5r1g", "Rockingham", "Western Australia", -32.281, 115.727),
    Place("qd4x4s", "Albany", "Western Australia", -35.0269, 117.8837),
    Place("", "Busselton", "Western Australia", -33.6516, 115.347),
    Place("", "Margaret River", "Western Australia", -33.953, 115.073),
    Place("", "Port Hedland", "Western Australia", -20.3107, 118.601),
    Place("qd1u2n", "Esperance", "Western Australia", -33.8608, 121.8896),
    Place("qdb3g6", "Geraldton", "Western Australia", -28.7774, 114.614),
    Place("qec32p", "Kalgoorlie", "Western Australia", -30.7489, 121.4658),
    Place("qg5k8c", "Broome", "Western Australia", -17.9614, 122.2359),
    Place("qgbx8x", "Karratha", "Western Australia", -20.7364, 116.8463),
    Place("r3gx2f", "Darwin", "Northern Territory", -12.4634, 130.8456),
    Place("r1r0fs", "Adelaide", "South Australia", -34.9285, 138.6007),
    Place("r1f93c", "Melbourne", "Victoria", -37.8136, 144.9631),
    Place("r3dp5h", "Hobart", "Tasmania", -42.8821, 147.3272),
    Place("r3gx2f", "Canberra", "Australian Capital Territory", -35.2809, 149.13),
    Place("r3gx2f", "Sydney", "New South Wales", -33.8688, 151.2093),
    Place("r7hg6k", "Brisbane", "Queensland", -27.4698, 153.0251),
    Place("r7k0yx", "Gold Coast", "Queensland", -28.0167, 153.4),
    Place("r7hx0w", "Sunshine Coast", "Queensland", -26.65, 153.0667),
    Place("r6n3xm", "Cairns", "Queensland", -16.9186, 145.7781),
    Place("r6kz2g", "Townsville", "Queensland", -19.2589, 146.8169),
    Place("r3gx2f", "Newcastle", "New South Wales", -32.9283, 151.7817),
    Place("r3gx2f", "Wollongong", "New South Wales", -34.4278, 150.8931),
    Place("", "Coffs Harbour", "New South Wales", -30.2963, 153.1135),
    Place("", "Dubbo", "New South Wales", -32.2569, 148.6011),
    Place("", "Wagga Wagga", "New South Wales", -35.1082, 147.3598),
    Place("", "Byron Bay", "New South Wales", -28.6474, 153.602),
    Place("", "Geelong", "Victoria", -38.1499, 144.3617),
    Place("", "Ballarat", "Victoria", -37.5622, 143.8503),
    Place("", "Bendigo", "Victoria", -36.757, 144.2794),
    Place("", "Mildura", "Victoria", -34.208, 142.1246),
    Place("", "Toowoomba", "Queensland", -27.5598, 151.9507),
    Place("", "Mackay", "Queensland", -21.1411, 149.186),
    Place("", "Rockhampton", "Queensland", -23.379, 150.51),
    Place("", "Mount Gambier", "South Australia", -37.8284, 140.7804),
    Place("", "Port Augusta", "South Australia", -32.4952, 137.7894),
    Place("", "Whyalla", "South Australia", -33.034, 137.585),
    Place("", "Launceston", "Tasmania", -41.4332, 147.1441),
    Place("", "Devonport", "Tasmania", -41.1769, 146.3515),
    Place("r1r0fs", "Alice Springs", "Northern Territory", -23.698, 133.8807),
    Place("", "Katherine", "Northern Territory", -14.4652, 132.2635)
)

private val fallbackDays = listOf(
    DayForecast("", "Mostly sunny", "mostly_sunny", 21, 12, 5, 0.0),
    DayForecast("", "Partly cloudy", "partly_cloudy", 20, 11, 20, 0.4),
    DayForecast("", "Sunny", "sunny", 22, 10, 5, 0.0),
    DayForecast("", "Cloud increasing", "cloudy", 19, 12, 30, 0.8),
    DayForecast("", "Shower or two", "shower", 18, 11, 55, 3.0),
    DayForecast("", "Partly cloudy", "partly_cloudy", 19, 10, 20, 0.2),
    DayForecast("", "Mostly sunny", "mostly_sunny", 21, 11, 10, 0.0)
)

private object BomRepository {
    suspend fun load(place: Place): WeatherState = withContext(Dispatchers.IO) {
        try {
            val locationId = geohash(place.latitude, place.longitude)
            val daily = get("https://api.weather.bom.gov.au/v1/locations/$locationId/forecasts/daily")
            val hourly = runCatching { get("https://api.weather.bom.gov.au/v1/locations/$locationId/forecasts/hourly") }.getOrNull()
            val observations = runCatching { get("https://api.weather.bom.gov.au/v1/locations/$locationId/observations") }.getOrNull()
            val warningData = runCatching { get("https://api.weather.bom.gov.au/v1/locations/$locationId/warnings") }.getOrNull()
            val dayArray = daily.optJSONArray("data") ?: JSONArray()
            val days = (0 until minOf(dayArray.length(), 7)).map { i ->
                val d = dayArray.getJSONObject(i)
                val rain = d.optJSONObject("rain")
                DayForecast(
                    d.optString("date"), d.optString("short_text", "Current conditions"),
                    d.optString("icon_descriptor", "partly_cloudy"),
                    d.optInt("temp_max", 20), d.optInt("temp_min", 11),
                    rain?.optInt("chance", 0) ?: 0,
                    rain?.optJSONObject("amount")?.optDouble("max", 0.0) ?: 0.0
                )
            }.ifEmpty { fallbackDays }
            val hourArray = hourly?.optJSONArray("data") ?: JSONArray()
            val hours = (0 until minOf(hourArray.length(), 24)).mapNotNull { i ->
                runCatching {
                    val h = hourArray.getJSONObject(i)
                    val rain = h.optJSONObject("rain")
                    val wind = h.optJSONObject("wind")
                    val temperature: Int = h.optInt("temp", days.first().high - 2)
                    HourForecast(
                        time = parseDate(h.optString("time", h.optString("date"))),
                        temp = temperature,
                        icon = h.optString("icon_descriptor", days.first().icon),
                        rainChance = rain?.optInt("chance", 0) ?: 0,
                        humidity = h.optInt("relative_humidity", 0),
                        wind = wind?.optInt("speed_kilometre", 0) ?: 0,
                        direction = wind?.optString("direction", "") ?: ""
                    )
                }.getOrNull()
            }
            val raw = observations?.opt("data")
            val o = when (raw) {
                is JSONArray -> raw.optJSONObject(0)
                is JSONObject -> raw.optJSONArray("observations")?.optJSONObject(0) ?: raw
                else -> null
            }
            val wind = o?.optJSONObject("wind")
            val gust = o?.optJSONObject("gust")
            val station = o?.optJSONObject("station")
            WeatherState(
                place, days, hours,
                Observation(
                    o?.numberOrNull("temp")?.roundToInt(),
                    o?.numberOrNull("temp_feels_like")?.roundToInt(),
                    o?.numberOrNull("humidity")?.roundToInt(),
                    wind?.numberOrNull("speed_kilometre")?.roundToInt(),
                    wind?.optString("direction", "") ?: "",
                    gust?.numberOrNull("speed_kilometre")?.roundToInt(),
                    o?.numberOrNull("pressure_msl"),
                    o?.numberOrNull("rain_since_9am"),
                    station?.optString("name", "Nearest observation") ?: "Nearest observation"
                ), true,
                warnings = warningData?.optJSONArray("data")?.let { array ->
                    (0 until array.length()).mapNotNull { array.optJSONObject(it)?.optString("title")?.takeIf(String::isNotBlank) }
                } ?: emptyList()
            )
        } catch (_: Exception) {
            WeatherState(place, fallbackDays, emptyList(), Observation(temp = 19, feels = 17, humidity = 54, wind = 9, direction = "W"), false)
        }
    }

    private fun get(address: String): JSONObject {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 12_000
        connection.readTimeout = 12_000
        connection.setRequestProperty("Accept", "application/json")
        return try {
            JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        } finally {
            connection.disconnect()
        }
    }
}

private fun JSONObject.numberOrNull(key: String): Double? =
    if (has(key) && !isNull(key)) optDouble(key).takeUnless { it.isNaN() } else null

private fun parseDate(value: String): Date =
    listOf("yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX").firstNotNullOfOrNull {
        runCatching { SimpleDateFormat(it, Locale.US).parse(value) }.getOrNull()
    } ?: Date()


private fun Place.cacheKey(): String = "${"%.4f".format(Locale.US, latitude)}:${"%.4f".format(Locale.US, longitude)}"

private fun WeatherState.toJson(): JSONObject = JSONObject().apply {
    put("place", JSONObject().apply {
        put("id", place.id); put("name", place.name); put("state", place.state)
        put("lat", place.latitude); put("lon", place.longitude); put("current", place.current)
    })
    put("days", JSONArray().apply { days.forEach { day -> put(JSONObject().apply {
        put("date", day.date); put("condition", day.condition); put("icon", day.icon)
        put("high", day.high); put("low", day.low); put("rainChance", day.rainChance); put("rainAmount", day.rainAmount)
    }) } })
    put("hours", JSONArray().apply { hours.forEach { hour -> put(JSONObject().apply {
        put("time", hour.time.time); put("temp", hour.temp); put("icon", hour.icon)
        put("rainChance", hour.rainChance); put("humidity", hour.humidity); put("wind", hour.wind); put("direction", hour.direction)
    }) } })
    put("observation", JSONObject().apply {
        observation.temp?.let { put("temp", it) }; observation.feels?.let { put("feels", it) }
        observation.humidity?.let { put("humidity", it) }; observation.wind?.let { put("wind", it) }
        put("direction", observation.direction); observation.gust?.let { put("gust", it) }
        observation.pressure?.let { put("pressure", it) }; observation.rainSince9?.let { put("rainSince9", it) }
        put("station", observation.station)
    })
    put("live", live); put("warnings", JSONArray(warnings)); put("updated", updated.time)
}

private fun weatherStateFromJson(json: JSONObject): WeatherState? = runCatching {
    val p = json.getJSONObject("place")
    val place = Place(p.optString("id"), p.optString("name"), p.optString("state"), p.optDouble("lat"), p.optDouble("lon"), p.optBoolean("current"))
    val dayArray = json.optJSONArray("days") ?: JSONArray()
    val days = (0 until dayArray.length()).map { i -> dayArray.getJSONObject(i).let { d ->
        DayForecast(d.optString("date"), d.optString("condition"), d.optString("icon"), d.optInt("high"), d.optInt("low"), d.optInt("rainChance"), d.optDouble("rainAmount"))
    } }.ifEmpty { fallbackDays }
    val hourArray = json.optJSONArray("hours") ?: JSONArray()
    val hours = (0 until hourArray.length()).map { i -> hourArray.getJSONObject(i).let { h ->
        HourForecast(Date(h.optLong("time")), h.optInt("temp"), h.optString("icon"), h.optInt("rainChance"), h.optInt("humidity"), h.optInt("wind"), h.optString("direction"))
    } }
    val o = json.optJSONObject("observation") ?: JSONObject()
    val observation = Observation(
        o.optIntOrNull("temp"), o.optIntOrNull("feels"), o.optIntOrNull("humidity"), o.optIntOrNull("wind"),
        o.optString("direction"), o.optIntOrNull("gust"), o.numberOrNull("pressure"), o.numberOrNull("rainSince9"), o.optString("station", "Nearest observation")
    )
    val warningArray = json.optJSONArray("warnings") ?: JSONArray()
    val warnings = (0 until warningArray.length()).mapNotNull { warningArray.optString(it).takeIf(String::isNotBlank) }
    WeatherState(place, days, hours, observation, json.optBoolean("live"), warnings, Date(json.optLong("updated", System.currentTimeMillis())))
}.getOrNull()

private fun JSONObject.optIntOrNull(key: String): Int? = if (has(key) && !isNull(key)) optInt(key) else null

private class AtmosPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("atmos_native", Context.MODE_PRIVATE)
    var onboarded: Boolean
        get() = prefs.getBoolean("onboarded", false)
        set(value) = prefs.edit().putBoolean("onboarded", value).apply()
    var theme: ThemeChoice
        get() = runCatching { ThemeChoice.valueOf(prefs.getString("theme", "System")!!) }.getOrDefault(ThemeChoice.System)
        set(value) = prefs.edit().putString("theme", value.name).apply()
    var darkNightMode: Boolean
        get() = prefs.getBoolean("darkNightMode", true)
        set(value) = prefs.edit().putBoolean("darkNightMode", value).apply()
    var density: DensityChoice
        get() = runCatching { DensityChoice.valueOf(prefs.getString("density", "Expanded")!!) }.getOrDefault(DensityChoice.Expanded)
        set(value) = prefs.edit().putString("density", value.name).apply()
    var temperatureUnit: TemperatureUnit
        get() = runCatching { TemperatureUnit.valueOf(prefs.getString("temperatureUnit", "Celsius")!!) }.getOrDefault(TemperatureUnit.Celsius)
        set(value) = prefs.edit().putString("temperatureUnit", value.name).apply()
    var menuLeft: Boolean
        get() = prefs.getBoolean("menuLeft", false)
        set(value) = prefs.edit().putBoolean("menuLeft", value).apply()
    var hiddenCards: Set<String>
        get() = prefs.getStringSet("hiddenCards", emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet("hiddenCards", value).apply()
    var cardOrder: List<String>
        get() = prefs.getString("cardOrder", null)?.split(",")?.filter { it.isNotBlank() } ?: detailCardIds
        set(value) = prefs.edit().putString("cardOrder", value.joinToString(",")).apply()
    fun cachedWeather(places: List<Place>): Map<String, WeatherState> {
        val root = runCatching { JSONObject(prefs.getString("weatherCache", "{}")) }.getOrDefault(JSONObject())
        return places.mapNotNull { place ->
            root.optJSONObject(place.cacheKey())?.let(::weatherStateFromJson)?.copy(place = place)?.let { place.cacheKey() to it }
        }.toMap()
    }
    fun saveWeatherCache(cache: Map<String, WeatherState>) {
        val root = JSONObject()
        cache.forEach { (key, state) -> root.put(key, state.toJson()) }
        prefs.edit().putString("weatherCache", root.toString()).apply()
    }

    var savedPlaces: List<Place>
        get() {
            val json = runCatching { JSONArray(prefs.getString("savedPlaces", "[]")) }.getOrDefault(JSONArray())
            return (0 until json.length()).mapNotNull { i ->
                json.optJSONObject(i)?.let { Place(it.optString("id"), it.optString("name"), it.optString("state"), it.optDouble("lat"), it.optDouble("lon"), it.optBoolean("current")) }
            }.ifEmpty { listOf(places.first()) }
        }
        set(value) {
            val json = JSONArray()
            value.forEach { json.put(JSONObject().put("id", it.id).put("name", it.name).put("state", it.state).put("lat", it.latitude).put("lon", it.longitude).put("current", it.current)) }
            prefs.edit().putString("savedPlaces", json.toString()).apply()
        }
}

@Composable
private fun AtmosNativeApp() {
    val context = LocalContext.current
    val preferences = remember { AtmosPreferences(context) }
    var launchVisible by remember { mutableStateOf(true) }
    var onboarded by remember { mutableStateOf(preferences.onboarded) }
    var theme by remember { mutableStateOf(preferences.theme) }
    var darkNightMode by remember { mutableStateOf(preferences.darkNightMode) }
    var density by remember { mutableStateOf(preferences.density) }
    var menuLeft by remember { mutableStateOf(preferences.menuLeft) }
    var temperatureUnit by remember { mutableStateOf(preferences.temperatureUnit) }
    var savedPlaces by remember { mutableStateOf(preferences.savedPlaces) }
    var currentPlace by remember { mutableStateOf(savedPlaces.first()) }
    val diskCache = remember(savedPlaces) { preferences.cachedWeather(savedPlaces) }
    var weather by remember { mutableStateOf(diskCache[currentPlace.cacheKey()] ?: WeatherState(currentPlace, fallbackDays, emptyList(), Observation(), false)) }
    val weatherCache = remember { mutableStateMapOf<String, WeatherState>().apply { putAll(diskCache) } }
    var refreshing by remember { mutableStateOf(false) }
    var loadingMessage by remember { mutableStateOf("Preparing your forecast…") }
    var page by rememberSaveable { mutableStateOf(Page.Home) }
    val scope = rememberCoroutineScope()
    val night = remember(weather.updated) { isNight() }
    val palette = remember(weather.days.firstOrNull()?.icon, night) { conditionPalette(weather.days.firstOrNull()?.icon.orEmpty(), night) }
    val systemDark = isSystemInDarkTheme()
    val dark = when (theme) {
        ThemeChoice.Dark -> true
        ThemeChoice.Light -> darkNightMode && night
        ThemeChoice.System -> systemDark || (darkNightMode && night)
    }

    suspend fun refresh(place: Place = currentPlace) {
        refreshing = true
        currentPlace = place
        val loaded = BomRepository.load(place)
        weather = loaded
        weatherCache[place.cacheKey()] = loaded
        preferences.saveWeatherCache(weatherCache)
        updateWidgets(context, loaded)
        refreshing = false
    }
    val onboardingLocation = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        onboarded = true
        preferences.onboarded = true
        if (grants.values.any { it }) {
            currentLocation(context)?.let { coordinates ->
                val nearest = places.minByOrNull { distanceSquared(it.latitude, it.longitude, coordinates.first, coordinates.second) } ?: places.first()
                val located = nearest.copy(latitude = coordinates.first, longitude = coordinates.second, current = true)
                savedPlaces = listOf(located) + savedPlaces.filterNot { it.current }
                preferences.savedPlaces = savedPlaces
                scope.launch { refresh(located) }
            }
        }
    }

    LaunchedEffect(Unit) {
        val minimumSplash = async { delay(700) }
        loadingMessage = "Loading saved locations…"
        val loaded = coroutineScope {
            savedPlaces.map { place ->
                async {
                    val fresh = withTimeoutOrNull(7_000) { BomRepository.load(place) }
                    place.cacheKey() to (fresh ?: weatherCache[place.cacheKey()] ?: WeatherState(place, fallbackDays, emptyList(), Observation(), false))
                }
            }.map { it.await() }.toMap()
        }
        weatherCache.clear()
        weatherCache.putAll(loaded)
        preferences.saveWeatherCache(weatherCache)
        weather = weatherCache[currentPlace.cacheKey()] ?: weather
        updateWidgets(context, weather)
        loadingMessage = "Forecast ready"
        minimumSplash.await()
        launchVisible = false
    }

    val scheme = if (dark) darkColorScheme(
        primary = palette.accent, secondary = palette.secondary,
        background = Color(0xFF101827), surface = Color(0xFF192234),
        onBackground = Color(0xFFF5F7FF), onSurface = Color(0xFFF5F7FF)
    ) else lightColorScheme(
        primary = palette.accent, secondary = palette.secondary,
        background = Color(0xFFF7F8FD), surface = Color(0xFFFEFBFF),
        onBackground = Color(0xFF18223A), onSurface = Color(0xFF18223A)
    )

    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Crossfade(targetState = launchVisible, animationSpec = tween(650), label = "launch") { launching ->
                when {
                    launching -> FullScreenAtmosArtwork {
                        Column(
                            Modifier.fillMaxSize().padding(bottom = 72.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom
                        ) {
                            CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size(30.dp))
                            Text(loadingMessage, Modifier.padding(top = 14.dp), color = Color.White.copy(.88f), fontSize = 13.sp)
                        }
                    }
                    !onboarded -> Onboarding(
                        onUseLocation = {
                            onboardingLocation.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                        },
                        onChoose = {
                            onboarded = true
                            preferences.onboarded = true
                            page = Page.Settings
                        }
                    )
                    else -> {
                        BackHandler(page != Page.Home) { page = Page.Home }
                        Box(Modifier.fillMaxSize()) {
                            AnimatedContent(page, label = "page") { target ->
                                when (target) {
                                    Page.Home -> HomePage(
                                        currentWeather = weather,
                                        weatherCache = weatherCache,
                                        savedPlaces = savedPlaces,
                                        currentPlace = currentPlace,
                                        refreshing = refreshing,
                                        density = density,
                                        preferences = preferences,
                                        temperatureUnit = temperatureUnit,
                                        onTemperatureUnit = { temperatureUnit = it; preferences.temperatureUnit = it },
                                        onRefresh = { scope.launch { refresh() } },
                                        onSelectPlace = { place ->
                                            currentPlace = place
                                            weatherCache[place.cacheKey()]?.let { weather = it } ?: scope.launch { refresh(place) }
                                        },
                                        onSavedPlacesChanged = { updated -> savedPlaces = updated; preferences.savedPlaces = updated },
                                        onAddLocation = { page = Page.Locations },
                                        onPage = { page = it }
                                    )
                                    Page.Conditions -> ConditionsPage(weather, temperatureUnit) { page = Page.Home }
                                    Page.Seasons -> SeasonsPage(dark) { page = Page.Home }
                                    Page.Settings -> SettingsPage(
                                        theme, darkNightMode, density, menuLeft, preferences,
                                        onTheme = { theme = it; preferences.theme = it },
                                        onDarkNightMode = { darkNightMode = it; preferences.darkNightMode = it },
                                        onDensity = { density = it; preferences.density = it },
                                        onMenuLeft = { menuLeft = it; preferences.menuLeft = it },
                                        onSelectPlace = { scope.launch { refresh(it); page = Page.Home } },
                                        onBack = { page = Page.Home }
                                    )
                                    Page.Locations -> LocationsPage(
                                        preferences, currentPlace,
                                        onSelect = { selected ->
                                            savedPlaces = preferences.savedPlaces
                                            scope.launch { refresh(selected); page = Page.Home }
                                        },
                                        onBack = { savedPlaces = preferences.savedPlaces; page = Page.Home }
                                    )
                                    Page.About -> AboutPage { page = Page.Home }
                                }
                            }
                            QuickMenu(menuLeft, page == Page.Home, onPage = { page = it })
                        }
                    }
                }
            }
        }
    }
}

private data class Palette(val top: Color, val bottom: Color, val accent: Color, val secondary: Color)

private fun conditionPalette(icon: String, night: Boolean): Palette {
    val s = icon.lowercase()
    return when {
        night -> Palette(Color(0xFF263C60), Color(0xFF433657), Color(0xFF9AB7FF), Color(0xFFB58BEA))
        "storm" in s || "thunder" in s -> Palette(Color(0xFF62548D), Color(0xFF343B62), Color(0xFFB69FE9), Color(0xFF7E8DD6))
        "rain" in s || "shower" in s -> Palette(Color(0xFF4E83A7), Color(0xFF46638D), Color(0xFF65C8DB), Color(0xFF71A9D6))
        "cloud" in s || "overcast" in s -> Palette(Color(0xFF899AB9), Color(0xFF687A9F), Color(0xFF8DB5D3), Color(0xFFA5B7D2))
        else -> Palette(Color(0xFFFFC65A), Color(0xFFEE7D62), Color(0xFFF3A74E), Color(0xFF75CDE2))
    }
}

@Composable
private fun FullScreenAtmosArtwork(content: (@Composable () -> Unit)? = null) {
    val context = LocalContext.current
    val bitmap = remember {
        runCatching { BitmapFactory.decodeStream(context.assets.open("public/assets/atmos-sunrise.png")).asImageBitmap() }.getOrNull()
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF182878))) {
        bitmap?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        content?.invoke()
    }
}

@Composable
private fun Onboarding(onUseLocation: () -> Unit, onChoose: () -> Unit) {
    FullScreenAtmosArtwork {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Color(0xE8151E52)), startY = 450f)))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 25.dp)
                .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 24.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Text("WEATHER, WHERE YOU ARE", color = Color.White.copy(.82f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.4.sp)
            Text("Welcome to\nAtmos.", color = Color.White, fontSize = 42.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold)
            Text("Beautiful Australian forecasts, shaped around the conditions outside.", color = Color(0xFFEAF0FF), fontSize = 14.sp)
            Spacer(Modifier.height(22.dp))
            Button(onUseLocation, Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF263F91))) { Text("Use my location", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onChoose, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text("Choose a location manually") }
            Text("Atmos only uses your location to find the nearest forecast.", Modifier.fillMaxWidth().padding(top = 10.dp), color = Color.White.copy(.7f), fontSize = 10.sp, textAlign = TextAlign.Center)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomePage(
    currentWeather: WeatherState,
    weatherCache: Map<String, WeatherState>,
    savedPlaces: List<Place>,
    currentPlace: Place,
    refreshing: Boolean,
    density: DensityChoice,
    preferences: AtmosPreferences,
    temperatureUnit: TemperatureUnit,
    onTemperatureUnit: (TemperatureUnit) -> Unit,
    onRefresh: () -> Unit,
    onSelectPlace: (Place) -> Unit,
    onSavedPlacesChanged: (List<Place>) -> Unit,
    onAddLocation: () -> Unit,
    onPage: (Page) -> Unit
) {
    // Recreate the pager whenever the saved-page structure changes. This avoids a
    // transient out-of-range pager position when the final saved location is removed.
    val pagerStructureKey = savedPlaces.mapIndexed { index, place -> place.pagerKey(index) }
    key(pagerStructureKey) {
        val addLocationPage = savedPlaces.size
        val selectedPage = savedPlaces.indexOfFirst { it.matches(currentPlace) }
            .takeIf { it >= 0 }
            ?: addLocationPage
        val pagerState = rememberPagerState(
            initialPage = selectedPage.coerceIn(0, addLocationPage),
            pageCount = { savedPlaces.size + 1 }
        )

        LaunchedEffect(currentPlace, pagerStructureKey) {
            val target = savedPlaces.indexOfFirst { it.matches(currentPlace) }
                .takeIf { it >= 0 }
                ?: addLocationPage
            if (target != pagerState.currentPage) pagerState.scrollToPage(target)
        }

        LaunchedEffect(pagerState, pagerStructureKey) {
            snapshotFlow { pagerState.settledPage }.collect { selected ->
                savedPlaces.getOrNull(selected)?.let(onSelectPlace)
                // The final page is deliberately the add-location page. It remains
                // visible even when there are no saved locations at all.
            }
        }

        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            pageSpacing = 12.dp,
            beyondViewportPageCount = 0,
            key = { index ->
                savedPlaces.getOrNull(index)?.pagerKey(index) ?: "add-location-page"
            }
        ) { index ->
            val offset = ((pagerState.currentPage - index) + pagerState.currentPageOffsetFraction).absoluteValue
            val pageModifier = if (offset > 0.001f) {
                Modifier.fillMaxSize().graphicsLayer {
                    val progress = offset.coerceIn(0f, 1f)
                    scaleX = 1f - progress * .025f
                    scaleY = 1f - progress * .025f
                    alpha = 1f - progress * .12f
                }
            } else {
                Modifier.fillMaxSize()
            }
            Box(pageModifier) {
                val place = savedPlaces.getOrNull(index)
                if (place == null) {
                    AddLocationPage(index, savedPlaces.size + 1, onAddLocation)
                } else {
                    val pageWeather = weatherCache[place.cacheKey()]
                        ?: if (place.matches(currentWeather.place)) currentWeather
                        else WeatherState(place, fallbackDays, emptyList(), Observation(), false)
                    ForecastPage(
                        weather = pageWeather,
                        refreshing = refreshing && place.matches(currentPlace),
                        density = density,
                        preferences = preferences,
                        temperatureUnit = temperatureUnit,
                        onTemperatureUnit = onTemperatureUnit,
                        onRefresh = onRefresh,
                        onSavedPlacesChanged = onSavedPlacesChanged,
                        forecastPage = index,
                        forecastPageCount = savedPlaces.size + 1,
                        onPage = onPage
                    )
                }
            }
        }
    }
}

private fun Place.matches(other: Place): Boolean =
    current == other.current &&
        name == other.name &&
        latitude == other.latitude &&
        longitude == other.longitude

private fun Place.pagerKey(index: Int): String =
    "location-$index-$name-$latitude-$longitude-${if (current) "current" else "saved"}"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ForecastPage(
    weather: WeatherState,
    refreshing: Boolean,
    density: DensityChoice,
    preferences: AtmosPreferences,
    temperatureUnit: TemperatureUnit,
    onTemperatureUnit: (TemperatureUnit) -> Unit,
    onRefresh: () -> Unit,
    onSavedPlacesChanged: (List<Place>) -> Unit,
    forecastPage: Int,
    forecastPageCount: Int,
    onPage: (Page) -> Unit
) {
    val day = weather.days.first()
    val palette = conditionPalette(day.icon, isNight())
    val padding = if (density == DensityChoice.Compact) 12.dp else 17.dp
    PullToRefreshBox(isRefreshing = refreshing, onRefresh = onRefresh, Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    colors = listOf(
                        palette.top.copy(alpha = .74f),
                        palette.bottom.copy(alpha = .50f),
                        palette.secondary.copy(alpha = .34f),
                        palette.secondary.copy(alpha = .16f),
                        MaterialTheme.colorScheme.background
                    ),
                    endY = 1950f
                )
            ),
            contentPadding = PaddingValues(
                start = padding, end = padding,
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 92.dp
            ),
            verticalArrangement = Arrangement.spacedBy(if (density == DensityChoice.Compact) 11.dp else 15.dp)
        ) {
            item(key = "location-header", contentType = "header") { LocationHeader(weather.place, preferences, temperatureUnit, onTemperatureUnit, onSavedPlacesChanged) }
            item(key = "hero", contentType = "hero") { HeroCard(weather, palette, temperatureUnit, forecastPage, forecastPageCount, onPage) }
            item(key = "glance", contentType = "summary") { AtAGlanceCard(weather, palette, temperatureUnit) }
            item(key = "hourly", contentType = "forecast-row") { HourlyCard(weather.hours, day, weather.place, temperatureUnit, palette) }
            item(key = "seven-day", contentType = "forecast-list") { SevenDayCard(weather.days, temperatureUnit, palette) }
            item(key = "precipitation", contentType = "chart") { PrecipitationCard(weather.hours, palette) }
            if (weather.warnings.isNotEmpty()) item(key = "warning", contentType = "warning") { WarningCard(weather.warnings) }
            item(key = "details", contentType = "details") { DetailCards(weather, preferences) }
            item(key = "footer", contentType = "footer") {
                Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Weather data supplied by the Australian Bureau of Meteorology.", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp)
                    Text("Atmos was built by Josh Stanley", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp)
                    val context = LocalContext.current
                    Text("Contact Josh", Modifier.padding(top = 9.dp).clickable { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:Josh.stanley@me.com"))) }, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun AddLocationPage(page: Int, pageCount: Int, onAddLocation: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primary.copy(.18f), MaterialTheme.colorScheme.background))
        ).padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(38.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(.18f))
        ) {
            Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.15f)) {
                    Text("+", Modifier.padding(horizontal = 22.dp, vertical = 12.dp), fontSize = 38.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(22.dp))
                Text("Add another location", fontSize = 27.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text("Save a town or city, then swipe between forecasts from the home screen.", Modifier.padding(top = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(.68f), textAlign = TextAlign.Center, lineHeight = 20.sp)
                Button(onClick = onAddLocation, modifier = Modifier.padding(top = 24.dp).fillMaxWidth().height(52.dp)) {
                    Text("Choose a location", fontWeight = FontWeight.Bold)
                }
                ForecastPageIndicator(page, pageCount, Modifier.padding(top = 28.dp))
            }
        }
    }
}

@Composable
private fun ForecastPageIndicator(current: Int, count: Int, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(count) { index ->
            val selected = index == current
            Box(
                Modifier
                    .height(7.dp)
                    .width(if (selected) 22.dp else 7.dp)
                    .clip(CircleShape)
                    .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.24f))
            )
        }
    }
}

@Composable
private fun LocationHeader(place: Place, preferences: AtmosPreferences, temperatureUnit: TemperatureUnit, onTemperatureUnit: (TemperatureUnit) -> Unit, onSavedPlacesChanged: (List<Place>) -> Unit) {
    val displayPlace = remember(place) {
        if (place.current) places.minByOrNull { distanceSquared(it.latitude, it.longitude, place.latitude, place.longitude) } ?: place else place
    }
    var saved by remember(place) { mutableStateOf(preferences.savedPlaces.any { it.name == place.name && it.state == place.state }) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(displayPlace.name, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text(displayPlace.state, color = MaterialTheme.colorScheme.onSurface.copy(.68f), fontSize = 13.sp)
        }
        Text(
            if (saved) "★" else "☆", fontSize = 34.sp,
            color = Color(0xFFFFB84F),
            modifier = Modifier.clickable {
                val list = preferences.savedPlaces.toMutableList()
                val index = list.indexOfFirst { it.name == place.name && it.state == place.state }
                when {
                    index >= 0 && list.size > 1 -> {
                        list.removeAt(index)
                        preferences.savedPlaces = list
                        onSavedPlacesChanged(list)
                        saved = false
                    }
                    index < 0 -> {
                        list.add(place)
                        preferences.savedPlaces = list
                        onSavedPlacesChanged(list)
                        saved = true
                    }
                }
            }
        )
        Spacer(Modifier.width(13.dp))
        Surface(
            modifier = Modifier.clickable { onTemperatureUnit(if (temperatureUnit == TemperatureUnit.Celsius) TemperatureUnit.Fahrenheit else TemperatureUnit.Celsius) },
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface.copy(.66f)
        ) {
            Text(if (temperatureUnit == TemperatureUnit.Celsius) "°C" else "°F", Modifier.padding(15.dp), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun HeroCard(weather: WeatherState, palette: Palette, temperatureUnit: TemperatureUnit, forecastPage: Int, forecastPageCount: Int, onPage: (Page) -> Unit) {
    val day = weather.days.first()
    val temp = weather.observation.temp ?: day.high - 2
    val night = isNight()
    val heroGradient = remember(palette) {
        Brush.linearGradient(listOf(palette.top, palette.bottom, palette.secondary))
    }
    Card(
        Modifier.fillMaxWidth().height(535.dp).clickable { onPage(Page.Conditions) },
        shape = RoundedCornerShape(38.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(Modifier.fillMaxSize().background(heroGradient)) {
            ConditionAtmosphere(icon = day.icon, night = night)
            Column(Modifier.fillMaxSize().padding(28.dp)) {
                SeasonPill(onClick = { onPage(Page.Seasons) })
                Spacer(Modifier.height(18.dp))
                Text(SimpleDateFormat("EEEE d MMMM", Locale.ENGLISH).format(Date()), color = Color.White.copy(.78f), fontWeight = FontWeight.Bold)
                Text("${displayTemperature(temp, temperatureUnit)}°", color = Color.White, fontSize = 90.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-5).sp)
                Text(nightCondition(day.condition), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Feels like ${displayTemperature(weather.observation.feels ?: temp - 1, temperatureUnit)}° · H ${displayTemperature(day.high, temperatureUnit)}° · L ${displayTemperature(day.low, temperatureUnit)}°", color = Color.White.copy(.82f), fontSize = 16.sp)
                Text(conditionNarrative(weather), Modifier.padding(top = 22.dp).widthIn(max = 310.dp), color = Color.White.copy(.84f), fontSize = 14.sp, lineHeight = 21.sp)
                Spacer(Modifier.weight(1f))
                ForecastPageIndicator(forecastPage, forecastPageCount, Modifier.align(Alignment.CenterHorizontally).padding(bottom = 13.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(25.dp)).background(Color(0x99101A30)).padding(vertical = 15.dp)) {
                    HeroStat("Rain", "${day.rainChance}%", Modifier.weight(1f))
                    HeroStat("Wind", weather.observation.wind?.let { "${weather.observation.direction} $it km/h" } ?: "—", Modifier.weight(1f))
                    HeroStat("Humidity", weather.observation.humidity?.let { "$it%" } ?: "—", Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable private fun HeroStat(label: String, value: String, modifier: Modifier) =
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color.White.copy(.7f), fontSize = 10.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }

@Composable
private fun SeasonPill(onClick: () -> Unit) {
    val season = seasonName()
    val color = when (season) {
        "Summer" -> Color(0xFFFFE49A)
        "Autumn" -> Color(0xFFFFC5A0)
        "Winter" -> Color(0xFFD9ECFF)
        else -> Color(0xFFDDF3D0)
    }
    Surface(Modifier.clickable(onClick = onClick), shape = CircleShape, color = color, shadowElevation = 8.dp) {
        Text("●  $season", Modifier.padding(horizontal = 15.dp, vertical = 10.dp), color = Color(0xFF31577B), fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ConditionAtmosphere(icon: String, night: Boolean) {
    val drawable = remember(icon, night) {
        when {
            icon.contains("storm", true) || icon.contains("thunder", true) -> R.drawable.ic_weather_storm
            icon.contains("rain", true) || icon.contains("shower", true) -> R.drawable.ic_weather_rain
            icon.contains("cloud", true) -> R.drawable.ic_weather_cloudy
            night -> R.drawable.ic_weather_night
            else -> R.drawable.ic_weather_sunny
        }
    }
    Image(
        painter = painterResource(drawable),
        contentDescription = null,
        modifier = Modifier
            .fillMaxSize()
            .padding(start = 150.dp, top = 26.dp, end = 12.dp, bottom = 245.dp)
            .alpha(.16f),
        contentScale = ContentScale.Fit
    )
}

@Composable
private fun WeatherArtwork(icon: String, night: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier.padding(5.dp)) {
        val w = size.width
        val h = size.height
        val centre = Offset(w * .55f, h * .38f)
        val r = size.minDimension * .22f
        val rainy = icon.contains("rain", true) || icon.contains("shower", true)
        val cloudy = rainy || icon.contains("cloud", true)
        val stormy = icon.contains("storm", true) || icon.contains("thunder", true)

        if (!cloudy) {
            if (night) {
                drawCircle(Color.Black.copy(.18f), r * 1.08f, centre + Offset(1.5.dp.toPx(), 2.dp.toPx()))
                drawCircle(Brush.radialGradient(listOf(Color(0xFFFFFDE7), Color(0xFFD9E2FF), Color(0xFF8FA4D8))), r, centre)
                val moonDisc = Path().apply { addOval(Rect(centre.x - r, centre.y - r, centre.x + r, centre.y + r)) }
                clipPath(moonDisc) {
                    drawCircle(Color(0xFF263A63), r * .88f, centre + Offset(r * .54f, -r * .12f))
                    drawCircle(Color.White.copy(.24f), r * .12f, centre + Offset(-r * .25f, -r * .26f))
                }
            } else {
                drawCircle(Color(0xFFF08A38).copy(.22f), r * 1.28f, centre)
                drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF9C8), Color(0xFFFFD15C), Color(0xFFF29338))), r, centre)
                drawCircle(Color.White.copy(.55f), r * .18f, centre + Offset(-r * .25f, -r * .28f))
            }
        } else {
            val sunCentre = Offset(w * .66f, h * .30f)
            val sunR = r * .82f
            if (!stormy) {
                if (night) {
                    drawCircle(Brush.radialGradient(listOf(Color(0xFFFFFDE7), Color(0xFF9FB2E6))), sunR, sunCentre)
                    drawCircle(Color(0xFF283C65), sunR * .82f, sunCentre + Offset(sunR * .52f, -sunR * .12f))
                } else {
                    drawCircle(Color(0xFFF6A03E).copy(.20f), sunR * 1.25f, sunCentre)
                    drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF8BE), Color(0xFFFFC653), Color(0xFFF08A37))), sunR, sunCentre)
                    drawCircle(Color.White.copy(.46f), sunR * .18f, sunCentre + Offset(-sunR * .24f, -sunR * .25f))
                }
            }

            fun cloudPath(dx: Float = 0f, dy: Float = 0f): Path = Path().apply {
                moveTo(w * .12f + dx, h * .62f + dy)
                cubicTo(w * .13f + dx, h * .49f + dy, w * .28f + dx, h * .48f + dy, w * .34f + dx, h * .43f + dy)
                cubicTo(w * .43f + dx, h * .28f + dy, w * .62f + dx, h * .34f + dy, w * .66f + dx, h * .49f + dy)
                cubicTo(w * .85f + dx, h * .47f + dy, w * .93f + dx, h * .63f + dy, w * .81f + dx, h * .72f + dy)
                lineTo(w * .28f + dx, h * .72f + dy)
                cubicTo(w * .16f + dx, h * .72f + dy, w * .10f + dx, h * .68f + dy, w * .12f + dx, h * .62f + dy)
                close()
            }

            drawPath(cloudPath(0f, 2.2.dp.toPx()), Color.Black.copy(.20f))
            drawPath(
                cloudPath(),
                Brush.verticalGradient(
                    if (stormy) listOf(Color(0xFF7385A4), Color(0xFF35445F), Color(0xFF1D293F))
                    else listOf(Color(0xFFF5F8FF), Color(0xFFB8C6DC), Color(0xFF7185A7))
                )
            )
            drawOval(
                color = Color.White.copy(if (stormy) .10f else .32f),
                topLeft = Offset(w * .28f, h * .42f),
                size = Size(w * .30f, h * .12f)
            )

            if (rainy || stormy) {
                val rainColor = if (stormy) Color(0xFF6FD8FF) else Color(0xFF69DDEA)
                repeat(3) { i ->
                    val x = w * (.32f + i * .18f)
                    drawLine(
                        Brush.verticalGradient(listOf(Color.White.copy(.72f), rainColor)),
                        Offset(x, h * .78f),
                        Offset(x - w * .045f, h * .94f),
                        2.8.dp.toPx(),
                        StrokeCap.Round
                    )
                }
            }
            if (stormy) {
                val bolt = Path().apply {
                    moveTo(w * .59f, h * .67f)
                    lineTo(w * .49f, h * .83f)
                    lineTo(w * .57f, h * .82f)
                    lineTo(w * .49f, h * .98f)
                    lineTo(w * .69f, h * .76f)
                    lineTo(w * .60f, h * .77f)
                    close()
                }
                drawPath(bolt, Brush.verticalGradient(listOf(Color(0xFFFFF3A6), Color(0xFFFFB63E))))
            }
        }
    }
}

@Composable
private fun AtmosCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(.15f))
    ) { Column(Modifier.padding(21.dp), content = content) }
}

@Composable
private fun ThemedForecastCard(
    palette: Palette,
    content: @Composable ColumnScope.() -> Unit
) {
    val outlineBrush = remember(palette) {
        Brush.horizontalGradient(
            listOf(
                palette.top.copy(alpha = .22f),
                palette.secondary.copy(alpha = .46f),
                palette.bottom.copy(alpha = .25f)
            )
        )
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(alpha = .30f))
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, outlineBrush, RoundedCornerShape(29.dp))
                .padding(21.dp),
            content = content
        )
    }
}

@Composable
private fun AtAGlanceCard(weather: WeatherState, palette: Palette, temperatureUnit: TemperatureUnit) {
    var page by rememberSaveable(weather.place.name) { mutableStateOf(0) }
    val maxPage = if (weather.days.size > 1) 1 else 0
    val borderBrush = remember(palette) {
        Brush.horizontalGradient(
            listOf(
                palette.top.copy(alpha = .10f),
                palette.secondary.copy(alpha = .28f),
                palette.bottom.copy(alpha = .10f)
            )
        )
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(.30f))
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .border(
                    width = 1.dp,
                    brush = borderBrush,
                    shape = RoundedCornerShape(29.dp)
                )
                .padding(21.dp)
        ) {
        Row(
            Modifier.pointerInput(maxPage) {
                var drag = 0f
                detectHorizontalDragGestures(
                    onDragStart = { drag = 0f },
                    onHorizontalDrag = { _, amount -> drag += amount },
                    onDragEnd = {
                        if (drag < -45f) page = maxPage
                        if (drag > 45f) page = 0
                    }
                )
            },
            verticalAlignment = Alignment.Top
        ) {
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primary.copy(.15f)) { Text("✦", Modifier.padding(13.dp), fontSize = 20.sp) }
            AnimatedContent(page, modifier = Modifier.padding(start = 14.dp).weight(1f), label = "glance-page") { selected ->
                val day = weather.days.getOrElse(selected) { weather.days.first() }
                Column {
                    Text(if (selected == 0) "Today at a glance" else "Tomorrow at a glance", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    val summary = if (selected == 0) conditionNarrative(weather) else day.condition
                    Text("$summary A high of ${displayTemperature(day.high, temperatureUnit)}° and low of ${displayTemperature(day.low, temperatureUnit)}°.", color = MaterialTheme.colorScheme.onSurface.copy(.76f), fontSize = 13.sp, lineHeight = 19.sp)
                    if (maxPage > 0) Text(if (selected == 0) "Swipe for tomorrow  ›" else "‹  Swipe for today", Modifier.padding(top = 7.dp), color = MaterialTheme.colorScheme.primary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        }
    }
}

@Composable
private fun HourlyCard(hours: List<HourForecast>, day: DayForecast, place: Place, temperatureUnit: TemperatureUnit, palette: Palette) = ThemedForecastCard(palette) {
    Text("Today", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Hourly forecast", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
    val source = remember(hours, day) {
        hours.ifEmpty {
            (0 until 12).map { HourForecast(Date(System.currentTimeMillis() + it * 3_600_000L), day.high - 2 - it / 4, day.icon, day.rainChance, 50, 10, "W") }
        }.take(18)
    }
    val solarTimes = remember(place.latitude, place.longitude) {
        calculateSolarTimes(Date(), place.latitude, place.longitude)
    }
    val timeline = remember(source, solarTimes) {
        buildList {
            source.forEach { add(TodayTimelineItem.Hour(it)) }
            solarTimes?.let {
                add(TodayTimelineItem.Sunrise(it.first))
                add(TodayTimelineItem.Sunset(it.second))
            }
        }.sortedBy { it.time.time }
    }
    val hourFormatter = remember { SimpleDateFormat("h a", Locale.ENGLISH) }
    val eventFormatter = remember { SimpleDateFormat("h:mm a", Locale.ENGLISH) }
    val sunriseGradient = remember { Brush.verticalGradient(listOf(Color(0xFFFFD58A), Color(0xFFF18A5B).copy(.48f), Color(0xFFFFC76A).copy(.16f))) }
    val sunsetGradient = remember { Brush.verticalGradient(listOf(Color(0xFF9B70E8).copy(.72f), Color(0xFFF07B63).copy(.52f), Color(0xFF633E91).copy(.24f))) }
    LazyRow(
        Modifier.fillMaxWidth().padding(top = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(timeline, key = { item ->
            when (item) {
                is TodayTimelineItem.Hour -> "hour-${item.time.time}"
                is TodayTimelineItem.Sunrise -> "sunrise-${item.time.time}"
                is TodayTimelineItem.Sunset -> "sunset-${item.time.time}"
            }
        }) { item ->
            when (item) {
                is TodayTimelineItem.Hour -> {
                    val hour = item.forecast
                    val isNow = source.firstOrNull()?.time?.time == hour.time.time
                    Column(
                        Modifier.width(78.dp).height(164.dp).clip(RoundedCornerShape(22.dp))
                            .background(if (isNow) MaterialTheme.colorScheme.primary.copy(.14f) else Color.Transparent)
                            .padding(horizontal = 7.dp, vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (isNow) "Now" else hourFormatter.format(hour.time).lowercase(), fontWeight = FontWeight.Bold)
                        WeatherArtwork(hour.icon, isNight(hour.time), Modifier.size(50.dp))
                        Text("${displayTemperature(hour.temp, temperatureUnit)}°", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("${hour.rainChance}%", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp)
                    }
                }
                is TodayTimelineItem.Sunrise -> SolarEventCard(
                    title = "Sunrise",
                    time = eventFormatter.format(item.time).lowercase(),
                    caption = "Day begins",
                    symbol = "☀",
                    gradient = sunriseGradient
                )
                is TodayTimelineItem.Sunset -> SolarEventCard(
                    title = "Sunset",
                    time = eventFormatter.format(item.time).lowercase(),
                    caption = "Day ends",
                    symbol = "◒",
                    gradient = sunsetGradient
                )
            }
        }
    }
}

private sealed class TodayTimelineItem(open val time: Date) {
    data class Hour(val forecast: HourForecast) : TodayTimelineItem(forecast.time)
    data class Sunrise(override val time: Date) : TodayTimelineItem(time)
    data class Sunset(override val time: Date) : TodayTimelineItem(time)
}

@Composable
private fun SolarEventCard(title: String, time: String, caption: String, symbol: String, gradient: Brush) {
    Column(
        Modifier.width(78.dp).height(164.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(gradient)
            .border(1.dp, Color.White.copy(.20f), RoundedCornerShape(22.dp))
            .padding(horizontal = 7.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(time, fontSize = 10.sp, color = Color.White.copy(.88f), textAlign = TextAlign.Center)
        Text(symbol, fontSize = 25.sp, color = Color.White)
        Text(caption, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(.92f), textAlign = TextAlign.Center)
    }
}

private fun calculateSolarTimes(date: Date, latitude: Double, longitude: Double): Pair<Date, Date>? {
    val calendar = Calendar.getInstance().apply { time = date }
    val dayOfYear = calendar.get(Calendar.DAY_OF_YEAR)
    val timezoneOffsetHours = calendar.timeZone.getOffset(date.time) / 3_600_000.0

    fun event(sunrise: Boolean): Date? {
        val lngHour = longitude / 15.0
        val approximateTime = dayOfYear + ((if (sunrise) 6.0 else 18.0) - lngHour) / 24.0
        val meanAnomaly = (0.9856 * approximateTime) - 3.289
        var trueLongitude = meanAnomaly + (1.916 * sin(Math.toRadians(meanAnomaly))) +
            (0.020 * sin(Math.toRadians(2 * meanAnomaly))) + 282.634
        trueLongitude = (trueLongitude + 360.0) % 360.0
        var rightAscension = Math.toDegrees(atan(0.91764 * tan(Math.toRadians(trueLongitude))))
        rightAscension = (rightAscension + 360.0) % 360.0
        val longitudeQuadrant = floor(trueLongitude / 90.0) * 90.0
        val rightAscensionQuadrant = floor(rightAscension / 90.0) * 90.0
        rightAscension = (rightAscension + longitudeQuadrant - rightAscensionQuadrant) / 15.0
        val sinDeclination = 0.39782 * sin(Math.toRadians(trueLongitude))
        val cosDeclination = cos(kotlin.math.asin(sinDeclination))
        val cosHourAngle = (cos(Math.toRadians(90.833)) - sinDeclination * sin(Math.toRadians(latitude))) /
            (cosDeclination * cos(Math.toRadians(latitude)))
        if (cosHourAngle !in -1.0..1.0) return null
        var localHour = if (sunrise) 360.0 - Math.toDegrees(acos(cosHourAngle)) else Math.toDegrees(acos(cosHourAngle))
        localHour /= 15.0
        val localMeanTime = localHour + rightAscension - (0.06571 * approximateTime) - 6.622
        val utcHour = (localMeanTime - lngHour + 24.0) % 24.0
        val localHourDecimal = (utcHour + timezoneOffsetHours + 24.0) % 24.0
        val hour = floor(localHourDecimal).toInt()
        val minute = ((localHourDecimal - hour) * 60.0).roundToInt().coerceIn(0, 59)
        return Calendar.getInstance().apply {
            time = date
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.time
    }

    val sunrise = event(true) ?: return null
    val sunset = event(false) ?: return null
    return sunrise to sunset
}

@Composable
private fun SevenDayCard(days: List<DayForecast>, temperatureUnit: TemperatureUnit, palette: Palette) = ThemedForecastCard(palette) {
    Text("7-day forecast", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Tap a day for more detail", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
    days.forEachIndexed { index, day ->
        var expanded by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (index == 0) "Today" else dayName(index), Modifier.width(64.dp), fontWeight = FontWeight.Bold)
                WeatherArtwork(day.icon, false, Modifier.size(43.dp))
                Text("${day.condition}\nRain ${day.rainChance}%", Modifier.weight(1f).padding(start = 9.dp), color = MaterialTheme.colorScheme.onSurface.copy(.73f), fontSize = 11.sp)
                Text("${displayTemperature(day.high, temperatureUnit)}°  ${displayTemperature(day.low, temperatureUnit)}°", fontWeight = FontWeight.Bold)
            }
            AnimatedVisibility(expanded) {
                Surface(Modifier.fillMaxWidth().padding(top = 10.dp), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primary.copy(.08f)) {
                    Text("Low ${displayTemperature(day.low, temperatureUnit)}° · High ${displayTemperature(day.high, temperatureUnit)}°\n${day.rainChance}% chance of rain · Up to ${day.rainAmount} mm possible.", Modifier.padding(15.dp), fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
        }
    }
}

@Composable
private fun PrecipitationCard(hours: List<HourForecast>, palette: Palette) = ThemedForecastCard(palette) {
    Text("Hourly precipitation", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Chance of rain over the hours ahead", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
    val source = remember(hours) {
        hours.take(18).ifEmpty { List(12) { HourForecast(Date(System.currentTimeMillis() + it * 3_600_000L), 18, "", it * 3, 0, 0, "") } }
    }
    val hourFormatter = remember { SimpleDateFormat("h", Locale.ENGLISH) }
    val barBrush = remember { Brush.verticalGradient(listOf(Color(0xFF79DCE5), Color(0xFF478ED1))) }
    LazyRow(
        Modifier.fillMaxWidth().height(132.dp).padding(top = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(source, key = { it.time.time }) { h ->
            Column(Modifier.width(46.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${h.rainChance}%", Modifier.height(18.dp).fillMaxWidth(), fontSize = 9.sp, textAlign = TextAlign.Center)
                Box(Modifier.height(78.dp).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier.width(16.dp)
                            .height((18 + h.rainChance.coerceIn(0, 100) * .58).dp)
                            .clip(CircleShape)
                            .background(barBrush)
                    )
                }
                Text(hourFormatter.format(h.time), Modifier.height(20.dp).fillMaxWidth(), fontSize = 9.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun WarningCard(warnings: List<String>) {
    val context = LocalContext.current
    Card(
        Modifier.fillMaxWidth().clickable { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bom.gov.au/australia/warnings/"))) },
        shape = RoundedCornerShape(25.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE7C2)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE9A850))
    ) {
        Row(Modifier.padding(18.dp)) {
            Text("⚠", fontSize = 25.sp)
            Column(Modifier.padding(start = 13.dp)) {
                Text("Weather warning", color = Color(0xFF704212), fontWeight = FontWeight.Bold)
                Text(warnings.first(), color = Color(0xFF704212), fontSize = 11.sp)
                if (warnings.size > 1) Text("+${warnings.size - 1} more warning${if (warnings.size > 2) "s" else ""}", color = Color(0xFF704212), fontSize = 10.sp)
            }
        }
    }
}

private val detailCardIds = listOf("sun", "wind", "moon", "rain", "uv", "pressure", "humidity", "season", "tide")

@Composable
private fun DetailCards(weather: WeatherState, preferences: AtmosPreferences) {
    val context = LocalContext.current
    var order by remember { mutableStateOf(preferences.cardOrder) }
    var hidden by remember { mutableStateOf(preferences.hiddenCards) }
    Column {
        Text("Weather details", Modifier.padding(start = 4.dp, top = 8.dp), fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Tap a card for more information · hold and drag to rearrange", Modifier.padding(start = 4.dp, bottom = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(.6f), fontSize = 11.sp)
        val visible = order.filterNot { it in hidden }
        visible.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                row.forEach { id ->
                    var expanded by remember { mutableStateOf(false) }
                    var drag by remember { mutableStateOf(0f) }
                    DetailCard(
                        id, weather, expanded, Modifier.weight(1f)
                            .pointerInput(id) {
                                detectDragGesturesAfterLongPress(
                                    onDrag = { change, amount -> change.consume(); drag += amount.y },
                                    onDragEnd = {
                                        val index = order.indexOf(id)
                                        val target = (index + if (drag > 35f) 1 else if (drag < -35f) -1 else 0).coerceIn(order.indices)
                                        if (target != index) {
                                            val list = order.toMutableList()
                                            list.removeAt(index)
                                            list.add(target, id)
                                            order = list
                                            preferences.cardOrder = list
                                        }
                                        drag = 0f
                                    }
                                )
                            }
                    ) {
                        if (expanded && id == "tide") {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bom.gov.au/australia/tides/")))
                        } else {
                            expanded = !expanded
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(11.dp))
        }
    }
}

private data class DetailValue(val title: String, val value: String, val detail: String, val color: Color)

@Composable
private fun DetailCard(id: String, weather: WeatherState, expanded: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val day = weather.days.first()
    val detailValue = remember(id, weather.observation, day) {
        when (id) {
            "sun" -> DetailValue("Sun & daylight", "5:38 pm", "Sunrise 7:11 am", Color(0xFFE8A527))
            "wind" -> DetailValue("Wind", weather.observation.wind?.let { "$it km/h" } ?: "Not available", "${weather.observation.direction} · gusts ${weather.observation.gust ?: "—"} km/h", Color(0xFF4C8DDC))
            "moon" -> DetailValue("Moon", moonName(), "${moonIllumination()}% illuminated", Color(0xFF7B68D5))
            "rain" -> DetailValue("Rain", "${day.rainChance}%", "Up to ${day.rainAmount} mm expected", Color(0xFF2BAEC4))
            "uv" -> DetailValue("UV index", "3", "Moderate · protection advised", Color(0xFFE9785C))
            "pressure" -> DetailValue("Pressure", weather.observation.pressure?.let { "${it.roundToInt()} hPa" } ?: "Not available", "Mean sea-level pressure", Color(0xFF656BD8))
            "humidity" -> DetailValue("Humidity", weather.observation.humidity?.let { "$it%" } ?: "Not available", "Current observation", Color(0xFF32A68B))
            "season" -> DetailValue("Season", seasonName(), daysToNextSeason(), Color(0xFFC67B48))
            else -> DetailValue("Tides", "BOM tides", "Official coastal predictions", Color(0xFF367FC5))
        }
    }
    val (title, value, detail, color) = detailValue
    Card(
        modifier.height(if (expanded) 270.dp else 180.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(.42f))
    ) {
        Box(Modifier.fillMaxSize().padding(16.dp)) {
            Surface(
                modifier = Modifier.align(Alignment.TopCenter).size(50.dp),
                shape = CircleShape,
                color = color.copy(.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(atmosGlyph(id), fontSize = 27.sp, color = color, textAlign = TextAlign.Center)
                }
            }
            Text(
                if (expanded) "⌄" else "›",
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 2.dp, end = 2.dp),
                color = MaterialTheme.colorScheme.onSurface.copy(.52f),
                fontSize = 23.sp
            )
            Column(
                modifier = Modifier.align(Alignment.Center).fillMaxWidth().padding(top = 35.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(title, color = MaterialTheme.colorScheme.onSurface.copy(.64f), fontSize = 11.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(5.dp))
                Text(value, fontSize = 22.sp, lineHeight = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(5.dp))
                Text(detail, color = MaterialTheme.colorScheme.onSurface.copy(.66f), fontSize = 10.sp, lineHeight = 14.sp, textAlign = TextAlign.Center)
                AnimatedVisibility(expanded) {
                    Text(
                        detailDescription(id),
                        Modifier.padding(top = 16.dp),
                        color = MaterialTheme.colorScheme.onSurface.copy(.75f),
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun ConditionsPage(weather: WeatherState, temperatureUnit: TemperatureUnit, onBack: () -> Unit) {
    val day = weather.days.first()
    val palette = conditionPalette(day.icon, isNight())
    LazyColumn(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(palette.top.copy(.7f), MaterialTheme.colorScheme.background), endY = 1200f)),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 25.dp
        )
    ) {
        item { PageHeader("Current conditions", onBack) }
        item {
            Box(Modifier.fillMaxWidth().height(480.dp)) {
                ConditionAtmosphere(day.icon, isNight())
                Column(Modifier.padding(top = 70.dp)) {
                    Text("${displayTemperature(weather.observation.temp ?: day.high - 2, temperatureUnit)}°", fontSize = 88.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-5).sp)
                    Text(nightCondition(day.condition), fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("Feels like ${displayTemperature(weather.observation.feels ?: day.high - 3, temperatureUnit)}° · H ${displayTemperature(day.high, temperatureUnit)}° · L ${displayTemperature(day.low, temperatureUnit)}°", color = MaterialTheme.colorScheme.onSurface.copy(.65f))
                    Surface(Modifier.fillMaxWidth().padding(top = 34.dp), shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface.copy(.22f), border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(.26f))) {
                        Text(conditionNarrative(weather), Modifier.padding(17.dp), fontSize = 14.sp, lineHeight = 22.sp)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text(if (weather.live) "LIVE BOM DATA" else "ESTIMATED DATA", Modifier.clip(CircleShape).background(palette.secondary.copy(.2f)).padding(horizontal = 11.dp, vertical = 7.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Text("Updated ${SimpleDateFormat("h:mm a", Locale.ENGLISH).format(weather.updated).lowercase()}", Modifier.padding(8.dp), fontSize = 9.sp)
            }
        }
        item { Text("${weather.place.name}, ${weather.place.state}", Modifier.padding(top = 22.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item { Text("Current observations and today’s forecast", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 11.sp) }
        val observations = listOf(
            Triple("Humidity", weather.observation.humidity?.let { "$it%" } ?: "Not available", "Current observation"),
            Triple("Wind", weather.observation.wind?.let { "${weather.observation.direction} $it km/h" } ?: "Not available", "Gusts ${weather.observation.gust ?: "—"} km/h"),
            Triple("Pressure", weather.observation.pressure?.let { "${it.roundToInt()} hPa" } ?: "Not available", "Mean sea-level pressure"),
            Triple("Rain chance", "${day.rainChance}%", "${day.rainAmount} mm possible"),
            Triple("UV index", "3", "Moderate"),
            Triple("Visibility", "Not available", "Nearest observation"),
            Triple("Rain since 9am", weather.observation.rainSince9?.let { "$it mm" } ?: "Not available", weather.observation.station),
            Triple("Moon phase", moonName(), "${moonIllumination()}% illuminated")
        )
        items(observations.chunked(2)) { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { item ->
                    Column(Modifier.weight(1f).padding(vertical = 20.dp).border(width = 0.dp, color = Color.Transparent).drawBehind { drawLine(palette.secondary.copy(.35f), Offset.Zero, Offset(size.width, 0f), 1.dp.toPx()) }) {
                        Text(item.first, color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 10.sp)
                        Text(item.second, Modifier.padding(vertical = 7.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text(item.third, color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SeasonsPage(dark: Boolean, onBack: () -> Unit) {
    val seasons = listOf(
        Season("Autumn", "Warmth softens.", "Long summer light gives way to cooler evenings and changing colour.", "1 March – 31 May", "Typical range 12–25°C", Color(0xFFE5A17D), Color(0xFFF6C8A5), Color(0xFF543638)),
        Season("Winter", "Cool, quiet light.", "Shorter days, crisp mornings and the year’s longest nights.", "1 June – 31 August", "Typical range 6–18°C", Color(0xFF9DBBDD), Color(0xFFCFE9F7), Color(0xFF173A68)),
        Season("Spring", "Colour returns.", "Days lengthen, landscapes brighten and warmth begins to build.", "1 September – 30 November", "Typical range 11–24°C", Color(0xFFA9D69E), Color(0xFFD8EDB8), Color(0xFF24563B)),
        Season("Summer", "Light lingers.", "Long, bright days bring warmth, clear evenings and vivid skies.", "1 December – 28 February", "Typical range 18–32°C", Color(0xFFF0A36F), Color(0xFFF9D98F), Color(0xFF6A3B24))
    )
    val currentSeason = seasonName()
    LazyColumn(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                if (dark) listOf(Color(0xFF13283A), Color(0xFF463659), Color(0xFF29493F))
                else listOf(Color(0xFFD9EFFF), Color(0xFFE8B9A7), Color(0xFF9ACBB1), Color(0xFFF3C97D))
            )
        ),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 25.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHeader("Seasons", onBack) }
        item {
            Column(Modifier.padding(top = 34.dp, bottom = 20.dp)) {
                Text("THE SOUTHERN HEMISPHERE", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("A year in colour.", fontSize = 43.sp, fontWeight = FontWeight.Bold)
                Text("Follow the gentle transition through Australia’s four meteorological seasons.", fontSize = 13.sp, lineHeight = 19.sp)
            }
        }
        items(seasons) { season ->
            Card(
                Modifier.fillMaxWidth().height(245.dp),
                shape = RoundedCornerShape(34.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.72f))
            ) {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(season.one, season.two))).padding(24.dp)) {
                    Column(Modifier.fillMaxHeight()) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = CircleShape, color = Color.White.copy(.42f)) {
                                Text(season.name, Modifier.padding(horizontal = 13.dp, vertical = 8.dp), color = season.textColor, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.weight(1f))
                            if (season.name == currentSeason) {
                                Surface(shape = CircleShape, color = Color.White.copy(.68f)) {
                                    Text("Current season", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = season.textColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(Modifier.height(23.dp))
                        Text(season.headline, color = season.textColor, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text(season.description, Modifier.widthIn(max = 285.dp).padding(top = 6.dp), color = season.textColor.copy(.78f), fontSize = 12.sp, lineHeight = 18.sp)
                        Spacer(Modifier.weight(1f))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(shape = CircleShape, color = Color.White.copy(.35f)) {
                                Text(season.dates, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = season.textColor, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                            Surface(shape = CircleShape, color = Color.White.copy(.48f)) {
                                Text(season.temperatureRange, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = season.textColor, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Atmos uses meteorological seasons for Australia and the Southern Hemisphere.",
                Modifier.padding(15.dp), fontSize = 11.sp, lineHeight = 17.sp, textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun SeasonAtmosSun(season: Season, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val centre = Offset(size.width / 2f, size.height / 2f)
        drawCircle(season.one.copy(.20f), radius = size.minDimension * .49f, center = centre)
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(.97f), season.two.copy(.95f), season.one),
                center = centre,
                radius = size.minDimension * .36f
            ),
            radius = size.minDimension * .36f,
            center = centre
        )
        drawCircle(Color.White.copy(.20f), radius = size.minDimension * .29f, center = centre, style = Stroke(width = 1.3.dp.toPx()))
    }
}

private data class Season(
    val name: String,
    val headline: String,
    val description: String,
    val dates: String,
    val temperatureRange: String,
    val one: Color,
    val two: Color,
    val textColor: Color = Color(0xFF4D3135)
)

private fun displayTemperature(celsius: Int, unit: TemperatureUnit): Int =
    if (unit == TemperatureUnit.Celsius) celsius else (celsius * 9f / 5f + 32f).roundToInt()


@Composable
private fun SettingsPage(
    theme: ThemeChoice,
    darkNightMode: Boolean,
    density: DensityChoice,
    menuLeft: Boolean,
    preferences: AtmosPreferences,
    onTheme: (ThemeChoice) -> Unit,
    onDarkNightMode: (Boolean) -> Unit,
    onDensity: (DensityChoice) -> Unit,
    onMenuLeft: (Boolean) -> Unit,
    onSelectPlace: (Place) -> Unit,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var hidden by remember { mutableStateOf(preferences.hiddenCards) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 30.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHeader("Settings", onBack) }
        item { Text("Make Atmos yours", Modifier.padding(top = 25.dp), fontSize = 34.sp, fontWeight = FontWeight.Bold) }
        item { Text("Location, saved places and appearance.", color = MaterialTheme.colorScheme.onSurface.copy(.62f)) }
        item {
            SettingsSection("Location", "Search Australian cities and regional locations.") {
                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search locations") }, singleLine = true)
                places.filter { query.length > 1 && "${it.name} ${it.state}".contains(query, true) }.take(8).forEach { place ->
                    Row(Modifier.fillMaxWidth().clickable { onSelectPlace(place) }.padding(vertical = 12.dp)) {
                        Column(Modifier.weight(1f)) { Text(place.name, fontWeight = FontWeight.Bold); Text(place.state, fontSize = 10.sp) }
                        Text("Select", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            SettingsSection("Appearance", "Choose how Atmos follows your device theme.") {
                ThemeChoice.entries.forEach { option -> ChoiceRow(option.name.replaceFirstChar { it.uppercase() }, option == theme) { onTheme(option) } }
                Row(
                    Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f).padding(end = 14.dp)) {
                        Text("Dark night mode", fontWeight = FontWeight.Bold)
                        Text(
                            "Automatically use Atmos's dark night palette after sunset. Turn this off to keep Light mode bright at night.",
                            color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                    Switch(checked = darkNightMode, onCheckedChange = onDarkNightMode)
                }
            }
        }
        item {
            SettingsSection("Layout", "Choose how much forecast information fits on screen.") {
                DensityChoice.entries.forEach { option -> ChoiceRow(option.name, option == density) { onDensity(option) } }
            }
        }
        item {
            SettingsSection("Floating menu", "Choose which side is most comfortable to reach.") {
                ChoiceRow("Left side", menuLeft) { onMenuLeft(true) }
                ChoiceRow("Right side", !menuLeft) { onMenuLeft(false) }
            }
        }
        item {
            SettingsSection("Weather detail cards", "Choose which cards appear. Hold and drag cards on the forecast to rearrange them.") {
                detailCardIds.forEach { id ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(detailTitle(id), fontWeight = FontWeight.Bold); Text("Show on the main forecast", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f)) }
                        Switch(id !in hidden, onCheckedChange = { show ->
                            hidden = if (show) hidden - id else hidden + id
                            preferences.hiddenCards = hidden
                        })
                    }
                }
                FilledTonalButton(onClick = { preferences.cardOrder = detailCardIds }, Modifier.fillMaxWidth()) { Text("Restore default order") }
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(.92f))) {
        Column(Modifier.padding(20.dp)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, Modifier.padding(top = 3.dp, bottom = 14.dp), color = MaterialTheme.colorScheme.onSurface.copy(.6f), fontSize = 11.sp)
            content()
        }
    }
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(17.dp),
        color = if (selected) MaterialTheme.colorScheme.primary.copy(.15f) else Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary.copy(.45f) else MaterialTheme.colorScheme.onSurface.copy(.1f))
    ) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f), fontWeight = FontWeight.Bold); Text(if (selected) "●" else "○", color = MaterialTheme.colorScheme.primary) } }
}

@Composable
private fun LocationsPage(preferences: AtmosPreferences, current: Place, onSelect: (Place) -> Unit, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(preferences.savedPlaces) }
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) {
            currentLocation(context)?.let { location ->
                val nearest = places.minByOrNull { distanceSquared(it.latitude, it.longitude, location.first, location.second) } ?: places.first()
                val place = nearest.copy(latitude = location.first, longitude = location.second, current = true)
                saved = listOf(place) + saved.filterNot { it.current }
                preferences.savedPlaces = saved
                onSelect(place)
            }
        }
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 30.dp
        )
    ) {
        item { PageHeader("Saved locations", onBack) }
        item { Text("Your weather, everywhere.", Modifier.padding(top = 30.dp), fontSize = 34.sp, fontWeight = FontWeight.Bold) }
        item { OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(vertical = 18.dp), placeholder = { Text("Search and add a location") }, singleLine = true) }
        item {
            Button(
                onClick = {
                    launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                },
                Modifier.fillMaxWidth()
            ) { Text("Use and save my current location") }
        }
        if (query.length > 1) {
            items(places.filter { "${it.name} ${it.state}".contains(query, true) }.take(12)) { place ->
                Row(Modifier.fillMaxWidth().clickable {
                    if (saved.none { it.name == place.name && it.state == place.state }) {
                        saved = saved + place
                        preferences.savedPlaces = saved
                    }
                }.padding(vertical = 14.dp)) {
                    Column(Modifier.weight(1f)) { Text(place.name, fontWeight = FontWeight.Bold); Text(place.state, fontSize = 10.sp) }
                    Text(if (saved.any { it.name == place.name && it.state == place.state }) "Added" else "Add", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
        }
        items(saved) { place ->
            Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable { onSelect(place) }) {
                    Text(place.name, fontWeight = FontWeight.Bold)
                    Text("${place.state}${if (place.name == current.name) " · Selected" else ""}", fontSize = 10.sp)
                }
                Text("×", Modifier.clickable {
                    if (saved.size > 1) {
                        saved = saved - place
                        preferences.savedPlaces = saved
                    }
                }.padding(12.dp), fontSize = 22.sp)
            }
        }
    }
}

@Composable
private fun AboutPage(onBack: () -> Unit) {
    val context = LocalContext.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 22.dp, end = 22.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 30.dp
        ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item { Box(Modifier.fillMaxWidth()) { PageHeader("About Atmos", onBack) } }
        item { Spacer(Modifier.height(35.dp)); Box(Modifier.size(150.dp).clip(RoundedCornerShape(44.dp))) { FullScreenAtmosArtwork() } }
        item { Text("Atmos", Modifier.padding(top = 22.dp), fontSize = 43.sp, fontWeight = FontWeight.Bold) }
        item { Text("Australian weather, thoughtfully presented.", color = MaterialTheme.colorScheme.onSurface.copy(.65f)) }
        item { Text("Built by Josh Stanley", Modifier.padding(top = 22.dp), fontWeight = FontWeight.Bold) }
        item { Button(onClick = { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:Josh.stanley@me.com"))) }, Modifier.padding(vertical = 20.dp)) { Text("Contact Josh") } }
        item { Text("Weather data", Modifier.fillMaxWidth().padding(top = 14.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item { Text("Forecasts, observations and warnings are supplied by the Australian Bureau of Meteorology. Atmos is independent and is not affiliated with or endorsed by the Bureau.", Modifier.padding(vertical = 10.dp), fontSize = 12.sp, lineHeight = 19.sp) }
        item { Text("Atmos 0.10.14 · Native Android preview", Modifier.padding(top = 30.dp), color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Surface(Modifier.size(46.dp).clickable(onClick = onBack), shape = CircleShape, color = MaterialTheme.colorScheme.surface.copy(.55f)) { Box(contentAlignment = Alignment.Center) { Text("‹", fontSize = 36.sp) } }
        Text(title, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.width(46.dp))
    }
}

@Composable
private fun QuickMenu(left: Boolean, visible: Boolean, onPage: (Page) -> Unit) {
    var open by remember { mutableStateOf(false) }
    if (!visible) return
    Box(
        Modifier.fillMaxSize().padding(
            start = if (left) 18.dp else 0.dp,
            end = if (left) 0.dp else 18.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 19.dp
        ),
        contentAlignment = if (left) Alignment.BottomStart else Alignment.BottomEnd
    ) {
        Column(horizontalAlignment = if (left) Alignment.Start else Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AnimatedVisibility(open, enter = fadeIn() + scaleIn(), exit = fadeOut() + scaleOut()) {
                Column(horizontalAlignment = if (left) Alignment.Start else Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        Triple("Current conditions", Page.Conditions, Color(0xFFE97978)),
                        Triple("Seasons", Page.Seasons, Color(0xFF91CF8C)),
                        Triple("Saved locations", Page.Locations, Color(0xFF64D1D0)),
                        Triple("About Atmos", Page.About, Color(0xFFB58BEA)),
                        Triple("Settings", Page.Settings, Color(0xFF75BCE9))
                    ).forEach { item ->
                        Surface(
                            Modifier.clickable { open = false; onPage(item.second) },
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surface.copy(.95f),
                            shadowElevation = 10.dp
                        ) {
                            Row(Modifier.padding(start = 14.dp, end = 8.dp, top = 7.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(item.first, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(9.dp))
                                Box(Modifier.size(32.dp).clip(CircleShape).background(item.third), contentAlignment = Alignment.Center) { Text(atmosGlyph(item.second.name.lowercase()), color = Color.White) }
                            }
                        }
                    }
                }
            }
            val rotation by animateFloatAsState(if (open) 45f else 0f, label = "menu")
            Surface(
                Modifier.size(60.dp).shadow(16.dp, CircleShape).clickable { open = !open },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(25.dp).graphicsLayer(rotationZ = rotation)) {
                        val stroke = 3.2.dp.toPx()
                        drawLine(Color.White, Offset(size.width / 2f, 0f), Offset(size.width / 2f, size.height), stroke, StrokeCap.Round)
                        drawLine(Color.White, Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), stroke, StrokeCap.Round)
                    }
                }
            }
        }
    }
}

private fun conditionNarrative(weather: WeatherState): String {
    val day = weather.days.first()
    val place = if (weather.place.current) weather.place.state else weather.place.name
    val condition = nightCondition(day.condition).replaceFirstChar { it.lowercase() }
    val rain = when {
        day.rainChance < 20 -> "Little rain is expected."
        day.rainChance < 50 -> "There is a ${day.rainChance}% chance of rain."
        else -> "Rain is likely, with a ${day.rainChance}% chance."
    }
    val wind = weather.observation.wind?.let { if (it < 15) "Winds remain light." else if (it < 30) "A moderate breeze is present." else "Strong winds are being observed." } ?: ""
    return "${if (isNight()) "A $condition evening" else day.condition} across $place. $rain $wind".trim()
}

private fun nightCondition(condition: String): String =
    if (!isNight()) condition else when {
        condition.contains("sunny", true) || condition.contains("clear", true) -> "Clear night"
        condition.contains("cloud", true) -> "Cloudy night"
        condition.contains("shower", true) -> "Evening showers"
        else -> condition
    }

private fun isNight(date: Date = Date()): Boolean {
    val hour = Calendar.getInstance().apply { time = date }.get(Calendar.HOUR_OF_DAY)
    return hour < 6 || hour >= 18
}

private fun seasonName(): String = when (Calendar.getInstance().get(Calendar.MONTH) + 1) {
    12, 1, 2 -> "Summer"
    3, 4, 5 -> "Autumn"
    6, 7, 8 -> "Winter"
    else -> "Spring"
}

private fun daysToNextSeason(): String {
    val calendar = Calendar.getInstance()
    val month = calendar.get(Calendar.MONTH) + 1
    val (nextMonth, nextName) = when (month) {
        12, 1, 2 -> 3 to "Autumn"
        3, 4, 5 -> 6 to "Winter"
        6, 7, 8 -> 9 to "Spring"
        else -> 12 to "Summer"
    }
    val next = Calendar.getInstance().apply {
        set(Calendar.MONTH, nextMonth - 1); set(Calendar.DAY_OF_MONTH, 1)
        if (time.before(calendar.time)) add(Calendar.YEAR, 1)
    }
    return "${((next.timeInMillis - calendar.timeInMillis) / 86_400_000L).coerceAtLeast(0)} days until $nextName"
}

private fun moonPhase(): Double {
    val known = 947182440000L
    val cycle = 2_551_443_000L
    return (((System.currentTimeMillis() - known) % cycle + cycle) % cycle).toDouble() / cycle
}

private fun moonIllumination(): Int = ((1 - cos(moonPhase() * 2 * PI)) / 2 * 100).roundToInt()
private fun moonName(): String = when (moonPhase()) {
    in 0.0..0.03, in 0.97..1.0 -> "New moon"
    in 0.03..0.22 -> "Waxing crescent"
    in 0.22..0.28 -> "First quarter"
    in 0.28..0.47 -> "Waxing gibbous"
    in 0.47..0.53 -> "Full moon"
    in 0.53..0.72 -> "Waning gibbous"
    in 0.72..0.78 -> "Last quarter"
    else -> "Waning crescent"
}

private fun dayName(offset: Int): String =
    SimpleDateFormat("EEE", Locale.ENGLISH).format(Date(System.currentTimeMillis() + offset * 86_400_000L))

private fun atmosGlyph(id: String): String = when (id) {
    "sun" -> "☀"; "wind" -> "≋"; "moon" -> "☾"; "rain" -> "◉"; "uv" -> "✹"
    "pressure" -> "◴"; "humidity" -> "♢"; "season", "seasons" -> "❋"; "tide" -> "≈"
    "conditions" -> "◉"; "locations" -> "⌖"; "about" -> "☼"; "settings" -> "⚙"
    else -> "✦"
}

private fun detailTitle(id: String): String = when (id) {
    "sun" -> "Sun & daylight"; "wind" -> "Wind"; "moon" -> "Moon"; "rain" -> "Rain"
    "uv" -> "UV index"; "pressure" -> "Pressure"; "humidity" -> "Humidity"
    "season" -> "Season"; else -> "Tides"
}

private fun detailDescription(id: String): String = when (id) {
    "sun" -> "Sunrise, sunset and remaining daylight are calculated for the selected location."
    "wind" -> "Current direction, speed and observed gusts from the nearest available station."
    "moon" -> "The current lunar phase and illumination are calculated locally."
    "rain" -> "Forecast precipitation chance and possible accumulation for today."
    "uv" -> "Protection is recommended when the UV index reaches 3 or higher."
    "pressure" -> "Pressure trends can help indicate changing weather."
    "humidity" -> "Relative humidity describes how much moisture is currently in the air."
    "season" -> "Atmos uses Southern Hemisphere meteorological seasons."
    else -> "Official tide predictions are available from the Bureau of Meteorology."
}

private fun currentLocation(context: Context): Pair<Double, Double>? {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    val candidates = manager.getProviders(true)
        .mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }
    val recentCutoff = System.currentTimeMillis() - 15 * 60 * 1000L
    val best = candidates.filter { it.time >= recentCutoff }
        .minByOrNull { it.accuracy }
        ?: candidates.maxByOrNull { it.time }
    return best?.let { it.latitude to it.longitude }
}

private fun distanceSquared(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
    val x = (aLon - bLon) * cos(aLat * PI / 180)
    val y = aLat - bLat
    return x * x + y * y
}

private fun geohash(latitude: Double, longitude: Double, precision: Int = 6): String {
    val alphabet = "0123456789bcdefghjkmnpqrstuvwxyz"
    var latMin = -90.0
    var latMax = 90.0
    var lonMin = -180.0
    var lonMax = 180.0
    var even = true
    var bit = 0
    var value = 0
    val result = StringBuilder()
    while (result.length < precision) {
        if (even) {
            val mid = (lonMin + lonMax) / 2
            if (longitude >= mid) { value = value or (1 shl (4 - bit)); lonMin = mid } else lonMax = mid
        } else {
            val mid = (latMin + latMax) / 2
            if (latitude >= mid) { value = value or (1 shl (4 - bit)); latMin = mid } else latMax = mid
        }
        even = !even
        if (bit < 4) bit++ else {
            result.append(alphabet[value])
            bit = 0
            value = 0
        }
    }
    return result.toString()
}

private fun updateWidgets(context: Context, weather: WeatherState) {
    val day = weather.days.first()
    val prefs = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE)
    prefs.edit()
        .putString("location", weather.place.name)
        .putString("location_id", geohash(weather.place.latitude, weather.place.longitude))
        .putString("temp", (weather.observation.temp ?: day.high - 2).toString())
        .putString("condition", nightCondition(day.condition))
        .putString("high", day.high.toString())
        .putString("low", day.low.toString())
        .putString("rain", day.rainChance.toString())
        .putString("icon", if (isNight()) "night" else day.icon)
        .apply()
    AtmosWidgetProvider.updateAll(context)
    AtmosWideWidgetProvider.updateAll(context)
    AtmosGlanceWidgetProvider.updateAll(context)
    AtmosWidgetUpdater.schedule(context)
}
