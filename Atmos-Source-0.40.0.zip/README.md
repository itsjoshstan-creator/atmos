# Atmos 0.40.0

Atmos 0.40.0 replaces the active legacy Compose atmosphere layers with one native Kotlin/Compose simulation engine.

## One authoritative renderer

`AtmosSceneRenderer` is now used by every active Atmos surface:

- Fullscreen Hero
- Immersive preloaded location scenes
- Current Conditions Hero
- Saved Locations cards
- Atmos System live demo

The existing navigation, weather repositories, BOM/Open-Meteo fallback, preferences, onboarding, widgets, location swiping, theme handling and forecast layouts remain in place.

## Native simulation

The renderer maintains a mutable population of particles that are spawned, updated and removed continuously. It supports up to 420 particles in Immersive intensity and includes:

- Rain, snow, mist and fog particles
- Seasonal motes, blossom, leaves and crystals
- Per-particle position, velocity, age, lifetime, size, depth, opacity, rotation and spin
- Wind-direction advection and wind-speed movement
- Gust and low-pressure turbulence
- Humidity-driven haze
- Condition-derived clouds and precipitation
- Temperature colour grading, heat shimmer and cold frost
- Solar-aware lighting
- Non-periodic storm lightning
- Full-scene crossfading already used by Immersive

The renderer uses a seeded random stream per location and condition so scenes are stable across recomposition while each particle still has an independent procedural lifecycle.

## Version

- Version name: 0.40.0
- Version code: 140
- GitHub Actions artifact: `Atmos-0.40.0-debug`

## Build validation

The source structure, workflow paths, version metadata and Kotlin delimiter balance were checked. A local Gradle compile could not run because this environment cannot download Gradle 8.14.3. GitHub Actions is therefore the final Android compiler validation.
