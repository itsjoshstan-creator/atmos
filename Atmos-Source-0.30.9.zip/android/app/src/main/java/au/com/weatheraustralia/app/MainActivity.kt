package au.com.weatheraustralia.app

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.absoluteValue
import kotlin.math.acos
import kotlin.math.atan
import kotlin.math.floor
import kotlin.math.tan
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestHighestRefreshRate()
        setContent { AtmosNativeApp() }
    }

    override fun onResume() {
        super.onResume()
        requestHighestRefreshRate()
    }

    private fun requestHighestRefreshRate() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val display = display ?: return
        val fastestMode = display.supportedModes.maxWithOrNull(
            compareBy<android.view.Display.Mode> { it.refreshRate }
                .thenBy { it.physicalWidth * it.physicalHeight }
        ) ?: return
        window.attributes = window.attributes.apply {
            preferredDisplayModeId = fastestMode.modeId
        }
    }
}

private enum class Page { Home, Radar, Seasons, Settings, Atmos, Locations, About }
private enum class ThemeChoice { System, Light, Dark }
private enum class HomeLayout { Card, Immersive }
private enum class LocationTransition { Standard, Immersive }
private enum class DensityChoice { Compact, Expanded }
private enum class TemperatureUnit { Celsius, Fahrenheit }
private enum class AtmosphereIntensity { Off, Subtle, Balanced, Immersive }
private const val WEATHER_REFRESH_INTERVAL_MS = 10 * 60 * 1000L

private data class Place(
    val id: String,
    val name: String,
    val state: String,
    val latitude: Double,
    val longitude: Double,
    val current: Boolean = false,
    val country: String = "Australia",
    val countryCode: String = "AU",
    val timeZoneId: String = ""
)

private data class DayForecast(
    val date: String,
    val condition: String,
    val icon: String,
    val high: Int,
    val low: Int,
    val rainChance: Int,
    val rainAmount: Double
)

private data class HourForecast(
    val time: Date,
    val temp: Int,
    val icon: String,
    val rainChance: Int,
    val humidity: Int,
    val wind: Int,
    val direction: String
)

private data class Observation(
    val temp: Int? = null,
    val feels: Int? = null,
    val humidity: Int? = null,
    val wind: Int? = null,
    val direction: String = "",
    val gust: Int? = null,
    val pressure: Double? = null,
    val rainSince9: Double? = null,
    val station: String = "Nearest observation"
)


private fun windDirectionDegrees(direction: String): Float {
    val normalised = direction.trim().uppercase()
    val points = mapOf(
        "N" to 0f, "NNE" to 22.5f, "NE" to 45f, "ENE" to 67.5f,
        "E" to 90f, "ESE" to 112.5f, "SE" to 135f, "SSE" to 157.5f,
        "S" to 180f, "SSW" to 202.5f, "SW" to 225f, "WSW" to 247.5f,
        "W" to 270f, "WNW" to 292.5f, "NW" to 315f, "NNW" to 337.5f
    )
    return points[normalised] ?: normalised.removeSuffix("°").toFloatOrNull()?.let { ((it % 360f) + 360f) % 360f } ?: 0f
}

private fun smoothStep(value: Float): Float {
    val x = value.coerceIn(0f, 1f)
    return x * x * (3f - 2f * x)
}

private data class HistoricalObservation(
    val time: Date,
    val temp: Int,
    val rainSince9: Double? = null
)

private data class WeatherState(
    val place: Place,
    val days: List<DayForecast>,
    val hours: List<HourForecast>,
    val observation: Observation,
    val live: Boolean,
    val warnings: List<String> = emptyList(),
    val updated: Date = Date()
)

private val places = listOf(
    Place("", "Forrestdale", "Western Australia", -32.155, 115.934),
    Place("qd66hr", "Fremantle", "Western Australia", -32.0569, 115.7439),
    Place("qd66hr", "Perth", "Western Australia", -31.9523, 115.8613),
    Place("qd65fp", "Mandurah", "Western Australia", -32.5269, 115.7217),
    Place("qd47rc", "Bunbury", "Western Australia", -33.3267, 115.6369),
    Place("qd6k4f", "Joondalup", "Western Australia", -31.745, 115.766),
    Place("qd5r1g", "Rockingham", "Western Australia", -32.281, 115.727),
    Place("qd4x4s", "Albany", "Western Australia", -35.0269, 117.8837),
    Place("", "Busselton", "Western Australia", -33.6516, 115.347),
    Place("", "Margaret River", "Western Australia", -33.953, 115.073),
    Place("", "Port Hedland", "Western Australia", -20.3107, 118.601),
    Place("qd1u2n", "Esperance", "Western Australia", -33.8608, 121.8896),
    Place("qdb3g6", "Geraldton", "Western Australia", -28.7774, 114.614),
    Place("qec32p", "Kalgoorlie", "Western Australia", -30.7489, 121.4658),
    Place("qg5k8c", "Broome", "Western Australia", -17.9614, 122.2359),
    Place("qgbx8x", "Karratha", "Western Australia", -20.7364, 116.8463),
    Place("r3gx2f", "Darwin", "Northern Territory", -12.4634, 130.8456),
    Place("r1r0fs", "Adelaide", "South Australia", -34.9285, 138.6007),
    Place("r1f93c", "Melbourne", "Victoria", -37.8136, 144.9631),
    Place("r3dp5h", "Hobart", "Tasmania", -42.8821, 147.3272),
    Place("r3gx2f", "Canberra", "Australian Capital Territory", -35.2809, 149.13),
    Place("r3gx2f", "Sydney", "New South Wales", -33.8688, 151.2093),
    Place("r7hg6k", "Brisbane", "Queensland", -27.4698, 153.0251),
    Place("r7k0yx", "Gold Coast", "Queensland", -28.0167, 153.4),
    Place("r7hx0w", "Sunshine Coast", "Queensland", -26.65, 153.0667),
    Place("r6n3xm", "Cairns", "Queensland", -16.9186, 145.7781),
    Place("r6kz2g", "Townsville", "Queensland", -19.2589, 146.8169),
    Place("r3gx2f", "Newcastle", "New South Wales", -32.9283, 151.7817),
    Place("r3gx2f", "Wollongong", "New South Wales", -34.4278, 150.8931),
    Place("", "Coffs Harbour", "New South Wales", -30.2963, 153.1135),
    Place("", "Dubbo", "New South Wales", -32.2569, 148.6011),
    Place("", "Wagga Wagga", "New South Wales", -35.1082, 147.3598),
    Place("", "Byron Bay", "New South Wales", -28.6474, 153.602),
    Place("", "Geelong", "Victoria", -38.1499, 144.3617),
    Place("", "Ballarat", "Victoria", -37.5622, 143.8503),
    Place("", "Bendigo", "Victoria", -36.757, 144.2794),
    Place("", "Mildura", "Victoria", -34.208, 142.1246),
    Place("", "Toowoomba", "Queensland", -27.5598, 151.9507),
    Place("", "Mackay", "Queensland", -21.1411, 149.186),
    Place("", "Rockhampton", "Queensland", -23.379, 150.51),
    Place("", "Mount Gambier", "South Australia", -37.8284, 140.7804),
    Place("", "Port Augusta", "South Australia", -32.4952, 137.7894),
    Place("", "Whyalla", "South Australia", -33.034, 137.585),
    Place("", "Launceston", "Tasmania", -41.4332, 147.1441),
    Place("", "Devonport", "Tasmania", -41.1769, 146.3515),
    Place("r1r0fs", "Alice Springs", "Northern Territory", -23.698, 133.8807),
    Place("", "Katherine", "Northern Territory", -14.4652, 132.2635)
)


private val defaultSavedPlaces: List<Place> by lazy {
    listOf(
        Place("global-kiel", "Kiel", "Schleswig-Holstein, Germany", 54.3233, 10.1228, country = "Germany", countryCode = "DE", timeZoneId = "Europe/Berlin"),
        Place("global-los-angeles", "Los Angeles", "California, United States", 34.0522, -118.2437, country = "United States", countryCode = "US", timeZoneId = "America/Los_Angeles"),
        Place("global-london", "London", "England, United Kingdom", 51.5074, -0.1278, country = "United Kingdom", countryCode = "GB", timeZoneId = "Europe/London"),
        Place("global-kuwait-city", "Kuwait City", "Al Asimah, Kuwait", 29.3759, 47.9774, country = "Kuwait", countryCode = "KW", timeZoneId = "Asia/Kuwait")
    )
}

private fun sameSavedPlace(a: Place, b: Place): Boolean {
    val sameName = a.name.equals(b.name, ignoreCase = true) && a.state.equals(b.state, ignoreCase = true)
    val closeCoordinates = distanceSquared(a.latitude, a.longitude, b.latitude, b.longitude) < 0.00008
    return sameName || closeCoordinates
}

private fun normaliseSavedPlaces(input: List<Place>, preferredFirst: Place? = null): List<Place> {
    val live = preferredFirst?.takeIf { it.current } ?: input.firstOrNull { it.current }
    val ordered = buildList {
        live?.let(::add)
        addAll(input.filterNot { it.current })
        preferredFirst?.takeUnless { it.current }?.let { if (none { saved -> sameSavedPlace(saved, it) }) add(it) }
    }
    val result = mutableListOf<Place>()
    ordered.filter { it.name.isNotBlank() && it.latitude.isFinite() && it.longitude.isFinite() }.forEach { candidate ->
        if (result.none { sameSavedPlace(it, candidate) }) result += candidate
    }
    return result
}

private val fallbackDays = listOf(
    DayForecast("", "Mostly sunny", "mostly_sunny", 21, 12, 5, 0.0),
    DayForecast("", "Partly cloudy", "partly_cloudy", 20, 11, 20, 0.4),
    DayForecast("", "Sunny", "sunny", 22, 10, 5, 0.0),
    DayForecast("", "Cloud increasing", "cloudy", 19, 12, 30, 0.8),
    DayForecast("", "Shower or two", "shower", 18, 11, 55, 3.0),
    DayForecast("", "Partly cloudy", "partly_cloudy", 19, 10, 20, 0.2),
    DayForecast("", "Mostly sunny", "mostly_sunny", 21, 11, 10, 0.0)
)


private fun coordinatesAreAustralian(latitude: Double, longitude: Double): Boolean =
    latitude in -44.5..-9.0 && longitude in 111.0..155.5

private fun Place.isAustralian(): Boolean {
    if (countryCode.isNotBlank()) return countryCode.equals("AU", ignoreCase = true)
    return coordinatesAreAustralian(latitude, longitude)
}

private object GlobalGeocodingRepository {
    suspend fun search(query: String): List<Place> = withContext(Dispatchers.IO) {
        if (query.trim().length < 2) return@withContext emptyList()
        runCatching {
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val connection = (URL("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=20&language=en&format=json").openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 10_000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "Atmos Android Weather App")
            }
            val json = try { JSONObject(connection.inputStream.bufferedReader().use { it.readText() }) } finally { connection.disconnect() }
            val results = json.optJSONArray("results") ?: JSONArray()
            (0 until results.length()).mapNotNull { index ->
                results.optJSONObject(index)?.let { item ->
                    val lat = item.optDouble("latitude", Double.NaN)
                    val lon = item.optDouble("longitude", Double.NaN)
                    if (!lat.isFinite() || !lon.isFinite()) return@let null
                    val country = item.optString("country", "")
                    val state = listOf(item.optString("admin1", ""), country).filter(String::isNotBlank).distinct().joinToString(", ")
                    Place(
                        id = "global:${item.optLong("id", 0L)}",
                        name = item.optString("name", "Location"),
                        state = state,
                        latitude = lat,
                        longitude = lon,
                        country = country,
                        countryCode = item.optString("country_code", ""),
                        timeZoneId = item.optString("timezone", "")
                    )
                }
            }.distinctBy { "${it.name.lowercase()}:${"%.3f".format(Locale.US, it.latitude)}:${"%.3f".format(Locale.US, it.longitude)}" }
        }.getOrDefault(emptyList())
    }
}

private object OpenMeteoRepository {
    suspend fun load(place: Place): WeatherState = withContext(Dispatchers.IO) {
        try {
            val url = buildString {
                append("https://api.open-meteo.com/v1/forecast?")
                append("latitude=${place.latitude}&longitude=${place.longitude}")
                append("&timezone=auto&timeformat=unixtime&forecast_days=10")
                append("&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,rain,weather_code,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m")
                append("&hourly=temperature_2m,relative_humidity_2m,precipitation_probability,weather_code,wind_speed_10m,wind_direction_10m")
                append("&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,sunrise,sunset,uv_index_max")
            }
            val json = get(url)
            val resolvedPlace = place.copy(timeZoneId = json.optString("timezone", place.timeZoneId))
            val daily = json.optJSONObject("daily") ?: JSONObject()
            val dailyTimes = daily.optJSONArray("time") ?: JSONArray()
            val days = (0 until minOf(dailyTimes.length(), 10)).map { i ->
                val code = daily.optJSONArray("weather_code")?.optInt(i, 3) ?: 3
                DayForecast(
                    date = epochDate(dailyTimes.optLong(i)),
                    condition = weatherCodeText(code),
                    icon = weatherCodeIcon(code),
                    high = daily.optJSONArray("temperature_2m_max")?.optDouble(i, 20.0)?.roundToInt() ?: 20,
                    low = daily.optJSONArray("temperature_2m_min")?.optDouble(i, 10.0)?.roundToInt() ?: 10,
                    rainChance = daily.optJSONArray("precipitation_probability_max")?.optInt(i, 0) ?: 0,
                    rainAmount = daily.optJSONArray("precipitation_sum")?.optDouble(i, 0.0) ?: 0.0
                )
            }.ifEmpty { fallbackDays }
            val hourly = json.optJSONObject("hourly") ?: JSONObject()
            val hourTimes = hourly.optJSONArray("time") ?: JSONArray()
            val nowSeconds = System.currentTimeMillis() / 1000L - 3600L
            val hours = (0 until hourTimes.length()).mapNotNull { i ->
                val epoch = hourTimes.optLong(i)
                if (epoch < nowSeconds) return@mapNotNull null
                val code = hourly.optJSONArray("weather_code")?.optInt(i, 3) ?: 3
                HourForecast(
                    time = Date(epoch * 1000L),
                    temp = hourly.optJSONArray("temperature_2m")?.optDouble(i, 20.0)?.roundToInt() ?: 20,
                    icon = weatherCodeIcon(code),
                    rainChance = hourly.optJSONArray("precipitation_probability")?.optInt(i, 0) ?: 0,
                    humidity = hourly.optJSONArray("relative_humidity_2m")?.optInt(i, 0) ?: 0,
                    wind = hourly.optJSONArray("wind_speed_10m")?.optDouble(i, 0.0)?.roundToInt() ?: 0,
                    direction = compassDirection(hourly.optJSONArray("wind_direction_10m")?.optDouble(i, 0.0) ?: 0.0)
                )
            }.take(48)
            val current = json.optJSONObject("current") ?: JSONObject()
            val currentCode = current.optInt("weather_code", 3)
            val currentDirection = current.optDouble("wind_direction_10m", 0.0)
            WeatherState(
                place = resolvedPlace,
                days = days,
                hours = hours,
                observation = Observation(
                    temp = current.numberOrNull("temperature_2m")?.roundToInt(),
                    feels = current.numberOrNull("apparent_temperature")?.roundToInt(),
                    humidity = current.numberOrNull("relative_humidity_2m")?.roundToInt(),
                    wind = current.numberOrNull("wind_speed_10m")?.roundToInt(),
                    direction = compassDirection(currentDirection),
                    gust = current.numberOrNull("wind_gusts_10m")?.roundToInt(),
                    pressure = current.numberOrNull("surface_pressure"),
                    rainSince9 = current.numberOrNull("precipitation") ?: current.numberOrNull("rain"),
                    station = "Open-Meteo · ${place.country.ifBlank { "International" }}"
                ),
                live = true,
                warnings = emptyList()
            )
        } catch (_: Exception) {
            WeatherState(place, fallbackDays, emptyList(), Observation(), false)
        }
    }

    private fun get(address: String): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 15_000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "Atmos Android Weather App")
        }
        return try { JSONObject(connection.inputStream.bufferedReader().use { it.readText() }) } finally { connection.disconnect() }
    }

    private fun epochDate(seconds: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(seconds * 1000L))
    private fun weatherCodeText(code: Int): String = when (code) {
        0 -> "Clear sky"; 1 -> "Mostly clear"; 2 -> "Partly cloudy"; 3 -> "Overcast"
        45, 48 -> "Fog"; 51, 53, 55, 56, 57 -> "Drizzle"; 61, 63, 65, 66, 67 -> "Rain"
        71, 73, 75, 77, 85, 86 -> "Snow"; 80, 81, 82 -> "Rain showers"; 95, 96, 99 -> "Thunderstorm"
        else -> "Current conditions"
    }
    private fun weatherCodeIcon(code: Int): String = when (code) {
        0 -> "sunny"; 1 -> "mostly_sunny"; 2 -> "partly_cloudy"; 3 -> "cloudy"
        45, 48 -> "fog"; 51, 53, 55, 56, 57 -> "drizzle"; 61, 63, 65, 66, 67, 80, 81, 82 -> "shower"
        71, 73, 75, 77, 85, 86 -> "snow"; 95, 96, 99 -> "thunderstorm"
        else -> "partly_cloudy"
    }
    private fun compassDirection(degrees: Double): String {
        val labels = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        return labels[((degrees / 45.0).roundToInt() % 8 + 8) % 8]
    }
}

private object WeatherRepository {
    suspend fun load(place: Place): WeatherState = if (place.isAustralian()) BomRepository.load(place) else OpenMeteoRepository.load(place)
}

private object BomRepository {
    suspend fun load(place: Place): WeatherState = withContext(Dispatchers.IO) {
        try {
            val locationId = geohash(place.latitude, place.longitude)
            val daily = get("https://api.weather.bom.gov.au/v1/locations/$locationId/forecasts/daily")
            val hourly = runCatching { get("https://api.weather.bom.gov.au/v1/locations/$locationId/forecasts/hourly") }.getOrNull()
            val observations = runCatching { get("https://api.weather.bom.gov.au/v1/locations/$locationId/observations") }.getOrNull()
            val warningData = runCatching { get("https://api.weather.bom.gov.au/v1/locations/$locationId/warnings") }.getOrNull()
            val dayArray = daily.optJSONArray("data") ?: JSONArray()
            val days = (0 until minOf(dayArray.length(), 7)).map { i ->
                val d = dayArray.getJSONObject(i)
                val rain = d.optJSONObject("rain")
                DayForecast(
                    d.optString("date"), d.optString("short_text", "Current conditions"),
                    d.optString("icon_descriptor", "partly_cloudy"),
                    d.optInt("temp_max", 20), d.optInt("temp_min", 11),
                    rain?.optInt("chance", 0) ?: 0,
                    rain?.optJSONObject("amount")?.optDouble("max", 0.0) ?: 0.0
                )
            }.ifEmpty { fallbackDays }
            val hourArray = hourly?.optJSONArray("data") ?: JSONArray()
            val hours = (0 until minOf(hourArray.length(), 24)).mapNotNull { i ->
                runCatching {
                    val h = hourArray.getJSONObject(i)
                    val rain = h.optJSONObject("rain")
                    val wind = h.optJSONObject("wind")
                    val temperature: Int = h.optInt("temp", days.first().high - 2)
                    HourForecast(
                        time = parseDate(h.optString("time", h.optString("date"))),
                        temp = temperature,
                        icon = h.optString("icon_descriptor", days.first().icon),
                        rainChance = rain?.optInt("chance", 0) ?: 0,
                        humidity = h.optInt("relative_humidity", 0),
                        wind = wind?.optInt("speed_kilometre", 0) ?: 0,
                        direction = wind?.optString("direction", "") ?: ""
                    )
                }.getOrNull()
            }
            val raw = observations?.opt("data")
            val o = when (raw) {
                is JSONArray -> raw.optJSONObject(0)
                is JSONObject -> raw.optJSONArray("observations")?.optJSONObject(0) ?: raw
                else -> null
            }
            val wind = o?.optJSONObject("wind")
            val gust = o?.optJSONObject("gust")
            val station = o?.optJSONObject("station")
            WeatherState(
                place, days, hours,
                Observation(
                    o?.numberOrNull("temp")?.roundToInt(),
                    o?.numberOrNull("temp_feels_like")?.roundToInt(),
                    o?.numberOrNull("humidity")?.roundToInt(),
                    wind?.numberOrNull("speed_kilometre")?.roundToInt(),
                    wind?.optString("direction", "") ?: "",
                    gust?.numberOrNull("speed_kilometre")?.roundToInt(),
                    o?.numberOrNull("pressure_msl"),
                    o?.numberOrNull("rain_since_9am"),
                    station?.optString("name", "Nearest observation") ?: "Nearest observation"
                ), true,
                warnings = warningData?.optJSONArray("data")?.let { array ->
                    (0 until array.length()).mapNotNull { array.optJSONObject(it)?.optString("title")?.takeIf(String::isNotBlank) }
                } ?: emptyList()
            )
        } catch (_: Exception) {
            WeatherState(place, fallbackDays, emptyList(), Observation(temp = 19, feels = 17, humidity = 54, wind = 9, direction = "W"), false)
        }
    }

    private fun get(address: String): JSONObject {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 12_000
        connection.readTimeout = 12_000
        connection.setRequestProperty("Accept", "application/json")
        return try {
            JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        } finally {
            connection.disconnect()
        }
    }
}

private fun JSONObject.numberOrNull(key: String): Double? =
    if (has(key) && !isNull(key)) optDouble(key).takeUnless { it.isNaN() } else null

private fun parseDate(value: String): Date =
    listOf("yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX").firstNotNullOfOrNull {
        runCatching { SimpleDateFormat(it, Locale.US).parse(value) }.getOrNull()
    } ?: Date()


private fun Place.cacheKey(): String = "${"%.4f".format(Locale.US, latitude)}:${"%.4f".format(Locale.US, longitude)}"

private fun WeatherState.toJson(): JSONObject = JSONObject().apply {
    put("place", JSONObject().apply {
        put("id", place.id); put("name", place.name); put("state", place.state)
        put("lat", place.latitude); put("lon", place.longitude); put("current", place.current); put("country", place.country); put("countryCode", place.countryCode); put("timeZoneId", place.timeZoneId)
    })
    put("days", JSONArray().apply { days.forEach { day -> put(JSONObject().apply {
        put("date", day.date); put("condition", day.condition); put("icon", day.icon)
        put("high", day.high); put("low", day.low); put("rainChance", day.rainChance); put("rainAmount", day.rainAmount)
    }) } })
    put("hours", JSONArray().apply { hours.forEach { hour -> put(JSONObject().apply {
        put("time", hour.time.time); put("temp", hour.temp); put("icon", hour.icon)
        put("rainChance", hour.rainChance); put("humidity", hour.humidity); put("wind", hour.wind); put("direction", hour.direction)
    }) } })
    put("observation", JSONObject().apply {
        observation.temp?.let { put("temp", it) }; observation.feels?.let { put("feels", it) }
        observation.humidity?.let { put("humidity", it) }; observation.wind?.let { put("wind", it) }
        put("direction", observation.direction); observation.gust?.let { put("gust", it) }
        observation.pressure?.let { put("pressure", it) }; observation.rainSince9?.let { put("rainSince9", it) }
        put("station", observation.station)
    })
    put("live", live); put("warnings", JSONArray(warnings)); put("updated", updated.time)
}

private fun weatherStateFromJson(json: JSONObject): WeatherState? = runCatching {
    val p = json.getJSONObject("place")
    val place = Place(p.optString("id"), p.optString("name"), p.optString("state"), p.optDouble("lat"), p.optDouble("lon"), p.optBoolean("current"), p.optString("country", "Australia"), p.optString("countryCode", "AU"), p.optString("timeZoneId", ""))
    val dayArray = json.optJSONArray("days") ?: JSONArray()
    val days = (0 until dayArray.length()).map { i -> dayArray.getJSONObject(i).let { d ->
        DayForecast(d.optString("date"), d.optString("condition"), d.optString("icon"), d.optInt("high"), d.optInt("low"), d.optInt("rainChance"), d.optDouble("rainAmount"))
    } }.ifEmpty { fallbackDays }
    val hourArray = json.optJSONArray("hours") ?: JSONArray()
    val hours = (0 until hourArray.length()).map { i -> hourArray.getJSONObject(i).let { h ->
        HourForecast(Date(h.optLong("time")), h.optInt("temp"), h.optString("icon"), h.optInt("rainChance"), h.optInt("humidity"), h.optInt("wind"), h.optString("direction"))
    } }
    val o = json.optJSONObject("observation") ?: JSONObject()
    val observation = Observation(
        o.optIntOrNull("temp"), o.optIntOrNull("feels"), o.optIntOrNull("humidity"), o.optIntOrNull("wind"),
        o.optString("direction"), o.optIntOrNull("gust"), o.numberOrNull("pressure"), o.numberOrNull("rainSince9"), o.optString("station", "Nearest observation")
    )
    val warningArray = json.optJSONArray("warnings") ?: JSONArray()
    val warnings = (0 until warningArray.length()).mapNotNull { warningArray.optString(it).takeIf(String::isNotBlank) }
    WeatherState(place, days, hours, observation, json.optBoolean("live"), warnings, Date(json.optLong("updated", System.currentTimeMillis())))
}.getOrNull()

private fun JSONObject.optIntOrNull(key: String): Int? = if (has(key) && !isNull(key)) optInt(key) else null

private class AtmosPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("atmos_native", Context.MODE_PRIVATE)
    var onboarded: Boolean
        get() = prefs.getBoolean("onboarded", false)
        set(value) = prefs.edit().putBoolean("onboarded", value).apply()
    var theme: ThemeChoice
        get() = runCatching { ThemeChoice.valueOf(prefs.getString("theme", "Dark")!!) }.getOrDefault(ThemeChoice.Dark)
        set(value) = prefs.edit().putString("theme", value.name).apply()
    var darkNightMode: Boolean
        get() = prefs.getBoolean("darkNightMode", true)
        set(value) = prefs.edit().putBoolean("darkNightMode", value).apply()
    var conditionAnimations: Boolean
        get() = prefs.getBoolean("conditionAnimations", true)
        set(value) = prefs.edit().putBoolean("conditionAnimations", value).apply()
    var atmosphereIntensity: AtmosphereIntensity
        get() = runCatching { AtmosphereIntensity.valueOf(prefs.getString("atmosphereIntensity", "Balanced")!!) }.getOrDefault(AtmosphereIntensity.Balanced)
        set(value) = prefs.edit().putString("atmosphereIntensity", value.name).apply()
    var seasonalAtmosphere: Boolean
        get() = prefs.getBoolean("seasonalAtmosphere", true)
        set(value) = prefs.edit().putBoolean("seasonalAtmosphere", value).apply()
    var temperatureAtmosphere: Boolean
        get() = prefs.getBoolean("temperatureAtmosphere", true)
        set(value) = prefs.edit().putBoolean("temperatureAtmosphere", value).apply()
    var solarAtmosphere: Boolean
        get() = prefs.getBoolean("solarAtmosphere", true)
        set(value) = prefs.edit().putBoolean("solarAtmosphere", value).apply()
    var ambientAtmosphere: Boolean
        get() = prefs.getBoolean("ambientAtmosphere", true)
        set(value) = prefs.edit().putBoolean("ambientAtmosphere", value).apply()

    var backgroundUpdates: Boolean
        get() = prefs.getBoolean("backgroundUpdates", true)
        set(value) = prefs.edit().putBoolean("backgroundUpdates", value).apply()
    var seasonalParticles: Boolean
        get() = prefs.getBoolean("seasonalParticles", true)
        set(value) = prefs.edit().putBoolean("seasonalParticles", value).apply()
    var heatShimmer: Boolean
        get() = prefs.getBoolean("heatShimmer", true)
        set(value) = prefs.edit().putBoolean("heatShimmer", value).apply()
    var coldFrost: Boolean
        get() = prefs.getBoolean("coldFrost", true)
        set(value) = prefs.edit().putBoolean("coldFrost", value).apply()
    var homeLayout: HomeLayout
        get() = runCatching { HomeLayout.valueOf(prefs.getString("homeLayout", "Immersive")!!) }.getOrDefault(HomeLayout.Immersive)
        set(value) = prefs.edit().putString("homeLayout", value.name).apply()
    var locationTransition: LocationTransition
        get() = runCatching { LocationTransition.valueOf(prefs.getString("locationTransition", "Standard")!!) }.getOrDefault(LocationTransition.Standard)
        set(value) = prefs.edit().putString("locationTransition", value.name).apply()
    var density: DensityChoice
        get() = runCatching { DensityChoice.valueOf(prefs.getString("density", "Expanded")!!) }.getOrDefault(DensityChoice.Expanded)
        set(value) = prefs.edit().putString("density", value.name).apply()
    var temperatureUnit: TemperatureUnit
        get() = runCatching { TemperatureUnit.valueOf(prefs.getString("temperatureUnit", "Celsius")!!) }.getOrDefault(TemperatureUnit.Celsius)
        set(value) = prefs.edit().putString("temperatureUnit", value.name).apply()
    var menuLeft: Boolean
        get() = prefs.getBoolean("menuLeft", false)
        set(value) = prefs.edit().putBoolean("menuLeft", value).apply()
    var hiddenCards: Set<String>
        get() = prefs.getStringSet("hiddenCards", emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet("hiddenCards", value).apply()
    var cardOrder: List<String>
        get() = prefs.getString("cardOrder", null)?.split(",")?.filter { it.isNotBlank() } ?: detailCardIds
        set(value) = prefs.edit().putString("cardOrder", value.joinToString(",")).apply()
    fun cachedWeather(places: List<Place>): Map<String, WeatherState> {
        val root = runCatching { JSONObject(prefs.getString("weatherCache", "{}")) }.getOrDefault(JSONObject())
        return places.mapNotNull { place ->
            root.optJSONObject(place.cacheKey())?.let(::weatherStateFromJson)?.copy(place = place)?.let { place.cacheKey() to it }
        }.toMap()
    }
    fun saveWeatherCache(cache: Map<String, WeatherState>) {
        val root = JSONObject()
        cache.forEach { (key, state) -> root.put(key, state.toJson()) }
        prefs.edit().putString("weatherCache", root.toString()).apply()
    }

    fun observationHistory(place: Place): List<HistoricalObservation> {
        val root = runCatching { JSONObject(prefs.getString("observationHistory", "{}")) }.getOrDefault(JSONObject())
        val array = root.optJSONArray(place.cacheKey()) ?: JSONArray()
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        return (0 until array.length()).mapNotNull { index ->
            array.optJSONObject(index)?.let { item ->
                val time = item.optLong("time", 0L)
                val temp = item.optIntOrNull("temp")
                if (time >= today && temp != null) HistoricalObservation(Date(time), temp, item.numberOrNull("rainSince9")) else null
            }
        }.sortedBy { it.time.time }
    }

    fun recordObservation(state: WeatherState) {
        val temp = state.observation.temp ?: return
        val root = runCatching { JSONObject(prefs.getString("observationHistory", "{}")) }.getOrDefault(JSONObject())
        val key = state.place.cacheKey()
        val existing = observationHistory(state.place).toMutableList()
        val now = state.updated
        val hourStart = Calendar.getInstance().apply {
            time = now; set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.time
        existing.removeAll { kotlin.math.abs(it.time.time - hourStart.time) < 30L * 60L * 1000L }
        existing += HistoricalObservation(hourStart, temp, state.observation.rainSince9)
        val array = JSONArray()
        existing.sortedBy { it.time.time }.takeLast(25).forEach { point ->
            array.put(JSONObject().apply {
                put("time", point.time.time); put("temp", point.temp)
                point.rainSince9?.let { put("rainSince9", it) }
            })
        }
        root.put(key, array)
        prefs.edit().putString("observationHistory", root.toString()).apply()
    }

    var savedPlaces: List<Place>
        get() {
            if (!prefs.contains("savedPlaces")) return defaultSavedPlaces
            val json = runCatching { JSONArray(prefs.getString("savedPlaces", "[]")) }.getOrDefault(JSONArray())
            val parsed = (0 until json.length()).mapNotNull { i ->
                json.optJSONObject(i)?.let {
                    Place(
                        it.optString("id"),
                        it.optString("name"),
                        it.optString("state"),
                        it.optDouble("lat"),
                        it.optDouble("lon"),
                        it.optBoolean("current"),
                        it.optString("country", "Australia"),
                        it.optString("countryCode", "AU"),
                        it.optString("timeZoneId", "")
                    )
                }
            }
            return normaliseSavedPlaces(parsed)
        }
        set(value) {
            val normalised = normaliseSavedPlaces(value)
            val json = JSONArray()
            normalised.forEach {
                json.put(
                    JSONObject()
                        .put("id", it.id)
                        .put("name", it.name)
                        .put("state", it.state)
                        .put("lat", it.latitude)
                        .put("lon", it.longitude)
                        .put("current", it.current)
                        .put("country", it.country)
                        .put("countryCode", it.countryCode)
                        .put("timeZoneId", it.timeZoneId)
                )
            }
            prefs.edit().putString("savedPlaces", json.toString()).apply()
        }

}

@Composable
private fun AtmosNativeApp() {
    val context = LocalContext.current
    val preferences = remember { AtmosPreferences(context) }
    var launchVisible by remember { mutableStateOf(true) }
    var onboarded by remember { mutableStateOf(preferences.onboarded) }
    var theme by remember { mutableStateOf(preferences.theme) }
    var darkNightMode by remember { mutableStateOf(preferences.darkNightMode) }
    var conditionAnimations by remember { mutableStateOf(preferences.conditionAnimations) }
    var homeLayout by remember { mutableStateOf(HomeLayout.Immersive) }
    var locationTransition by remember { mutableStateOf(preferences.locationTransition) }
    // 0.30.8 retires the old rounded-card home. Existing installations are
    // migrated to Fullscreen Hero while preserving an Immersive selection.
    LaunchedEffect(Unit) {
        if (preferences.homeLayout == HomeLayout.Card) {
            preferences.homeLayout = HomeLayout.Immersive
            preferences.locationTransition = LocationTransition.Standard
            locationTransition = LocationTransition.Standard
        }
    }
    var atmosphereIntensity by remember { mutableStateOf(preferences.atmosphereIntensity) }
    var immersiveHeroVisible by remember { mutableStateOf(homeLayout == HomeLayout.Immersive) }
    var showLayoutOnboarding by remember { mutableStateOf(false) }
    var showAtmosOnboarding by remember { mutableStateOf(false) }
    var awaitingManualLayoutChoice by remember { mutableStateOf(false) }
    var density by remember { mutableStateOf(preferences.density) }
    var menuLeft by remember { mutableStateOf(preferences.menuLeft) }
    var temperatureUnit by remember { mutableStateOf(preferences.temperatureUnit) }
    var savedPlaces by remember { mutableStateOf(preferences.savedPlaces) }
    var currentPlace by remember { mutableStateOf(savedPlaces.firstOrNull() ?: defaultSavedPlaces.first()) }
    val diskCache = remember(savedPlaces) { preferences.cachedWeather(savedPlaces) }
    var weather by remember { mutableStateOf(diskCache[currentPlace.cacheKey()] ?: WeatherState(currentPlace, fallbackDays, emptyList(), Observation(), false)) }
    val weatherCache = remember { mutableStateMapOf<String, WeatherState>().apply { putAll(diskCache) } }
    var refreshing by remember { mutableStateOf(false) }
    var loadingMessage by remember { mutableStateOf("Preparing your forecast…") }
    var page by rememberSaveable { mutableStateOf(Page.Home) }
    val scope = rememberCoroutineScope()
    val night = remember(weather.updated) { isNight() }
    val palette = remember(weather.days.firstOrNull()?.icon, night) { conditionPalette(weather.days.firstOrNull()?.icon.orEmpty(), night) }
    val systemDark = isSystemInDarkTheme()
    val dark = when (theme) {
        ThemeChoice.Dark -> true
        ThemeChoice.Light -> darkNightMode && night
        ThemeChoice.System -> systemDark || (darkNightMode && night)
    }

    val activity = context as? Activity
    val heroForeground = solarLegibleForeground(palette)
    SideEffect {
        activity?.window?.let { window ->
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = page == Page.Home && heroForeground != Color.White
                isAppearanceLightNavigationBars = page == Page.Home && dark.not()
            }
        }
    }

    LaunchedEffect(Unit) { scheduleBackgroundUpdates(context, preferences.backgroundUpdates) }

    suspend fun refresh(place: Place = currentPlace, force: Boolean = false) {
        val cached = weatherCache[place.cacheKey()]
        if (!force && cached != null && System.currentTimeMillis() - cached.updated.time < WEATHER_REFRESH_INTERVAL_MS) {
            currentPlace = place
            weather = cached
            return
        }
        refreshing = true
        currentPlace = place
        val loaded = WeatherRepository.load(place)
        weather = loaded
        weatherCache[place.cacheKey()] = loaded
        preferences.saveWeatherCache(weatherCache)
        preferences.recordObservation(loaded)
        updateWidgets(context, loaded)
        refreshing = false
    }

    suspend fun updateDeviceLocationAndWeather(refreshSelectedToo: Boolean = true) {
        val selectedCached = weatherCache[currentPlace.cacheKey()]
        if (selectedCached != null && System.currentTimeMillis() - selectedCached.updated.time < WEATHER_REFRESH_INTERVAL_MS) return
        // Keep the currently composed pager and its existing weather untouched while
        // location and forecast requests run. Applying the new live Place before its
        // weather was ready changed the pager key and briefly exposed the add-location
        // page during every foreground refresh.
        val placesBeforeRefresh = savedPlaces
        val selectedBeforeRefresh = currentPlace
        val oldLive = placesBeforeRefresh.firstOrNull { it.current } ?: return
        val coordinates = requestCurrentLocation(context) ?: return
        val nearest = places.minByOrNull {
            distanceSquared(it.latitude, it.longitude, coordinates.first, coordinates.second)
        } ?: oldLive
        val inAustralia = coordinatesAreAustralian(coordinates.first, coordinates.second)
        val live = if (inAustralia) Place(
            id = nearest.id,
            name = "Current location",
            state = "Near ${nearest.name}, ${nearest.state}",
            latitude = coordinates.first,
            longitude = coordinates.second,
            current = true,
            country = "Australia",
            countryCode = "AU",
            timeZoneId = nearest.timeZoneId.ifBlank { australianTimeZoneId(nearest) }
        ) else Place(
            id = "live-global",
            name = "Current location",
            state = "International",
            latitude = coordinates.first,
            longitude = coordinates.second,
            current = true,
            country = "International",
            countryCode = ""
        )
        val selectedWasLive = selectedBeforeRefresh.current
        val liveWeather = WeatherRepository.load(live)
        val selected = placesBeforeRefresh.firstOrNull { sameSavedPlace(it, selectedBeforeRefresh) }
            ?: selectedBeforeRefresh
        val selectedWeather = if (!selectedWasLive && refreshSelectedToo) {
            WeatherRepository.load(selected)
        } else null

        // Commit the refreshed location list and weather together in one frame. The
        // live card remains first and the user stays on whichever pager page was open.
        val updatedPlaces = normaliseSavedPlaces(listOf(live) + placesBeforeRefresh.filterNot { it.current })
        val oldKey = oldLive.cacheKey()
        weatherCache.remove(oldKey)
        weatherCache[live.cacheKey()] = liveWeather
        selectedWeather?.let { weatherCache[selected.cacheKey()] = it }
        savedPlaces = updatedPlaces
        preferences.savedPlaces = updatedPlaces
        preferences.recordObservation(liveWeather)
        selectedWeather?.let(preferences::recordObservation)

        if (selectedWasLive) {
            currentPlace = live
            weather = liveWeather
            updateWidgets(context, liveWeather)
        } else {
            val preservedSelection = updatedPlaces.firstOrNull { sameSavedPlace(it, selectedBeforeRefresh) }
                ?: selectedBeforeRefresh
            currentPlace = preservedSelection
            selectedWeather?.let {
                weather = it
                updateWidgets(context, it)
            }
        }
        preferences.saveWeatherCache(weatherCache)
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    var hasSeenFirstResume by remember { mutableStateOf(false) }
    val isRefreshing by androidx.compose.runtime.rememberUpdatedState(refreshing)
    DisposableEffect(lifecycleOwner, onboarded, launchVisible) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val selectedState = weatherCache[currentPlace.cacheKey()] ?: weather
                val refreshDue = System.currentTimeMillis() - selectedState.updated.time >= WEATHER_REFRESH_INTERVAL_MS
                if (hasSeenFirstResume && onboarded && !launchVisible && !isRefreshing && refreshDue) {
                    scope.launch {
                        refreshing = true
                        try {
                            if (savedPlaces.any { it.current }) updateDeviceLocationAndWeather() else refresh(currentPlace)
                        } finally { refreshing = false }
                    }
                }
                hasSeenFirstResume = true
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val onboardingLocation = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        onboarded = true
        preferences.onboarded = true
        showLayoutOnboarding = true
        if (grants.values.any { it }) {
            scope.launch {
                val coordinates = requestCurrentLocation(context) ?: currentLocation(context)
                coordinates?.let {
                    val nearest = places.minByOrNull { place -> distanceSquared(place.latitude, place.longitude, it.first, it.second) } ?: places.first()
                    val located = nearest.copy(latitude = it.first, longitude = it.second, current = true)
                    savedPlaces = normaliseSavedPlaces(listOf(located) + savedPlaces.filterNot { place -> place.current })
                    preferences.savedPlaces = savedPlaces
                    refresh(located)
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        val minimumSplash = async { delay(700) }
        loadingMessage = "Loading saved locations…"
        val loaded = coroutineScope {
            savedPlaces.map { place ->
                async {
                    val cached = weatherCache[place.cacheKey()]
                    val cacheFresh = cached != null && System.currentTimeMillis() - cached.updated.time < WEATHER_REFRESH_INTERVAL_MS
                    val fresh = if (cacheFresh) cached else withTimeoutOrNull(7_000) { WeatherRepository.load(place) }
                    place.cacheKey() to (fresh ?: cached ?: WeatherState(place, fallbackDays, emptyList(), Observation(), false))
                }
            }.map { it.await() }.toMap()
        }
        weatherCache.clear()
        weatherCache.putAll(loaded)
        preferences.saveWeatherCache(weatherCache)
        loaded.values.forEach(preferences::recordObservation)
        weather = weatherCache[currentPlace.cacheKey()] ?: weather
        updateWidgets(context, weather)
        loadingMessage = "Forecast ready"
        minimumSplash.await()
        launchVisible = false
        val selectedState = weatherCache[currentPlace.cacheKey()] ?: weather
        val refreshDue = System.currentTimeMillis() - selectedState.updated.time >= WEATHER_REFRESH_INTERVAL_MS
        if (onboarded && savedPlaces.any { it.current } && refreshDue) {
            refreshing = true
            try { updateDeviceLocationAndWeather(refreshSelectedToo = false) } finally { refreshing = false }
        }
    }

    val scheme = if (dark) darkColorScheme(
        primary = palette.accent, secondary = palette.secondary,
        background = Color(0xFF101827), surface = Color(0xFF192234),
        onBackground = Color(0xFFF5F7FF), onSurface = Color(0xFFF5F7FF)
    ) else lightColorScheme(
        primary = palette.accent, secondary = palette.secondary,
        background = Color(0xFFF7F8FD), surface = Color(0xFFFEFBFF),
        onBackground = Color(0xFF18223A), onSurface = Color(0xFF18223A)
    )

    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Crossfade(targetState = launchVisible, animationSpec = tween(650), label = "launch") { launching ->
                when {
                    launching -> FullScreenAtmosArtwork {
                        Column(
                            Modifier.fillMaxSize().padding(bottom = 72.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom
                        ) {
                            Text("ATMOS", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                            Text("THE WEATHER, ALIVE", Modifier.padding(top = 5.dp, bottom = 18.dp), color = Color.White.copy(.68f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.2.sp)
                            Text(loadingMessage, color = Color.White.copy(.88f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    showLayoutOnboarding -> LayoutOnboarding(
                        selectedTransition = locationTransition,
                        selectedTheme = theme,
                        selectedIntensity = atmosphereIntensity,
                        onSelect = { transition ->
                            homeLayout = HomeLayout.Immersive
                            locationTransition = transition
                        },
                        onTheme = { theme = it; preferences.theme = it },
                        onIntensity = { atmosphereIntensity = it; preferences.atmosphereIntensity = it },
                        onContinue = {
                            preferences.homeLayout = HomeLayout.Immersive
                            preferences.locationTransition = locationTransition
                            showLayoutOnboarding = false
                            showAtmosOnboarding = true
                        }
                    )
                    showAtmosOnboarding -> AtmosSystemOnboarding(
                        intensity = atmosphereIntensity,
                        preferences = preferences,
                        onIntensity = { atmosphereIntensity = it; preferences.atmosphereIntensity = it },
                        onContinue = {
                            conditionAnimations = atmosphereIntensity != AtmosphereIntensity.Off
                            preferences.conditionAnimations = conditionAnimations
                            showAtmosOnboarding = false
                            page = Page.Home
                        }
                    )
                    !onboarded -> Onboarding(
                        onUseLocation = {
                            onboardingLocation.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                        },
                        onChoose = {
                            onboarded = true
                            preferences.onboarded = true
                            awaitingManualLayoutChoice = true
                            page = Page.Locations
                        }
                    )
                    else -> {
                        BackHandler(page != Page.Home) { page = Page.Home }
                        Box(Modifier.fillMaxSize()) {
                            AnimatedContent(
                                targetState = page,
                                transitionSpec = {
                                    val forward = targetState.ordinal >= initialState.ordinal
                                    (fadeIn(tween(300)) + slideInHorizontally(tween(380)) { if (forward) it / 7 else -it / 7 }) togetherWith
                                        (fadeOut(tween(220)) + slideOutHorizontally(tween(320)) { if (forward) -it / 10 else it / 10 })
                                },
                                label = "atmosPage"
                            ) { target ->
                                when (target) {
                                    Page.Home -> HomePage(
                                        currentWeather = weather,
                                        weatherCache = weatherCache,
                                        savedPlaces = savedPlaces,
                                        currentPlace = currentPlace,
                                        refreshing = refreshing,
                                        density = density,
                                        preferences = preferences,
                                        temperatureUnit = temperatureUnit,
                                        conditionAnimations = conditionAnimations,
                                        homeLayout = homeLayout,
                                        locationTransition = locationTransition,
                                        onTemperatureUnit = { temperatureUnit = it; preferences.temperatureUnit = it },
                                        onRefresh = { scope.launch { refresh(force = true) } },
                                        onSelectPlace = { place ->
                                            currentPlace = place
                                            weather = weatherCache[place.cacheKey()]
                                                ?: WeatherState(place, fallbackDays, emptyList(), Observation(), false)
                                        },
                                        onSavedPlacesChanged = { updated ->
                                            val normalised = normaliseSavedPlaces(updated, updated.firstOrNull())
                                            savedPlaces = normalised
                                            preferences.savedPlaces = normalised
                                        },
                                        onAddLocation = { page = Page.Locations },
                                        onImmersiveHeroVisible = { immersiveHeroVisible = it },
                                        onPage = { page = it }
                                    )
                                    Page.Radar -> RadarPage(currentPlace) { page = Page.Home }
                                    Page.Seasons -> SeasonsPage(dark) { page = Page.Home }
                                    Page.Settings -> SettingsPage(
                                        theme, darkNightMode, conditionAnimations, homeLayout, locationTransition, density, menuLeft, temperatureUnit, preferences,
                                        onTheme = { theme = it; preferences.theme = it },
                                        onDarkNightMode = { darkNightMode = it; preferences.darkNightMode = it },
                                        onConditionAnimations = { conditionAnimations = it; preferences.conditionAnimations = it },
                                        onHomeLayout = { homeLayout = it; preferences.homeLayout = it },
                                        onLocationTransition = { locationTransition = it; preferences.locationTransition = it },
                                        onDensity = { density = it; preferences.density = it },
                                        onMenuLeft = { menuLeft = it; preferences.menuLeft = it },
                                        onTemperatureUnit = { temperatureUnit = it; preferences.temperatureUnit = it },
                                        onOpenAtmos = { page = Page.Atmos },
                                        onBack = { page = Page.Home }
                                    )
                                    Page.Atmos -> AtmosSystemPage(weather, temperatureUnit, preferences) { page = Page.Settings }
                                    Page.Locations -> LocationsPage(
                                        preferences, currentPlace, weatherCache, temperatureUnit,
                                        onLocationAdded = { added ->
                                            savedPlaces = preferences.savedPlaces
                                            scope.launch {
                                                val loaded = runCatching { WeatherRepository.load(added) }.getOrNull() ?: return@launch
                                                weatherCache[added.cacheKey()] = loaded
                                                preferences.saveWeatherCache(weatherCache)
                                                preferences.recordObservation(loaded)
                                            }
                                        },
                                        onSelect = { selected ->
                                            savedPlaces = preferences.savedPlaces
                                            if (awaitingManualLayoutChoice) {
                                                val ordered = normaliseSavedPlaces(listOf(selected) + savedPlaces.filterNot { sameSavedPlace(it, selected) }, selected)
                                                savedPlaces = ordered
                                                preferences.savedPlaces = ordered
                                            }
                                            scope.launch {
                                                refresh(selected)
                                                page = Page.Home
                                                if (awaitingManualLayoutChoice) {
                                                    awaitingManualLayoutChoice = false
                                                    showLayoutOnboarding = true
                                                }
                                            }
                                        },
                                        onBack = { savedPlaces = preferences.savedPlaces; page = Page.Home }
                                    )
                                    Page.About -> AboutPage { page = Page.Home }
                                }
                            }
                            QuickMenu(
                                left = menuLeft,
                                visible = page == Page.Home,
                                lifted = page == Page.Home && homeLayout == HomeLayout.Immersive && immersiveHeroVisible,
                                weather = weather,
                                onPage = { page = it }
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class Palette(val top: Color, val bottom: Color, val accent: Color, val secondary: Color)

private fun conditionPalette(icon: String, night: Boolean): Palette {
    val s = icon.lowercase()
    return when {
        night -> Palette(Color(0xFF263C60), Color(0xFF433657), Color(0xFF9AB7FF), Color(0xFFB58BEA))
        "storm" in s || "thunder" in s -> Palette(Color(0xFF62548D), Color(0xFF343B62), Color(0xFFB69FE9), Color(0xFF7E8DD6))
        "rain" in s || "shower" in s -> Palette(Color(0xFF4E83A7), Color(0xFF46638D), Color(0xFF65C8DB), Color(0xFF71A9D6))
        "cloud" in s || "overcast" in s -> Palette(Color(0xFF899AB9), Color(0xFF687A9F), Color(0xFF8DB5D3), Color(0xFFA5B7D2))
        else -> Palette(Color(0xFFFFC65A), Color(0xFFEE7D62), Color(0xFFF3A74E), Color(0xFF75CDE2))
    }
}

private fun blendColor(from: Color, to: Color, amount: Float): Color {
    val t = amount.coerceIn(0f, 1f)
    return Color(
        red = from.red + (to.red - from.red) * t,
        green = from.green + (to.green - from.green) * t,
        blue = from.blue + (to.blue - from.blue) * t,
        alpha = from.alpha + (to.alpha - from.alpha) * t
    )
}

private fun blendPalette(from: Palette, to: Palette, amount: Float): Palette = Palette(
    top = blendColor(from.top, to.top, amount),
    bottom = blendColor(from.bottom, to.bottom, amount),
    accent = blendColor(from.accent, to.accent, amount),
    secondary = blendColor(from.secondary, to.secondary, amount)
)

private fun australianTimeZoneId(place: Place): String = when {
    place.state.contains("Western Australia", true) -> "Australia/Perth"
    place.state.contains("Northern Territory", true) -> "Australia/Darwin"
    place.state.contains("South Australia", true) -> "Australia/Adelaide"
    place.state.contains("Queensland", true) -> "Australia/Brisbane"
    place.state.contains("Tasmania", true) -> "Australia/Hobart"
    place.state.contains("Victoria", true) -> "Australia/Melbourne"
    place.state.contains("New South Wales", true) -> "Australia/Sydney"
    place.state.contains("Australian Capital Territory", true) -> "Australia/Sydney"
    place.longitude < 129.0 -> "Australia/Perth"
    place.longitude < 138.0 -> "Australia/Darwin"
    place.longitude < 141.0 -> "Australia/Adelaide"
    place.latitude > -29.0 && place.longitude > 141.0 -> "Australia/Brisbane"
    else -> "Australia/Sydney"
}

private fun Place.timeZone(): TimeZone {
    val zoneId = timeZoneId.takeIf { it.isNotBlank() } ?: if (isAustralian()) australianTimeZoneId(this) else TimeZone.getDefault().id
    return TimeZone.getTimeZone(zoneId)
}

private fun localFormatter(pattern: String, place: Place): SimpleDateFormat =
    SimpleDateFormat(pattern, Locale.ENGLISH).apply { timeZone = place.timeZone() }

private fun solarAwarePalette(icon: String, place: Place, now: Date): Palette {
    val dayPalette = conditionPalette(icon, false)
    val nightPalette = conditionPalette(icon, true)
    // A near-black OLED palette is reserved for genuinely late night. The first
    // hours after sunset retain colour so the sunset transition does not collapse
    // immediately into black.
    val oledNightPalette = Palette(
        top = Color(0xFF05070D),
        bottom = Color(0xFF0A0D16),
        accent = Color(0xFF7895D8),
        secondary = Color(0xFF65527F)
    )
    val sunrisePalette = Palette(
        top = Color(0xFF5D6FA8),
        bottom = Color(0xFFFF8B72),
        accent = Color(0xFFFFD37A),
        secondary = Color(0xFF9CCFE5)
    )
    val sunsetPalette = Palette(
        top = Color(0xFF765C9E),
        bottom = Color(0xFFF16F63),
        accent = Color(0xFFFFC066),
        secondary = Color(0xFF435582)
    )
    val solar = calculateSolarTimes(now, place.latitude, place.longitude, place.timeZone())
        ?: return conditionPalette(icon, isNight(now))
    val sunrise = solar.first.time
    val sunset = solar.second.time
    val current = now.time
    val dawnStart = sunrise - 75L * 60_000L
    val sunriseEnd = sunrise + 60L * 60_000L
    val sunsetStart = sunset - 75L * 60_000L
    val duskEnd = sunset + 75L * 60_000L
    val oledTransitionStart = sunset + 150L * 60_000L
    val oledTransitionEnd = sunset + 210L * 60_000L

    fun progress(start: Long, end: Long): Float =
        ((current - start).toDouble() / (end - start).toDouble()).toFloat().coerceIn(0f, 1f)

    return when {
        // Before dawn it has already been dark for several hours, so use the
        // OLED palette and blend directly into the sunrise treatment.
        current < dawnStart -> oledNightPalette
        current < sunrise -> blendPalette(oledNightPalette, sunrisePalette, progress(dawnStart, sunrise))
        current < sunriseEnd -> blendPalette(sunrisePalette, dayPalette, progress(sunrise, sunriseEnd))
        current < sunsetStart -> dayPalette
        current < sunset -> blendPalette(dayPalette, sunsetPalette, progress(sunsetStart, sunset))
        current < duskEnd -> blendPalette(sunsetPalette, nightPalette, progress(sunset, duskEnd))
        current < oledTransitionStart -> nightPalette
        current < oledTransitionEnd -> blendPalette(nightPalette, oledNightPalette, progress(oledTransitionStart, oledTransitionEnd))
        else -> oledNightPalette
    }
}

@Composable
private fun rememberSolarAwarePalette(icon: String, place: Place): Palette {
    var nowMillis by remember(place.latitude, place.longitude) { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(place.latitude, place.longitude) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(60_000L)
        }
    }
    val target = remember(icon, place.latitude, place.longitude, nowMillis) {
        solarAwarePalette(icon, place, Date(nowMillis))
    }
    val top by animateColorAsState(target.top, tween(1400), label = "solarTop")
    val bottom by animateColorAsState(target.bottom, tween(1400), label = "solarBottom")
    val accent by animateColorAsState(target.accent, tween(1400), label = "solarAccent")
    val secondary by animateColorAsState(target.secondary, tween(1400), label = "solarSecondary")
    return Palette(top, bottom, accent, secondary)
}

@Composable
private fun FullScreenAtmosArtwork(content: (@Composable () -> Unit)? = null) {
    val context = LocalContext.current
    val bitmap = remember {
        runCatching { BitmapFactory.decodeStream(context.assets.open("public/assets/atmos-sunrise.png")).asImageBitmap() }.getOrNull()
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF182878))) {
        bitmap?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        content?.invoke()
    }
}

@Composable
private fun Onboarding(onUseLocation: () -> Unit, onChoose: () -> Unit) {
    FullScreenAtmosArtwork {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Color(0xE8151E52)), startY = 450f)))
        Column(
            Modifier.fillMaxSize().padding(horizontal = 25.dp)
                .padding(
                    top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 30.dp,
                    bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 24.dp
                )
        ) {
            Text("WEATHER, WHERE YOU ARE", color = Color.White.copy(.82f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.4.sp)
            Text("Weather that moves with you.", Modifier.padding(top = 5.dp), color = Color.White, fontSize = 38.sp, lineHeight = 42.sp, fontWeight = FontWeight.Bold)
            Text("Choose Fullscreen Hero or the new Immersive experience, powered by one living atmosphere.", Modifier.padding(top = 6.dp), color = Color(0xFFEAF0FF), fontSize = 14.sp)
            Spacer(Modifier.weight(1f))
            Button(onUseLocation, Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF263F91))) { Text("Use my location", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onChoose, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text("Choose a location manually") }
            Text("Atmos only uses your location to find the nearest forecast.", Modifier.fillMaxWidth().padding(top = 10.dp), color = Color.White.copy(.7f), fontSize = 10.sp, textAlign = TextAlign.Center)
        }
    }
}


@Composable
private fun LayoutOnboarding(
    selectedTransition: LocationTransition,
    selectedTheme: ThemeChoice,
    selectedIntensity: AtmosphereIntensity,
    onSelect: (LocationTransition) -> Unit,
    onTheme: (ThemeChoice) -> Unit,
    onIntensity: (AtmosphereIntensity) -> Unit,
    onContinue: () -> Unit
) {
    val deepGradient = Brush.verticalGradient(listOf(Color(0xFF07101F), Color(0xFF10162D), Color(0xFF24133D), Color(0xFF0B1830)))
    Box(Modifier.fillMaxSize().background(deepGradient)) {
        Box(Modifier.size(280.dp).offset(x = 150.dp, y = (-75).dp).background(Brush.radialGradient(listOf(Color(0x665F8CFF), Color.Transparent)), CircleShape))
        Box(Modifier.size(250.dp).offset(x = (-115).dp, y = 470.dp).background(Brush.radialGradient(listOf(Color(0x55FF8A63), Color.Transparent)), CircleShape))
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp)
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 24.dp, bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 22.dp)
        ) {
            Text("PERSONALISE ATMOS", color = Color.White.copy(.62f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.2.sp)
            Text("Make it feel like yours.", color = Color.White, fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold)
            Text("Choose how Atmos looks. You can change these choices later in Settings.", Modifier.padding(top = 7.dp), color = Color.White.copy(.70f), fontSize = 12.sp, lineHeight = 18.sp)
            Spacer(Modifier.height(24.dp))
            Text("APPEARANCE", color = Color.White.copy(.56f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ThemePreviewCard(false, selectedTheme == ThemeChoice.Light, Modifier.weight(1f)) { onTheme(ThemeChoice.Light) }
                ThemePreviewCard(true, selectedTheme == ThemeChoice.Dark, Modifier.weight(1f)) { onTheme(ThemeChoice.Dark) }
            }
            Spacer(Modifier.height(22.dp))
            Text("FORECAST EXPERIENCE", color = Color.White.copy(.56f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
            Text("Choose how saved locations move through the same living Atmos scene.", Modifier.padding(top = 7.dp, bottom = 10.dp), color = Color.White.copy(.66f), fontSize = 11.sp, lineHeight = 16.sp)
            LayoutPreviewCard("Fullscreen Hero", "A complete hero forecast for each location.", false, selectedTransition == LocationTransition.Standard) { onSelect(LocationTransition.Standard) }
            Spacer(Modifier.height(10.dp))
            LayoutPreviewCard("Immersive", "The atmosphere stays continuous while forecast content glides between locations.", true, selectedTransition == LocationTransition.Immersive) { onSelect(LocationTransition.Immersive) }
            Spacer(Modifier.height(26.dp))
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF131A32))) {
                Text("Continue", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AtmosSystemOnboarding(
    intensity: AtmosphereIntensity,
    preferences: AtmosPreferences,
    onIntensity: (AtmosphereIntensity) -> Unit,
    onContinue: () -> Unit
) {
    var seasonal by remember { mutableStateOf(preferences.seasonalAtmosphere) }
    var temperature by remember { mutableStateOf(preferences.temperatureAtmosphere) }
    var solar by remember { mutableStateOf(preferences.solarAtmosphere) }
    var ambient by remember { mutableStateOf(preferences.ambientAtmosphere) }
    var particles by remember { mutableStateOf(preferences.seasonalParticles) }
    val transition = rememberInfiniteTransition(label = "atmos-onboarding")
    val drift by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Restart), label = "preview-drift")
    val deepGradient = Brush.verticalGradient(listOf(Color(0xFF07101F), Color(0xFF10162D), Color(0xFF24133D), Color(0xFF0B1830)))
    Box(Modifier.fillMaxSize().background(deepGradient)) {
        Box(Modifier.size(300.dp).offset(x = 145.dp, y = (-80).dp).background(Brush.radialGradient(listOf(Color(0x665F8CFF), Color.Transparent)), CircleShape))
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp)
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 24.dp, bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 22.dp)
        ) {
            Text("THE ATMOS SYSTEM", color = Color.White.copy(.62f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.2.sp)
            Text("Weather you can feel.", color = Color.White, fontSize = 35.sp, lineHeight = 39.sp, fontWeight = FontWeight.Bold)
            Text("Atmos uses feels-like temperature, season, sunlight and wind to give every forecast its own character.", Modifier.padding(top = 7.dp), color = Color.White.copy(.72f), fontSize = 12.sp, lineHeight = 18.sp)
            Spacer(Modifier.height(20.dp))
            val previewStart by animateColorAsState(
                if (!solar || !ambient) Color(0xFF31435C) else if (temperature) Color(0xFF315D89) else Color(0xFF405875),
                tween(650), label = "preview-start"
            )
            val previewMiddle by animateColorAsState(
                if (seasonal) Color(0xFF8C668F) else Color(0xFF536782),
                tween(650), label = "preview-middle"
            )
            val previewEnd by animateColorAsState(
                if (temperature) Color(0xFFF0A06F) else Color(0xFF7B88A2),
                tween(650), label = "preview-end"
            )
            Surface(Modifier.fillMaxWidth().height(184.dp), shape = RoundedCornerShape(30.dp), color = Color.White.copy(.08f), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.14f))) {
                Box(Modifier.fillMaxSize()) {
                    Canvas(Modifier.fillMaxSize()) {
                        drawRect(Brush.linearGradient(listOf(previewStart, previewMiddle, previewEnd), Offset(size.width * drift, 0f), Offset(size.width * (1f - drift), size.height)))
                        if (solar) drawCircle(Color(0xFFFFE6AE).copy(.82f), radius = 20.dp.toPx(), center = Offset(size.width * .82f, size.height * .24f))
                        if (temperature) drawRect(Brush.radialGradient(listOf(Color(0x55FFB071), Color.Transparent), center = Offset(size.width * .20f, size.height * .76f), radius = size.width * .52f))
                        if (particles && intensity != AtmosphereIntensity.Off) repeat(if (intensity == AtmosphereIntensity.Immersive) 28 else if (intensity == AtmosphereIntensity.Subtle) 10 else 18) { i ->
                            val phase = (drift + i * .137f) % 1f
                            val lifeAlpha = when { phase < .16f -> phase / .16f; phase > .78f -> (1f - phase) / .22f; else -> 1f }
                            val x = size.width * ((i * .173f + phase * .24f) % 1f)
                            val y = size.height * ((i * .119f + phase * .72f) % 1f)
                            drawCircle(if (seasonal && i % 2 == 0) Color(0xFFFFE7F1).copy(.60f * lifeAlpha) else Color(0xFFFFD58C).copy(.48f * lifeAlpha), 3.0f + (i % 4) * .9f, Offset(x, y))
                        }
                    }
                    Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
                        Text("23°", color = Color.White, fontSize = 36.sp, lineHeight = 38.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Warm afternoon", color = Color.White.copy(.82f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(Modifier.align(Alignment.TopStart).padding(15.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            "Season" to seasonal,
                            "Feels like" to temperature,
                            "Sunlight" to solar,
                            "Particles" to particles
                        ).forEach { (label, enabled) ->
                            Surface(shape = CircleShape, color = Color(0x66101A30), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(if (enabled) .42f else .12f))) {
                                Text(label, Modifier.padding(horizontal = 8.dp, vertical = 5.dp), color = Color.White.copy(if (enabled) .95f else .38f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("INTENSITY", color = Color.White.copy(.56f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AtmosphereIntensity.entries.forEach { option ->
                    val chosen = intensity == option
                    Surface(Modifier.weight(1f).clickable { onIntensity(option) }, shape = RoundedCornerShape(14.dp), color = if (chosen) Color.White.copy(.18f) else Color.White.copy(.05f), border = androidx.compose.foundation.BorderStroke(if (chosen) 2.dp else 1.dp, Color.White.copy(if (chosen) .70f else .13f))) {
                        Text(option.name, Modifier.padding(vertical = 11.dp), color = Color.White, textAlign = TextAlign.Center, fontSize = 10.sp, fontWeight = if (chosen) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), color = Color.White.copy(.07f), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    AtmosOnboardingToggle("Seasonal colour", "Spring, summer, autumn, winter and tropical seasons.", seasonal) { seasonal = it; preferences.seasonalAtmosphere = it }
                    AtmosOnboardingToggle("Feels-like temperature", "Warmth, chill, frost and heat shimmer.", temperature) { temperature = it; preferences.temperatureAtmosphere = it }
                    AtmosOnboardingToggle("Sunlight and gradient", "Living hero colour from dawn through night.", solar && ambient) { enabled -> solar = enabled; ambient = enabled; preferences.solarAtmosphere = enabled; preferences.ambientAtmosphere = enabled }
                    AtmosOnboardingToggle("Seasonal particles", "Blossom, motes, leaves and winter crystals.", particles) { particles = it; preferences.seasonalParticles = it }
                }
            }
            Text("Everything can be fine-tuned later in Settings → Atmos system.", Modifier.fillMaxWidth().padding(top = 14.dp), color = Color.White.copy(.52f), fontSize = 10.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(18.dp))
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF131A32))) { Text("Start using Atmos", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun AtmosOnboardingToggle(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(subtitle, color = Color.White.copy(.62f), fontSize = 9.sp, lineHeight = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun AtmosSelectionTick(selected: Boolean, modifier: Modifier = Modifier, darkInk: Boolean = false) {
    AnimatedVisibility(
        visible = selected,
        modifier = modifier,
        enter = scaleIn(tween(220, easing = FastOutSlowInEasing)) + fadeIn(tween(160)),
        exit = scaleOut(tween(140)) + fadeOut(tween(120))
    ) {
        Surface(
            Modifier.size(25.dp),
            shape = CircleShape,
            color = if (darkInk) Color(0xFF20314D) else Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, if (darkInk) Color.White.copy(.32f) else Color(0xFFBFD9FF))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("✓", color = if (darkInk) Color.White else Color(0xFF29476D), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun ThemePreviewCard(dark: Boolean, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val sky = if (dark) listOf(Color(0xFF101B31), Color(0xFF293B5A)) else listOf(Color(0xFFBEE4FF), Color(0xFFFFE0C7))
    val ink = if (dark) Color.White else Color(0xFF20314D)
    Surface(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(24.dp), color = Color.Transparent, border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Color(0xFF77BFFF) else ink.copy(.18f))) {
        Box(Modifier.height(112.dp).background(Brush.linearGradient(sky)).padding(13.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(if (dark) Color(0xFFFFF3C4) else Color(0xFFFFB85A), radius = 13.dp.toPx(), center = Offset(size.width - 19.dp.toPx(), 18.dp.toPx()))
                drawRoundRect(ink.copy(.14f), Offset(0f,size.height*.56f), Size(size.width,size.height*.31f), CornerRadius(14.dp.toPx()))
                drawLine(ink.copy(.75f), Offset(12.dp.toPx(),size.height*.72f), Offset(size.width*.62f,size.height*.72f), strokeWidth=3.dp.toPx(), cap=StrokeCap.Round)
            }
            Text(if (dark) "Dark" else "Light", color=ink, fontWeight=FontWeight.Bold, fontSize=15.sp)
            AtmosSelectionTick(selected, Modifier.align(Alignment.TopEnd), darkInk = !dark)
        }
    }
}

@Composable
private fun LayoutPreviewCard(
    title: String,
    subtitle: String,
    immersive: Boolean,
    selected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (selected) Color.White else Color.White.copy(.28f)
    Surface(
        modifier = Modifier.fillMaxWidth().height(202.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(28.dp),
        color = if (selected) Color(0xFF344F78) else Color(0xFF233753),
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, borderColor)
    ) {
        Row(Modifier.fillMaxSize().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.width(112.dp).fillMaxHeight().clip(RoundedCornerShape(22.dp))
                    .background(
                        if (immersive) Brush.verticalGradient(
                            listOf(Color(0xFFFFB14E), Color(0xFFEE716D), Color(0xFF263247), Color(0xFF080D17)),
                            endY = 520f
                        ) else Brush.verticalGradient(
                            listOf(Color(0xFFFFB14E), Color(0xFFEE8A72), Color(0xFF9FD8E2)),
                            endY = 520f
                        )
                    )
            ) {
                if (immersive) {
                    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 9.dp)) {
                        Text("Sydney", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("New South Wales", color = Color.White.copy(.68f), fontSize = 5.sp)
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.width(38.dp).height(12.dp).clip(CircleShape).background(Color(0xFFD9ECFF)))
                        Text("19°", Modifier.padding(top = 6.dp), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Mostly sunny", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Canvas(Modifier.fillMaxWidth().height(29.dp)) {
                            val path = Path().apply { moveTo(0f, size.height * .72f); lineTo(size.width * .28f, size.height * .50f); lineTo(size.width * .55f, size.height * .62f); lineTo(size.width, size.height * .22f) }
                            drawPath(path, Color.White.copy(.9f), style = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round))
                        }
                        Box(Modifier.fillMaxWidth().height(16.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x66101A30)))
                    }
                } else {
                    Column(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 9.dp)) {
                        Text("Sydney", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("New South Wales", color = Color.White.copy(.68f), fontSize = 5.sp)
                        Spacer(Modifier.height(9.dp))
                        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(.16f)).padding(9.dp)) {
                            Column {
                                Box(Modifier.width(35.dp).height(10.dp).clip(CircleShape).background(Color(0xFFD9ECFF)))
                                Text("19°", Modifier.padding(top = 5.dp), color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Mostly sunny", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.weight(1f))
                                Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(Color(0x66101A30)))
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Box(Modifier.fillMaxWidth().height(25.dp).clip(RoundedCornerShape(10.dp)).background(Color(0x44101A30)))
                    }
                }
                AtmosSelectionTick(selected, Modifier.align(Alignment.TopEnd).padding(7.dp))
            }
            Column(Modifier.weight(1f).padding(start = 16.dp)) {
                Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, Modifier.padding(top = 6.dp), color = Color.White.copy(.74f), fontSize = 11.sp, lineHeight = 16.sp)
                Spacer(Modifier.weight(1f))
                Text(if (selected) "Selected" else "Tap to choose", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomePage(
    currentWeather: WeatherState,
    weatherCache: Map<String, WeatherState>,
    savedPlaces: List<Place>,
    currentPlace: Place,
    refreshing: Boolean,
    density: DensityChoice,
    preferences: AtmosPreferences,
    temperatureUnit: TemperatureUnit,
    conditionAnimations: Boolean,
    homeLayout: HomeLayout,
    locationTransition: LocationTransition,
    onTemperatureUnit: (TemperatureUnit) -> Unit,
    onRefresh: () -> Unit,
    onSelectPlace: (Place) -> Unit,
    onSavedPlacesChanged: (List<Place>) -> Unit,
    onAddLocation: () -> Unit,
    onImmersiveHeroVisible: (Boolean) -> Unit,
    onPage: (Page) -> Unit
) {
    // Recreate the pager whenever the saved-page structure changes. This avoids a
    // transient out-of-range pager position when the final saved location is removed.
    val pagerStructureKey = remember(savedPlaces) {
        savedPlaces.mapIndexed { index, place -> place.pagerKey(index) }
    }
    key(pagerStructureKey) {
        val addLocationPage = savedPlaces.size
        val selectedPage = remember(savedPlaces, currentPlace, addLocationPage) {
            savedPlaces.indexOfFirst { it.matches(currentPlace) }
                .takeIf { it >= 0 }
                ?: addLocationPage
        }
        val pagerState = rememberPagerState(
            initialPage = selectedPage.coerceIn(0, addLocationPage),
            pageCount = { savedPlaces.size + 1 }
        )

        LaunchedEffect(currentPlace, pagerStructureKey) {
            val target = savedPlaces.indexOfFirst { it.matches(currentPlace) }
                .takeIf { it >= 0 }
                ?: addLocationPage
            if (target != pagerState.currentPage) pagerState.scrollToPage(target)
        }

        LaunchedEffect(pagerState, pagerStructureKey) {
            snapshotFlow { pagerState.currentPage to pagerState.isScrollInProgress }
                .collect { (selected, isScrolling) ->
                    if (!isScrolling) {
                        savedPlaces.getOrNull(selected)?.let(onSelectPlace)
                    }
                    // The final page is deliberately the add-location page. It remains
                    // visible even when there are no saved locations at all.
                }
        }

        val pagerScope = rememberCoroutineScope()
        Box(Modifier.fillMaxSize()) {
            if (locationTransition == LocationTransition.Immersive && homeLayout == HomeLayout.Immersive) {
                ImmersiveLocationAtmosphere(
                    pagerState = pagerState,
                    savedPlaces = savedPlaces,
                    weatherCache = weatherCache,
                    preferences = preferences,
                    conditionAnimations = conditionAnimations,
                    modifier = Modifier.fillMaxSize()
                )
            }
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                pageSpacing = 12.dp,
                beyondViewportPageCount = 1,
                key = { index ->
                    savedPlaces.getOrNull(index)?.pagerKey(index) ?: "add-location-page"
                }
            ) { index ->
                // Let HorizontalPager perform only its native translation. The previous
                // scale/fade effect read currentPageOffsetFraction during composition,
                // which caused both large forecast pages to recompose on every drag frame.
                Box(Modifier.fillMaxSize()) {
                    val place = savedPlaces.getOrNull(index)
                    if (place == null) {
                        AddLocationPage(index, savedPlaces.size + 1, onAddLocation)
                    } else {
                        val cachedWeather = weatherCache[place.cacheKey()]
                        val pageWeather = remember(place, cachedWeather) {
                            cachedWeather ?: WeatherState(place, fallbackDays, emptyList(), Observation(), false)
                        }
                        ForecastPage(
                            weather = pageWeather,
                            refreshing = refreshing && place.matches(currentPlace),
                            density = density,
                            preferences = preferences,
                            temperatureUnit = temperatureUnit,
                            // Keep the adaptive atmosphere alive while dragging between locations.
                            // Adjacent pages are precomposed, so their continuous animation clocks
                            // remain active and the two atmospheres naturally cross-fade with the
                            // pager instead of stopping and restarting mid-swipe.
                            conditionAnimations = conditionAnimations,
                            homeLayout = homeLayout,
                            immersiveScene = locationTransition == LocationTransition.Immersive && homeLayout == HomeLayout.Immersive,
                            onTemperatureUnit = onTemperatureUnit,
                            onRefresh = onRefresh,
                            onSavedPlacesChanged = onSavedPlacesChanged,
                            isActivePage = index == pagerState.currentPage,
                            onImmersiveHeroVisible = onImmersiveHeroVisible,
                            forecastPage = index,
                            forecastPageCount = savedPlaces.size + 1,
                            onPage = onPage
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = pagerState.currentPage > 0,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut(),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(
                        top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 12.dp,
                        end = 19.dp
                    )
            ) {
                AtmosHomeButton {
                    pagerScope.launch { pagerState.animateScrollToPage(0) }
                }
            }
        }
    }
}


@Composable
private fun AtmosHomeButton(onClick: () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    Surface(
        modifier = Modifier
            .size(48.dp)
            .atmosPress(onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .94f),
        shadowElevation = 10.dp,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.primary.copy(alpha = .30f)
        )
    ) {
        Canvas(Modifier.fillMaxSize().padding(12.dp)) {
            val stroke = 2.2.dp.toPx()
            val roof = Path().apply {
                moveTo(size.width * .12f, size.height * .48f)
                lineTo(size.width * .50f, size.height * .15f)
                lineTo(size.width * .88f, size.height * .48f)
            }
            drawPath(
                path = roof,
                color = accent,
                style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            val body = Path().apply {
                moveTo(size.width * .24f, size.height * .43f)
                lineTo(size.width * .24f, size.height * .84f)
                lineTo(size.width * .76f, size.height * .84f)
                lineTo(size.width * .76f, size.height * .43f)
            }
            drawPath(
                path = body,
                color = accent,
                style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            drawRoundRect(
                color = accent.copy(alpha = .22f),
                topLeft = Offset(size.width * .43f, size.height * .58f),
                size = Size(size.width * .14f, size.height * .26f),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
        }
    }
}

private fun Place.matches(other: Place): Boolean =
    if (current && other.current) true else sameSavedPlace(this, other)

private fun Place.pagerKey(index: Int): String =
    // A live location's coordinates can change on every foreground refresh, but it is
    // still the same first pager card. Its stable key prevents HorizontalPager from
    // being destroyed and recreated while GPS/weather data is updating.
    if (current) "location-current" else "location-$index-${name.lowercase(Locale.ROOT)}-${state.lowercase(Locale.ROOT)}"

private fun interpolateNullableDouble(from: Double?, to: Double?, progress: Float): Double? = when {
    from == null -> to
    to == null -> from
    else -> from + (to - from) * progress
}

@Composable
private fun ImmersiveLocationAtmosphere(
    pagerState: PagerState,
    savedPlaces: List<Place>,
    weatherCache: Map<String, WeatherState>,
    preferences: AtmosPreferences,
    conditionAnimations: Boolean,
    modifier: Modifier = Modifier
) {
    // Drive the atmosphere from the pager's continuous physical position. This begins
    // changing on the very first drag pixel and remains continuous when currentPage
    // advances halfway through a swipe.
    val pagePosition = (pagerState.currentPage + pagerState.currentPageOffsetFraction)
        .coerceIn(0f, (savedPlaces.size - 1).coerceAtLeast(0).toFloat())
    val lowerIndex = floor(pagePosition).toInt().coerceIn(0, (savedPlaces.size - 1).coerceAtLeast(0))
    val upperIndex = (lowerIndex + 1).coerceIn(0, (savedPlaces.size - 1).coerceAtLeast(0))
    val progress = (pagePosition - lowerIndex).coerceIn(0f, 1f)
    val currentPlace = savedPlaces.getOrNull(lowerIndex)
    val targetPlace = savedPlaces.getOrNull(upperIndex) ?: currentPlace
    if (currentPlace == null || targetPlace == null) {
        Box(modifier.background(MaterialTheme.colorScheme.background))
        return
    }
    val from = weatherCache[currentPlace.cacheKey()] ?: WeatherState(currentPlace, fallbackDays, emptyList(), Observation(), false)
    val to = weatherCache[targetPlace.cacheKey()] ?: WeatherState(targetPlace, fallbackDays, emptyList(), Observation(), false)
    val fromPalette = rememberSolarAwarePalette(from.days.first().icon, from.place)
    val toPalette = rememberSolarAwarePalette(to.days.first().icon, to.place)
    val palette = blendPalette(fromPalette, toPalette, progress)
    val lerpInt: (Int?, Int?) -> Int? = { a, b ->
        when {
            a == null -> b
            b == null -> a
            else -> (a + (b - a) * progress).roundToInt()
        }
    }
    val blendedObservation = Observation(
        temp = lerpInt(from.observation.temp, to.observation.temp),
        feels = lerpInt(from.observation.feels, to.observation.feels),
        humidity = lerpInt(from.observation.humidity, to.observation.humidity),
        wind = lerpInt(from.observation.wind, to.observation.wind),
        direction = if (progress < .5f) from.observation.direction else to.observation.direction,
        gust = lerpInt(from.observation.gust, to.observation.gust),
        pressure = interpolateNullableDouble(from.observation.pressure, to.observation.pressure, progress),
        rainSince9 = interpolateNullableDouble(from.observation.rainSince9, to.observation.rainSince9, progress),
        station = if (progress < .5f) from.observation.station else to.observation.station
    )
    val fromCondition = from.days.first().condition
    val toCondition = to.days.first().condition
    val sceneTemp = blendedObservation.feels ?: blendedObservation.temp ?: 18
    Box(modifier) {
        LivingHeroGradient(
            palette = palette,
            observation = blendedObservation,
            condition = if (progress < .5f) fromCondition else toCondition,
            enabled = conditionAnimations && preferences.ambientAtmosphere && preferences.atmosphereIntensity != AtmosphereIntensity.Off,
            intensity = preferences.atmosphereIntensity,
            modifier = Modifier.fillMaxSize()
        )
        // Condition-specific particles, haze, frost and shimmer cross-fade from the
        // first swipe movement instead of switching abruptly at the midpoint.
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = 1f - progress }) {
            TemperatureAtmosphereEffect(
                temperatureC = from.observation.feels ?: from.observation.temp ?: sceneTemp,
                place = from.place,
                condition = fromCondition,
                observation = from.observation,
                enabled = conditionAnimations,
                preferences = preferences,
                modifier = Modifier.fillMaxSize()
            )
        }
        if (upperIndex != lowerIndex) {
            Box(Modifier.fillMaxSize().graphicsLayer { alpha = progress }) {
                TemperatureAtmosphereEffect(
                    temperatureC = to.observation.feels ?: to.observation.temp ?: sceneTemp,
                    place = to.place,
                    condition = toCondition,
                    observation = to.observation,
                    enabled = conditionAnimations,
                    preferences = preferences,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color.Transparent, Color.Transparent, MaterialTheme.colorScheme.background.copy(alpha = .30f), MaterialTheme.colorScheme.background),
                    startY = 0f,
                    endY = 2100f
                )
            )
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ForecastPage(
    weather: WeatherState,
    refreshing: Boolean,
    density: DensityChoice,
    preferences: AtmosPreferences,
    temperatureUnit: TemperatureUnit,
    conditionAnimations: Boolean,
    homeLayout: HomeLayout,
    immersiveScene: Boolean = false,
    onTemperatureUnit: (TemperatureUnit) -> Unit,
    onRefresh: () -> Unit,
    onSavedPlacesChanged: (List<Place>) -> Unit,
    isActivePage: Boolean,
    onImmersiveHeroVisible: (Boolean) -> Unit,
    forecastPage: Int,
    forecastPageCount: Int,
    onPage: (Page) -> Unit
) {
    val day = weather.days.first()
    val palette = rememberSolarAwarePalette(day.icon, weather.place)
    val padding = if (density == DensityChoice.Compact) 12.dp else 17.dp
    val appBackground = MaterialTheme.colorScheme.background
    val pageBackground = remember(palette, appBackground) {
        Brush.verticalGradient(
            colors = listOf(
                palette.top.copy(alpha = .74f),
                palette.bottom.copy(alpha = .50f),
                palette.secondary.copy(alpha = .34f),
                palette.secondary.copy(alpha = .16f),
                appBackground
            ),
            endY = 1950f
        )
    }
    val homeScrollState = rememberScrollState()
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 92.dp
    val cardSpacing = if (density == DensityChoice.Compact) 11.dp else 15.dp
    val immersiveHeroThresholdPx = with(LocalDensity.current) { LocalConfiguration.current.screenHeightDp.dp.toPx() * .72f }

    // A forecast reveal should represent genuinely new weather data, not the pager
    // composing an adjacent location. Initial composition starts fully presented and
    // only the currently visible page animates when its update timestamp changes.
    var presentedUpdateTime by remember(weather.place.cacheKey()) { mutableStateOf(weather.updated.time) }
    var dataPresented by remember(weather.place.cacheKey()) { mutableStateOf(true) }
    LaunchedEffect(weather.updated.time, weather.place.cacheKey(), isActivePage) {
        if (isActivePage && weather.updated.time != presentedUpdateTime) {
            presentedUpdateTime = weather.updated.time
            dataPresented = false
            delay(35)
            dataPresented = true
        } else if (!dataPresented) {
            dataPresented = true
        }
    }
    val contentAlpha by animateFloatAsState(if (dataPresented) 1f else .84f, tween(420), label = "forecastDataAlpha")
    val contentLift by animateFloatAsState(if (dataPresented) 0f else 14f, tween(520), label = "forecastDataLift")

    LaunchedEffect(homeLayout, isActivePage, homeScrollState, immersiveHeroThresholdPx) {
        if (homeLayout != HomeLayout.Immersive || !isActivePage) {
            if (isActivePage) onImmersiveHeroVisible(false)
        } else {
            snapshotFlow { homeScrollState.value < immersiveHeroThresholdPx }
                .collect { visible -> onImmersiveHeroVisible(visible) }
        }
    }

    PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = onRefresh,
        modifier = Modifier.fillMaxSize(),
        indicator = {}
    ) {
        // The home feed is deliberately composed in full rather than lazily recycled.
        // There are only a handful of cards, so paying the composition cost once at launch
        // avoids item creation/disposal and prefetch work while the user is scrolling.
        Column(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = contentAlpha; translationY = contentLift }
                .background(if (immersiveScene) Color.Transparent else Color.Transparent)
                .then(if (immersiveScene) Modifier else Modifier.background(pageBackground))
                .verticalScroll(homeScrollState)
                .padding(bottom = bottomInset),
            verticalArrangement = Arrangement.spacedBy(if (homeLayout == HomeLayout.Immersive) 0.dp else cardSpacing)
        ) {
            if (homeLayout == HomeLayout.Immersive) {
                HeroCard(
                    weather, palette, temperatureUnit, conditionAnimations,
                    forecastPage, forecastPageCount, onPage, onTemperatureUnit, { onPage(Page.Locations) },
                    animateTemperature = isActivePage,
                    refreshing = refreshing,
                    immersive = true,
                    place = weather.place,
                    history = preferences.observationHistory(weather.place),
                    topInset = topInset,
                    renderAtmosphere = !immersiveScene,
                    darkLowerSection = immersiveScene
                )
                Spacer(Modifier.height(cardSpacing))
            } else {
                Column(
                    Modifier.fillMaxWidth().padding(start = padding, end = padding, top = topInset),
                    verticalArrangement = Arrangement.spacedBy(cardSpacing)
                ) {
                    LocationHeader(weather.place) { onPage(Page.Locations) }
                    AnimatedVisibility(visible = refreshing, enter = fadeIn(tween(180)), exit = fadeOut(tween(180))) {
                        AtmosRefreshIndicator(palette, compact = true)
                    }
                    HeroCard(weather, palette, temperatureUnit, conditionAnimations, forecastPage, forecastPageCount, onPage, onTemperatureUnit, { onPage(Page.Locations) }, animateTemperature = isActivePage, refreshing = false, history = preferences.observationHistory(weather.place), renderAtmosphere = !immersiveScene)
                }
                ScrollDownCue(palette, Modifier.padding(vertical = 8.dp))
            }
            Column(
                Modifier.fillMaxWidth().padding(horizontal = padding),
                verticalArrangement = Arrangement.spacedBy(cardSpacing)
            ) {
                Box(Modifier.graphicsLayer()) { AtAGlanceCard(weather, palette, temperatureUnit) }
                Box(Modifier.graphicsLayer()) { HourlyCard(weather.hours, day, weather.place, temperatureUnit, palette) }
                Box(Modifier.graphicsLayer()) { SevenDayCard(weather.days, temperatureUnit, palette) }
                Box(Modifier.graphicsLayer()) { PrecipitationCard(weather.hours, palette) }
                if (weather.warnings.isNotEmpty()) Box(Modifier.graphicsLayer()) { WarningCard(weather.warnings) }
                Box(Modifier.graphicsLayer()) { DetailCards(weather, preferences) }
                Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (weather.place.isAustralian()) "Weather data supplied by the Australian Bureau of Meteorology." else "International forecast data supplied by Open-Meteo.",
                        color = MaterialTheme.colorScheme.onSurface.copy(.66f),
                        fontSize = 10.sp
                    )
                    Text("Atmos was built by Josh Stanley", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp)
                    val context = LocalContext.current
                    Text("Contact Josh", Modifier.padding(top = 9.dp).clickable { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:Josh.stanley@me.com"))) }, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}


@Composable
private fun AtmosRefreshIndicator(palette: Palette, compact: Boolean = false) {
    val transition = rememberInfiniteTransition(label = "atmosRefresh")
    val phase by transition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(1_650, easing = LinearEasing)), label = "refreshPhase"
    )
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .88f),
        border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(alpha = .35f)),
        shadowElevation = if (compact) 2.dp else 8.dp
    ) {
        Row(Modifier.padding(horizontal = if (compact) 11.dp else 14.dp, vertical = if (compact) 7.dp else 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Canvas(Modifier.size(if (compact) 18.dp else 24.dp)) {
                val centre = Offset(size.width / 2f, size.height / 2f)
                repeat(3) { index ->
                    val angle = (phase * 360f + index * 120f) * PI.toFloat() / 180f
                    val radius = size.minDimension * .30f
                    drawCircle(
                        color = listOf(palette.top, palette.secondary, palette.accent)[index].copy(alpha = .86f),
                        radius = 2.4.dp.toPx(),
                        center = Offset(centre.x + cos(angle) * radius, centre.y + sin(angle) * radius)
                    )
                }
            }
            Text("Refreshing the atmosphere", Modifier.padding(start = 8.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AtmosPageBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val transition = rememberInfiniteTransition(label = "atmosPageBackground")
    val phase by transition.animateFloat(
        0f,
        1f,
        infiniteRepeatable(tween(36_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "pagePhase"
    )
    val start = Offset(phase * 420f, 0f)
    val end = Offset(1080f - phase * 260f, 1920f)
    Box(
        modifier.background(
            Brush.linearGradient(
                colors = listOf(
                    Color(0xFF040814),
                    Color(0xFF0A1530),
                    Color(0xFF16244A),
                    Color(0xFF291D4A),
                    Color(0xFF102A43),
                    Color(0xFF050A17)
                ),
                start = start,
                end = end
            )
        )
    ) { content() }
}

@Composable
private fun Modifier.atmosPress(onClick: () -> Unit): Modifier {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (pressed) .975f else 1f,
        spring(dampingRatio = .72f, stiffness = 520f),
        label = "atmosPressScale"
    )
    return graphicsLayer { scaleX = scale; scaleY = scale }
        .pointerInput(onClick) { detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false }, onTap = { onClick() }) }
}

@Composable
private fun AddLocationPage(page: Int, pageCount: Int, onAddLocation: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primary.copy(.18f), MaterialTheme.colorScheme.background))
        ).padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(38.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(.18f))
        ) {
            Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.15f)) {
                    Text("+", Modifier.padding(horizontal = 22.dp, vertical = 12.dp), fontSize = 38.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(22.dp))
                Text("Add another location", fontSize = 27.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text("Save a town or city, then swipe between forecasts from the home screen.", Modifier.padding(top = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(.68f), textAlign = TextAlign.Center, lineHeight = 20.sp)
                Button(onClick = onAddLocation, modifier = Modifier.padding(top = 24.dp).fillMaxWidth().height(52.dp)) {
                    Text("Choose a location", fontWeight = FontWeight.Bold)
                }
                ForecastPageIndicator(page, pageCount, Modifier.padding(top = 28.dp))
            }
        }
    }
}

@Composable
private fun ForecastPageIndicator(
    current: Int,
    count: Int,
    modifier: Modifier = Modifier,
    selectedColour: Color? = null,
    unselectedColour: Color? = null
) {
    val theme = MaterialTheme.colorScheme.primary
    val darkerTheme = Color(
        red = (theme.red * .58f).coerceIn(0f, 1f),
        green = (theme.green * .58f).coerceIn(0f, 1f),
        blue = (theme.blue * .58f).coerceIn(0f, 1f),
        alpha = 1f
    )
    val active = selectedColour ?: darkerTheme.copy(alpha = .88f)
    val inactive = unselectedColour ?: darkerTheme.copy(alpha = .46f)
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(count) { index ->
            val selected = index == current
            Box(
                Modifier
                    .height(7.dp)
                    .width(if (selected) 22.dp else 7.dp)
                    .clip(CircleShape)
                    .background(if (selected) active else inactive)
            )
        }
    }
}

@Composable
private fun LocationHeader(place: Place, onClick: () -> Unit) {
    val liveAccent = MaterialTheme.colorScheme.primary
    val displayPlace = remember(place) {
        if (place.current) places.minByOrNull { distanceSquared(it.latitude, it.longitude, place.latitude, place.longitude) } ?: place else place
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(horizontal = 5.dp, vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(displayPlace.name, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            if (place.current) {
                Surface(Modifier.padding(start = 9.dp), shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.16f), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(.42f))) {
                    Row(Modifier.padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Canvas(Modifier.size(12.dp)) {
                            val marker = Path().apply { moveTo(size.width*.14f,size.height*.46f); lineTo(size.width*.86f,size.height*.12f); lineTo(size.width*.59f,size.height*.88f); lineTo(size.width*.46f,size.height*.57f); close() }
                            drawPath(marker, liveAccent)
                        }
                        Text("LIVE", Modifier.padding(start = 5.dp), color = MaterialTheme.colorScheme.primary, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                }
            }
        }
        Text(displayPlace.state, color = MaterialTheme.colorScheme.onSurface.copy(.68f), fontSize = 13.sp)
    }
}


private data class NaturalParticle(
    val startX: Float,
    val startY: Float,
    val driftX: Float,
    val driftY: Float,
    val noisePhaseX: Float,
    val noisePhaseY: Float,
    val noiseFrequencyX: Float,
    val noiseFrequencyY: Float,
    val turbulence: Float,
    val rotationPhase: Float,
    val rotationSpeed: Float,
    val lifeOffset: Float,
    val lifeSpeed: Float,
    val depth: Float
)

@Composable
private fun TemperatureAtmosphereEffect(
    temperatureC: Int,
    place: Place,
    condition: String,
    observation: Observation,
    enabled: Boolean,
    preferences: AtmosPreferences,
    modifier: Modifier = Modifier
) {
    val intensity = preferences.atmosphereIntensity
    if (!enabled || intensity == AtmosphereIntensity.Off) return

    val strength = when (intensity) {
        AtmosphereIntensity.Off -> 0f
        AtmosphereIntensity.Subtle -> .72f
        AtmosphereIntensity.Balanced -> 1f
        AtmosphereIntensity.Immersive -> 1.42f
    }
    val transition = rememberInfiniteTransition(label = "adaptiveAtmosphere")
    val drift by transition.animateFloat(
        0f,
        1f,
        infiniteRepeatable(tween(3_600_000, easing = LinearEasing), RepeatMode.Restart),
        label = "ambientDrift"
    )
    val pulse by transition.animateFloat(.76f, 1f, infiniteRepeatable(tween(7_000, easing = LinearEasing), RepeatMode.Reverse), label = "ambientPulse")
    val season = seasonName(place)
    val cloudy = condition.contains("cloud", true) || condition.contains("overcast", true)
    val wind = (observation.wind ?: 8).coerceIn(0, 70)
    val humidity = (observation.humidity ?: 55).coerceIn(0, 100)
    val pressure = (observation.pressure ?: 1013.0).coerceIn(970.0, 1045.0)
    // Meteorological direction describes where the wind comes from. Particles travel
    // towards the opposite bearing, with no directional push at 10 km/h or below.
    val windFromDegrees = windDirectionDegrees(observation.direction)
    val travelRadians = Math.toRadians((windFromDegrees + 180f).toDouble())
    val windDirectionX = kotlin.math.sin(travelRadians).toFloat()
    val windDirectionY = -kotlin.math.cos(travelRadians).toFloat()
    val windInfluence = when {
        wind <= 10 -> 0f
        wind < 20 -> smoothStep((wind - 10f) / 10f) * .55f
        wind < 40 -> .55f + smoothStep((wind - 20f) / 20f) * .55f
        else -> 1.10f + ((wind - 40f) / 30f).coerceIn(0f, 1f) * .35f
    }
    val windFactor = windInfluence
    val moisture = humidity / 100f
    val instability = ((1015.0 - pressure) / 45.0).toFloat().coerceIn(0f, 1f)
    val particleCount = when (intensity) {
        AtmosphereIntensity.Off -> 0
        AtmosphereIntensity.Subtle -> 10
        AtmosphereIntensity.Balanced -> 18
        AtmosphereIntensity.Immersive -> 28
    }
    val naturalParticles = remember(season, particleCount, place.name) {
        val random = kotlin.random.Random((season.hashCode() * 31) xor place.name.hashCode())
        List(particleCount) {
            NaturalParticle(
                startX = random.nextFloat(),
                startY = random.nextFloat(),
                driftX = random.nextFloat() * .010f - .005f,
                driftY = random.nextFloat() * .004f - .002f,
                noisePhaseX = random.nextFloat() * 6.28318f,
                noisePhaseY = random.nextFloat() * 6.28318f,
                noiseFrequencyX = .16f + random.nextFloat() * .27f,
                noiseFrequencyY = .12f + random.nextFloat() * .23f,
                turbulence = .012f + random.nextFloat() * .025f,
                rotationPhase = random.nextFloat() * 6.28318f,
                rotationSpeed = (random.nextFloat() * 2f - 1f) * (.22f + random.nextFloat() * .38f),
                lifeOffset = random.nextFloat(),
                lifeSpeed = .013f + random.nextFloat() * .013f,
                depth = random.nextFloat()
            )
        }
    }

    Canvas(modifier) {
        // Ambient motion now lives in the hero gradient. Keep only a restrained,
        // weather-driven veil here so particles and thermal effects remain clean.
        if (preferences.ambientAtmosphere) {
            val hazeAlpha = (.012f + moisture * .035f + instability * .018f) * strength
            drawRect(
                Brush.linearGradient(
                    listOf(Color.White.copy(hazeAlpha * pulse), Color.Transparent, Color(0xFF8FC7E8).copy(hazeAlpha * .38f)),
                    Offset.Zero,
                    Offset(size.width, size.height)
                )
            )
        }

        if (preferences.seasonalAtmosphere) {
            val seasonal = when (season) {
                "Spring" -> Color(0xFF91E6B1)
                "Summer" -> Color(0xFFFFD36A)
                "Autumn" -> Color(0xFFFFA45B)
                "Winter" -> Color(0xFF8DD9FF)
                "Wet season" -> Color(0xFF63D9C4)
                else -> Color(0xFFFFD98A)
            }
            drawRect(Brush.radialGradient(listOf(seasonal.copy(alpha = .11f * strength * pulse), Color.Transparent), center = Offset(size.width * .82f, size.height * .12f), radius = size.minDimension * .82f))
        }

        if (preferences.temperatureAtmosphere) when {
            temperatureC <= 0 && preferences.coldFrost -> {
                drawRect(Brush.radialGradient(listOf(Color(0x4439C6FF).copy(alpha = .25f * strength), Color.Transparent), center = Offset(size.width * .18f, size.height * .12f), radius = size.minDimension * .75f))
                drawRect(Brush.linearGradient(listOf(Color.White.copy(.075f * pulse * strength), Color.Transparent, Color.White.copy(.035f * strength)), Offset.Zero, Offset(size.width, size.height * .55f)))
            }
            temperatureC < 8 && preferences.coldFrost -> drawRect(Brush.radialGradient(listOf(Color(0x3039B9FF).copy(alpha = .16f * strength), Color.Transparent), center = Offset(size.width * .22f, size.height * .18f), radius = size.minDimension * .82f))
            temperatureC >= 40 -> drawRect(Brush.radialGradient(listOf(Color(0x55FF8A32).copy(alpha = .30f * pulse * strength), Color.Transparent), center = Offset(size.width * .72f, size.height * .16f), radius = size.minDimension * .9f))
            temperatureC >= 32 -> drawRect(Brush.radialGradient(listOf(Color(0x42FFB24A).copy(alpha = .24f * pulse * strength), Color.Transparent), center = Offset(size.width * .76f, size.height * .12f), radius = size.minDimension * .85f))
            temperatureC >= 25 -> drawRect(Brush.radialGradient(listOf(Color(0x2CFFD06A).copy(alpha = .15f * pulse * strength), Color.Transparent), center = Offset(size.width * .78f, size.height * .14f), radius = size.minDimension * .75f))
            temperatureC in 8..15 -> drawRect(Brush.radialGradient(listOf(Color(0x1E78D7FF).copy(alpha = .11f * strength), Color.Transparent), center = Offset(size.width * .16f, size.height * .20f), radius = size.minDimension * .85f))
        }

        if (preferences.heatShimmer && temperatureC >= 32) {
            val count = if (intensity == AtmosphereIntensity.Immersive) 6 else 4
            repeat(count) { index ->
                val y = size.height * (.62f + index * .052f)
                val wave = kotlin.math.sin((drift * 6.283f) + index * .8f) * (if (temperatureC >= 40) 10f else 6f)
                drawLine(Color(0xFFFFD28A).copy(alpha = .045f * strength), Offset(size.width * .10f, y + wave), Offset(size.width * .92f, y - wave), strokeWidth = 1.7f)
            }
        }

        if (preferences.seasonalParticles) {
            val particleColor = when (season) {
                "Spring" -> Color(0xFFFFD9EA)
                "Summer" -> Color(0xFFFFD77A)
                "Autumn" -> Color(0xFFFF9A4D)
                "Winter" -> Color(0xFFE4F7FF)
                "Wet season" -> Color(0xFFAEFFF0)
                else -> Color.Transparent
            }
            if (particleColor != Color.Transparent) {
                val baseAlpha = when (intensity) {
                    AtmosphereIntensity.Off -> 0f
                    AtmosphereIntensity.Subtle -> .19f
                    AtmosphereIntensity.Balanced -> .28f
                    AtmosphereIntensity.Immersive -> .38f
                }
                val naturalTime = drift * 3600f
                naturalParticles.forEachIndexed { index, particle ->
                    // Each particle has independent velocity, turbulence, lifetime and rotation.
                    // Two non-matching noise waves create smooth wandering without a visible loop.
                    val noiseX = kotlin.math.sin(naturalTime * particle.noiseFrequencyX + particle.noisePhaseX) * .62f +
                        kotlin.math.sin(naturalTime * particle.noiseFrequencyX * .417f + particle.noisePhaseY) * .38f
                    val noiseY = kotlin.math.sin(naturalTime * particle.noiseFrequencyY + particle.noisePhaseY) * .58f +
                        kotlin.math.cos(naturalTime * particle.noiseFrequencyY * .361f + particle.noisePhaseX) * .42f
                    val gustWave = kotlin.math.max(0f, kotlin.math.sin(naturalTime * .071f + particle.noisePhaseX)).let { it * it }
                    val gustStrength = gustWave * windFactor * (.00070f + particle.depth * .00055f)
                    // Above 10 km/h, directional travel becomes visible. At 20 km/h and
                    // beyond, particles clearly cross the hero while preserving turbulence.
                    val directionalSpeed = when {
                        windInfluence <= 0f -> 0f
                        wind < 20 -> .00115f + windInfluence * .00235f
                        else -> .00310f + (windInfluence - .55f).coerceAtLeast(0f) * .00410f
                    } * (.78f + particle.depth * .44f)
                    val windTravel = (directionalSpeed + gustStrength) * naturalTime
                    val xNorm = particle.startX + particle.driftX * naturalTime + windDirectionX * windTravel +
                        noiseX * particle.turbulence * (1f + windFactor * .32f)
                    val seasonalLift = when (season) {
                        "Summer" -> -.00030f
                        "Winter" -> -.00005f
                        "Autumn" -> .00020f
                        "Spring" -> .00008f
                        else -> .00003f
                    }
                    val yNorm = particle.startY + (particle.driftY + seasonalLift) * naturalTime +
                        windDirectionY * windTravel + noiseY * particle.turbulence * .76f
                    val x = size.width * ((xNorm % 1f + 1f) % 1f)
                    val y = size.height * ((yNorm % 1f + 1f) % 1f)

                    val phase = ((particle.lifeOffset + naturalTime * particle.lifeSpeed) % 1f + 1f) % 1f
                    val lifecycleAlpha = when {
                        phase < .18f -> (phase / .18f).coerceIn(0f, 1f)
                        phase > .78f -> ((1f - phase) / .22f).coerceIn(0f, 1f)
                        else -> 1f
                    }
                    val sizeScale = when (intensity) {
                        AtmosphereIntensity.Off -> 0f
                        AtmosphereIntensity.Subtle -> 1.08f
                        AtmosphereIntensity.Balanced -> 1.24f
                        AtmosphereIntensity.Immersive -> 1.46f
                    }
                    val depthScale = .82f + particle.depth * .72f
                    val radius = when (season) {
                        "Autumn" -> 2.45f + index % 4 * .78f
                        "Spring" -> 2.20f + index % 4 * .68f
                        "Summer" -> 1.75f + index % 4 * .52f
                        "Winter" -> 2.05f + index % 4 * .58f
                        else -> 1.75f + index % 4 * .52f
                    } * sizeScale * depthScale
                    val depthAlpha = .76f + particle.depth * .34f
                    val organicPulse = .88f + .12f * kotlin.math.sin(naturalTime * .41f + particle.rotationPhase)
                    val alpha = (baseAlpha * strength * depthAlpha * lifecycleAlpha * organicPulse).coerceIn(0f, .76f)
                    val center = Offset(x, y)
                    val rotation = particle.rotationPhase * 57.2958f + naturalTime * particle.rotationSpeed * when (season) {
                        "Autumn" -> 30f
                        "Spring" -> 19f
                        "Winter" -> 4f
                        else -> 8f
                    }

                    when (season) {
                        "Spring" -> rotate(rotation, center) {
                            drawOval(
                                color = particleColor.copy(alpha = alpha),
                                topLeft = Offset(x - radius * .72f, y - radius * 1.25f),
                                size = Size(radius * 1.44f, radius * 2.5f)
                            )
                            drawCircle(Color.White.copy(alpha = alpha * .28f), radius * .24f, center)
                        }
                        "Summer" -> {
                            drawCircle(particleColor.copy(alpha = alpha * .18f), radius * 2.15f, center)
                            drawCircle(particleColor.copy(alpha = alpha), radius * .72f, center)
                        }
                        "Autumn" -> rotate(rotation, center) {
                            val leaf = Path().apply {
                                moveTo(x, y - radius * 1.35f)
                                cubicTo(x + radius, y - radius * .55f, x + radius * .9f, y + radius * .55f, x, y + radius * 1.35f)
                                cubicTo(x - radius * .9f, y + radius * .55f, x - radius, y - radius * .55f, x, y - radius * 1.35f)
                                close()
                            }
                            drawPath(leaf, particleColor.copy(alpha = alpha))
                            drawLine(Color(0xFFFFE0B8).copy(alpha = alpha * .35f), Offset(x, y - radius), Offset(x, y + radius), strokeWidth = .65f)
                        }
                        "Winter" -> rotate(rotation, center) {
                            val crystal = Path().apply {
                                moveTo(x, y - radius * 1.25f)
                                lineTo(x + radius * .82f, y)
                                lineTo(x, y + radius * 1.25f)
                                lineTo(x - radius * .82f, y)
                                close()
                            }
                            drawPath(crystal, particleColor.copy(alpha = alpha * .72f))
                            drawLine(Color.White.copy(alpha = alpha), Offset(x, y - radius), Offset(x, y + radius), strokeWidth = .7f)
                            drawLine(Color.White.copy(alpha = alpha * .9f), Offset(x - radius * .65f, y), Offset(x + radius * .65f, y), strokeWidth = .7f)
                            if (index % 5 == 0) drawCircle(Color.White.copy(alpha = alpha * .48f), radius * 1.65f, center, style = Stroke(width = .55f))
                        }
                        else -> {
                            drawCircle(particleColor.copy(alpha = alpha * .22f), radius * 1.8f, center)
                            drawCircle(particleColor.copy(alpha = alpha), radius * .68f, center)
                        }
                    }
                }
            }
        }
    }
}

private fun temperatureGlow(temperatureC: Int): Color = when {
    temperatureC <= 0 -> Color(0xFF9CE8FF)
    temperatureC < 6 -> Color(0xFFB8EFFF)
    temperatureC >= 40 -> Color(0xFFFFA45C)
    temperatureC >= 32 -> Color(0xFFFFC56B)
    temperatureC >= 28 -> Color(0xFFFFDA8A)
    else -> Color.White
}

@Composable
private fun LivingHeroGradient(
    palette: Palette,
    observation: Observation,
    condition: String,
    enabled: Boolean,
    intensity: AtmosphereIntensity,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "livingHeroGradient")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 28_000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heroGradientPhase"
    )
    val breathe by transition.animateFloat(
        initialValue = .94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 10_000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heroGradientBreath"
    )
    val wind = (observation.wind ?: 8).coerceIn(0, 70)
    val motion = when (intensity) {
        AtmosphereIntensity.Off -> 0f
        AtmosphereIntensity.Subtle -> .45f
        AtmosphereIntensity.Balanced -> .72f
        AtmosphereIntensity.Immersive -> 1f
    }
    val cloudy = condition.contains("cloud", true) || condition.contains("overcast", true)
    val animatedTop by animateColorAsState(palette.top, tween(1_200, easing = FastOutSlowInEasing), label = "weatherTop")
    val animatedBottom by animateColorAsState(palette.bottom, tween(1_200, easing = FastOutSlowInEasing), label = "weatherBottom")
    val animatedSecondary by animateColorAsState(palette.secondary, tween(1_200, easing = FastOutSlowInEasing), label = "weatherSecondary")

    Canvas(modifier) {
        if (!enabled) {
            drawRect(Brush.linearGradient(listOf(animatedTop, animatedBottom, animatedSecondary)))
            return@Canvas
        }

        val windBias = (wind / 70f) * .12f
        val x = size.width * (.12f + phase * (.24f + windBias) * motion)
        val y = size.height * (.03f + (1f - phase) * .16f * motion)
        val endX = size.width * (.92f - phase * .16f * motion)
        val endY = size.height * (.86f + phase * .10f * motion)
        drawRect(
            Brush.linearGradient(
                colors = listOf(animatedTop, animatedSecondary, animatedBottom),
                start = Offset(x, y),
                end = Offset(endX, endY)
            )
        )

        val accentAlpha = (if (cloudy) .10f else .16f) * motion
        drawRect(
            Brush.radialGradient(
                colors = listOf(animatedSecondary.copy(alpha = accentAlpha), Color.Transparent),
                center = Offset(
                    size.width * (.72f - phase * .30f * motion),
                    size.height * (.18f + phase * .22f * motion)
                ),
                radius = size.minDimension * .95f * breathe
            )
        )
        drawRect(
            Brush.radialGradient(
                colors = listOf(animatedTop.copy(alpha = .10f * motion), Color.Transparent),
                center = Offset(
                    size.width * (.18f + phase * .22f * motion),
                    size.height * (.78f - phase * .18f * motion)
                ),
                radius = size.minDimension * .82f / breathe
            )
        )
    }
}

@Composable
private fun HeroCard(
    weather: WeatherState,
    palette: Palette,
    temperatureUnit: TemperatureUnit,
    conditionAnimations: Boolean,
    forecastPage: Int,
    forecastPageCount: Int,
    onPage: (Page) -> Unit,
    onTemperatureUnit: (TemperatureUnit) -> Unit,
    onOpenLocations: () -> Unit,
    animateTemperature: Boolean = true,
    refreshing: Boolean = false,
    immersive: Boolean = false,
    place: Place? = null,
    history: List<HistoricalObservation> = emptyList(),
    topInset: androidx.compose.ui.unit.Dp = 0.dp,
    renderAtmosphere: Boolean = true,
    darkLowerSection: Boolean = false
) {
    val day = weather.days.first()
    val temp = weather.observation.temp ?: day.high - 2
    val context = LocalContext.current
    val atmospherePreferences = remember(context) { AtmosPreferences(context) }
    val night = isNight(Date(), weather.place.timeZone())
    val heroHeight = if (immersive) LocalConfiguration.current.screenHeightDp.dp else 535.dp
    Card(
        Modifier.fillMaxWidth().height(heroHeight),
        shape = RoundedCornerShape(if (immersive) 0.dp else 38.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(Modifier.fillMaxSize()) {
            if (renderAtmosphere) {
                LivingHeroGradient(
                    palette = palette,
                    observation = weather.observation,
                    condition = day.condition,
                    enabled = conditionAnimations && atmospherePreferences.ambientAtmosphere && atmospherePreferences.atmosphereIntensity != AtmosphereIntensity.Off,
                    intensity = atmospherePreferences.atmosphereIntensity,
                    modifier = Modifier.fillMaxSize()
                )
                TemperatureAtmosphereEffect(
                    temperatureC = weather.observation.feels ?: temp,
                    place = weather.place,
                    condition = day.condition,
                    observation = weather.observation,
                    enabled = conditionAnimations,
                    preferences = atmospherePreferences,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Column(
                Modifier.fillMaxSize().padding(
                    start = if (immersive) 28.dp else 28.dp,
                    end = if (immersive) 28.dp else 28.dp,
                    top = if (immersive) topInset + 4.dp else 28.dp,
                    bottom = if (immersive) 28.dp else 28.dp
                )
            ) {
                if (immersive && place != null) {
                    val displayPlace = place
                    val overlayText = solarLegibleForeground(palette)
                    Row(Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onOpenLocations).padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(displayPlace.name, color = overlayText, fontSize = 31.sp, fontWeight = FontWeight.Bold)
                        if (place.current) {
                            Surface(
                                Modifier.padding(start = 10.dp),
                                shape = CircleShape,
                                color = overlayText.copy(alpha = .16f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, overlayText.copy(alpha = .46f))
                            ) {
                                Row(Modifier.padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Canvas(Modifier.size(12.dp)) {
                                        val marker = Path().apply {
                                            moveTo(size.width * .14f, size.height * .46f)
                                            lineTo(size.width * .86f, size.height * .12f)
                                            lineTo(size.width * .59f, size.height * .88f)
                                            lineTo(size.width * .46f, size.height * .57f)
                                            close()
                                        }
                                        drawPath(marker, overlayText)
                                    }
                                    Text("LIVE", Modifier.padding(start = 5.dp), color = overlayText, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                            }
                        }
                    }
                    Text(displayPlace.state, color = overlayText.copy(.74f), fontSize = 14.sp)
                    if (place.current && weather.observation.station.isNotBlank()) {
                        Text("Weather from ${weather.observation.station}", color = overlayText.copy(.62f), fontSize = 11.sp)
                    }
                    AnimatedVisibility(
                        visible = refreshing,
                        enter = fadeIn(tween(180)) + expandVertically(tween(220)),
                        exit = fadeOut(tween(180)) + shrinkVertically(tween(220))
                    ) {
                        Box(Modifier.padding(top = 10.dp, bottom = 2.dp)) {
                            AtmosRefreshIndicator(palette, compact = true)
                        }
                    }
                    Spacer(Modifier.height(if (refreshing) 12.dp else 22.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    SeasonPill(place = weather.place, onClick = { onPage(Page.Seasons) })
                    when {
                        !weather.place.isAustralian() -> CountryPill(weather.place, Date())
                        else -> AustralianTimePill(weather.place, Date())
                    }
                }
                Spacer(Modifier.height(18.dp))
                val heroText = solarLegibleForeground(palette)
                Text(localFormatter("EEEE d MMMM", weather.place).format(Date()), color = heroText.copy(.78f), fontWeight = FontWeight.Bold)
                val temperatureAccent = temperatureGlow(weather.observation.feels ?: temp)
                val animatedTemperature by animateIntAsState(
                    targetValue = displayTemperature(temp, temperatureUnit),
                    animationSpec = tween(durationMillis = if (animateTemperature) 560 else 0),
                    label = "heroTemperature"
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AnimatedContent(
                        targetState = temperatureUnit,
                        transitionSpec = {
                            if (animateTemperature) {
                                (fadeIn(tween(300)) + scaleIn(initialScale = .94f, animationSpec = tween(440))) togetherWith
                                    (fadeOut(tween(180)) + scaleOut(targetScale = 1.04f, animationSpec = tween(240)))
                            } else {
                                fadeIn(tween(0)) togetherWith fadeOut(tween(0))
                            }
                        },
                        label = "heroTemperatureUnit"
                    ) {
                        Text(
                            "$animatedTemperature°",
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable {
                                    onTemperatureUnit(if (temperatureUnit == TemperatureUnit.Celsius) TemperatureUnit.Fahrenheit else TemperatureUnit.Celsius)
                                }
                                .padding(end = 8.dp),
                            color = blendColor(heroText, temperatureAccent, if (temp <= 5 || temp >= 28) .16f else 0f),
                            fontSize = 90.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = (-5).sp
                        )
                    }
                    AnimatedVisibility(
                        visible = temperatureUnit == TemperatureUnit.Fahrenheit,
                        enter = fadeIn(tween(220)) + scaleIn(initialScale = .88f, animationSpec = tween(280)),
                        exit = fadeOut(tween(150)) + scaleOut(targetScale = .90f, animationSpec = tween(180))
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = heroText.copy(alpha = .15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, heroText.copy(alpha = .34f))
                        ) {
                            Text(
                                "°F",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                color = heroText,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = .5.sp
                            )
                        }
                    }
                }
                Text(nightCondition(day.condition), color = heroText, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Feels like ${displayTemperature(weather.observation.feels ?: temp - 1, temperatureUnit)}° · H ${displayTemperature(day.high, temperatureUnit)}° · L ${displayTemperature(day.low, temperatureUnit)}°", color = heroText.copy(.82f), fontSize = 16.sp)
                Text(conditionNarrative(weather), Modifier.padding(top = 22.dp).widthIn(max = 310.dp), color = heroText.copy(.84f), fontSize = 14.sp, lineHeight = 21.sp)
                if (immersive) {
                    ImmersiveDayChart(
                        hours = weather.hours,
                        temperatureUnit = temperatureUnit,
                        palette = palette,
                        place = place ?: weather.place,
                        history = history,
                        darkLowerSection = darkLowerSection,
                        modifier = Modifier.padding(top = 16.dp, bottom = 12.dp).weight(1f)
                    )
                } else {
                    Spacer(Modifier.weight(1f))
                }
                val indicatorForeground = if (immersive) {
                    if (darkLowerSection) immersiveLowerForeground(palette, MaterialTheme.colorScheme.background) else heroLowerForeground(palette)
                } else null
                ForecastPageIndicator(
                    forecastPage,
                    forecastPageCount,
                    Modifier.align(Alignment.CenterHorizontally).padding(bottom = 13.dp),
                    selectedColour = indicatorForeground?.copy(alpha = .96f),
                    unselectedColour = indicatorForeground?.copy(alpha = .48f)
                )
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(25.dp)).background(Color(0x99101A30)).padding(vertical = 15.dp)) {
                    HeroStat("Rain", "${day.rainChance}%", Modifier.weight(1f))
                    HeroStat("Wind", weather.observation.wind?.let { "${weather.observation.direction} $it km/h" } ?: "—", Modifier.weight(1f))
                    HeroStat("Humidity", weather.observation.humidity?.let { "$it%" } ?: "—", Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ImmersiveDayChart(
    hours: List<HourForecast>,
    temperatureUnit: TemperatureUnit,
    palette: Palette,
    place: Place,
    history: List<HistoricalObservation>,
    darkLowerSection: Boolean,
    modifier: Modifier = Modifier
) {
    // This chart is intentionally forecast-only: it begins at the current hour and
    // continues for the following 24 hours. Historical observations are not mixed in.
    val window = remember(hours, place.timeZoneId) {
        val now = Calendar.getInstance(place.timeZone())
        val start = (now.clone() as Calendar).apply {
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.time
        val end = Calendar.getInstance(place.timeZone()).apply {
            time = start
            add(Calendar.HOUR_OF_DAY, 24)
        }.time
        start to end
    }
    val forecastWindow = remember(hours, window) {
        val sorted = hours
            .filter { it.time.time >= window.first.time && it.time.time <= window.second.time }
            .sortedBy { it.time.time }

        // Keep one point for every hour across the complete 24-hour window. BOM normally
        // supplies hourly points; nearest-neighbour filling only protects against a gap.
        (0..24).mapNotNull { offset ->
            val target = Calendar.getInstance(place.timeZone()).apply {
                time = window.first
                add(Calendar.HOUR_OF_DAY, offset)
            }.time
            sorted.minByOrNull { kotlin.math.abs(it.time.time - target.time) }
                ?.takeIf { kotlin.math.abs(it.time.time - target.time) <= 90L * 60L * 1000L }
                ?.copy(time = target)
        }
    }
    if (forecastWindow.size < 2) return

    val temperatures = remember(forecastWindow, temperatureUnit) {
        forecastWindow.map { displayTemperature(it.temp, temperatureUnit) }
    }
    val minimum = temperatures.minOrNull() ?: 0
    val maximum = temperatures.maxOrNull() ?: minimum + 1
    val range = (maximum - minimum).coerceAtLeast(1)
    val axisFormatter = remember(place.timeZoneId) { localFormatter("ha", place) }
    val firstTime = window.first.time
    val lastTime = window.second.time
    val appBackground = MaterialTheme.colorScheme.background
    val lowerForeground = remember(palette, appBackground, darkLowerSection) {
        if (darkLowerSection) immersiveLowerForeground(palette, appBackground) else heroLowerForeground(palette)
    }
    val chartColours = remember(palette, lowerForeground) { immersiveChartColours(palette, lowerForeground) }

    // Solar events can cross midnight, so calculate both the starting day and next day.
    val solarEvents = remember(place.latitude, place.longitude, window) {
        listOf(window.first, window.second).flatMap { date ->
            calculateSolarTimes(date, place.latitude, place.longitude, place.timeZone())?.let { times ->
                listOf(
                    Triple(times.first, true, "Sunrise"),
                    Triple(times.second, false, "Sunset")
                )
            } ?: emptyList()
        }.distinctBy { it.first.time }
            .filter { it.first.time in firstTime..lastTime }
            .sortedBy { it.first.time }
    }

    Column(modifier.fillMaxWidth().fillMaxHeight()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "NEXT 24 HOURS",
                    color = chartColours.label,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.4.sp
                )
                Text(
                    "From now",
                    color = chartColours.primaryText,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                "${maximum}° / ${minimum}°",
                color = chartColours.primaryText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(top = 6.dp, bottom = 2.dp)
        ) {
            val chartWidth = maxWidth
            val chartHeight = maxHeight
            val horizontalInset = 5.dp
            val chartTopInset = 9.dp
            val chartBottomInset = 18.dp

            Canvas(Modifier.fillMaxSize()) {
                val left = horizontalInset.toPx()
                val right = size.width - horizontalInset.toPx()
                val top = chartTopInset.toPx()
                val bottom = size.height - chartBottomInset.toPx()
                val step = (right - left) / (forecastWindow.size - 1).coerceAtLeast(1)

                fun temperatureY(index: Int): Float {
                    val normalised = (temperatures[index] - minimum).toFloat() / range
                    return bottom - (bottom - top) * (.18f + normalised * .72f)
                }

                forecastWindow.forEachIndexed { index, hour ->
                    val x = left + index * step
                    val barHeight = (bottom - top) * .40f * hour.rainChance.coerceIn(0, 100) / 100f
                    drawLine(
                        chartColours.precipitation,
                        Offset(x, bottom),
                        Offset(x, bottom - barHeight),
                        (step * .58f).coerceAtLeast(1.8.dp.toPx()),
                        StrokeCap.Round
                    )
                }

                val linePath = Path()
                temperatures.forEachIndexed { index, _ ->
                    val x = left + index * step
                    val y = temperatureY(index)
                    if (index == 0) linePath.moveTo(x, y) else linePath.lineTo(x, y)
                }
                drawPath(
                    linePath,
                    chartColours.line,
                    style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )

                temperatures.forEachIndexed { index, _ ->
                    if (index % 6 == 0 || index == temperatures.lastIndex) {
                        val x = left + index * step
                        val y = temperatureY(index)
                        drawCircle(chartColours.pointGlow, 5.dp.toPx(), Offset(x, y))
                        drawCircle(chartColours.point, 2.4.dp.toPx(), Offset(x, y))
                    }
                }
            }

            // Because the chart starts now, NOW is permanently anchored at its left edge.
            Column(
                Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 0.dp, y = 0.dp)
                    .width(40.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = chartColours.primaryText.copy(alpha = .18f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, chartColours.primaryText.copy(alpha = .38f))
                ) {
                    Text("NOW", Modifier.padding(horizontal = 7.dp, vertical = 3.dp), color = chartColours.primaryText, fontSize = 7.sp, fontWeight = FontWeight.ExtraBold)
                }
                Box(Modifier.width(1.dp).height((chartHeight - 24.dp).coerceAtLeast(0.dp)).background(chartColours.primaryText.copy(alpha = .34f)))
            }

            solarEvents.forEach { (time, sunrise, _) ->
                val rawFraction = (time.time - firstTime).toFloat() / (lastTime - firstTime).toFloat()
                val fraction = rawFraction.coerceIn(.05f, .95f)
                val exactIndex = fraction * temperatures.lastIndex.coerceAtLeast(1)
                val lowerIndex = exactIndex.toInt().coerceIn(0, temperatures.lastIndex)
                val upperIndex = (lowerIndex + 1).coerceAtMost(temperatures.lastIndex)
                val blend = exactIndex - lowerIndex
                val eventTemperature = temperatures[lowerIndex] +
                    (temperatures[upperIndex] - temperatures[lowerIndex]) * blend
                val normalised = (eventTemperature - minimum).toFloat() / range
                val lineYFraction = 1f - (.18f + normalised * .72f)
                val placeAbove = lineYFraction > .48f
                val markerY = if (placeAbove) {
                    (chartHeight * lineYFraction - 76.dp).coerceAtLeast(0.dp)
                } else {
                    (chartHeight * lineYFraction + 20.dp).coerceAtMost(chartHeight - 58.dp)
                }

                SolarChartMarker(
                    sunrise = sunrise,
                    colours = chartColours,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = chartWidth * fraction - 28.dp, y = markerY)
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf(0, 6, 12, 18, 24).forEachIndexed { index, offset ->
                val labelTime = Calendar.getInstance().apply {
                    time = window.first
                    add(Calendar.HOUR_OF_DAY, offset)
                }.time
                Text(
                    if (index == 0) "Now" else axisFormatter.format(labelTime).lowercase(),
                    color = chartColours.label,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    style = androidx.compose.ui.text.TextStyle(
                        shadow = androidx.compose.ui.graphics.Shadow(
                            color = Color.Black.copy(alpha = .32f),
                            offset = Offset(0f, 1f),
                            blurRadius = 2f
                        )
                    )
                )
            }
        }
    }
}

private data class ImmersiveChartColours(
    val line: Color,
    val precipitation: Color,
    val point: Color,
    val pointGlow: Color,
    val primaryText: Color,
    val label: Color,
    val progressTop: Color,
    val progressBottom: Color
)

private fun paletteBrightness(palette: Palette): Float {
    fun brightness(colour: Color): Float = colour.red * .299f + colour.green * .587f + colour.blue * .114f
    return brightness(palette.top) * .46f + brightness(palette.bottom) * .34f + brightness(palette.secondary) * .20f
}

private fun solarLegibleForeground(palette: Palette): Color =
    if (paletteBrightness(palette) > .57f) Color(0xFF172033) else Color.White

private fun colourBrightness(colour: Color): Float =
    colour.red * .299f + colour.green * .587f + colour.blue * .114f

private fun heroLowerForeground(palette: Palette): Color {
    // Fullscreen Hero keeps a brighter weather-coloured lower section.
    val lowerBackdrop = blendColor(palette.bottom, palette.secondary, .30f)
    return if (colourBrightness(lowerBackdrop) > .57f) Color(0xFF172033) else Color.White
}

private fun immersiveLowerForeground(palette: Palette, appBackground: Color): Color {
    // The lower immersive hero is deliberately pulled toward the app background.
    // Judge contrast against that blended backdrop rather than the bright upper sky.
    val lowerBackdrop = blendColor(palette.bottom, appBackground, .72f)
    return if (colourBrightness(lowerBackdrop) > .57f) Color(0xFF172033) else Color.White
}

private fun immersiveChartColours(palette: Palette, foreground: Color): ImmersiveChartColours {
    val brightBackground = colourBrightness(foreground) < .5f
    val line = if (brightBackground) Color(0xFF24324A) else Color(0xFFF5FBFF)
    // Rain must remain distinct over both pale sunrise oranges and deep sunset purples.
    val rain = if (brightBackground) Color(0xFF006E9E).copy(alpha = .94f) else Color(0xFF72DCFF).copy(alpha = .96f)
    return ImmersiveChartColours(
        line = line,
        precipitation = rain,
        point = foreground,
        pointGlow = if (brightBackground) Color.White.copy(alpha = .54f) else palette.accent.copy(alpha = .68f),
        primaryText = foreground,
        label = foreground.copy(alpha = .92f),
        progressTop = foreground.copy(alpha = .20f),
        progressBottom = foreground.copy(alpha = .05f)
    )
}

@Composable
private fun SolarChartMarker(
    sunrise: Boolean,
    colours: ImmersiveChartColours,
    modifier: Modifier = Modifier
) {
    val iconColour = colours.primaryText.copy(alpha = .92f)
    Column(modifier.width(56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(28.dp)) {
            val horizon = size.height * .62f
            val centreX = size.width * .5f
            drawLine(
                iconColour.copy(alpha = .72f),
                Offset(size.width * .12f, horizon),
                Offset(size.width * .88f, horizon),
                1.2.dp.toPx(),
                StrokeCap.Round
            )
            drawArc(
                color = iconColour,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(size.width * .32f, horizon - size.height * .18f),
                size = Size(size.width * .36f, size.height * .36f),
                style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round)
            )
            repeat(3) { index ->
                val x = size.width * (.28f + index * .22f)
                drawLine(
                    iconColour.copy(alpha = .55f),
                    Offset(x - 2.dp.toPx(), horizon + 4.dp.toPx()),
                    Offset(x + 2.dp.toPx(), horizon + 4.dp.toPx()),
                    1.dp.toPx(),
                    StrokeCap.Round
                )
            }

            val arrowTop = if (sunrise) size.height * .08f else size.height * .18f
            val arrowBottom = if (sunrise) size.height * .38f else size.height * .48f
            drawLine(
                iconColour,
                Offset(centreX, arrowBottom),
                Offset(centreX, arrowTop),
                1.7.dp.toPx(),
                StrokeCap.Round
            )
            val arrowDirection = if (sunrise) 1f else -1f
            val tipY = if (sunrise) arrowTop else arrowBottom
            val wingY = tipY + 4.dp.toPx() * arrowDirection
            drawLine(iconColour, Offset(centreX, tipY), Offset(centreX - 3.5.dp.toPx(), wingY), 1.7.dp.toPx(), StrokeCap.Round)
            drawLine(iconColour, Offset(centreX, tipY), Offset(centreX + 3.5.dp.toPx(), wingY), 1.7.dp.toPx(), StrokeCap.Round)
        }
    }
}

@Composable
private fun ImmersiveOutlookPill(
    weather: WeatherState,
    temperatureUnit: TemperatureUnit,
    modifier: Modifier = Modifier
) {
    val day = weather.days.first()
    val outlook = when {
        day.rainChance >= 70 -> "Rain likely today"
        day.rainChance >= 35 -> "A chance of showers"
        day.condition.contains("cloud", true) -> "Clouds through the day"
        day.condition.contains("sun", true) || day.condition.contains("clear", true) -> "Bright conditions ahead"
        else -> day.condition
    }
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White.copy(alpha = .13f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .18f))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            WeatherArtwork(day.icon, night = isNight(), modifier = Modifier.size(46.dp))
            Column(Modifier.weight(1f).padding(start = 11.dp)) {
                Text("TODAY'S OUTLOOK", color = Color.White.copy(.64f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text(outlook, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                "${displayTemperature(day.high, temperatureUnit)}° / ${displayTemperature(day.low, temperatureUnit)}°",
                color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun ScrollDownCue(palette: Palette, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Scroll for your forecast", color = MaterialTheme.colorScheme.onSurface.copy(.54f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Canvas(Modifier.padding(top = 5.dp).size(width = 28.dp, height = 13.dp)) {
            val stroke = 2.dp.toPx()
            drawLine(palette.secondary.copy(.78f), Offset(size.width * .18f, size.height * .25f), Offset(size.width * .5f, size.height * .72f), stroke, StrokeCap.Round)
            drawLine(palette.secondary.copy(.78f), Offset(size.width * .82f, size.height * .25f), Offset(size.width * .5f, size.height * .72f), stroke, StrokeCap.Round)
        }
    }
}

@Composable private fun HeroStat(label: String, value: String, modifier: Modifier) =
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color.White.copy(.7f), fontSize = 10.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }

@Composable
private fun SeasonPill(place: Place, onClick: () -> Unit) {
    val season = seasonName(place)
    val color = when (season) {
        "Summer" -> Color(0xFFFFE49A)
        "Autumn" -> Color(0xFFFFC5A0)
        "Winter" -> Color(0xFFD9ECFF)
        else -> Color(0xFFDDF3D0)
    }
    Surface(Modifier.clickable(onClick = onClick), shape = CircleShape, color = color, shadowElevation = 8.dp) {
        Text("●  $season", Modifier.padding(horizontal = 15.dp, vertical = 10.dp), color = Color(0xFF31577B), fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun LocationSeasonPill(place: Place) {
    val season = seasonName(place)
    val color = when (season) {
        "Summer" -> Color(0xFFFFE49A)
        "Autumn" -> Color(0xFFFFC5A0)
        "Winter" -> Color(0xFFD9ECFF)
        else -> Color(0xFFDDF3D0)
    }
    Surface(
        shape = CircleShape,
        color = color.copy(alpha = .94f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.26f))
    ) {
        Text(
            season,
            Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            color = Color(0xFF31577B),
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = .35.sp
        )
    }
}

@Composable
private fun CountryPill(place: Place, now: Date) {
    val code = place.countryCode.uppercase(Locale.US)
    val flag = if (code.length == 2) code.map { String(Character.toChars(127397 + it.code)) }.joinToString("") else "⌖"
    val localTime = remember(place.timeZoneId, now.time / 60_000L) {
        localFormatter("h:mm a", place).format(now).lowercase(Locale.ENGLISH)
    }
    Surface(shape = CircleShape, color = Color(0x33203355), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.28f))) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("$flag  ${place.country.ifBlank { "International" }}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.padding(horizontal = 8.dp).width(1.dp).height(12.dp).background(Color.White.copy(.28f)))
            Text(localTime, color = Color.White.copy(.82f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}


@Composable
private fun AustralianTimePill(place: Place, now: Date) {
    val localTime = remember(place.timeZoneId, now.time / 60_000L) {
        localFormatter("h:mm a", place).format(now).lowercase(Locale.ENGLISH)
    }
    Surface(
        shape = CircleShape,
        color = Color(0x33203355),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.28f))
    ) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!place.current) {
                Text(place.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.padding(horizontal = 8.dp).width(1.dp).height(12.dp).background(Color.White.copy(.28f)))
            }
            Text(localTime, color = Color.White.copy(.82f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ConditionAtmosphere(icon: String, night: Boolean) {
    val drawable = remember(icon, night) {
        when {
            icon.contains("storm", true) || icon.contains("thunder", true) -> R.drawable.ic_weather_storm
            icon.contains("rain", true) || icon.contains("shower", true) -> R.drawable.ic_weather_rain
            icon.contains("cloud", true) -> R.drawable.ic_weather_cloudy
            night -> R.drawable.ic_weather_night
            else -> R.drawable.ic_weather_sunny
        }
    }
    Image(
        painter = painterResource(drawable),
        contentDescription = null,
        modifier = Modifier
            .fillMaxSize()
            .padding(start = 150.dp, top = 26.dp, end = 12.dp, bottom = 245.dp)
            .alpha(.16f),
        contentScale = ContentScale.Fit
    )
}

@Composable
private fun WeatherArtwork(icon: String, night: Boolean, modifier: Modifier = Modifier) {
    AnimatedContent(
        targetState = icon to night,
        transitionSpec = {
            (fadeIn(tween(520)) + scaleIn(tween(620), initialScale = .92f)) togetherWith
                (fadeOut(tween(360)) + scaleOut(tween(420), targetScale = 1.05f))
        },
        label = "atmosWeatherArtwork"
    ) { state ->
        WeatherArtworkCanvas(state.first, state.second, modifier)
    }
}

@Composable
private fun WeatherArtworkCanvas(icon: String, night: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier.padding(7.dp)) {
        val w = size.width
        val h = size.height
        val rainy = icon.contains("rain", true) || icon.contains("shower", true)
        val stormy = icon.contains("storm", true) || icon.contains("thunder", true)
        val snowy = icon.contains("snow", true) || icon.contains("sleet", true) || icon.contains("hail", true)
        val foggy = icon.contains("fog", true) || icon.contains("mist", true) || icon.contains("haze", true)
        val cloudy = rainy || stormy || snowy || foggy || icon.contains("cloud", true) || icon.contains("overcast", true)
        val accent = if (night) Color(0xFFB9C8FF) else Color(0xFFFFB94E)
        val cloudTop = if (stormy) Color(0xFF65728D) else Color(0xFFE7EDF7)
        val cloudBottom = if (stormy) Color(0xFF303B54) else Color(0xFF8EA2BE)

        if (!cloudy) {
            val centre = Offset(w * .5f, h * .48f)
            val r = size.minDimension * .23f
            drawCircle(accent.copy(.16f), r * 1.36f, centre)
            drawCircle(accent, r, centre)
            if (night) {
                drawCircle(Color(0xFF253858), r * .92f, centre + Offset(r * .48f, -r * .16f))
            } else {
                repeat(8) { index ->
                    val angle = index * PI.toFloat() / 4f
                    val inner = r * 1.32f
                    val outer = r * 1.66f
                    drawLine(
                        accent.copy(.82f),
                        Offset(centre.x + cos(angle) * inner, centre.y + sin(angle) * inner),
                        Offset(centre.x + cos(angle) * outer, centre.y + sin(angle) * outer),
                        strokeWidth = 2.2.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }
            return@Canvas
        }

        val orbCentre = Offset(w * .68f, h * .31f)
        val orbR = size.minDimension * .15f
        if (!stormy) {
            drawCircle(accent.copy(.14f), orbR * 1.35f, orbCentre)
            drawCircle(accent, orbR, orbCentre)
            if (night) drawCircle(Color(0xFF293B5D), orbR * .86f, orbCentre + Offset(orbR * .48f, -orbR * .14f))
        }

        val cloud = Path().apply {
            moveTo(w * .12f, h * .64f)
            cubicTo(w * .12f, h * .51f, w * .25f, h * .48f, w * .34f, h * .48f)
            cubicTo(w * .39f, h * .34f, w * .59f, h * .34f, w * .66f, h * .50f)
            cubicTo(w * .84f, h * .48f, w * .91f, h * .60f, w * .84f, h * .70f)
            cubicTo(w * .80f, h * .75f, w * .73f, h * .76f, w * .64f, h * .76f)
            lineTo(w * .28f, h * .76f)
            cubicTo(w * .17f, h * .76f, w * .11f, h * .71f, w * .12f, h * .64f)
            close()
        }
        drawPath(cloud, Brush.verticalGradient(listOf(cloudTop, cloudBottom)))
        drawPath(cloud, Color.White.copy(if (stormy) .04f else .10f), style = Stroke(width = 1.dp.toPx()))

        if (foggy) {
            repeat(3) { index ->
                val y = h * (.81f + index * .075f)
                drawLine(
                    Color(0xFFDCE7F4).copy(alpha = .78f - index * .14f),
                    Offset(w * (.20f + index * .04f), y),
                    Offset(w * (.80f - index * .03f), y),
                    1.45.dp.toPx(),
                    StrokeCap.Round
                )
            }
        }
        if (snowy) {
            repeat(3) { i ->
                val centre = Offset(w * (.30f + i * .20f), h * (.85f + (i % 2) * .06f))
                val r = size.minDimension * .045f
                drawLine(Color(0xFFE8F7FF), centre - Offset(r, 0f), centre + Offset(r, 0f), 1.2.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFFE8F7FF), centre - Offset(0f, r), centre + Offset(0f, r), 1.2.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFFE8F7FF), centre - Offset(r * .7f, r * .7f), centre + Offset(r * .7f, r * .7f), 1.1.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFFE8F7FF), centre - Offset(r * .7f, -r * .7f), centre + Offset(r * .7f, -r * .7f), 1.1.dp.toPx(), StrokeCap.Round)
            }
        }
        if ((rainy || stormy) && !snowy && !foggy) {
            repeat(3) { i ->
                val x = w * (.31f + i * .19f)
                drawLine(
                    color = Color(0xFF62D5EA),
                    start = Offset(x, h * .82f),
                    end = Offset(x - w * .035f, h * .96f),
                    strokeWidth = 1.75.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
        if (stormy) {
            val bolt = Path().apply {
                moveTo(w * .59f, h * .70f)
                lineTo(w * .49f, h * .85f)
                lineTo(w * .57f, h * .84f)
                lineTo(w * .50f, h * .98f)
                lineTo(w * .69f, h * .78f)
                lineTo(w * .60f, h * .79f)
                close()
            }
            drawPath(bolt, Color(0xFFFFC84F))
        }
    }
}

@Composable
private fun AtmosCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(.15f))
    ) { Column(Modifier.padding(21.dp), content = content) }
}

@Composable
private fun ThemedForecastCard(
    palette: Palette,
    content: @Composable ColumnScope.() -> Unit
) {
    val outlineBrush = remember(palette) {
        Brush.horizontalGradient(
            listOf(
                palette.top.copy(alpha = .22f),
                palette.secondary.copy(alpha = .46f),
                palette.bottom.copy(alpha = .25f)
            )
        )
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(alpha = .30f))
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, outlineBrush, RoundedCornerShape(29.dp))
                .padding(21.dp),
            content = content
        )
    }
}

@Composable
private fun AtAGlanceCard(weather: WeatherState, palette: Palette, temperatureUnit: TemperatureUnit) {
    var page by rememberSaveable(weather.place.name) { mutableStateOf(0) }
    val maxPage = if (weather.days.size > 1) 1 else 0
    val borderBrush = remember(palette) {
        Brush.horizontalGradient(
            listOf(
                palette.top.copy(alpha = .10f),
                palette.secondary.copy(alpha = .28f),
                palette.bottom.copy(alpha = .10f)
            )
        )
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(29.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(.30f))
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .border(
                    width = 1.dp,
                    brush = borderBrush,
                    shape = RoundedCornerShape(29.dp)
                )
                .padding(21.dp)
        ) {
        Row(
            Modifier.pointerInput(maxPage) {
                var drag = 0f
                detectHorizontalDragGestures(
                    onDragStart = { drag = 0f },
                    onHorizontalDrag = { _, amount -> drag += amount },
                    onDragEnd = {
                        if (drag < -45f) page = maxPage
                        if (drag > 45f) page = 0
                    }
                )
            },
            verticalAlignment = Alignment.Top
        ) {
            val glanceDay = weather.days.getOrElse(page) { weather.days.first() }
            WeatherArtwork(
                icon = glanceDay.icon,
                night = false,
                modifier = Modifier
                    .size(64.dp)
                    .padding(top = 2.dp)
            )
            AnimatedContent(page, modifier = Modifier.padding(start = 12.dp).weight(1f), label = "glance-page") { selected ->
                val day = weather.days.getOrElse(selected) { weather.days.first() }
                Column {
                    Text(if (selected == 0) "Today at a glance" else "Tomorrow at a glance", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    val summary = if (selected == 0) conditionNarrative(weather) else day.condition
                    Text("$summary A high of ${displayTemperature(day.high, temperatureUnit)}° and low of ${displayTemperature(day.low, temperatureUnit)}°.", color = MaterialTheme.colorScheme.onSurface.copy(.76f), fontSize = 13.sp, lineHeight = 19.sp)
                }
            }
        }
        if (maxPage > 0) {
            ForecastPageIndicator(
                current = page,
                count = maxPage + 1,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 14.dp)
            )
        }
        }
    }
}

@Composable
private fun HourlyCard(hours: List<HourForecast>, day: DayForecast, place: Place, temperatureUnit: TemperatureUnit, palette: Palette) = ThemedForecastCard(palette) {
    Text("Today", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Hourly forecast", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
    val source = remember(hours, day) {
        hours.ifEmpty {
            (0 until 12).map { HourForecast(Date(System.currentTimeMillis() + it * 3_600_000L), day.high - 2 - it / 4, day.icon, day.rainChance, 50, 10, "W") }
        }.take(18)
    }
    val solarTimes = remember(place.latitude, place.longitude, place.timeZoneId) {
        calculateSolarTimes(Date(), place.latitude, place.longitude, place.timeZone())
    }
    var nowMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            nowMillis = System.currentTimeMillis()
        }
    }
    val timeline = remember(source, solarTimes, nowMillis) {
        buildList {
            source.forEach { add(TodayTimelineItem.Hour(it)) }
            solarTimes?.let { times ->
                if (times.first.time > nowMillis) add(TodayTimelineItem.Sunrise(times.first))
                if (times.second.time > nowMillis) add(TodayTimelineItem.Sunset(times.second))
            }
        }.sortedBy { it.time.time }
    }
    val hourFormatter = remember(place.timeZoneId) { localFormatter("h a", place) }
    val eventFormatter = remember(place.timeZoneId) { localFormatter("h:mm a", place) }
    val sunriseGradient = remember { Brush.verticalGradient(listOf(Color(0xFFFFD58A), Color(0xFFF18A5B).copy(.48f), Color(0xFFFFC76A).copy(.16f))) }
    val sunsetGradient = remember { Brush.verticalGradient(listOf(Color(0xFF9B70E8).copy(.72f), Color(0xFFF07B63).copy(.52f), Color(0xFF633E91).copy(.24f))) }
    LazyRow(
        Modifier.fillMaxWidth().padding(top = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(
            items = timeline,
            key = { item ->
            when (item) {
                is TodayTimelineItem.Hour -> "hour-${item.time.time}"
                is TodayTimelineItem.Sunrise -> "sunrise-${item.time.time}"
                is TodayTimelineItem.Sunset -> "sunset-${item.time.time}"
            }
        },
            contentType = { item ->
                when (item) {
                    is TodayTimelineItem.Hour -> "hour"
                    is TodayTimelineItem.Sunrise -> "solar"
                    is TodayTimelineItem.Sunset -> "solar"
                }
            }
        ) { item ->
            when (item) {
                is TodayTimelineItem.Hour -> {
                    val hour = item.forecast
                    val isNow = source.firstOrNull()?.time?.time == hour.time.time
                    Column(
                        Modifier.width(78.dp).height(164.dp).clip(RoundedCornerShape(22.dp))
                            .background(if (isNow) MaterialTheme.colorScheme.primary.copy(.14f) else Color.Transparent)
                            .padding(horizontal = 7.dp, vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (isNow) "Now" else hourFormatter.format(hour.time).lowercase(), fontWeight = FontWeight.Bold)
                        WeatherArtwork(hour.icon, isNight(hour.time, place.timeZone()), Modifier.size(50.dp))
                        Text("${displayTemperature(hour.temp, temperatureUnit)}°", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("${hour.rainChance}%", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp)
                    }
                }
                is TodayTimelineItem.Sunrise -> SolarEventCard(
                    title = "Sunrise",
                    time = eventFormatter.format(item.time).lowercase(),
                    caption = "Day begins",
                    sunrise = true,
                    gradient = sunriseGradient
                )
                is TodayTimelineItem.Sunset -> SolarEventCard(
                    title = "Sunset",
                    time = eventFormatter.format(item.time).lowercase(),
                    caption = "Day ends",
                    sunrise = false,
                    gradient = sunsetGradient
                )
            }
        }
    }
}

private sealed class TodayTimelineItem(open val time: Date) {
    data class Hour(val forecast: HourForecast) : TodayTimelineItem(forecast.time)
    data class Sunrise(override val time: Date) : TodayTimelineItem(time)
    data class Sunset(override val time: Date) : TodayTimelineItem(time)
}

@Composable
private fun SolarEventCard(title: String, time: String, caption: String, sunrise: Boolean, gradient: Brush) {
    val primary = MaterialTheme.colorScheme.primary
    Column(
        Modifier.width(78.dp).height(164.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.primary.copy(.10f))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(.22f), RoundedCornerShape(22.dp))
            .padding(horizontal = 7.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Canvas(Modifier.size(48.dp)) {
            val horizonY = size.height * .67f
            drawLine(
                color = primary.copy(.35f),
                start = Offset(size.width * .12f, horizonY),
                end = Offset(size.width * .88f, horizonY),
                strokeWidth = 1.5.dp.toPx(),
                cap = StrokeCap.Round
            )
            val centre = Offset(size.width * .5f, horizonY)
            val orbCentre = if (sunrise) centre - Offset(0f, size.height * .18f) else centre - Offset(0f, size.height * .12f)
            drawCircle(Color(0xFFFFB94E).copy(.18f), size.minDimension * .23f, orbCentre)
            drawCircle(Color(0xFFFFB94E), size.minDimension * .14f, orbCentre)
            repeat(5) { index ->
                val x = size.width * (.28f + index * .11f)
                val spread = (index - 2).absoluteValue * 1.5.dp.toPx()
                drawLine(
                    Color(0xFFFFB94E).copy(.50f),
                    Offset(x - spread, horizonY + 4.dp.toPx()),
                    Offset(x + spread, horizonY + 4.dp.toPx()),
                    1.3.dp.toPx(),
                    StrokeCap.Round
                )
            }
        }
        Text(time, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(caption, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f), textAlign = TextAlign.Center)
    }
}

private fun calculateSolarTimes(date: Date, latitude: Double, longitude: Double, timeZone: TimeZone = TimeZone.getDefault()): Pair<Date, Date>? {
    val calendar = Calendar.getInstance(timeZone).apply { time = date }
    val dayOfYear = calendar.get(Calendar.DAY_OF_YEAR)
    val timezoneOffsetHours = timeZone.getOffset(date.time) / 3_600_000.0

    fun event(sunrise: Boolean): Date? {
        val lngHour = longitude / 15.0
        val approximateTime = dayOfYear + ((if (sunrise) 6.0 else 18.0) - lngHour) / 24.0
        val meanAnomaly = (0.9856 * approximateTime) - 3.289
        var trueLongitude = meanAnomaly + (1.916 * sin(Math.toRadians(meanAnomaly))) +
            (0.020 * sin(Math.toRadians(2 * meanAnomaly))) + 282.634
        trueLongitude = (trueLongitude + 360.0) % 360.0
        var rightAscension = Math.toDegrees(atan(0.91764 * tan(Math.toRadians(trueLongitude))))
        rightAscension = (rightAscension + 360.0) % 360.0
        val longitudeQuadrant = floor(trueLongitude / 90.0) * 90.0
        val rightAscensionQuadrant = floor(rightAscension / 90.0) * 90.0
        rightAscension = (rightAscension + longitudeQuadrant - rightAscensionQuadrant) / 15.0
        val sinDeclination = 0.39782 * sin(Math.toRadians(trueLongitude))
        val cosDeclination = cos(kotlin.math.asin(sinDeclination))
        val cosHourAngle = (cos(Math.toRadians(90.833)) - sinDeclination * sin(Math.toRadians(latitude))) /
            (cosDeclination * cos(Math.toRadians(latitude)))
        if (cosHourAngle !in -1.0..1.0) return null
        var localHour = if (sunrise) 360.0 - Math.toDegrees(acos(cosHourAngle)) else Math.toDegrees(acos(cosHourAngle))
        localHour /= 15.0
        val localMeanTime = localHour + rightAscension - (0.06571 * approximateTime) - 6.622
        val utcHour = (localMeanTime - lngHour + 24.0) % 24.0
        val localHourDecimal = (utcHour + timezoneOffsetHours + 24.0) % 24.0
        val hour = floor(localHourDecimal).toInt()
        val minute = ((localHourDecimal - hour) * 60.0).roundToInt().coerceIn(0, 59)
        return Calendar.getInstance(timeZone).apply {
            time = date
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.time
    }

    val sunrise = event(true) ?: return null
    val sunset = event(false) ?: return null
    return sunrise to sunset
}

@Composable
private fun SevenDayCard(days: List<DayForecast>, temperatureUnit: TemperatureUnit, palette: Palette) = ThemedForecastCard(palette) {
    Text("7-day forecast", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Tap a day for more detail", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
    days.forEachIndexed { index, day ->
        var expanded by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (index == 0) "Today" else dayName(index), Modifier.width(64.dp), fontWeight = FontWeight.Bold)
                WeatherArtwork(day.icon, false, Modifier.size(43.dp))
                Text("${day.condition}\nRain ${day.rainChance}%", Modifier.weight(1f).padding(start = 9.dp), color = MaterialTheme.colorScheme.onSurface.copy(.73f), fontSize = 11.sp)
                Text("${displayTemperature(day.high, temperatureUnit)}°  ${displayTemperature(day.low, temperatureUnit)}°", fontWeight = FontWeight.Bold)
            }
            AnimatedVisibility(expanded) {
                Surface(Modifier.fillMaxWidth().padding(top = 10.dp), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primary.copy(.08f)) {
                    Text("Low ${displayTemperature(day.low, temperatureUnit)}° · High ${displayTemperature(day.high, temperatureUnit)}°\n${day.rainChance}% chance of rain · Up to ${day.rainAmount} mm possible.", Modifier.padding(15.dp), fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
        }
    }
}

@Composable
private fun PrecipitationCard(hours: List<HourForecast>, palette: Palette) = ThemedForecastCard(palette) {
    Text("Hourly precipitation", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("Chance of rain over the hours ahead", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
    val source = remember(hours) {
        hours.take(18).ifEmpty { List(12) { HourForecast(Date(System.currentTimeMillis() + it * 3_600_000L), 18, "", it * 3, 0, 0, "") } }
    }
    val hourFormatter = remember { SimpleDateFormat("h", Locale.ENGLISH) }
    val barBrush = remember { Brush.verticalGradient(listOf(Color(0xFF79DCE5), Color(0xFF478ED1))) }
    LazyRow(
        Modifier.fillMaxWidth().height(132.dp).padding(top = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(
            items = source,
            key = { it.time.time },
            contentType = { "precipitation-hour" }
        ) { h ->
            Column(Modifier.width(46.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${h.rainChance}%", Modifier.height(18.dp).fillMaxWidth(), fontSize = 9.sp, textAlign = TextAlign.Center)
                Box(Modifier.height(78.dp).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier.width(16.dp)
                            .height((18 + h.rainChance.coerceIn(0, 100) * .58).dp)
                            .clip(CircleShape)
                            .background(barBrush)
                    )
                }
                Text(hourFormatter.format(h.time), Modifier.height(20.dp).fillMaxWidth(), fontSize = 9.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun WarningCard(warnings: List<String>) {
    val context = LocalContext.current
    Card(
        Modifier.fillMaxWidth().clickable { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bom.gov.au/australia/warnings/"))) },
        shape = RoundedCornerShape(25.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE7C2)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE9A850))
    ) {
        Row(Modifier.padding(18.dp)) {
            Text("⚠", fontSize = 25.sp)
            Column(Modifier.padding(start = 13.dp)) {
                Text("Weather warning", color = Color(0xFF704212), fontWeight = FontWeight.Bold)
                Text(warnings.first(), color = Color(0xFF704212), fontSize = 11.sp)
                if (warnings.size > 1) Text("+${warnings.size - 1} more warning${if (warnings.size > 2) "s" else ""}", color = Color(0xFF704212), fontSize = 10.sp)
            }
        }
    }
}

private val detailCardIds = listOf("sun", "wind", "moon", "rain", "uv", "pressure", "humidity", "season", "tide")

@Composable
private fun DetailCards(weather: WeatherState, preferences: AtmosPreferences) {
    val context = LocalContext.current
    var order by remember { mutableStateOf(preferences.cardOrder) }
    var hidden by remember { mutableStateOf(preferences.hiddenCards) }
    Column {
        Text("Weather details", Modifier.padding(start = 4.dp, top = 8.dp), fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Tap a card for more information · hold and drag to rearrange", Modifier.padding(start = 4.dp, bottom = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(.6f), fontSize = 11.sp)
        val visible = order.filterNot { it in hidden }
        visible.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                row.forEach { id ->
                    var expanded by remember { mutableStateOf(false) }
                    var drag by remember { mutableStateOf(0f) }
                    DetailCard(
                        id, weather, expanded, Modifier.weight(1f)
                            .pointerInput(id) {
                                detectDragGesturesAfterLongPress(
                                    onDrag = { change, amount -> change.consume(); drag += amount.y },
                                    onDragEnd = {
                                        val index = order.indexOf(id)
                                        val target = (index + if (drag > 35f) 1 else if (drag < -35f) -1 else 0).coerceIn(order.indices)
                                        if (target != index) {
                                            val list = order.toMutableList()
                                            list.removeAt(index)
                                            list.add(target, id)
                                            order = list
                                            preferences.cardOrder = list
                                        }
                                        drag = 0f
                                    }
                                )
                            }
                    ) {
                        if (expanded && id == "tide") {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bom.gov.au/australia/tides/")))
                        } else {
                            expanded = !expanded
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(11.dp))
        }
    }
}

private data class DetailValue(val title: String, val value: String, val detail: String, val color: Color)

@Composable
private fun DetailCard(id: String, weather: WeatherState, expanded: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val day = weather.days.first()
    val detailValue = remember(id, weather.observation, day) {
        when (id) {
            "sun" -> DetailValue("Sun & daylight", "5:38 pm", "Sunrise 7:11 am", Color(0xFFE8A527))
            "wind" -> DetailValue("Wind", weather.observation.wind?.let { "$it km/h" } ?: "Not available", "${weather.observation.direction} · gusts ${weather.observation.gust ?: "—"} km/h", Color(0xFF4C8DDC))
            "moon" -> DetailValue("Moon", moonName(), "${moonIllumination()}% illuminated", Color(0xFF7B68D5))
            "rain" -> DetailValue("Rain", "${day.rainChance}%", "Up to ${day.rainAmount} mm expected", Color(0xFF2BAEC4))
            "uv" -> DetailValue("UV index", "3", "Moderate · protection advised", Color(0xFFE9785C))
            "pressure" -> DetailValue("Pressure", weather.observation.pressure?.let { "${it.roundToInt()} hPa" } ?: "Not available", "Mean sea-level pressure", Color(0xFF656BD8))
            "humidity" -> DetailValue("Humidity", weather.observation.humidity?.let { "$it%" } ?: "Not available", "Current observation", Color(0xFF32A68B))
            "season" -> DetailValue("Season", seasonName(weather.place), daysToNextSeason(weather.place), Color(0xFFC67B48))
            else -> DetailValue("Tides", "BOM tides", "Official coastal predictions", Color(0xFF367FC5))
        }
    }
    val (title, value, detail, color) = detailValue
    Card(
        modifier.height(if (expanded) 270.dp else 180.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(.42f))
    ) {
        Box(Modifier.fillMaxSize().padding(16.dp)) {
            Surface(
                modifier = Modifier.align(Alignment.TopCenter).size(50.dp),
                shape = CircleShape,
                color = color.copy(.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(atmosGlyph(id), fontSize = 27.sp, color = color, textAlign = TextAlign.Center)
                }
            }
            Text(
                if (expanded) "⌄" else "›",
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 2.dp, end = 2.dp),
                color = MaterialTheme.colorScheme.onSurface.copy(.52f),
                fontSize = 23.sp
            )
            Column(
                modifier = Modifier.align(Alignment.Center).fillMaxWidth().padding(top = 35.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(title, color = MaterialTheme.colorScheme.onSurface.copy(.64f), fontSize = 11.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(5.dp))
                Text(value, fontSize = 22.sp, lineHeight = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(5.dp))
                Text(detail, color = MaterialTheme.colorScheme.onSurface.copy(.66f), fontSize = 10.sp, lineHeight = 14.sp, textAlign = TextAlign.Center)
                AnimatedVisibility(expanded) {
                    Text(
                        detailDescription(id),
                        Modifier.padding(top = 16.dp),
                        color = MaterialTheme.colorScheme.onSurface.copy(.75f),
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun ConditionsDayChart(hours: List<HourForecast>, temperatureUnit: TemperatureUnit, palette: Palette, place: Place) {
    val surfaceColor = MaterialTheme.colorScheme.surface
    val gridColor = MaterialTheme.colorScheme.onSurface.copy(.08f)
    val fullDay = remember(hours) { hours.take(24) }
    if (fullDay.size < 2) return
    val temperatures = fullDay.map { displayTemperature(it.temp, temperatureUnit) }
    val minTemp = temperatures.minOrNull() ?: 0
    val maxTemp = temperatures.maxOrNull() ?: minTemp + 1
    val range = (maxTemp - minTemp).coerceAtLeast(1)
    val formatter = remember(place.timeZoneId) { localFormatter("ha", place) }
    Card(
        Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 22.dp),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(.88f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(.35f))
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Today’s temperature & rain", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Full-day outlook", color = MaterialTheme.colorScheme.onSurface.copy(.60f), fontSize = 10.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${maxTemp}° / ${minTemp}°", fontWeight = FontWeight.Bold)
                    Text("Peak / low", color = MaterialTheme.colorScheme.onSurface.copy(.55f), fontSize = 9.sp)
                }
            }
            Canvas(Modifier.fillMaxWidth().height(190.dp).padding(top = 20.dp, bottom = 14.dp)) {
                val left = 4.dp.toPx()
                val right = size.width - 4.dp.toPx()
                val top = 8.dp.toPx()
                val bottom = size.height - 8.dp.toPx()
                repeat(4) { index ->
                    val y = top + (bottom - top) * index / 3f
                    drawLine(gridColor, Offset(left, y), Offset(right, y), 1.dp.toPx())
                }
                val step = (right - left) / (fullDay.size - 1).coerceAtLeast(1)
                fullDay.forEachIndexed { index, hour ->
                    val barMax = (bottom - top) * .40f
                    val barHeight = barMax * hour.rainChance.coerceIn(0, 100) / 100f
                    val x = left + index * step
                    drawLine(
                        palette.accent.copy(.34f),
                        Offset(x, bottom),
                        Offset(x, bottom - barHeight),
                        strokeWidth = (step * .55f).coerceAtLeast(2.dp.toPx()),
                        cap = StrokeCap.Round
                    )
                }
                val path = Path()
                temperatures.forEachIndexed { index, temp ->
                    val x = left + index * step
                    val normalised = (temp - minTemp).toFloat() / range
                    val y = bottom - (bottom - top) * (.25f + normalised * .67f)
                    if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, palette.secondary, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
                temperatures.forEachIndexed { index, temp ->
                    if (index % 4 == 0 || index == temperatures.lastIndex) {
                        val x = left + index * step
                        val normalised = (temp - minTemp).toFloat() / range
                        val y = bottom - (bottom - top) * (.25f + normalised * .67f)
                        drawCircle(surfaceColor, 4.3.dp.toPx(), Offset(x, y))
                        drawCircle(palette.secondary, 2.5.dp.toPx(), Offset(x, y))
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf(0, fullDay.size / 3, (fullDay.size * 2) / 3, fullDay.lastIndex).distinct().forEach { index ->
                    Text(formatter.format(fullDay[index].time).lowercase(), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                }
            }
            Row(Modifier.padding(top = 13.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(palette.secondary))
                    Text(" Temperature", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(palette.accent.copy(.55f)))
                    Text(" Precipitation", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f))
                }
            }
        }
    }
}

@Composable
private fun ConditionsPage(weather: WeatherState, temperatureUnit: TemperatureUnit, onBack: () -> Unit) {
    val day = weather.days.first()
    val palette = conditionPalette(day.icon, isNight())
    LazyColumn(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(palette.top.copy(.7f), MaterialTheme.colorScheme.background), endY = 1200f)),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 25.dp
        )
    ) {
        item { PageHeader("Current conditions", onBack) }
        item {
            Box(Modifier.fillMaxWidth().height(350.dp)) {
                Column(Modifier.padding(top = 38.dp)) {
                    Text("${displayTemperature(weather.observation.temp ?: day.high - 2, temperatureUnit)}°", fontSize = 88.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-5).sp)
                    Text(nightCondition(day.condition), fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("Feels like ${displayTemperature(weather.observation.feels ?: day.high - 3, temperatureUnit)}° · H ${displayTemperature(day.high, temperatureUnit)}° · L ${displayTemperature(day.low, temperatureUnit)}°", color = MaterialTheme.colorScheme.onSurface.copy(.65f))
                    Surface(Modifier.fillMaxWidth().padding(top = 34.dp), shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface.copy(.22f), border = androidx.compose.foundation.BorderStroke(1.dp, palette.secondary.copy(.26f))) {
                        Text(conditionNarrative(weather), Modifier.padding(17.dp), fontSize = 14.sp, lineHeight = 22.sp)
                    }
                }
            }
        }
        item {
            ConditionsDayChart(weather.hours, temperatureUnit, palette, weather.place)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text(if (weather.live) "LIVE BOM DATA" else "ESTIMATED DATA", Modifier.clip(CircleShape).background(palette.secondary.copy(.2f)).padding(horizontal = 11.dp, vertical = 7.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Text("Updated ${localFormatter("h:mm a", weather.place).format(weather.updated).lowercase()}", Modifier.padding(8.dp), fontSize = 9.sp)
            }
        }
        item { Text("${weather.place.name}, ${weather.place.state}", Modifier.padding(top = 22.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item { Text("Current observations and today’s forecast", color = MaterialTheme.colorScheme.onSurface.copy(.72f), fontSize = 11.sp) }
        val observations = listOf(
            Triple("Humidity", weather.observation.humidity?.let { "$it%" } ?: "Not available", "Current observation"),
            Triple("Wind", weather.observation.wind?.let { "${weather.observation.direction} $it km/h" } ?: "Not available", "Gusts ${weather.observation.gust ?: "—"} km/h"),
            Triple("Pressure", weather.observation.pressure?.let { "${it.roundToInt()} hPa" } ?: "Not available", "Mean sea-level pressure"),
            Triple("Rain chance", "${day.rainChance}%", "${day.rainAmount} mm possible"),
            Triple("UV index", "3", "Moderate"),
            Triple("Visibility", "Not available", "Nearest observation"),
            Triple("Rain since 9am", weather.observation.rainSince9?.let { "$it mm" } ?: "Not available", weather.observation.station),
            Triple("Moon phase", moonName(), "${moonIllumination()}% illuminated")
        )
        items(observations.chunked(2)) { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { item ->
                    Column(Modifier.weight(1f).padding(vertical = 20.dp).border(width = 0.dp, color = Color.Transparent).drawBehind { drawLine(palette.secondary.copy(.35f), Offset.Zero, Offset(size.width, 0f), 1.dp.toPx()) }) {
                        Text(item.first, color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 10.sp)
                        Text(item.second, Modifier.padding(vertical = 7.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text(item.third, color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SeasonsPage(dark: Boolean, onBack: () -> Unit) {
    val seasons = listOf(
        Season("Autumn", "Warmth softens.", "Long summer light gives way to cooler evenings and changing colour.", "1 March – 31 May", "Typical range 12–25°C", Color(0xFFE5A17D), Color(0xFFF6C8A5), Color(0xFF543638)),
        Season("Winter", "Cool, quiet light.", "Shorter days, crisp mornings and the year’s longest nights.", "1 June – 31 August", "Typical range 6–18°C", Color(0xFF9DBBDD), Color(0xFFCFE9F7), Color(0xFF173A68)),
        Season("Spring", "Colour returns.", "Days lengthen, landscapes brighten and warmth begins to build.", "1 September – 30 November", "Typical range 11–24°C", Color(0xFFA9D69E), Color(0xFFD8EDB8), Color(0xFF24563B)),
        Season("Summer", "Light lingers.", "Long, bright days bring warmth, clear evenings and vivid skies.", "1 December – 28 February", "Typical range 18–32°C", Color(0xFFF0A36F), Color(0xFFF9D98F), Color(0xFF6A3B24))
    )
    val currentSeason = seasonName(Place("season-page", "Australia", "", -25.0, 133.0))
    LazyColumn(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                if (dark) listOf(Color(0xFF13283A), Color(0xFF463659), Color(0xFF29493F))
                else listOf(Color(0xFFD9EFFF), Color(0xFFE8B9A7), Color(0xFF9ACBB1), Color(0xFFF3C97D))
            )
        ),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 25.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHeader("Seasons", onBack) }
        item {
            Column(Modifier.padding(top = 34.dp, bottom = 20.dp)) {
                Text("THE SOUTHERN HEMISPHERE", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("A year in colour.", fontSize = 43.sp, fontWeight = FontWeight.Bold)
                Text("Follow the gentle transition through Australia’s four meteorological seasons.", fontSize = 13.sp, lineHeight = 19.sp)
            }
        }
        items(seasons) { season ->
            Card(
                Modifier.fillMaxWidth().height(245.dp),
                shape = RoundedCornerShape(34.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.72f))
            ) {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(season.one, season.two))).padding(24.dp)) {
                    Column(Modifier.fillMaxHeight()) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = CircleShape, color = Color.White.copy(.42f)) {
                                Text(season.name, Modifier.padding(horizontal = 13.dp, vertical = 8.dp), color = season.textColor, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.weight(1f))
                            if (season.name == currentSeason) {
                                Surface(shape = CircleShape, color = Color.White.copy(.68f)) {
                                    Text("Current season", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = season.textColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(Modifier.height(23.dp))
                        Text(season.headline, color = season.textColor, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text(season.description, Modifier.widthIn(max = 285.dp).padding(top = 6.dp), color = season.textColor.copy(.78f), fontSize = 12.sp, lineHeight = 18.sp)
                        Spacer(Modifier.weight(1f))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(shape = CircleShape, color = Color.White.copy(.35f)) {
                                Text(season.dates, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = season.textColor, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                            Surface(shape = CircleShape, color = Color.White.copy(.48f)) {
                                Text(season.temperatureRange, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = season.textColor, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Atmos uses meteorological seasons for Australia and the Southern Hemisphere.",
                Modifier.padding(15.dp), fontSize = 11.sp, lineHeight = 17.sp, textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun SeasonAtmosSun(season: Season, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val centre = Offset(size.width / 2f, size.height / 2f)
        drawCircle(season.one.copy(.20f), radius = size.minDimension * .49f, center = centre)
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(.97f), season.two.copy(.95f), season.one),
                center = centre,
                radius = size.minDimension * .36f
            ),
            radius = size.minDimension * .36f,
            center = centre
        )
        drawCircle(Color.White.copy(.20f), radius = size.minDimension * .29f, center = centre, style = Stroke(width = 1.3.dp.toPx()))
    }
}

private data class Season(
    val name: String,
    val headline: String,
    val description: String,
    val dates: String,
    val temperatureRange: String,
    val one: Color,
    val two: Color,
    val textColor: Color = Color(0xFF4D3135)
)

private fun displayTemperature(celsius: Int, unit: TemperatureUnit): Int =
    if (unit == TemperatureUnit.Celsius) celsius else (celsius * 9f / 5f + 32f).roundToInt()


@Composable
private fun SettingsPage(
    theme: ThemeChoice,
    darkNightMode: Boolean,
    conditionAnimations: Boolean,
    homeLayout: HomeLayout,
    locationTransition: LocationTransition,
    density: DensityChoice,
    menuLeft: Boolean,
    temperatureUnit: TemperatureUnit,
    preferences: AtmosPreferences,
    onTheme: (ThemeChoice) -> Unit,
    onDarkNightMode: (Boolean) -> Unit,
    onConditionAnimations: (Boolean) -> Unit,
    onHomeLayout: (HomeLayout) -> Unit,
    onLocationTransition: (LocationTransition) -> Unit,
    onDensity: (DensityChoice) -> Unit,
    onMenuLeft: (Boolean) -> Unit,
    onTemperatureUnit: (TemperatureUnit) -> Unit,
    onOpenAtmos: () -> Unit,
    onBack: () -> Unit
) {
    var hidden by remember { mutableStateOf(preferences.hiddenCards) }
    var atmosphereIntensity by remember { mutableStateOf(preferences.atmosphereIntensity) }
    var seasonalAtmosphere by remember { mutableStateOf(preferences.seasonalAtmosphere) }
    var temperatureAtmosphere by remember { mutableStateOf(preferences.temperatureAtmosphere) }
    var solarAtmosphere by remember { mutableStateOf(preferences.solarAtmosphere) }
    var ambientAtmosphere by remember { mutableStateOf(preferences.ambientAtmosphere) }
    var seasonalParticles by remember { mutableStateOf(preferences.seasonalParticles) }
    var heatShimmer by remember { mutableStateOf(preferences.heatShimmer) }
    var coldFrost by remember { mutableStateOf(preferences.coldFrost) }
    var backgroundUpdates by remember { mutableStateOf(preferences.backgroundUpdates) }
    val settingsContext = LocalContext.current
    AtmosPageBackground(Modifier.fillMaxSize()) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 30.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHeader("Settings", onBack, foreground = Color.White) }
        item { Text("Make Atmos yours", Modifier.padding(top = 25.dp), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold) }
        item { Text("Appearance, layout and forecast preferences.", color = Color.White.copy(.68f)) }
        item {
            SettingsSection("Appearance", "Choose how Atmos follows your device theme.") {
                ThemeChoice.entries.forEach { option -> ChoiceRow(option.name.replaceFirstChar { it.uppercase() }, option == theme) { onTheme(option) } }
                Text("Forecast experience", Modifier.padding(top = 16.dp, bottom = 3.dp), fontWeight = FontWeight.Bold)
                Text("Both modes use the full Atmos hero. Choose whether each location is presented separately or flows through one continuous environment.", color = MaterialTheme.colorScheme.onSurface.copy(.60f), fontSize = 10.sp, lineHeight = 14.sp)
                Spacer(Modifier.height(10.dp))
                LayoutPreviewCard(
                    title = "Fullscreen Hero",
                    subtitle = "A complete full-screen hero forecast for each saved location.",
                    immersive = false,
                    selected = locationTransition == LocationTransition.Standard,
                    onClick = {
                        onHomeLayout(HomeLayout.Immersive)
                        onLocationTransition(LocationTransition.Standard)
                    }
                )
                Spacer(Modifier.height(10.dp))
                LayoutPreviewCard(
                    title = "Immersive",
                    subtitle = "The Atmos background changes continuously from the instant you swipe.",
                    immersive = true,
                    selected = locationTransition == LocationTransition.Immersive,
                    onClick = {
                        onHomeLayout(HomeLayout.Immersive)
                        onLocationTransition(LocationTransition.Immersive)
                    }
                )
                Text("Temperature unit", Modifier.padding(top = 16.dp, bottom = 4.dp), fontWeight = FontWeight.Bold)
                ChoiceRow("Celsius (°C)", temperatureUnit == TemperatureUnit.Celsius) { onTemperatureUnit(TemperatureUnit.Celsius) }
                ChoiceRow("Fahrenheit (°F)", temperatureUnit == TemperatureUnit.Fahrenheit) { onTemperatureUnit(TemperatureUnit.Fahrenheit) }
                Row(
                    Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f).padding(end = 14.dp)) {
                        Text("Dark night mode", fontWeight = FontWeight.Bold)
                        Text(
                            "Automatically use Atmos's dark night palette after sunset. Turn this off to keep Light mode bright at night.",
                            color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                    Switch(checked = darkNightMode, onCheckedChange = onDarkNightMode)
                }
            }
        }
        item {
            SettingsSection("Atmos system", "Control the living weather experience independently from the app layout.") {
                Text("Living Atmosphere", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Atmos coordinates feels-like temperature, season, sunlight, wind, humidity and pressure so the entire forecast moves as one environment.", Modifier.padding(top = 4.dp, bottom = 12.dp), color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 10.sp, lineHeight = 14.sp)
                FilledTonalButton(onClick = onOpenAtmos, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                    Text("Explore the Atmos system")
                }
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(end = 14.dp)) {
                        Text("Atmos system", fontWeight = FontWeight.Bold)
                        Text("Turn all living lighting, motion and particles on or off.", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp)
                    }
                    Switch(checked = conditionAnimations, onCheckedChange = onConditionAnimations)
                }
                Text("Intensity", Modifier.padding(top = 8.dp, bottom = 4.dp), fontWeight = FontWeight.Bold)
                AtmosphereIntensity.entries.forEach { option ->
                    ChoiceRow(option.name, option == atmosphereIntensity) {
                        atmosphereIntensity = option
                        preferences.atmosphereIntensity = option
                        onConditionAnimations(option != AtmosphereIntensity.Off)
                    }
                }
                AtmosSettingsToggle("Seasonal atmosphere", "Season palettes and tropical wet/dry identity.", seasonalAtmosphere) { seasonalAtmosphere = it; preferences.seasonalAtmosphere = it }
                AtmosSettingsToggle("Feels-like temperature", "Warmth, chill, frost and heat shimmer use the apparent temperature.", temperatureAtmosphere) { temperatureAtmosphere = it; preferences.temperatureAtmosphere = it }
                AtmosSettingsToggle("Solar lighting", "Continuous dawn, daylight, sunset and night lighting.", solarAtmosphere) { solarAtmosphere = it; preferences.solarAtmosphere = it }
                AtmosSettingsToggle("Animated hero gradient", "Gently moves the hero colours using wind, season, temperature and time of day.", ambientAtmosphere) { ambientAtmosphere = it; preferences.ambientAtmosphere = it }
                AtmosSettingsToggle("Seasonal particles", "Wind-responsive blossom, motes, leaves and crystals.", seasonalParticles) { seasonalParticles = it; preferences.seasonalParticles = it }
                AtmosSettingsToggle("Heat shimmer", "Subtle horizon movement in genuinely hot feels-like conditions.", heatShimmer) { heatShimmer = it; preferences.heatShimmer = it }
                AtmosSettingsToggle("Cold and frost", "Cool bloom and crystalline highlights in cold conditions.", coldFrost) { coldFrost = it; preferences.coldFrost = it }
            }
        }
        item {
            SettingsSection("Weather updates", "Control automatic forecast refreshes.") {
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(end = 14.dp)) {
                        Text("Background updates", fontWeight = FontWeight.Bold)
                        Text("Refresh saved locations about every 30 minutes. Android may delay work to protect battery.", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    Switch(checked = backgroundUpdates, onCheckedChange = { enabled ->
                        backgroundUpdates = enabled
                        preferences.backgroundUpdates = enabled
                        scheduleBackgroundUpdates(settingsContext, enabled)
                    })
                }
                Text("Automatic foreground refreshes remain limited to once every 10 minutes. Pull-to-refresh always requests fresh data immediately.", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
        item {
            SettingsSection("Layout", "Choose how much forecast information fits on screen.") {
                DensityChoice.entries.forEach { option -> ChoiceRow(option.name, option == density) { onDensity(option) } }
            }
        }
        item {
            SettingsSection("Floating menu", "Choose which side is most comfortable to reach.") {
                ChoiceRow("Left side", menuLeft) { onMenuLeft(true) }
                ChoiceRow("Right side", !menuLeft) { onMenuLeft(false) }
            }
        }
        item {
            SettingsSection("Weather detail cards", "Choose which cards appear. Hold and drag cards on the forecast to rearrange them.") {
                detailCardIds.forEach { id ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(detailTitle(id), fontWeight = FontWeight.Bold); Text("Show on the main forecast", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f)) }
                        Switch(id !in hidden, onCheckedChange = { show ->
                            hidden = if (show) hidden - id else hidden + id
                            preferences.hiddenCards = hidden
                        })
                    }
                }
                FilledTonalButton(onClick = { preferences.cardOrder = detailCardIds }, Modifier.fillMaxWidth()) { Text("Restore default order") }
            }
        }
    }
    }
}



@Composable
private fun AtmosSystemPage(
    weather: WeatherState,
    temperatureUnit: TemperatureUnit,
    preferences: AtmosPreferences,
    onBack: () -> Unit
) {
    var enabled by remember { mutableStateOf(true) }
    var seasonal by remember { mutableStateOf(preferences.seasonalAtmosphere) }
    var temperature by remember { mutableStateOf(preferences.temperatureAtmosphere) }
    var solar by remember { mutableStateOf(preferences.solarAtmosphere) }
    var ambient by remember { mutableStateOf(preferences.ambientAtmosphere) }
    var particles by remember { mutableStateOf(preferences.seasonalParticles) }
    var shimmer by remember { mutableStateOf(preferences.heatShimmer) }
    var frost by remember { mutableStateOf(preferences.coldFrost) }
    val palette = rememberSolarAwarePalette(weather.days.first().icon, weather.place)
    val day = weather.days.first()
    val temp = weather.observation.temp ?: day.high - 2
    val foreground = solarLegibleForeground(palette)

    AtmosPageBackground(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 32.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { PageHeader("Atmos system", onBack, foreground = Color.White) }
            item {
                Column(Modifier.padding(top = 18.dp)) {
                    Text("Weather, made alive.", color = Color.White, fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold)
                    Text("Explore each environmental layer and see how it contributes to the final Atmos scene.", Modifier.padding(top = 7.dp), color = Color.White.copy(.70f), fontSize = 13.sp, lineHeight = 19.sp)
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().height(560.dp),
                    shape = RoundedCornerShape(34.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Box(Modifier.fillMaxSize()) {
                        if (enabled) {
                            LivingHeroGradient(
                                palette = palette,
                                observation = weather.observation,
                                condition = day.condition,
                                enabled = ambient,
                                intensity = AtmosphereIntensity.Immersive,
                                modifier = Modifier.fillMaxSize()
                            )
                            TemperatureAtmosphereEffect(
                                temperatureC = weather.observation.feels ?: temp,
                                place = weather.place,
                                condition = day.condition,
                                observation = weather.observation,
                                enabled = temperature || seasonal || solar || particles || shimmer || frost,
                                preferences = preferences,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface))
                        }
                        Column(Modifier.fillMaxSize().padding(25.dp)) {
                            Text("LIVE DEMO", color = foreground.copy(.70f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text(weather.place.name, Modifier.padding(top = 8.dp), color = foreground, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                            Text(weather.place.state, color = foreground.copy(.72f), fontSize = 13.sp)
                            Spacer(Modifier.height(36.dp))
                            Text("${displayTemperature(temp, temperatureUnit)}°", color = foreground, fontSize = 88.sp, lineHeight = 88.sp, fontWeight = FontWeight.ExtraBold)
                            Text(nightCondition(day.condition), color = foreground, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("Feels like ${displayTemperature(weather.observation.feels ?: temp, temperatureUnit)}°", Modifier.padding(top = 5.dp), color = foreground.copy(.80f), fontSize = 14.sp)
                            Spacer(Modifier.weight(1f))
                            Surface(shape = RoundedCornerShape(24.dp), color = Color(0x99101A30)) {
                                Row(Modifier.fillMaxWidth().padding(vertical = 15.dp)) {
                                    HeroStat("Rain", "${day.rainChance}%", Modifier.weight(1f))
                                    HeroStat("Wind", weather.observation.wind?.let { "$it km/h" } ?: "—", Modifier.weight(1f))
                                    HeroStat("Humidity", weather.observation.humidity?.let { "$it%" } ?: "—", Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
            item {
                SettingsSection("Atmos controls", "Toggle each layer to understand its role in the living scene.") {
                    AtmosSettingsToggle("Atmos system", "Enables or disables the complete environmental renderer.", enabled) { enabled = it }
                    AtmosSettingsToggle("Seasonal colour", "Adjusts the palette for summer, autumn, winter, spring and tropical seasons.", seasonal) { seasonal = it; preferences.seasonalAtmosphere = it }
                    AtmosSettingsToggle("Feels-like temperature", "Adds visual warmth, chill, heat shimmer and frost according to apparent temperature.", temperature) { temperature = it; preferences.temperatureAtmosphere = it }
                    AtmosSettingsToggle("Solar lighting", "Moves the scene through dawn, daylight, sunset and night using local solar time.", solar) { solar = it; preferences.solarAtmosphere = it }
                    AtmosSettingsToggle("Living gradient", "Gently shifts colour and light so the background never feels static.", ambient) { ambient = it; preferences.ambientAtmosphere = it }
                    AtmosSettingsToggle("Seasonal particles", "Adds subtle blossom, dust, leaves or crystals that react to wind.", particles) { particles = it; preferences.seasonalParticles = it }
                    AtmosSettingsToggle("Heat shimmer", "Introduces restrained horizon distortion during genuinely hot conditions.", shimmer) { shimmer = it; preferences.heatShimmer = it }
                    AtmosSettingsToggle("Cold and frost", "Adds cool bloom and crystalline highlights during cold conditions.", frost) { frost = it; preferences.coldFrost = it }
                }
            }
            item {
                SettingsSection("How Atmos was built", "A shared environmental renderer turns forecast data into one coherent visual system.") {
                    Text("Atmos was created to make weather feel present rather than simply reported.", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(
                        "The renderer begins with the selected location, its local time and current forecast. It combines solar position, season, apparent temperature, humidity, wind, pressure and weather condition into a single scene state. That state controls the gradient, lighting, atmospheric overlays, movement, particles and foreground contrast.",
                        Modifier.padding(top = 10.dp),
                        color = MaterialTheme.colorScheme.onSurface.copy(.72f),
                        fontSize = 12.sp,
                        lineHeight = 19.sp
                    )
                    Text("How it works", Modifier.padding(top = 18.dp), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        "Solar-aware colour establishes the time-of-day light. Seasonal and temperature layers then tint that base without replacing it. Wind influences movement, while rain, snow, fog, frost and heat effects are added only when the forecast supports them. Text and chart colours are calculated independently for Fullscreen Hero and Immersive so each remains legible over its own lower-screen treatment.",
                        Modifier.padding(top = 7.dp),
                        color = MaterialTheme.colorScheme.onSurface.copy(.72f),
                        fontSize = 12.sp,
                        lineHeight = 19.sp
                    )
                    Text("Why it exists", Modifier.padding(top = 18.dp), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        "Most weather apps place information on top of a decorative background. Atmos treats the environment itself as part of the forecast. The aim is to communicate time, season and conditions at a glance while preserving clarity, restraint and battery-conscious performance.",
                        Modifier.padding(top = 7.dp),
                        color = MaterialTheme.colorScheme.onSurface.copy(.72f),
                        fontSize = 12.sp,
                        lineHeight = 19.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun AtmosSettingsToggle(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 14.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 10.sp, lineHeight = 14.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SettingsSection(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    val accent = when (title) {
        "Location" -> Color(0xFF64B8D7)
        "Appearance" -> Color(0xFFFF9B67)
        "Layout" -> Color(0xFF8E9FE8)
        "Floating menu" -> Color(0xFF73C7AE)
        "Weather detail cards" -> Color(0xFFE58CB4)
        else -> MaterialTheme.colorScheme.primary
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(.24f))
    ) {
        Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AtmosSettingsGlyph(title, accent, Modifier.size(48.dp))
                    Text(title, Modifier.padding(start = 13.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Text(subtitle, Modifier.padding(top = 5.dp, bottom = 14.dp), color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 11.sp)
                content()
            }
        }
    }
}


@Composable
private fun AtmosSettingsGlyph(title: String, accent: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "settingsGlyph-$title")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(8_000, easing = LinearEasing), RepeatMode.Reverse), label = "glyphPhase")
    Canvas(modifier) {
        drawCircle(accent.copy(alpha = .14f), size.minDimension * .48f)
        when (title) {
            "Appearance" -> {
                drawCircle(accent, size.minDimension * .20f, Offset(size.width * (.46f + phase * .08f), size.height * .48f))
                drawArc(accent.copy(.52f), 205f, 230f, false, style = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round))
            }
            "Atmos system" -> repeat(3) { index ->
                val angle = (phase * 90f + index * 120f) * PI.toFloat() / 180f
                drawCircle(accent.copy(alpha = .55f + index * .12f), 2.2.dp.toPx(), Offset(size.width / 2f + cos(angle) * size.width * .24f, size.height / 2f + sin(angle) * size.height * .24f))
            }
            "Layout" -> {
                drawRoundRect(accent.copy(.72f), Offset(size.width * .20f, size.height * .22f), Size(size.width * .60f, size.height * .24f), CornerRadius(4.dp.toPx()))
                drawRoundRect(accent.copy(.42f), Offset(size.width * .20f, size.height * .54f), Size(size.width * .27f, size.height * .22f), CornerRadius(4.dp.toPx()))
                drawRoundRect(accent.copy(.42f), Offset(size.width * .53f, size.height * .54f), Size(size.width * .27f, size.height * .22f), CornerRadius(4.dp.toPx()))
            }
            else -> {
                drawCircle(accent.copy(.82f), size.minDimension * .15f, Offset(size.width * .38f, size.height * .44f))
                drawCircle(accent.copy(.48f), size.minDimension * .11f, Offset(size.width * .64f, size.height * (.56f - phase * .06f)))
            }
        }
    }
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).atmosPress(onClick),
        shape = RoundedCornerShape(17.dp),
        color = if (selected) MaterialTheme.colorScheme.primary.copy(.15f) else Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary.copy(.45f) else MaterialTheme.colorScheme.onSurface.copy(.1f))
    ) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f), fontWeight = FontWeight.Bold); Text(if (selected) "●" else "○", color = MaterialTheme.colorScheme.primary) } }
}

@Composable
private fun LocationsPage(
    preferences: AtmosPreferences,
    current: Place,
    weatherCache: Map<String, WeatherState>,
    temperatureUnit: TemperatureUnit,
    onLocationAdded: (Place) -> Unit,
    onSelect: (Place) -> Unit,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<Place>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(preferences.savedPlaces) }
    var draggingKey by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(0f) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(query) {
        val clean = query.trim()
        if (clean.length < 2) {
            searchResults = emptyList()
            searching = false
        } else {
            searching = true
            delay(320)
            val local = places.filter { "${it.name} ${it.state}".contains(clean, true) }.take(8)
            val global = GlobalGeocodingRepository.search(clean)
            searchResults = (local + global)
                .distinctBy { "${it.name.lowercase()}:${"%.3f".format(Locale.US, it.latitude)}:${"%.3f".format(Locale.US, it.longitude)}" }
                .take(20)
            searching = false
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) scope.launch {
            val location = requestCurrentLocation(context) ?: currentLocation(context)
            location?.let {
                val nearest = places.minByOrNull { place -> distanceSquared(place.latitude, place.longitude, it.first, it.second) } ?: places.first()
                val live = if (coordinatesAreAustralian(it.first, it.second)) {
                    nearest.copy(latitude = it.first, longitude = it.second, current = true, country = "Australia", countryCode = "AU")
                } else {
                    Place("live-global", "Current location", "International", it.first, it.second, true, "International", "")
                }
                saved = normaliseSavedPlaces(listOf(live) + saved.filterNot { place -> place.current })
                preferences.savedPlaces = saved
                onSelect(live)
            }
        }
    }

    AtmosPageBackground(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 18.dp,
                end = 18.dp,
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 34.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PageHeader("Locations", onBack, foreground = Color.White) }
            item {
                Column(Modifier.padding(top = 22.dp, bottom = 4.dp)) {
                    Text("Your atmosphere, everywhere.", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold, lineHeight = 36.sp)
                    Text("Live conditions from every saved place. Hold a card and move it exactly where you want it.", Modifier.padding(top = 8.dp), color = Color.White.copy(.68f), fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
            item {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White.copy(.09f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.15f))
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search Australia or the world", color = Color.White.copy(.55f)) },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = Color.White,
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            disabledBorderColor = Color.Transparent,
                            errorBorderColor = Color.Transparent,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        )
                    )
                }
            }
            item {
                FilledTonalButton(
                    onClick = { launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(20.dp)
                ) { Text(if (saved.any { it.current }) "Refresh current location" else "Use my current location", fontWeight = FontWeight.Bold) }
            }
            if (searching) item {
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                    Text("Searching worldwide…", Modifier.padding(start = 10.dp), color = Color.White.copy(.68f), fontSize = 12.sp)
                }
            }
            if (query.length > 1) items(searchResults, key = { "search:${it.cacheKey()}:${it.name}" }) { place ->
                Surface(
                    Modifier.fillMaxWidth().atmosPress {
                        if (saved.none { sameSavedPlace(it, place) }) {
                            saved = normaliseSavedPlaces(saved + place)
                            preferences.savedPlaces = saved
                            onLocationAdded(place)
                        }
                        query = ""
                    },
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White.copy(.10f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.14f))
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(place.name, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(place.state.ifBlank { place.country }, color = Color.White.copy(.58f), fontSize = 10.sp)
                        }
                        Text(if (saved.any { sameSavedPlace(it, place) }) "Added" else "+ Add", color = Color(0xFF8FD7FF), fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (query.length < 2) item {
                Text("SAVED ATMOSPHERES", Modifier.padding(top = 8.dp, bottom = 2.dp), color = Color.White.copy(.48f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            }
            if (query.length < 2) itemsIndexed(saved, key = { _, place -> place.pagerKey(0) }) { _, place ->
                val key = place.pagerKey(0)
                val canDrag = !place.current
                val weather = weatherCache[place.cacheKey()]
                val day = weather?.days?.firstOrNull()
                val temperature = weather?.observation?.temp ?: weather?.hours?.firstOrNull()?.temp ?: day?.high
                val condition = day?.condition ?: if (weather == null) "Forecast loading" else "Current conditions"
                val icon = day?.icon.orEmpty()
                // Use the exact same solar-aware palette as the full hero. This preserves
                // dawn, daytime, sunset, twilight and true-night colour transitions for
                // every saved location instead of collapsing previews into one generic
                // day/night palette.
                val palette = rememberSolarAwarePalette(icon, place)
                val cardForeground = solarLegibleForeground(palette)
                val isDragging = draggingKey == key
                val cardHeightPx = with(LocalDensity.current) { 174.dp.toPx() }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(174.dp)
                        .clickable { onSelect(place) }
                        .zIndex(if (isDragging) 10f else 0f)
                        .graphicsLayer {
                            translationY = if (isDragging) dragOffset else 0f
                            scaleX = if (isDragging) 1.025f else 1f
                            scaleY = if (isDragging) 1.025f else 1f
                            shadowElevation = if (isDragging) 24.dp.toPx() else 0f
                        }
                        .pointerInput(saved, key, canDrag) {
                            if (canDrag) detectDragGesturesAfterLongPress(
                                onDragStart = { draggingKey = key; dragOffset = 0f },
                                onDragCancel = { draggingKey = null; dragOffset = 0f },
                                onDragEnd = { draggingKey = null; dragOffset = 0f; preferences.savedPlaces = saved },
                                onDrag = { change, amount ->
                                    change.consume()
                                    dragOffset += amount.y
                                    val from = saved.indexOfFirst { it.pagerKey(0) == key }
                                    if (from >= 0) {
                                        val direction = when {
                                            dragOffset > cardHeightPx * .52f -> 1
                                            dragOffset < -cardHeightPx * .52f -> -1
                                            else -> 0
                                        }
                                        val target = from + direction
                                        if (direction != 0 && target in saved.indices && !saved[target].current) {
                                            val mutable = saved.toMutableList()
                                            val moved = mutable.removeAt(from)
                                            mutable.add(target, moved)
                                            saved = normaliseSavedPlaces(mutable)
                                            preferences.savedPlaces = saved
                                            dragOffset -= direction * cardHeightPx
                                        }
                                    }
                                }
                            )
                        },
                    shape = RoundedCornerShape(30.dp),
                    color = Color.Transparent,
                    border = androidx.compose.foundation.BorderStroke(1.dp, cardForeground.copy(if (isDragging) .34f else .18f))
                ) {
                    Box(Modifier.fillMaxSize()) {
                        if (weather != null) {
                            LivingHeroGradient(
                                palette = palette,
                                observation = weather.observation,
                                condition = condition,
                                enabled = preferences.conditionAnimations && preferences.ambientAtmosphere && preferences.atmosphereIntensity != AtmosphereIntensity.Off,
                                intensity = preferences.atmosphereIntensity,
                                modifier = Modifier.fillMaxSize()
                            )
                            TemperatureAtmosphereEffect(
                                temperatureC = weather.observation.feels ?: temperature ?: 18,
                                place = place,
                                condition = condition,
                                observation = weather.observation,
                                enabled = preferences.conditionAnimations,
                                preferences = preferences,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(
                                Modifier.fillMaxSize().background(
                                    Brush.linearGradient(listOf(palette.top, palette.secondary, palette.bottom))
                                )
                            )
                        }
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, cardForeground.copy(alpha = .025f), if (cardForeground == Color.White) Color.Black.copy(.20f) else Color.White.copy(.10f))
                                    )
                                )
                        )
                        Column(Modifier.fillMaxSize().padding(20.dp)) {
                            Row(verticalAlignment = Alignment.Top) {
                                Column(Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(place.name, color = cardForeground, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Spacer(Modifier.width(8.dp))
                                        LocationSeasonPill(place)
                                        if (place.current) Text("  LIVE", color = cardForeground.copy(.78f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                    }
                                    Text(place.state.ifBlank { place.country }, color = cardForeground.copy(.68f), fontSize = 10.sp, maxLines = 1)
                                }
                                if (!place.current) Spacer(Modifier.width(38.dp))
                            }
                            Spacer(Modifier.weight(1f))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        temperature?.let { "${displayTemperature(it, temperatureUnit)}°${if (temperatureUnit == TemperatureUnit.Fahrenheit) "F" else ""}" } ?: "—°",
                                        color = cardForeground,
                                        fontSize = 48.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = (-2).sp,
                                        lineHeight = 50.sp
                                    )
                                    Text(condition, color = cardForeground.copy(.82f), fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(SimpleDateFormat("h:mm a", Locale.getDefault()).apply { timeZone = place.timeZone() }.format(Date()), color = cardForeground, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text(if (sameSavedPlace(place, current)) "CURRENTLY VIEWING" else "LOCAL TIME", color = cardForeground.copy(.55f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                            }
                        }
                        if (!place.current) {
                            Surface(
                                Modifier.align(Alignment.TopEnd).padding(top = 12.dp, end = 12.dp).clickable {
                                    saved = normaliseSavedPlaces(saved.filterNot { sameSavedPlace(it, place) })
                                    preferences.savedPlaces = saved
                                },
                                shape = CircleShape,
                                color = palette.secondary.copy(alpha = .22f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, cardForeground.copy(.30f)),
                                shadowElevation = 5.dp
                            ) {
                                Text(
                                    "×",
                                    Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                                    color = cardForeground,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class RadarSite(
    val id: Int,
    val name: String,
    val latitude: Double,
    val longitude: Double
) {
    val productCode: String get() = "IDR${id.toString().padStart(2, '0')}3"
}

private val radarSites = listOf(
    RadarSite(70, "Perth (Serpentine)", -32.39, 115.87),
    RadarSite(31, "Albany", -34.94, 117.80),
    RadarSite(6, "Geraldton", -28.80, 114.70),
    RadarSite(32, "Esperance", -33.83, 121.89),
    RadarSite(48, "Kalgoorlie", -30.78, 121.45),
    RadarSite(17, "Broome", -17.95, 122.24),
    RadarSite(111, "Karratha", -20.71, 116.77),
    RadarSite(2, "Melbourne", -37.86, 144.76),
    RadarSite(71, "Sydney (Terrey Hills)", -33.70, 151.21),
    RadarSite(3, "Wollongong (Appin)", -34.26, 150.88),
    RadarSite(40, "Canberra (Captains Flat)", -35.66, 149.51),
    RadarSite(66, "Brisbane (Mt Stapylton)", -27.72, 153.24),
    RadarSite(19, "Cairns", -16.82, 145.68),
    RadarSite(64, "Adelaide (Buckland Park)", -34.62, 138.47),
    RadarSite(76, "Hobart (Mt Koonya)", -43.11, 147.81),
    RadarSite(63, "Darwin (Berrimah)", -12.46, 130.93),
    RadarSite(25, "Alice Springs", -23.82, 133.90)
)

private object BomRadarRepository {
    suspend fun load(context: Context, site: RadarSite, force: Boolean = false): Pair<Bitmap?, Date?> = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "radar").apply { mkdirs() }
        val imageFile = File(dir, "${site.productCode}.gif")
        val timestampFile = File(dir, "${site.productCode}.time")
        val freshEnough = imageFile.exists() && System.currentTimeMillis() - imageFile.lastModified() < 4 * 60 * 1000
        if (!force && freshEnough) {
            return@withContext BitmapFactory.decodeFile(imageFile.absolutePath) to Date(imageFile.lastModified())
        }
        val address = "https://www.bom.gov.au/radar/${site.productCode}.gif?t=${System.currentTimeMillis()}"
        val downloaded = runCatching {
            val connection = (URL(address).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 15_000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Atmos Android Weather App")
            }
            connection.inputStream.use { input ->
                imageFile.outputStream().use { output -> input.copyTo(output) }
            }
            connection.disconnect()
            imageFile.setLastModified(System.currentTimeMillis())
            timestampFile.writeText(System.currentTimeMillis().toString())
            BitmapFactory.decodeFile(imageFile.absolutePath)
        }.getOrNull()
        val bitmap = downloaded ?: imageFile.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) }
        bitmap to imageFile.takeIf { it.exists() }?.let { Date(it.lastModified()) }
    }
}

@Composable
private fun RadarPage(place: Place, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val site = remember(place.latitude, place.longitude) {
        radarSites.minByOrNull { distanceSquared(it.latitude, it.longitude, place.latitude, place.longitude) } ?: radarSites.first()
    }
    var radarBitmap by remember(site.id) { mutableStateOf<Bitmap?>(null) }
    var updated by remember(site.id) { mutableStateOf<Date?>(null) }
    var loading by remember(site.id) { mutableStateOf(true) }
    var failed by remember(site.id) { mutableStateOf(false) }

    fun request(force: Boolean) {
        scope.launch {
            loading = true
            failed = false
            val result = BomRadarRepository.load(context, site, force)
            radarBitmap = result.first
            updated = result.second
            failed = result.first == null
            loading = false
        }
    }

    LaunchedEffect(site.id) { request(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 30.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHeader("Rain radar", onBack) }
        item {
            Column {
                Text(place.name, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                Text("Nearest radar · ${site.name} · 128 km", color = MaterialTheme.colorScheme.onSurface.copy(.62f), fontSize = 12.sp)
            }
        }
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101A2A)),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Box(
                    Modifier.fillMaxWidth().height(390.dp)
                        .background(Brush.verticalGradient(listOf(Color(0xFF17263E), Color(0xFF0B1423)))),
                    contentAlignment = Alignment.Center
                ) {
                    radarBitmap?.let { bitmap ->
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Bureau rain radar for ${site.name}",
                            modifier = Modifier.fillMaxSize().padding(8.dp).clip(RoundedCornerShape(24.dp)),
                            contentScale = ContentScale.Fit
                        )
                    }
                    if (loading) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                            Text("Loading latest radar…", Modifier.padding(top = 12.dp), color = Color.White.copy(.78f), fontSize = 12.sp)
                        }
                    } else if (failed) {
                        Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Radar unavailable", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text("The nearest Bureau radar image could not be loaded. It may be temporarily offline.", Modifier.padding(top = 8.dp), color = Color.White.copy(.7f), textAlign = TextAlign.Center, fontSize = 12.sp)
                        }
                    }
                    Box(Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(13.dp).clip(CircleShape).background(Color.White).border(3.dp, Color(0xFF5DA9FF), CircleShape))
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Latest observation", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(updated?.let { SimpleDateFormat("h:mm a", Locale.getDefault()).format(it) } ?: "Not available", color = MaterialTheme.colorScheme.onSurface.copy(.58f), fontSize = 11.sp)
                }
                Button(onClick = { request(true) }, enabled = !loading) { Text("Refresh") }
            }
        }
        item {
            Card(
                Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.primary.copy(.22f), RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(.82f))
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("Rain intensity", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        listOf(
                            Color(0xFFB8E5FF) to "Light",
                            Color(0xFF57C8A9) to "Moderate",
                            Color(0xFFFFD75A) to "Heavy",
                            Color(0xFFF06161) to "Intense"
                        ).forEach { (colour, label) ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.width(48.dp).height(8.dp).clip(CircleShape).background(colour))
                                Text(label, Modifier.padding(top = 6.dp), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f))
                            }
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Radar shows observed precipitation, not a forecast. Coverage and accuracy can reduce farther from the radar site. Data © Commonwealth of Australia, Bureau of Meteorology. Atmos is independent and is not endorsed by the Bureau.",
                color = MaterialTheme.colorScheme.onSurface.copy(.55f), fontSize = 10.sp, lineHeight = 15.sp
            )
        }
    }
}

@Composable
private fun AtmosAboutFeatureCard(symbol: String, title: String, description: String, accent: Color) {
    Surface(
        Modifier.fillMaxWidth().padding(top = 14.dp),
        shape = RoundedCornerShape(28.dp),
        color = Color.White.copy(.08f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.Top) {
            Surface(Modifier.size(48.dp), shape = CircleShape, color = accent.copy(.16f), border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(.38f))) {
                Box(contentAlignment = Alignment.Center) { Text(symbol, color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            }
            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(description, Modifier.padding(top = 5.dp), color = Color.White.copy(.66f), fontSize = 11.sp, lineHeight = 17.sp)
            }
        }
    }
}

@Composable
private fun AboutPage(onBack: () -> Unit) {
    val context = LocalContext.current
    val versionName = BuildConfig.VERSION_NAME
    val buildNumber = BuildConfig.VERSION_CODE
    val deepGradient = Brush.verticalGradient(
        listOf(
            Color(0xFF07101F),
            Color(0xFF10162D),
            Color(0xFF24133D),
            Color(0xFF0B1830)
        )
    )

    Box(Modifier.fillMaxSize().background(deepGradient)) {
        Box(
            Modifier
                .size(280.dp)
                .offset(x = 150.dp, y = (-75).dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0x665F8CFF), Color.Transparent)
                    ),
                    CircleShape
                )
        )
        Box(
            Modifier
                .size(250.dp)
                .offset(x = (-115).dp, y = 470.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0x55FF8A63), Color.Transparent)
                    ),
                    CircleShape
                )
        )

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 22.dp,
                end = 22.dp,
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 15.dp,
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 34.dp
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        Modifier.size(46.dp).clickable(onClick = onBack),
                        shape = CircleShape,
                        color = Color.White.copy(.10f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("‹", color = Color.White, fontSize = 36.sp)
                        }
                    }
                    Text(
                        "About Atmos",
                        Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Spacer(Modifier.width(46.dp))
                }
            }
            item {
                Spacer(Modifier.height(34.dp))
                Box(
                    Modifier
                        .size(162.dp)
                        .shadow(28.dp, RoundedCornerShape(48.dp), ambientColor = Color(0x885A79FF), spotColor = Color(0x885A79FF))
                        .clip(RoundedCornerShape(48.dp))
                        .border(1.dp, Color.White.copy(.22f), RoundedCornerShape(48.dp))
                ) { FullScreenAtmosArtwork() }
            }
            item {
                Text(
                    "Atmos",
                    Modifier.padding(top = 24.dp),
                    color = Color.White,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            item {
                Text(
                    "Australian weather, thoughtfully presented.",
                    color = Color.White.copy(.72f),
                    textAlign = TextAlign.Center
                )
            }
            item {
                Row(
                    Modifier.padding(top = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(.12f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.16f))
                    ) {
                        Text(
                            "VERSION $versionName",
                            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF826BFF).copy(.32f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFB9AEFF).copy(.42f))
                    ) {
                        Text(
                            "BUILD $buildNumber",
                            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            item {
                Surface(
                    Modifier.fillMaxWidth().padding(top = 28.dp),
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White.copy(.08f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Made for Australia", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Atmos is designed in Australia around the way Australians experience weather: local observations, clear forecasts, changing seasons and conditions that can shift quickly.",
                            Modifier.padding(top = 8.dp),
                            color = Color.White.copy(.68f),
                            fontSize = 12.sp,
                            lineHeight = 19.sp
                        )
                    }
                }
            }
            item {
                Surface(
                    Modifier.fillMaxWidth().padding(top = 14.dp),
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White.copy(.08f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Weather data", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Australian forecasts, observations and warnings are sourced from the Bureau of Meteorology wherever available. International forecasts are provided by Open-Meteo, using the location’s local time zone. Atmos is independent and is not affiliated with or endorsed by either provider.",
                            Modifier.padding(top = 8.dp),
                            color = Color.White.copy(.68f),
                            fontSize = 12.sp,
                            lineHeight = 19.sp
                        )
                    }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(top = 28.dp)) {
                    Text("THE ATMOS SYSTEM", color = Color.White.copy(.58f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("A forecast that responds to the weather.", Modifier.padding(top = 6.dp), color = Color.White, fontSize = 25.sp, lineHeight = 29.sp, fontWeight = FontWeight.Bold)
                    Text("Atmos turns live forecast data into a coordinated visual environment. Rather than adding decoration, each layer responds to the same conditions so the interface feels calm, coherent and alive.", Modifier.padding(top = 9.dp), color = Color.White.copy(.68f), fontSize = 12.sp, lineHeight = 19.sp)
                }
            }
            item { AtmosAboutFeatureCard("☼", "Solar light", "Dawn, daylight, sunset, twilight and night continuously shape the hero lighting and gradient.", Color(0xFFFFC66D)) }
            item { AtmosAboutFeatureCard("≈", "Feels-like temperature", "Apparent temperature adds restrained warmth, coolness, frost or shimmer so the forecast feels closer to conditions outside.", Color(0xFF7ED8FF)) }
            item { AtmosAboutFeatureCard("✦", "Seasonal atmosphere", "Season and climate region influence colour, ambience and optional particles—from blossom and summer motes to leaves and winter crystals.", Color(0xFFC7A4FF)) }
            item { AtmosAboutFeatureCard("↗", "Natural wind", "Wind direction and speed guide gradient movement and particle travel, while turbulence keeps motion organic rather than looped.", Color(0xFF78DFC5)) }
            item {
                Surface(Modifier.fillMaxWidth().padding(top = 14.dp), shape = RoundedCornerShape(28.dp), color = Color.White.copy(.08f), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Built to stay subtle", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("The system adapts its density and movement to the selected Atmos intensity. Every layer can also be adjusted or disabled in Settings → Atmos system, including particles, seasonal colour, solar lighting, temperature effects and wind response.", Modifier.padding(top = 8.dp), color = Color.White.copy(.68f), fontSize = 12.sp, lineHeight = 19.sp)
                    }
                }
            }
            item {
                Text("Built by Josh Stanley", Modifier.padding(top = 24.dp), color = Color.White.copy(.92f), fontWeight = FontWeight.Bold)
            }
            item {
                Button(
                    onClick = { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:Josh.stanley@me.com"))) },
                    modifier = Modifier.padding(top = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF131A32))
                ) { Text("Contact Josh", fontWeight = FontWeight.Bold) }
            }
            item {
                Text(
                    "Atmos $versionName · Build $buildNumber",
                    Modifier.padding(top = 28.dp),
                    color = Color.White.copy(.48f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit, foreground: Color = MaterialTheme.colorScheme.onSurface) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Surface(Modifier.size(46.dp).clickable(onClick = onBack), shape = CircleShape, color = foreground.copy(.10f)) { Box(contentAlignment = Alignment.Center) { Text("‹", color = foreground, fontSize = 36.sp) } }
        Text(title, Modifier.weight(1f), color = foreground, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.width(46.dp))
    }
}

@Composable
private fun QuickMenu(left: Boolean, visible: Boolean, lifted: Boolean, weather: WeatherState, onPage: (Page) -> Unit) {
    var open by remember { mutableStateOf(false) }
    if (!visible) return
    val extraLift by animateDpAsState(if (lifted) 96.dp else 0.dp, animationSpec = tween(260), label = "quick-menu-lift")
    Box(
        Modifier.fillMaxSize().padding(
            start = if (left) 18.dp else 0.dp,
            end = if (left) 0.dp else 18.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 19.dp + extraLift
        ),
        contentAlignment = if (left) Alignment.BottomStart else Alignment.BottomEnd
    ) {
        Column(horizontalAlignment = if (left) Alignment.Start else Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AnimatedVisibility(open, enter = fadeIn() + scaleIn(), exit = fadeOut() + scaleOut()) {
                Column(horizontalAlignment = if (left) Alignment.Start else Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        Triple("Rain radar", Page.Radar, Color(0xFF5E9FE8)),
                        Triple("Seasons", Page.Seasons, Color(0xFF91CF8C)),
                        Triple("Saved locations", Page.Locations, Color(0xFF64D1D0)),
                        Triple("About Atmos", Page.About, Color(0xFFB58BEA)),
                        Triple("Settings", Page.Settings, Color(0xFF75BCE9))
                    ).forEach { item ->
                        Surface(
                            Modifier.clickable { open = false; onPage(item.second) },
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surface.copy(.95f),
                            shadowElevation = 10.dp
                        ) {
                            Row(Modifier.padding(start = 14.dp, end = 8.dp, top = 7.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(item.first, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(9.dp))
                                Box(Modifier.size(32.dp).clip(CircleShape).background(item.third), contentAlignment = Alignment.Center) { Text(atmosGlyph(item.second.name.lowercase()), color = Color.White) }
                            }
                        }
                    }
                }
            }
            val rotation by animateFloatAsState(if (open) 45f else 0f, label = "menu")
            val condition = weather.days.firstOrNull()?.condition.orEmpty().lowercase()
            val season = seasonName(weather.place)
            val menuColors = when {
                "rain" in condition || "shower" in condition -> listOf(Color(0xFF4DA6D8), Color(0xFF315C9A))
                "storm" in condition || "thunder" in condition -> listOf(Color(0xFF7561A8), Color(0xFF343B62))
                "cloud" in condition || "overcast" in condition -> listOf(Color(0xFF9BADBF), Color(0xFF667A9A))
                season == "Spring" -> listOf(Color(0xFF8BDFB0), Color(0xFF68B7D0))
                season == "Autumn" -> listOf(Color(0xFFF0A45D), Color(0xFFC56B4B))
                season == "Winter" -> listOf(Color(0xFF88D4F2), Color(0xFF7893D0))
                else -> listOf(Color(0xFFFFC35A), Color(0xFFED7C65))
            }
            val menuGlyph = when {
                open -> "×"
                "rain" in condition || "shower" in condition -> "⌁"
                "storm" in condition || "thunder" in condition -> "ϟ"
                "cloud" in condition || "overcast" in condition -> "☁"
                season == "Spring" -> "✿"
                season == "Autumn" -> "❋"
                season == "Winter" -> "✦"
                else -> "☀"
            }
            Surface(
                Modifier.size(60.dp).shadow(16.dp, CircleShape).clickable { open = !open },
                shape = CircleShape,
                color = Color.Transparent
            ) {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(menuColors)), contentAlignment = Alignment.Center) {
                    Text(menuGlyph, color = Color.White, fontSize = if (open) 30.sp else 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.graphicsLayer(rotationZ = if (open) rotation else 0f))
                }
            }
        }
    }
}

private fun conditionNarrative(weather: WeatherState): String {
    val day = weather.days.first()
    val place = if (weather.place.current) weather.place.state else weather.place.name
    val condition = nightCondition(day.condition).replaceFirstChar { it.lowercase() }
    val rain = when {
        day.rainChance < 20 -> "Little rain is expected."
        day.rainChance < 50 -> "There is a ${day.rainChance}% chance of rain."
        else -> "Rain is likely, with a ${day.rainChance}% chance."
    }
    val wind = weather.observation.wind?.let { if (it < 15) "Winds remain light." else if (it < 30) "A moderate breeze is present." else "Strong winds are being observed." } ?: ""
    return "${if (isNight()) "A $condition evening" else day.condition} across $place. $rain $wind".trim()
}

private fun nightCondition(condition: String): String =
    if (!isNight()) condition else when {
        condition.contains("sunny", true) || condition.contains("clear", true) -> "Clear night"
        condition.contains("cloud", true) -> "Cloudy night"
        condition.contains("shower", true) -> "Evening showers"
        else -> condition
    }

private fun isNight(date: Date = Date(), timeZone: TimeZone = TimeZone.getDefault()): Boolean {
    val hour = Calendar.getInstance(timeZone).apply { time = date }.get(Calendar.HOUR_OF_DAY)
    return hour < 6 || hour >= 18
}

private fun Place.hasDifferentLocalTime(now: Date = Date()): Boolean {
    val device = TimeZone.getDefault()
    val location = timeZone()
    return device.getOffset(now.time) != location.getOffset(now.time)
}

private fun seasonName(place: Place, date: Date = Date()): String {
    val calendar = Calendar.getInstance(place.timeZone()).apply { time = date }
    val month = calendar.get(Calendar.MONTH) + 1
    val latitude = place.latitude

    // Very low latitudes do not experience four meaningful temperature seasons.
    // Atmos uses a simple tropical wet/dry convention rather than displaying a
    // misleading northern or southern season.
    if (kotlin.math.abs(latitude) < 8.0) {
        val wet = if (latitude >= 0.0) month in 5..10 else month >= 11 || month <= 4
        return if (wet) "Wet season" else "Dry season"
    }

    val southern = latitude < 0.0
    return if (southern) {
        when (month) {
            12, 1, 2 -> "Summer"
            3, 4, 5 -> "Autumn"
            6, 7, 8 -> "Winter"
            else -> "Spring"
        }
    } else {
        when (month) {
            12, 1, 2 -> "Winter"
            3, 4, 5 -> "Spring"
            6, 7, 8 -> "Summer"
            else -> "Autumn"
        }
    }
}

private fun daysToNextSeason(place: Place, date: Date = Date()): String {
    val calendar = Calendar.getInstance(place.timeZone()).apply { time = date }
    val month = calendar.get(Calendar.MONTH) + 1
    val latitude = place.latitude

    if (kotlin.math.abs(latitude) < 8.0) {
        val wetNow = if (latitude >= 0.0) month in 5..10 else month >= 11 || month <= 4
        val nextMonth = if (latitude >= 0.0) {
            if (wetNow) 11 else 5
        } else {
            if (wetNow) 5 else 11
        }
        val nextName = if (wetNow) "Dry season" else "Wet season"
        val next = Calendar.getInstance(place.timeZone()).apply {
            time = date
            set(Calendar.MONTH, nextMonth - 1)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (!time.after(date)) add(Calendar.YEAR, 1)
        }
        return "${((next.timeInMillis - date.time) / 86_400_000L).coerceAtLeast(0)} days until $nextName"
    }

    val southern = latitude < 0.0
    val (nextMonth, nextName) = if (southern) {
        when (month) {
            12, 1, 2 -> 3 to "Autumn"
            3, 4, 5 -> 6 to "Winter"
            6, 7, 8 -> 9 to "Spring"
            else -> 12 to "Summer"
        }
    } else {
        when (month) {
            12, 1, 2 -> 3 to "Spring"
            3, 4, 5 -> 6 to "Summer"
            6, 7, 8 -> 9 to "Autumn"
            else -> 12 to "Winter"
        }
    }
    val next = Calendar.getInstance(place.timeZone()).apply {
        time = date
        set(Calendar.MONTH, nextMonth - 1)
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        if (!time.after(date)) add(Calendar.YEAR, 1)
    }
    return "${((next.timeInMillis - date.time) / 86_400_000L).coerceAtLeast(0)} days until $nextName"
}

private fun moonPhase(): Double {
    val known = 947182440000L
    val cycle = 2_551_443_000L
    return (((System.currentTimeMillis() - known) % cycle + cycle) % cycle).toDouble() / cycle
}

private fun moonIllumination(): Int = ((1 - cos(moonPhase() * 2 * PI)) / 2 * 100).roundToInt()
private fun moonName(): String = when (moonPhase()) {
    in 0.0..0.03, in 0.97..1.0 -> "New moon"
    in 0.03..0.22 -> "Waxing crescent"
    in 0.22..0.28 -> "First quarter"
    in 0.28..0.47 -> "Waxing gibbous"
    in 0.47..0.53 -> "Full moon"
    in 0.53..0.72 -> "Waning gibbous"
    in 0.72..0.78 -> "Last quarter"
    else -> "Waning crescent"
}

private fun dayName(offset: Int): String =
    SimpleDateFormat("EEE", Locale.ENGLISH).format(Date(System.currentTimeMillis() + offset * 86_400_000L))

private fun atmosGlyph(id: String): String = when (id) {
    "sun" -> "☀"; "wind" -> "≋"; "moon" -> "☾"; "rain" -> "◉"; "uv" -> "✹"
    "pressure" -> "◴"; "humidity" -> "♢"; "season", "seasons" -> "❋"; "tide" -> "≈"
    "conditions" -> "◉"; "locations" -> "⌖"; "about" -> "☼"; "settings" -> "⚙"
    else -> "✦"
}

private fun detailTitle(id: String): String = when (id) {
    "sun" -> "Sun & daylight"; "wind" -> "Wind"; "moon" -> "Moon"; "rain" -> "Rain"
    "uv" -> "UV index"; "pressure" -> "Pressure"; "humidity" -> "Humidity"
    "season" -> "Season"; else -> "Tides"
}

private fun detailDescription(id: String): String = when (id) {
    "sun" -> "Sunrise, sunset and remaining daylight are calculated for the selected location."
    "wind" -> "Current direction, speed and observed gusts from the nearest available station."
    "moon" -> "The current lunar phase and illumination are calculated locally."
    "rain" -> "Forecast precipitation chance and possible accumulation for today."
    "uv" -> "Protection is recommended when the UV index reaches 3 or higher."
    "pressure" -> "Pressure trends can help indicate changing weather."
    "humidity" -> "Relative humidity describes how much moisture is currently in the air."
    "season" -> "Atmos uses Southern Hemisphere meteorological seasons."
    else -> "Official tide predictions are available from the Bureau of Meteorology."
}

private suspend fun requestCurrentLocation(context: Context): Pair<Double, Double>? {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!fine && !coarse) return null
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    val provider = when {
        fine && manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
        manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
        else -> manager.getProviders(true).firstOrNull()
    } ?: return currentLocation(context)
    return withTimeoutOrNull(12_000) {
        suspendCancellableCoroutine { continuation ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                runCatching { manager.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(context)) { location -> if (continuation.isActive) continuation.resume(location?.let { it.latitude to it.longitude }) } }
                    .onFailure { if (continuation.isActive) continuation.resume(currentLocation(context)) }
            } else {
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) { manager.removeUpdates(this); if (continuation.isActive) continuation.resume(location.latitude to location.longitude) }
                    @Deprecated("Deprecated in Java") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
                    override fun onProviderEnabled(provider: String) = Unit
                    override fun onProviderDisabled(provider: String) = Unit
                }
                runCatching { manager.requestSingleUpdate(provider, listener, context.mainLooper) }.onFailure { if (continuation.isActive) continuation.resume(currentLocation(context)) }
                continuation.invokeOnCancellation { runCatching { manager.removeUpdates(listener) } }
            }
        }
    } ?: currentLocation(context)
}

private fun currentLocation(context: Context): Pair<Double, Double>? {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    val candidates = manager.getProviders(true)
        .mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }
    val recentCutoff = System.currentTimeMillis() - 15 * 60 * 1000L
    val best = candidates.filter { it.time >= recentCutoff }
        .minByOrNull { it.accuracy }
        ?: candidates.maxByOrNull { it.time }
    return best?.let { it.latitude to it.longitude }
}

private fun distanceSquared(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
    val x = (aLon - bLon) * cos(aLat * PI / 180)
    val y = aLat - bLat
    return x * x + y * y
}

private fun geohash(latitude: Double, longitude: Double, precision: Int = 6): String {
    val alphabet = "0123456789bcdefghjkmnpqrstuvwxyz"
    var latMin = -90.0
    var latMax = 90.0
    var lonMin = -180.0
    var lonMax = 180.0
    var even = true
    var bit = 0
    var value = 0
    val result = StringBuilder()
    while (result.length < precision) {
        if (even) {
            val mid = (lonMin + lonMax) / 2
            if (longitude >= mid) { value = value or (1 shl (4 - bit)); lonMin = mid } else lonMax = mid
        } else {
            val mid = (latMin + latMax) / 2
            if (latitude >= mid) { value = value or (1 shl (4 - bit)); latMin = mid } else latMax = mid
        }
        even = !even
        if (bit < 4) bit++ else {
            result.append(alphabet[value])
            bit = 0
            value = 0
        }
    }
    return result.toString()
}

private const val BACKGROUND_WORK_NAME = "atmos_weather_background_refresh"

private fun scheduleBackgroundUpdates(context: Context, enabled: Boolean) {
    val manager = WorkManager.getInstance(context)
    if (!enabled) {
        manager.cancelUniqueWork(BACKGROUND_WORK_NAME)
        return
    }
    val request = PeriodicWorkRequestBuilder<AtmosBackgroundWorker>(30, TimeUnit.MINUTES)
        .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
        .build()
    manager.enqueueUniquePeriodicWork(BACKGROUND_WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
}

class AtmosBackgroundWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            val preferences = AtmosPreferences(applicationContext)
            if (!preferences.backgroundUpdates) {
                return Result.success()
            }

            val locations = preferences.savedPlaces
            if (locations.isEmpty()) {
                return Result.success()
            }

            val refreshed = coroutineScope {
                locations
                    .map { place -> async { runCatching { WeatherRepository.load(place) }.getOrNull() } }
                    .mapNotNull { it.await() }
            }

            if (refreshed.isNotEmpty()) {
                val cache = preferences.cachedWeather(locations).toMutableMap()
                refreshed.forEach { state -> cache[state.place.cacheKey()] = state }
                preferences.saveWeatherCache(cache)
                refreshed.firstOrNull()?.let { updateWidgets(applicationContext, it) }
            }

            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}

private fun updateWidgets(context: Context, weather: WeatherState) {
    val day = weather.days.first()
    val prefs = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE)
    prefs.edit()
        .putString("location", weather.place.name)
        .putString("location_id", geohash(weather.place.latitude, weather.place.longitude))
        .putString("temp", (weather.observation.temp ?: day.high - 2).toString())
        .putString("condition", nightCondition(day.condition))
        .putString("high", day.high.toString())
        .putString("low", day.low.toString())
        .putString("rain", day.rainChance.toString())
        .putString("icon", if (isNight()) "night" else day.icon)
        .putString("season", seasonName(weather.place))
        .putLong("updated_at", System.currentTimeMillis())
        .also { editor ->
            weather.days.take(7).forEachIndexed { index, forecast ->
                val label = if (index == 0) "TODAY" else try {
                    java.text.SimpleDateFormat("EEE", java.util.Locale.ENGLISH).format(
                        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(forecast.date)!!
                    ).uppercase(java.util.Locale.ENGLISH)
                } catch (_: Exception) { "—" }
                editor.putString("day_name_$index", label)
                editor.putString("day_high_$index", forecast.high.toString())
                editor.putString("day_low_$index", forecast.low.toString())
                editor.putString("day_icon_$index", forecast.icon)
            }
        }
        .apply()
    AtmosWidgetProvider.updateAll(context)
    AtmosWideWidgetProvider.updateAll(context)
    AtmosGlanceWidgetProvider.updateAll(context)
    AtmosWeeklyWidgetProvider.updateAll(context)
    AtmosWidgetUpdater.schedule(context)
}
