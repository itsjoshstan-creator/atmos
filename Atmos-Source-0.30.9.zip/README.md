# Atmos 0.30.9

Changes in this build:
- Independent lower-screen text and chart contrast for Fullscreen Hero and Immersive.
- Immersive previews now show the darker lower-screen treatment in onboarding and Settings.
- Settings cards use solid theme surfaces without gradients for improved light-mode legibility.
- New interactive Atmos System page with a live fullscreen demo, layer controls, and an explanation of the renderer and design philosophy.
- Version code 104 / version name 0.30.9.
