# Atmos 0.18.3

This source update makes seasons and displayed local times follow the selected location.

- Season pill uses the selected location's latitude and local calendar date.
- Northern and Southern Hemisphere meteorological seasons are handled correctly.
- Tropical locations close to the equator use wet/dry season labels.
- The Weather Details season card and season widget data use the selected location.
- International country pills continue to show the selected location's local time.
- Australian locations show a local-time pill when their UTC offset differs from the device timezone.
- Daylight-saving differences are handled through the saved IANA timezone.
- Build: 75
