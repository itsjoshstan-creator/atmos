# Atmos 0.16.9

Native Android source for Atmos 0.16.9.

Changes in this build:
- Reverted the immersive temperature chart to a rolling forecast beginning at the current hour.
- Displays up to the next 24 hourly forecast points instead of historical observations.
- Restored a clear NOW marker at the start of the chart.
- Removed the midnight-to-midnight historical/day-progress chart behaviour.
- Kept the existing precipitation trend and all other Atmos interface improvements.

Build the Android project in the `android` directory.
