# Atmos 0.20.4

Changes in this source release:

- Each season now has a distinct particle silhouette and visual identity.
- Spring uses softly rotating blossom petals.
- Summer uses warm pollen and illuminated light motes with subtle halos.
- Autumn uses tapered, gently tumbling leaves.
- Winter uses pale-blue diamond-dust crystals with crisp facets and occasional rings.
- Seasonal colours, opacity, sizing, and rotation have been tuned independently.
- Particle vertical travel has been reduced substantially so particles drift rather than fall quickly.
- Wind now adds a restrained horizontal breeze and sway without pulling particles rapidly down the screen.
- Individual fade-in, fade-out, and invisible recycling from 0.20.3 remain intact.

Version: 0.20.4
Build: 87

The Gradle compile step could not be completed in the generation environment because services.gradle.org was unreachable. Verify with GitHub Actions.
