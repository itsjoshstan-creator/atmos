# Atmos 0.17.10

Native Android source for Atmos 0.17.10.

Changes in this build:
- Reworked sunrise, sunset, first-light and last-light calculations to keep each event on the selected location's correct local calendar day.
- Corrected UV extraction across BOM hourly and daily response shapes and selected the current/upcoming hourly value.
- Audited weather-details cards to use the current forecast hour rather than the first item in the hourly feed.
- Pressure now displays only when the active observation station reports a valid pressure value; otherwise it clearly shows Not available.
- Normalised BOM observation and warning response shapes so weather data and active warnings are not silently discarded.
- Added the active-warning pill beside the season pill, including warning count and navigation to the warnings page.
- Updated the About badge to Atmos 0.17.10 / Build 71.

Build the Android project in the `android` directory.


## 0.18.0
- Added worldwide location search powered by Open-Meteo geocoding.
- Australian locations continue to use Bureau of Meteorology forecasts, observations and warnings.
- International locations use Open-Meteo current, hourly and 10-day forecast data.
- Added a country pill beside the season pill for international locations.
- Current-location reverse geocoding now supports locations outside Australia.
- Seasons adapt to the selected location's hemisphere.
