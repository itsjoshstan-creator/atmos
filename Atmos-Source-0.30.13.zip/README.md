# Atmos 0.30.9

Changes in this build:
- Independent lower-screen text and chart contrast for Fullscreen Hero and Immersive.
- Immersive previews now show the darker lower-screen treatment in onboarding and Settings.
- Settings cards use solid theme surfaces without gradients for improved light-mode legibility.
- New interactive Atmos System page with a live fullscreen demo, layer controls, and an explanation of the renderer and design philosophy.
- Version code 104 / version name 0.30.9.

## 0.30.10
- Added Automatic (Location) appearance mode.
- Theme day/night state follows calculated sunrise and sunset at the selected observation location and its timezone.
- Added Automatic, Follow Device, Light and Dark choices to onboarding and Settings.
- Automatic (Location) is the recommended default for new installs.
- Theme state is refreshed every minute and immediately recalculated when the selected location changes.
- Light and Dark remain fixed; Follow Device follows Android appearance.


## Atmos 0.30.13

- Automatic (Location) theme now fades continuously between light and dark while swiping between observation locations.
- The theme blend uses the same continuous pager position as the immersive atmosphere.
- Material surfaces, cards, text, outlines and app chrome interpolate together rather than switching at the page boundary.
- Sunrise/sunset-driven theme changes settle with a gentle 1.1 second fade when not actively swiping.

## 0.30.13
- Scoped location swipe theme interpolation to the Home pager instead of rebuilding the app-wide Material theme on every drag frame.
- Kept the root Material theme tied to the settled observation location.
- Used `PagerState.settledPage` for final location commits to prevent the previous theme flashing during pager handoff.
- Preserved continuous light/dark colour blending for Home cards, charts, navigation and text while swiping.

## GitHub Actions build fix
- Added `.github/workflows/android-build.yml`.
- Corrected the Gradle cache and working-directory paths from `project/android` to `android`.
- The Node 20 deprecation text is a runner warning and is not the cause of the failed build.


## 0.30.13 immersive transition experiment

Immersive mode now transitions between two complete preloaded Atmos scenes. Forecast content continues to move with the pager, while the destination atmosphere cross-fades over the current atmosphere directly from raw swipe progress. The dark lower zone remains a separate continuous overlay.
