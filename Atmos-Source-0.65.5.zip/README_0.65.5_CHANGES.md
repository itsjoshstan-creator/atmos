# Atmos 0.65.5

## Atmos Timeline — first iteration

- Added Atmos Timeline as a primary bottom navigation destination.
- Replaced Settings in the bottom navigation with Timeline.
- Moved Settings into the Atmos floating menu.
- Timeline uses the active location and real hourly forecast data.
- Scrubbing updates time, temperature, rain chance, wind and condition.
- Atmos scene colours are regenerated for the selected forecast hour using solar position, forecast temperature and existing seasonal grading.
- Timeline defaults to the forecast hour nearest the current time.
- Preserved the event-driven renderer and existing app architecture.

## Build note

A local Gradle compile could not be completed in the sandbox because the Gradle 8.14.3 distribution was not cached and external network access is disabled. The source changes were statically inspected.
