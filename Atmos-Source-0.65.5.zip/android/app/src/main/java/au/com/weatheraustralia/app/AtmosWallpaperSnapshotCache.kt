package au.com.weatheraustralia.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import java.io.File
import java.io.FileOutputStream
import java.util.Date

/**
 * Produces the wallpaper as a cached, completed immersive Atmos frame.
 *
 * The in-app renderer is intentionally left untouched. This cache reproduces the
 * 0.65.0 immersive composition order: Atmos scene first, then the exact fixed
 * 2100 px lower darkening overlay used by ImmersiveLocationAtmosphere.
 */
internal object AtmosWallpaperSnapshotCache {
    private const val FILE_NAME = "atmos_wallpaper_snapshot.png"
    private const val META_NAME = "atmos_wallpaper_snapshot_meta"

    private fun file(context: Context): File = File(context.filesDir, FILE_NAME)

    fun load(context: Context): Bitmap? = runCatching {
        BitmapFactory.decodeFile(file(context).absolutePath)
    }.getOrNull()

    fun getOrCreate(
        context: Context,
        weather: WeatherState,
        width: Int,
        height: Int,
        immersiveBottom: Int,
        now: Date = Date()
    ): Bitmap? {
        val safeWidth = width.coerceAtLeast(1)
        val safeHeight = height.coerceAtLeast(1)
        val minute = now.time / 60_000L
        val meta = "${weather.place.latitude}:${weather.place.longitude}:${weather.updated.time}:$minute:$safeWidth:$safeHeight:$immersiveBottom"
        val prefs = context.getSharedPreferences("atmos_native", Context.MODE_PRIVATE)
        val existing = file(context)
        if (existing.exists() && prefs.getString(META_NAME, null) == meta) {
            load(context)?.let { return it }
        }

        val day = weather.days.firstOrNull() ?: return null
        return runCatching {
            val palette = applyAtmosphericPaletteVariables(
                solarAwarePalette(day.icon, weather.place, now),
                weather.observation,
                day.condition,
                weather.place,
                now
            )
            val temperature = weather.observation.feels ?: weather.observation.temp ?: 18
            val spec = buildAtmosSceneSpec(
                palette = palette,
                observation = weather.observation,
                condition = day.condition,
                temperatureC = temperature,
                place = weather.place,
                now = now,
                enabled = true
            )

            val bitmap = Bitmap.createBitmap(safeWidth, safeHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            // This is the same base scene used by the 0.65.0 in-app hero.
            SharedAtmosSceneRenderer.render(
                canvas = canvas,
                width = safeWidth,
                height = safeHeight,
                spec = spec,
                immersive = false
            )

            // Exact 0.65.0 ImmersiveLocationAtmosphere overlay. Keep this independent
            // from wallpaper surface dimensions by baking it into the cached frame.
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
            val thirtyPercent = AndroidColor.argb(
                (0.30f * 255f).toInt(),
                AndroidColor.red(immersiveBottom),
                AndroidColor.green(immersiveBottom),
                AndroidColor.blue(immersiveBottom)
            )
            paint.shader = LinearGradient(
                0f,
                0f,
                0f,
                2100f,
                intArrayOf(
                    AndroidColor.TRANSPARENT,
                    AndroidColor.TRANSPARENT,
                    thirtyPercent,
                    immersiveBottom
                ),
                null,
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, safeWidth.toFloat(), safeHeight.toFloat(), paint)

            val temp = File(context.filesDir, "$FILE_NAME.tmp")
            FileOutputStream(temp).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            if (existing.exists()) existing.delete()
            temp.renameTo(existing)
            prefs.edit()
                .putString(META_NAME, meta)
                .putLong("wallpaperSnapshotVersion", System.currentTimeMillis())
                .apply()
            bitmap
        }.getOrNull()
    }
}
