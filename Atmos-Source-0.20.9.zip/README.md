
## 0.20.9
- The hero temperature can now be tapped to switch between Celsius and Fahrenheit, with a refined animated value transition.
- Newly loaded forecast data settles into view with a subtle, performant Atmos reveal.
- Tapping the location name opens the saved locations and search page in both card and immersive layouts.
- The locations page now uses the same deep atmospheric gradient language as About Atmos.
- Main page changes use directional Atmos-themed fade and slide transitions.
- versionName: 0.20.9
- versionCode: 92
# Atmos 0.20.9

Built from Atmos 0.20.6.

## Changes
- Adaptive hero foreground now applies to the current temperature, condition, feels-like/high/low text, narrative, location and chart.
- Android status-bar icons follow the hero gradient contrast on the home screen.
- Australian locations derive an appropriate IANA timezone and always show local time.
- Current Location now remains the device location; nearby place and BOM observation station are presented separately.
- Automatic refresh remains limited to once every 10 minutes, while manual pull-to-refresh always bypasses the cache limit.
- Optional WorkManager background refresh updates saved locations approximately every 30 minutes, subject to Android battery scheduling.

## Version
- versionName: 0.20.9
- versionCode: 90

## Verification
The source archive passed ZIP integrity checks. Local Gradle compilation could not be completed because this environment could not reach services.gradle.org. Verify with GitHub Actions.
