# Atmos 0.50.1

Atmos Engine 2.0 Phase 1 visibility and performance correction. See `README_0.50.1_CHANGES.md` for details.
