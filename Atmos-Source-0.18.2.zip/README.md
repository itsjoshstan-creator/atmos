# Atmos 0.18.1

This source update fixes international location search in the native Android UI.

- Worldwide location search now calls the Open-Meteo geocoding service from Kotlin.
- International results can be added, reordered, removed and selected.
- Australian locations continue to use BOM.
- International locations use Open-Meteo current, hourly and daily forecasts.
- International hero cards show a country pill.
- Saved locations persist country metadata.
- Build: 73
