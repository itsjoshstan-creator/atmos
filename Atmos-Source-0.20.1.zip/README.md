# Atmos 0.18.3

This source update makes seasons and displayed local times follow the selected location.

- Season pill uses the selected location's latitude and local calendar date.
- Northern and Southern Hemisphere meteorological seasons are handled correctly.
- Tropical locations close to the equator use wet/dry season labels.
- The Weather Details season card and season widget data use the selected location.
- International country pills continue to show the selected location's local time.
- Australian locations show a local-time pill when their UTC offset differs from the device timezone.
- Daylight-saving differences are handled through the saved IANA timezone.
- Build: 75


## 0.19.1
- Removed the legacy condition-specific hero animations (rain streaks, moving clouds, snow, fog, wind, clear-sky glow and storm flashes).
- Retained the new temperature-responsive atmosphere effects introduced in 0.19.0.
- Updated the Appearance setting label and description to match the remaining effects.

## 0.19.5
- Keeps adaptive temperature and seasonal atmosphere effects running throughout location swipes.
- Removes the pager-drag pause that previously made effects abruptly disappear.
- Precomposes two neighbouring locations so their atmosphere animation state is ready before it enters the viewport.
- Allows adjacent location atmospheres to transition naturally with the pager movement instead of stopping and restarting.
- Build: 81


## Atmos 0.20.0 – Living Atmosphere

- Expands the existing atmosphere engine with wind-driven particles, humidity haze, pressure-sensitive motion and continuously drifting light.
- Adds a dedicated Atmos System onboarding experience after theme and layout selection.
- Adds a dedicated Atmos System settings section with intensity and individual effect controls.
- Makes the floating menu button respond to the current condition and season.
- Retains the ten-minute automatic weather refresh limit and feels-like temperature behaviour.

Build note: Gradle compilation could not be run in the packaging environment because services.gradle.org was unavailable. Verify with GitHub Actions.
