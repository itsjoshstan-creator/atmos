# Atmos 0.50.6

Lean Atmos renderer update. See `README_0.50.6_CHANGES.md` for details.
