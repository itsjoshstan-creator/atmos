# Atmos 0.20.8

Built from Atmos 0.20.6.

## Changes
- Adaptive hero foreground now applies to the current temperature, condition, feels-like/high/low text, narrative, location and chart.
- Android status-bar icons follow the hero gradient contrast on the home screen.
- Australian locations derive an appropriate IANA timezone and always show local time.
- Current Location now remains the device location; nearby place and BOM observation station are presented separately.
- Automatic refresh remains limited to once every 10 minutes, while manual pull-to-refresh always bypasses the cache limit.
- Optional WorkManager background refresh updates saved locations approximately every 30 minutes, subject to Android battery scheduling.

## Version
- versionName: 0.20.8
- versionCode: 90

## Verification
The source archive passed ZIP integrity checks. Local Gradle compilation could not be completed because this environment could not reach services.gradle.org. Verify with GitHub Actions.
