(() => {
  'use strict';

  const TAU = Math.PI * 2;
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, Number(v) || 0));
  const mix = (a, b, t) => a + (b - a) * t;
  const smooth = (a, b, rate, dt) => mix(a, b, 1 - Math.exp(-rate * dt));

  function hashSeed(text) {
    let h = 2166136261;
    for (let i = 0; i < String(text).length; i++) {
      h ^= String(text).charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }

  function mulberry32(seed) {
    return function () {
      let t = seed += 0x6D2B79F5;
      t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61);
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  function rgba(rgb, alpha) {
    return `rgba(${rgb[0] | 0},${rgb[1] | 0},${rgb[2] | 0},${clamp(alpha)})`;
  }

  function paletteFor(scene) {
    const night = 1 - scene.daylight;
    const hot = clamp((scene.temperature - 24) / 16);
    const cold = clamp((10 - scene.temperature) / 18);
    const storm = scene.storm;
    const clouds = scene.cloudCover;
    const haze = scene.haze;

    const topDay = [76 + hot * 45, 145 + hot * 15, 214 - hot * 32];
    const bottomDay = [164 + hot * 60, 207 - hot * 22, 238 - hot * 55];
    const topNight = [8, 18, 44];
    const bottomNight = [29, 37, 78];
    let top = topDay.map((v, i) => mix(v, topNight[i], night));
    let bottom = bottomDay.map((v, i) => mix(v, bottomNight[i], night));

    const grey = [62, 76, 98];
    const stormGrey = [28, 35, 51];
    const desaturate = clamp(clouds * .48 + storm * .48);
    top = top.map((v, i) => mix(v, mix(grey[i], stormGrey[i], storm), desaturate));
    bottom = bottom.map((v, i) => mix(v, mix([130, 145, 158][i], stormGrey[i] + 12, storm), desaturate));

    if (cold > 0) {
      top = top.map((v, i) => mix(v, [106, 151, 205][i], cold * .28));
      bottom = bottom.map((v, i) => mix(v, [194, 221, 239][i], cold * .32));
    }
    if (haze > 0) bottom = bottom.map((v, i) => mix(v, [205, 198, 187][i], haze * .28));
    return { top, bottom };
  }

  class Particle {
    constructor() { this.alive = false; }
  }

  class AtmosRenderer {
    constructor(canvas, options = {}) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d', { alpha: true, desynchronized: true });
      this.options = options;
      this.dpr = 1;
      this.width = 1;
      this.height = 1;
      this.last = performance.now();
      this.elapsed = 0;
      this.accumulator = 0;
      this.spawnCarry = 0;
      this.particles = Array.from({ length: options.maxParticles || 420 }, () => new Particle());
      this.clouds = [];
      this.scene = this.defaultScene();
      this.target = { ...this.scene };
      this.random = mulberry32(hashSeed(options.seed || 'Atmos'));
      this.running = true;
      this.active = true;
      this.reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
      this.resizeObserver = new ResizeObserver(() => this.resize());
      this.resizeObserver.observe(canvas.parentElement || canvas);
      this.resize();
      this.resetClouds();
      this.frame = this.frame.bind(this);
      requestAnimationFrame(this.frame);
    }

    defaultScene() {
      return {
        daylight: .8,
        solarElevation: .7,
        temperature: 20,
        feelsLike: 20,
        humidity: .55,
        pressure: 1013,
        pressureAnomaly: 0,
        windSpeed: 5,
        windDirection: 260,
        gustSpeed: 8,
        visibility: 20000,
        cloudCover: .35,
        precipitation: 0,
        rainChance: .1,
        snowfall: 0,
        storm: 0,
        fog: 0,
        uv: 3,
        condition: 'partly',
        haze: .15,
        instability: .2,
        intensity: 1
      };
    }

    resize() {
      const rect = this.canvas.getBoundingClientRect();
      this.dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.width = Math.max(1, rect.width);
      this.height = Math.max(1, rect.height);
      const w = Math.round(this.width * this.dpr);
      const h = Math.round(this.height * this.dpr);
      if (this.canvas.width !== w || this.canvas.height !== h) {
        this.canvas.width = w;
        this.canvas.height = h;
      }
      this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    }

    setActive(active = true) {
      this.active = Boolean(active);
      if (this.active) this.last = performance.now();
    }

    setScene(input = {}, immediate = false) {
      const pressure = Number.isFinite(Number(input.pressure)) ? Number(input.pressure) : 1013;
      const humidity = clamp((Number(input.humidity) || 0) / (Number(input.humidity) > 1 ? 100 : 1));
      const visibility = Math.max(300, Number(input.visibility) || 20000);
      const wind = Math.max(0, Number(input.windSpeed) || 0);
      const gust = Math.max(wind, Number(input.gustSpeed) || wind);
      const rainAmount = Math.max(0, Number(input.precipitation) || 0);
      const rainChance = clamp((Number(input.rainChance) || 0) / (Number(input.rainChance) > 1 ? 100 : 1));
      const cloud = clamp((Number(input.cloudCover) || 0) / (Number(input.cloudCover) > 1 ? 100 : 1));
      const condition = String(input.condition || '').toLowerCase();
      const storm = /storm|thunder|hail/.test(condition) ? 1 : clamp(Number(input.storm) || 0);
      const snow = /snow|sleet|ice/.test(condition) ? Math.max(.4, Number(input.snowfall) || .6) : Math.max(0, Number(input.snowfall) || 0);
      const fog = Math.max(/fog|mist/.test(condition) ? .75 : 0, clamp(Number(input.fog) || 0));
      const daylight = clamp(Number(input.daylight ?? 1));
      const solarElevation = clamp(Number(input.solarElevation ?? daylight));
      const pressureAnomaly = clamp((1013 - pressure) / 35, -1, 1);
      const lowVisibility = clamp((18000 - visibility) / 17500);
      const haze = clamp(humidity * .42 + lowVisibility * .72 + fog * .56);
      const instability = clamp(Math.max(0, pressureAnomaly) * .52 + storm * .8 + clamp((gust - wind) / 35) * .35);
      const precipitation = clamp(Math.max(rainAmount / 5, rainChance * (/rain|shower|drizzle|storm/.test(condition) ? 1 : .32)));

      this.target = {
        ...this.target,
        daylight,
        solarElevation,
        temperature: Number(input.temperature ?? 20),
        feelsLike: Number(input.feelsLike ?? input.temperature ?? 20),
        humidity,
        pressure,
        pressureAnomaly,
        windSpeed: wind,
        windDirection: ((Number(input.windDirection) || 0) % 360 + 360) % 360,
        gustSpeed: gust,
        visibility,
        cloudCover: Math.max(cloud, /cloud|overcast|fog|rain|storm/.test(condition) ? .55 : 0),
        precipitation,
        rainChance,
        snowfall: clamp(snow),
        storm,
        fog,
        uv: Math.max(0, Number(input.uv) || 0),
        condition,
        haze,
        instability,
        intensity: clamp(Number(input.intensity ?? 1), 0, 1)
      };
      if (immediate) this.scene = { ...this.target };
    }

    resetClouds() {
      this.clouds = Array.from({ length: 7 }, (_, i) => ({
        x: this.random() * Math.max(1, this.width),
        y: this.random() * Math.max(1, this.height * .6) - this.height * .08,
        size: .45 + this.random() * 1.05,
        speed: .1 + this.random() * .35,
        alpha: .15 + this.random() * .34,
        phase: this.random() * TAU,
        depth: .3 + this.random() * .7
      }));
    }

    spawn(type) {
      const p = this.particles.find(x => !x.alive);
      if (!p) return;
      const s = this.scene;
      p.alive = true;
      p.type = type;
      p.age = 0;
      p.seed = this.random() * TAU;
      p.depth = .35 + this.random() * .65;
      p.x = this.random() * (this.width + 80) - 40;
      p.y = type === 'mist' ? this.random() * this.height : -20 - this.random() * 80;
      p.life = type === 'mist' ? 5 + this.random() * 8 : 1.4 + this.random() * 3.8;
      p.size = type === 'rain' ? .7 + this.random() * 1.6 : type === 'snow' ? 1.2 + this.random() * 3.6 : 12 + this.random() * 34;
      p.opacity = type === 'rain' ? .22 + this.random() * .48 : type === 'snow' ? .32 + this.random() * .55 : .015 + this.random() * .045;
      p.rotation = this.random() * TAU;
      p.spin = (this.random() - .5) * 1.4;
      p.vxJitter = (this.random() - .5) * 18;
      p.vyJitter = this.random() * 65;
      p.noiseFreq = .4 + this.random() * 1.8;
      p.noiseAmp = 4 + this.random() * 24;
      if (type === 'rain') p.life = Math.max(.7, this.height / (350 + p.vyJitter));
    }

    updateScene(dt) {
      const rate = this.options.transitionRate || 4.5;
      for (const key of Object.keys(this.target)) {
        if (typeof this.target[key] === 'number') this.scene[key] = smooth(this.scene[key], this.target[key], rate, dt);
        else this.scene[key] = this.target[key];
      }
    }

    updateParticles(dt) {
      const s = this.scene;
      const intensity = s.intensity;
      const rainRate = s.precipitation * (55 + 175 * s.precipitation) * intensity;
      const snowRate = s.snowfall * (18 + 70 * s.snowfall) * intensity;
      const mistRate = s.haze * (3 + 16 * s.haze) * intensity;
      this.spawnCarry += (rainRate + snowRate + mistRate) * dt;
      while (this.spawnCarry >= 1) {
        const total = rainRate + snowRate + mistRate;
        const r = this.random() * total;
        this.spawn(r < rainRate ? 'rain' : r < rainRate + snowRate ? 'snow' : 'mist');
        this.spawnCarry--;
      }

      const windRad = (s.windDirection - 90) * Math.PI / 180;
      const windX = Math.cos(windRad) * s.windSpeed * 1.75;
      const windY = Math.sin(windRad) * s.windSpeed * .24;
      const gustPulse = Math.sin(this.elapsed * .65) * Math.max(0, s.gustSpeed - s.windSpeed) * .65;
      const turbulence = 2 + s.instability * 34;

      for (const p of this.particles) {
        if (!p.alive) continue;
        p.age += dt;
        if (p.age >= p.life) { p.alive = false; continue; }
        const noise = Math.sin(this.elapsed * p.noiseFreq + p.seed) * p.noiseAmp * turbulence / 20;
        if (p.type === 'rain') {
          p.x += (windX + gustPulse + p.vxJitter + noise) * dt * p.depth;
          p.y += (320 + p.vyJitter + Math.abs(windY)) * dt * p.depth;
        } else if (p.type === 'snow') {
          p.x += (windX * .72 + gustPulse * .5 + p.vxJitter * .25 + noise) * dt * p.depth;
          p.y += (28 + p.vyJitter * .24 + Math.abs(windY) * .2) * dt * p.depth;
          p.rotation += p.spin * dt;
        } else {
          p.x += (windX * .14 + noise * .18) * dt * p.depth;
          p.y += (windY * .04 + Math.sin(this.elapsed * .22 + p.seed) * 1.6) * dt;
        }
        if (p.x < -80) p.x = this.width + 80;
        if (p.x > this.width + 80) p.x = -80;
        if (p.y > this.height + 80) p.alive = false;
      }
    }

    drawBackground(ctx) {
      const s = this.scene;
      const palette = paletteFor(s);
      const sky = ctx.createLinearGradient(0, 0, this.width, this.height);
      sky.addColorStop(0, rgba(palette.top, 1));
      sky.addColorStop(.58, rgba(palette.bottom, 1));
      sky.addColorStop(1, rgba(palette.bottom.map(v => v * .82), 1));
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, this.width, this.height);

      const sunX = this.width * (.78 - .56 * clamp(s.solarElevation));
      const sunY = this.height * (.1 + .5 * (1 - s.solarElevation));
      const sunAlpha = s.daylight * (1 - s.cloudCover * .62) * (.25 + s.uv / 14);
      if (sunAlpha > .02) {
        const glow = ctx.createRadialGradient(sunX, sunY, 1, sunX, sunY, this.width * .48);
        glow.addColorStop(0, `rgba(255,235,174,${sunAlpha * .72})`);
        glow.addColorStop(.18, `rgba(255,186,120,${sunAlpha * .34})`);
        glow.addColorStop(1, 'rgba(255,180,100,0)');
        ctx.fillStyle = glow;
        ctx.fillRect(0, 0, this.width, this.height);
      }

      const cold = clamp((8 - s.feelsLike) / 18);
      const hot = clamp((s.feelsLike - 27) / 17);
      if (cold > .02) {
        const frost = ctx.createLinearGradient(0, 0, 0, this.height);
        frost.addColorStop(0, `rgba(195,229,255,${cold * .09})`);
        frost.addColorStop(1, `rgba(220,245,255,${cold * .22})`);
        ctx.fillStyle = frost; ctx.fillRect(0, 0, this.width, this.height);
      }
      if (hot > .02) {
        const heat = ctx.createLinearGradient(0, this.height * .35, 0, this.height);
        heat.addColorStop(0, 'rgba(255,145,80,0)');
        heat.addColorStop(1, `rgba(255,130,65,${hot * .14})`);
        ctx.fillStyle = heat; ctx.fillRect(0, 0, this.width, this.height);
      }
    }

    drawClouds(ctx, dt) {
      const s = this.scene;
      const density = s.cloudCover;
      if (density < .025) return;
      const windRad = (s.windDirection - 90) * Math.PI / 180;
      const drift = Math.cos(windRad) * (4 + s.windSpeed * .28);
      for (let i = 0; i < this.clouds.length; i++) {
        const c = this.clouds[i];
        c.x += drift * c.speed * dt;
        c.y += Math.sin(this.elapsed * .08 + c.phase) * .045;
        const radius = this.width * .26 * c.size;
        if (c.x < -radius * 2) c.x = this.width + radius;
        if (c.x > this.width + radius * 2) c.x = -radius;
        const active = clamp(density * 1.65 - i * .095);
        if (active <= .01) continue;
        const alpha = c.alpha * active * (.55 + s.storm * .42);
        const cloudRgb = s.storm > .25 ? [35, 42, 58] : [225, 233, 240];
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.filter = `blur(${Math.max(7, radius * .085)}px)`;
        ctx.fillStyle = rgba(cloudRgb, 1);
        ctx.beginPath();
        ctx.ellipse(c.x, c.y, radius * 1.35, radius * .42, 0, 0, TAU);
        ctx.ellipse(c.x - radius * .46, c.y + radius * .08, radius * .66, radius * .34, 0, 0, TAU);
        ctx.ellipse(c.x + radius * .42, c.y + radius * .05, radius * .74, radius * .36, 0, 0, TAU);
        ctx.fill();
        ctx.restore();
      }
    }

    drawParticles(ctx) {
      const s = this.scene;
      for (const p of this.particles) {
        if (!p.alive) continue;
        const life = p.age / p.life;
        const fade = Math.min(1, life * 6, (1 - life) * 7);
        ctx.save();
        ctx.globalAlpha = p.opacity * fade;
        if (p.type === 'rain') {
          const windLean = clamp(s.windSpeed / 45) * 12;
          ctx.strokeStyle = 'rgba(205,238,255,.95)';
          ctx.lineWidth = p.size;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + windLean, p.y + 14 + p.size * 5);
          ctx.stroke();
        } else if (p.type === 'snow') {
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.fillStyle = 'rgba(244,251,255,.96)';
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, TAU);
          ctx.fill();
        } else {
          const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size);
          g.addColorStop(0, 'rgba(236,240,238,.15)');
          g.addColorStop(1, 'rgba(236,240,238,0)');
          ctx.fillStyle = g;
          ctx.fillRect(p.x - p.size, p.y - p.size, p.size * 2, p.size * 2);
        }
        ctx.restore();
      }
    }

    drawHaze(ctx) {
      const s = this.scene;
      if (s.haze <= .02) return;
      const g = ctx.createLinearGradient(0, this.height * .22, 0, this.height);
      g.addColorStop(0, 'rgba(225,229,225,0)');
      g.addColorStop(.64, `rgba(225,229,225,${s.haze * .09})`);
      g.addColorStop(1, `rgba(225,229,225,${s.haze * .28})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, this.width, this.height);
    }

    drawLightning(ctx) {
      const s = this.scene;
      if (s.storm < .25) return;
      const chance = s.storm * s.instability * .012;
      if (this.random() > chance) return;
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.fillStyle = `rgba(230,240,255,${.08 + s.storm * .16})`;
      ctx.fillRect(0, 0, this.width, this.height);
      ctx.restore();
    }

    draw(dt) {
      const ctx = this.ctx;
      ctx.clearRect(0, 0, this.width, this.height);
      this.drawBackground(ctx);
      this.drawClouds(ctx, dt);
      this.drawHaze(ctx);
      this.drawParticles(ctx);
      this.drawLightning(ctx);
    }

    frame(now) {
      if (!this.running) return;
      let dt = Math.min(.05, Math.max(.001, (now - this.last) / 1000));
      this.last = now;
      if (document.hidden || !this.active || this.width < 2 || this.height < 2) { this.last = now; requestAnimationFrame(this.frame); return; }
      if (this.reducedMotion) dt = Math.min(dt, 1 / 12);
      this.elapsed += dt;
      this.updateScene(dt);
      this.updateParticles(dt);
      this.draw(dt);
      requestAnimationFrame(this.frame);
    }

    destroy() {
      this.running = false;
      this.resizeObserver.disconnect();
    }
  }

  window.AtmosRenderer = AtmosRenderer;
})();
