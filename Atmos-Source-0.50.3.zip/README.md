# Atmos 0.50.3

Lean Atmos renderer update. See `README_0.50.3_CHANGES.md` for details.
