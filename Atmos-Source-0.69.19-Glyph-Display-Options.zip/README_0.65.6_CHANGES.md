# Atmos 0.65.6

- Added Atmos intensity: Subtle, Balanced, Cinematic. Balanced preserves the 0.65.5 render.
- Added Atmos transition speed: Instant, Smooth, Slow.
- Added native UI accent colour choices.
- Added consolidated unit preferences for temperature, wind, pressure, rainfall and visibility.
- Updated About Atmos with current renderer, weather pipeline, widget and live wallpaper information.
- Version code 356.
