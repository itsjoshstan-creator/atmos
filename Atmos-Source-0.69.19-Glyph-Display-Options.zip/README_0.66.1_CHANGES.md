# Atmos 0.66.1

- Weather effects now default to off for new installations.
- Immersive layout remains the default forecast experience.
- Expanded remains the default content density.
- Settings is reorganised into Appearance & layout, Weather experience, Updates & notifications, and Home screen subpages.
- Added a performance and battery-use warning to Weather Effects.
- Existing features and visual styling are preserved.
