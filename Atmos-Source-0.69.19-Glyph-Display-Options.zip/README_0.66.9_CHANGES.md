# Atmos 0.66.9 — Sun God Rays

Built from the corrected 0.66.8 source.

## Solar rendering
- Replaced the previous localised radial solar-glare washes with subtle ambient solar colour grading.
- Added distinct, diffused sun god rays to the Atmos weather-effects layer.
- The ray origin always remains beyond the visible top edge, so no sun disc is shown.
- Rays follow the local sun path from east to west and respond immediately to Hero timeline scrubbing.
- Clear weather shows more and stronger shafts; cloud, rain, fog, overcast and storms progressively suppress the effect.
- Temperatures above approximately 29°C make rays warmer and more pronounced, reaching their strongest treatment in very hot weather.
- Rays fade in and out rather than appearing abruptly.
- The effect is event-driven and does not add a permanent frame loop when no other animated weather effect is active.

## Settings
- Added **Sun god rays** to Settings → Weather experience → Weather effects.
- Enabled by default and independently toggleable.
- Updated the performance warning to clarify that god rays default to on while other motion effects remain off by default.

## Build
- Version name: 0.66.9
- Version code: 369
- Stable development signing retained.
