# Atmos 0.69.19

## Nothing Glyph Matrix display controls

- Added Temperature only, Conditions only and alternating Temperature + conditions modes.
- Added sunrise, sunset and next-solar-event countdown modes with minute-based AOD updates.
- Added precipitation chance, feels-like and automatic context-aware display modes.
- Added static or animated weather symbols.
- Added Celsius and Fahrenheit selection.
- Added first saved or currently selected location selection.
- Added Glyph brightness and alternation interval controls.
- Preserved the working native Phone (4a) Pro Glyph service and structured 13×13 renderer from 0.69.18.
