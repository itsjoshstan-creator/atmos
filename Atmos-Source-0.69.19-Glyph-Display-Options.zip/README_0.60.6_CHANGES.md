# Atmos 0.60.6

## Status-bar temperature option

- Added a separate **Show temperature in status bar** setting beneath the persistent current-weather notification.
- When enabled, the notification small icon displays the rounded current temperature for the first saved location.
- When disabled, Atmos uses a standard weather icon while retaining the full persistent forecast notification.
- Improved padding and sizing of one-digit, two-digit and negative temperature icons for better status-bar legibility.
- The option follows the existing notification permission and refresh lifecycle.

Version code: 306
