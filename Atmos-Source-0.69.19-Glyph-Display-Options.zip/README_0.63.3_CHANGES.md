# Atmos 0.63.3

- Rebased directly from Atmos 0.63.2.
- Removed the left-side Saved Places page from the weather pager.
- Weather paging now begins with the first saved forecast and ends with Add Location.
- Added condition-matched gradient location names to main hero cards with adaptive legibility.
- Replaced the floating menu ellipsis with a solid current-condition glyph.
- Changed the forecast heading to report the actual number of available days.
- Renamed the Locations heading to “Your atmospheres”.
- Unified Locations, Seasons and Settings heading size, spacing and subtitle layout.
- Reordered page transition direction to match the native bottom navigation order.
- Added Dual atmosphere layout for the first two saved locations.
- Dual atmosphere uses two fixed compact hero cards, one above the other, with no lower forecast feed and no vertical scrolling.
