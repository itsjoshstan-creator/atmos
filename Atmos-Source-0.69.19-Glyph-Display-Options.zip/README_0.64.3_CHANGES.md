# Atmos 0.64.3 Changes

- Rebased directly from the stable 0.64.0 Performance build.
- Discarded the 0.64.1 and 0.64.2 cloud/effects implementations.
- Reintroduced solar glare as a soft atmospheric bloom with no visible sun disc.
- Glare position follows each location from sunrise to sunset along a realistic daylight arc.
- Glare height peaks around local solar midday and lowers toward sunrise and sunset.
- Layered radial light fields blend into the existing Atmos gradient without adding a continuous render loop.
- Retained the release-optimised Performance APK configuration and all 0.64.0 performance improvements.
