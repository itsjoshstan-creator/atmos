# Atmos 0.69.7

- Added transparent 4×3 Right now widget.
- Added transparent 4×4 Atmos Moments widget.
- Added transparent 4×2 Today at a glance widget.
- Unified Light, Dark and Automatic text modes across all widgets.
- Added Android widget-picker previews for the full widget family.
- Standardized outer padding to match the existing 4×4 Hero widget.
