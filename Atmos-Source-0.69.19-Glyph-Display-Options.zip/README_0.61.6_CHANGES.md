# Atmos 0.61.6

## Atmos Display redesign

- Replaced the previous drifting expanded forecast presentation with a dedicated minimal ambient display.
- Normal cards, controls, labels and forecast content fade away after the existing idle delay.
- The active weather atmosphere remains animated behind a simple local clock.
- Displays only a medium-sized time and a smaller current temperature beneath it.
- Uses the same extra-bold typography treatment as the main temperature display.
- Every ten seconds the clock and temperature fade out, move to another safe screen position, and fade back in to reduce burn-in risk.
- Tapping the display temporarily restores the normal interface and controls.

## Floating menu

- Added an Atmos Display action to the floating menu for immediate activation.
- Direct activation works even when automatic Atmos Display is disabled in Settings.
- The existing display-duration setting still controls how long the direct display remains active.
