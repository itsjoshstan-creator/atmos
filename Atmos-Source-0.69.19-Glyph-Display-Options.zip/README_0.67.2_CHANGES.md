# Atmos 0.67.2

## Simplified landscape god rays

- Simplified the ray field to four to six broad shafts depending on conditions.
- Widened every ray substantially and increased its expansion towards the bottom of the screen.
- Reworked the off-screen source into a wide solar band with only gentle convergence.
- The source now follows a vertical solar arc: lower near sunrise, highest around midday, and lower again towards sunset.
- The ray field travels from the eastern side in the morning to the western/right side in the evening.
- Retained independent slow drift, breathing, weather dependence, heat warmth, and sunrise/sunset fading.
- Preserved the lightweight layered-path renderer and 12 fps ray-only motion clock.

Version code: 372
Version name: 0.67.2
