# Atmos 0.67.8 Build Fix

Fixed the two Kotlin compilation errors reported by GitHub Actions:

- Replaced the invalid `Page.Timeline` navigation target with the existing Home destination used by the current 0.67.7-based navigation model.
- Replaced unavailable Material 3 `HorizontalDivider` with the compatible `Divider` component.

No Living Clouds or Atmos Moments rendering/data logic was otherwise changed.
