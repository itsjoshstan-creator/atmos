# Atmos 0.61.4

Builds directly from the stable Atmos 0.61.2 baseline. The experimental Google account and cloud-backup work from 0.61.3 is intentionally not included.

## Compact layout refinement

- Removed only the secondary descriptive condition paragraph beneath the hero weather summary in Compact mode.
- Retained the large condition title, current temperature, feels-like temperature, daily high and daily low.
- Reduced the Compact hero height so no empty space is left where the paragraph previously appeared.
- Expanded and immersive-expanded layouts are unchanged and continue to show the descriptive condition narrative.
