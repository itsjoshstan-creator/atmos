# Atmos 0.50.8

## Forecast presentation
- The Rain, Wind and Humidity summary now uses a subtle condition-matched surface.
- The surface remains restrained in both light and dark themes and selects a legible foreground automatically.
- Compact hero height now grows when the condition narrative wraps onto additional lines, preventing clipping or overlap.

## Saved places overview
- Compact saved-place previews now use each location's solar-aware Atmos gradient.
- Text contrast is calculated independently for each preview.
- Tapping a preview takes the pager directly to that saved location.

## Layout settings and onboarding
- Forecast experience and content density now live together in the Layout settings card.
- Compact and Expanded include illustrated previews using the same visual language as Card style and Immersive.
- Compact and Expanded are also available during onboarding beneath Forecast experience.
- In Compact mode the floating menu remains at its normal bottom position.

## OLED card definition
- Late-night OLED view now keeps a faint cool outline around forecast cards, including Today at a glance and weather detail cards.
- The outline activates only in the actual OLED solar period, remaining deliberately restrained against the near-black background.
