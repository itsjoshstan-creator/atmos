# Atmos 0.67.3 — Premium God Rays Rebuild

- Removed the previous landscape/fan-style ray geometry.
- Rebuilt sun god rays as 3–4 large, independently composed light volumes.
- Each ray begins narrow at an off-screen local solar source and spreads towards the lower display.
- Added a broad soft halo, luminous body and defined inner core without hard edges or runtime blur filters.
- Rays follow each location’s sunrise-to-sunset solar position and remain hidden at night.
- Width, position and intensity evolve slowly over tens of seconds.
- Clearer weather shows four rays; cloudier appropriate daylight conditions show three.
- Hot weather warms and strengthens the effect.
- Ray-only animation reduced to 6 fps to protect performance while preserving slow movement.
- Version updated to 0.67.3 (code 373).
