# Atmos 0.63.1

- Reflowed the immersive hero around the native Android bottom navigation bar.
- The hero now ends above the navigation surface and keeps its pager handle and lower content fully visible.
- Added extra-bold Atmos gradient headings to Locations and Settings.
- Restyled the Material 3 bottom navigation as a flat translucent frosted-glass surface.
- Preserved native Material navigation behaviour and dynamic colour support.
