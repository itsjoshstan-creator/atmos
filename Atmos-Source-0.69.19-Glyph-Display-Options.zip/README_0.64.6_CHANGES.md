# Atmos 0.64.6 — Live Wallpaper

- Added a native Android `WallpaperService`.
- Uses the first saved location and its shared cached weather data.
- Renders only the Atmos gradient and unified weather-lighting engine.
- No location name, temperature, clock, cards, controls, or other text is drawn.
- Includes solar-position glare, seasonal light, humidity/visibility scattering, pressure mood, moonlight, and stars.
- Event-driven rendering: updates when visible, on weather/cache changes, and once per solar minute.
- Stops scheduled redraws while the wallpaper is hidden.
- Added a Settings action that opens Android's live-wallpaper preview.
- Retains the 0.64.5 performance APK configuration and all existing app features.
