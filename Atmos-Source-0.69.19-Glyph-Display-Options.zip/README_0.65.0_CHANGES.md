# Atmos 0.65.0

- Anchored the live wallpaper immersive lower dark gradient to the visible display height.
- Matched the in-app immersive hero fade progression and bottom colour.
- Prevented oversized wallpaper surfaces from placing the dark zone below the visible home screen.
