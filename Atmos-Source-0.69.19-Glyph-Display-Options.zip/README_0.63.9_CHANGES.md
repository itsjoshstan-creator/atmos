# Atmos 0.63.9 Changes

- Built directly from Atmos 0.63.7 Rebased; the 0.63.8 solar-status changes are not included.
- Dual atmosphere cards are now tappable.
- Tapping a dual card opens that exact saved location in the normal full forecast layout.
- Android back gesture/button returns to the same dual-atmosphere pair page.
- Opening a full forecast from Dual mode does not change the saved Dual layout preference.
- Added a quick Dual/Single atmosphere toggle to the floating condition menu.
- Switching to Single uses the normal forecast pager; switching back restores Dual mode.
- The last viewed dual pair is retained while viewing a full forecast.
