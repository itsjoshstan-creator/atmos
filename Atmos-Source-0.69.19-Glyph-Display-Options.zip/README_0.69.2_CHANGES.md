# Atmos 0.69.2

- OLED night presentation now becomes fully dark about one hour after local sunset.
- Strengthened the frost effect below 5°C with larger windscreen-style crystals and edge icing.
- Removed the Seasons page gradient so it matches the neutral Settings and Locations backgrounds.
- Updated the in-app changelog.
- Gradient Hero typography is enabled by default for new installs and users without an existing preference.
