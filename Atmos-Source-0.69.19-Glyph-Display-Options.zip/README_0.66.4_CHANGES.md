# Atmos 0.66.4

## Widget temperature consistency

- Fixed the 4×4 and other Atmos widgets occasionally showing a different temperature from the app and persistent notification.
- The widget refresh alarm now reads the first saved location's cached `WeatherState`, matching the app's shared source of truth.
- Headline temperature priority is now consistent: current observation, then first hourly forecast, then daily fallback.
- The widget's independent BOM hourly refresh no longer overwrites the current observed temperature with `hours[0].temp`.
- Widget refresh cadence is now 15 minutes, aligned with Atmos background weather updates.
- Preserves the stable Atmos development signing configuration introduced in 0.66.3.

Version: 0.66.4 (364)
