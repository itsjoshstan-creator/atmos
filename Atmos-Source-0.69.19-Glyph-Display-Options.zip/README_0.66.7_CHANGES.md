# Atmos 0.66.7

## 4×4 widget Hero text matching

- The transparent 4×4 Hero widget now uses the same solar-aware light/dark foreground decision as the immersive Hero.
- The shared decision is calculated from the first saved location's Atmos palette, local solar state, current observation, app theme and Dark at night setting.
- Primary temperature and condition text, secondary metadata, date, summary, local time pill and the gradient location title now switch together.
- The widget refreshes immediately when the app's light/dark mode changes and also receives the correct mode during background weather updates.
- Existing transparent layout, forecast content, temperature synchronization and stable signing are preserved.

## Build

- Version name: 0.66.7
- Version code: 367
