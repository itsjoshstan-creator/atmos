# Atmos 0.61.9

- Restored the main temperature degree symbol to its original raised superscript position.
- Positioned the temperature trend arrow directly beside the degree symbol at the same raised height.
- Preserved the compact inline trend treatment and subtle rising/falling animation introduced in 0.61.8.
- Updated versionName to 0.61.9 and versionCode to 319.
