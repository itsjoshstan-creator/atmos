# Atmos 0.66.8 — Hero Timeline Scrub Refinement

Built from Atmos 0.66.7.

## Hero timeline

- The NOW indicator now follows the user's finger continuously after long-press activation.
- The indicator label updates to the exact local time being scrubbed.
- The timeline subtitle also displays the selected local time while scrubbing.
- Releasing still returns the Hero to Now with the existing smooth 900 ms return.

## Atmos response

- Active scrub interpolation was reduced from 180 ms to 75 ms for a more direct response.
- Scrubbed Atmos palette blending now uses a dedicated fast transition:
  - Smooth: 150 ms
  - Slow: 230 ms
  - Instant remains immediate
- Normal location and weather transitions remain unchanged at their existing slower values.

## Legibility

- Hero foreground contrast now follows the scrubbed Atmos palette, not the live palette.
- Text changes appropriately between light and dark as the scrub crosses daylight, twilight and night.
- The gradient location title and lower chart colours also follow the scrubbed scene.
- The displayed date follows the scrubbed local time when crossing midnight.

## Build

- Version name: 0.66.8
- Version code: 368
- Stable signing configuration retained.
