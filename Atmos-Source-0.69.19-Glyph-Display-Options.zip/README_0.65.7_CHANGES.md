# Atmos 0.65.7

- Wired Atmos intensity into the actual scene renderer.
- Balanced remains the existing visual baseline.
- Subtle reduces palette depth, glare, atmospheric scattering, pressure mood, moonlight, stars, thermal and seasonal effects.
- Cinematic strengthens those same effects within capped limits.
- Wallpaper snapshots read and cache the selected intensity.
- Transparent hero widget location gradient responds to intensity.
