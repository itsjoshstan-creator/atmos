# Atmos 0.66.0 Animated Weather Effects

- Animated rain, wind streaks, snow, haze, fog, heat haze, frost, and lightning.
- Haze and fog now drift softly with the observed wind direction.
- Heat haze undulates subtly above 35°C.
- Frost shimmers slowly below 5°C.
- Lightning uses an irregular multi-pulse atmospheric flash.
- Effects remain individually toggleable in Settings.
- The animation loop only runs while at least one enabled effect is visible.
