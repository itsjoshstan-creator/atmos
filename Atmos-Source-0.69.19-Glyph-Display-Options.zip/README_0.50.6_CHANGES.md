# Atmos 0.50.6

- Fixes the Kotlin compilation failure caused by the removed `inferCloudCover()` helper.
- Removes the now-unused Atmos Engine 2.0 state derivation block, including cloud-cover, humidity, pressure, precipitation, wind-energy, clarity, density and personality calculations.
- Removes unused wind-direction and smoothing helpers left behind after the lean gradient renderer refactor.
- No intended visual or behavioural changes from 0.50.5.
