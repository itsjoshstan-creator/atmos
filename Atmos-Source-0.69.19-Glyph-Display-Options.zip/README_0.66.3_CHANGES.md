# Atmos 0.66.3

Built directly from the 0.66.2 source base.

## Weather-effects performance

- Fog and haze now use explicit lifecycle alpha rather than appearing or disappearing abruptly.
- Fade-in duration: approximately 1.05 seconds.
- Fade-out duration: approximately 1.35 seconds.
- Slow fog/haze-only scenes update at 20 fps instead of forcing 30/60 fps full-screen redraws.
- Rain, snow, wind, heat haze and lightning retain 30 fps, or 60 fps when the optional 60 fps mode is enabled.
- The effects frame loop stops after all active effects and fade-out lifecycles have completed.
- No additional renderer or permanent idle loop was introduced.

## Navigation transitions

- Settings category pages now use the same restrained fade and horizontal motion language as the main application pages.
- Opening a category moves forward; returning to the Settings index reverses the direction.
- Existing application-level transitions remain unchanged.

## In-place APK updates

- Package remains `au.com.weatheraustralia.app`.
- Version increased to code 363 / name 0.66.3.
- Performance APKs now use the included stable Atmos development signing key instead of a runner-generated debug key.
- The first APK built with this key may require one final uninstall if the installed build has a different signature. Later builds that preserve this key can update directly over 0.66.3.

## Build note

The included development keystore is intended only for private testing builds. A separately secured release/upload key must be used for Play Store publishing.
