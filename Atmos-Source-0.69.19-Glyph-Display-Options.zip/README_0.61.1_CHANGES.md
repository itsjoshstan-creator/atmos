# Atmos 0.61.1 changes

- Removed the large condition artwork from the persistent notification shade entry.
- Replaced the circular temperature small icon with bold, text-only temperature numerals and a raised degree mark.
- Removed lifecycle resume refreshes; returning to an existing Atmos task now relies on background data.
- Cold process launches use cached background data when fresh and refresh only when the shared cache is stale.
- Foreground and ambient refreshes now update all saved locations concurrently as one batch.
- Weather refresh completion no longer changes `currentPlace`; HorizontalPager exclusively owns location selection, preventing snap-back during swipes.
- Preserved background location relocation, WorkManager refreshes, widgets, and notification updates.

Version: 0.61.1 (311)

## GitHub Actions packaging fix

- Removed the fragile `cache-dependency-path` override from `actions/setup-java`.
- Added an explicit Android project structure check before invoking Gradle.
- Corrected the uploaded artifact name to `Atmos-0.61.1-debug`.
- Packaged `.github/` and `android/` directly at the archive root so repository paths match the workflow.
