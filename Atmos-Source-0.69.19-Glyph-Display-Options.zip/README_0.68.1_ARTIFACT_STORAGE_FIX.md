# Atmos 0.68.1 — GitHub Actions artifact storage fix

- New build artifacts are retained for one day instead of fourteen days.
- Before each non-pull-request upload, the workflow deletes all but the five newest repository artifacts.
- Artifact names now include the GitHub Actions run number.
- Added `actions: write` permission so the workflow can remove old artifacts through the GitHub API.
- Pull-request workflows skip artifact cleanup to avoid permission issues on forked pull requests.

GitHub may take 6–12 hours to recalculate storage usage after old artifacts are deleted. If the account is already at its quota, manually deleting old artifacts once may still be necessary before the first corrected workflow can upload successfully.
