# Atmos 0.50.1 changes

- Cached Atmos Engine 2.0 weather, pressure, solar, timezone and personality derivation outside the per-frame Canvas draw loop.
- Refreshes solar/night state once per minute instead of recalculating it on every rendered frame.
- Increased humidity pearl/cyan, dry-air amber, pressure/clarity depth, atmospheric density, horizon luminance, seasonal colour and feels-like grading by roughly 35–50%.
- Preserved static full-screen colour fields; the removed animated gradient has not returned.
- Fresh installations now default to Immersive rather than Ultra.
- Existing users retain their saved Atmos mode.
