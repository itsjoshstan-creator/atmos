# Atmos 0.60.3

## Atmos Display refinements

- Preserves the normal status-bar/cutout safe inset while Atmos Display hides Android status-bar icons.
- Prevents the location name from moving beneath a front-facing camera cutout or notch.
- Keeps the clock pill current with a minute-aligned clock tick.
- Uses the same live clock value for the date label.
- Retains the existing hidden navigation controls, 10-minute weather refresh, idle fade, and screen-awake duration behaviour.

## Build metadata

- Version code: 303
- Version name: 0.60.3
- GitHub Actions artifact: `Atmos-0.60.3-debug`
