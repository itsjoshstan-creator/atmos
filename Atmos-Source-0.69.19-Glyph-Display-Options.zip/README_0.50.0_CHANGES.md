# Atmos 0.50.0 — Atmos Engine 2.0, Phase 1

- Introduces one continuous `AtmosEngineState` shared by palette and native rendering.
- Derives warmth, moisture, clarity, density, stability, wind energy, solar energy, seasonal influence, night intensity, cloud cover, pressure energy and precipitation energy.
- Adds smoothly blended atmospheric personalities: Tropical, Alpine, Desert, Maritime, Storm, Winter and Temperate.
- Adds atmospheric depth through zenith clarity, suspended air mass and horizon luminance fields.
- Wind now influences cloud advection, haze position, solar halo position and particle turbulence.
- Air clarity controls contrast and zenith depth; atmospheric density controls horizon softness, cloud body and haze.
- Stronger feels-like thermal grading is routed through the common engine state.
- Air colour and sky luminance are coordinated with the same physical inputs.
- Retains the static-gradient performance strategy and existing render profiles.
