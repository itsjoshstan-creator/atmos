# Atmos 0.50.7

- Expanded Seasons with Southern Hemisphere, Northern Hemisphere, and tropical wet/dry sections.
- Highlights the current season for the user location with a high-contrast inverted pill.
- Added a Locations overview card immediately to the left of the first forecast page.
- Dark mode at night now follows only the saved current-device location sunrise and sunset.
- Compact density removes the hero temperature/precipitation chart and Rain/Wind/Humidity strip, shortening the hero so lower forecast cards appear sooner.
