# Atmos 0.68.2

## Right now card
- Fixed the three metric tiles so Wind, Humidity and Rain are identical heights.
- Centred icons, values and labels consistently within each tile.
- Improved spacing for longer wind-unit values.

## Today at a glance
- Moved the card title to the left edge to match Right now and Today forecast cards.
- Moved the condition artwork down beside the descriptive forecast text.

## Compact location transitions
- Adjacent compact pages now precompose the first three below-Hero cards.
- Right now, Atmos Moments and Today at a glance are present throughout a location swipe instead of appearing after settlement.
- Heavier charts and detail cards remain deferred until the page settles, preserving performance.

## About and attribution
- Expanded the Weather data section with provider-specific attribution and licence information.
- Added links to the Bureau of Meteorology copyright terms and Open-Meteo.
- Added the Open-Meteo CC BY 4.0 licence reference and a general forecast disclaimer.

## Build
- Version name: 0.68.2
- Version code: 382
