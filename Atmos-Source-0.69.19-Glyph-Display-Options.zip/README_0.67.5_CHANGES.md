# Atmos 0.67.5 — Scene-Shaping God Rays

- Reduced the normal god-ray count from three to two.
- A third ray appears only in exceptionally clear or hot daylight.
- Rays are substantially larger and can span most of the display.
- Increased downward expansion so each shaft shapes the full scene.
- Added stronger, slow horizontal drift and width breathing.
- Added a very broad low-opacity halo around every shaft for softer, fading edges.
- Kept a defined inner light volume so the rays remain obvious.
- Increased ray-only motion from 6 fps to 8 fps for clearer movement while retaining a low rendering cost.
- Existing solar position, daylight envelope, weather dependence, heat warmth, toggle and widget text-mode controls remain unchanged.
