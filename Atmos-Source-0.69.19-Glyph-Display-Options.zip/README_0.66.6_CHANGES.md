# Atmos 0.66.6

## Hero timeline scrubbing

- The main immersive Hero's Next 24 Hours chart is now interactive after a press-and-hold.
- Dragging across the chart interpolates the forecast time, temperature, humidity, wind and condition.
- The complete Hero atmosphere uses the shared Atmos renderer with the selected forecast time and solar position.
- Atmos palette changes retain the existing long, lazy colour transitions so rapid scrubbing does not create hard scene cuts.
- Releasing the chart eases the Hero back to the current observation over 900 ms.
- When Immersive uses a preloaded location background, a scrub scene fades over it and fades away as the Hero returns to now.

## Help & gestures

- Added Help & gestures to the floating Atmos menu.
- Added an Atmos-styled Help page covering Hero timeline scrubbing, Celsius/Fahrenheit switching, Seasons, Locations, location-local time, location swiping, Atmos Display, widgets and live wallpaper.

## Build

- Version name: 0.66.6
- Version code: 366
- Existing stable development signing configuration is preserved for in-place updates.
