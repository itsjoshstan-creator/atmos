# Atmos 0.67.4

## Simplified diagonal god rays

- Reduced the effect to three rays in most daylight conditions and four only in clearer or hotter scenes.
- Rays are substantially larger and use only a broad body plus a defined inner core.
- Increased diagonal projection at every time of day, including midday.
- Increased fan separation so the shafts spread apart more visibly as they descend.
- Sunrise rays lean down and across from the eastern side; sunset rays reverse from the western side.
- Retained slow width, position, and intensity changes and the existing condition/temperature/daylight response.
- Reduced each ray from three draw layers to two to lower rendering work.

## 4×4 widget text mode

Added **Settings → Home screen → 4×4 widget text** with:

- **Automatic** — follows the same solar-aware contrast decision as the main Hero.
- **Light text** — always uses light widget typography.
- **Dark text** — always uses dark widget typography.

The selection is stored persistently and applied immediately to the transparent 4×4 Hero widget. Automatic remains the default.

## Version

- Version name: 0.67.4
- Version code: 374
