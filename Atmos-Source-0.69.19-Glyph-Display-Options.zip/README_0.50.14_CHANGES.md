# Atmos 0.50.14

## Season Stories

- Added a dedicated, location-aware page for every season.
- Tapping the current season pill on a forecast opens that location's active season.
- Every season card in the Seasons hub now opens its detailed page.
- Added bespoke Atmos gradients for Summer, Autumn, Winter, Spring, Wet season and Dry season.
- Added an oversized extra-bold seasonal title and location-specific introduction.
- Added date ranges, broad temperature ranges, precipitation character, daylight behaviour and landscape context.
- Added a local countdown to the next season and identifies the next season by name.
- Seasonal cycles follow the selected location's Northern Hemisphere, Southern Hemisphere or tropical wet/dry context.
- Added clear wording that seasonal ranges are expressive guidance rather than official climate normals.
