# Atmos 0.41.5

Fixes the Kotlin compilation failure in saved-location cards. `rememberSolarAwarePalette` requires a non-null `Observation`; loading cards now pass `weather?.observation ?: Observation()`.
