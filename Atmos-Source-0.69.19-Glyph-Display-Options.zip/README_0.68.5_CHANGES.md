# Atmos 0.68.5

Cleanly rebased from Atmos 0.68.2.

## Changes
- Replaced the Right Now humidity symbol with a static fog-cloud icon. Right Now icons remain non-animated.
- Made Atmos Moments non-interactive while preserving condition-themed Timeline and time highlights.
- Added a What's new submenu to Settings showing the latest three versions, with consistently aligned change markers.
- Increased compact Hero temperature sizing responsively while retaining consistent padding and handling wider three-digit values.
- Added a subtle condition-gradient tint to the persistent Android navigation bar with smooth colour transitions.
- Retained the left-aligned Today at a glance title and condition icon beside the descriptive text.
- Increased rain visibility, especially over bright daylight Atmos scenes, using a lightweight contrasting two-layer rain stroke.
