# Atmos 0.60.0

## New Atmos widget system — Phase 1

- Retired the previous collection of legacy widgets from the Android widget picker.
- Introduced **Atmos Today**, a new 2 × 2 flagship widget built from the current Atmos visual language.
- Uses the established 0.50.16 condition-aware Atmos widget gradients without the discarded 0.50.17 experiment.
- Large temperature-led hierarchy, location, condition and daily high/low.
- Compact three-point hourly rail using the latest cached forecast.
- Shared widget design tokens for spacing, typography, translucency and corner treatment.
- Entire widget opens Atmos.
- Background refresh remains scheduled approximately every 30 minutes.

This release establishes the visual and technical foundation for the future Atmos widget family.
