# Atmos 0.50.4

## Build fix

- Removed a stale `atmosphereIntensity` reference from `SettingsPage` after the Atmos settings UI was removed in 0.50.3.
- No visual or behavioural changes from 0.50.3.
- Updated Android version metadata and GitHub Actions artifact name.
