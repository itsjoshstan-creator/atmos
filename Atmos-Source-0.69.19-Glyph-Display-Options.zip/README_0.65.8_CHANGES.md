# Atmos 0.65.8 — Distinct Intensity Modes

- Increased the visual separation between Subtle, Balanced, and Cinematic Atmos intensity modes.
- Balanced remains unchanged from the established Atmos renderer.
- Subtle now produces a calmer, flatter palette with substantially reduced solar, seasonal, thermal, pressure, moonlight, star, and cloud-shadow influence.
- Cinematic now produces richer colour separation, stronger directional light, deeper atmospheric contrast, and more visible environmental grading while remaining controlled.
- Increased safe effect ceilings only for values above the Balanced profile, so the Balanced appearance remains unchanged.
- Version code 358.
