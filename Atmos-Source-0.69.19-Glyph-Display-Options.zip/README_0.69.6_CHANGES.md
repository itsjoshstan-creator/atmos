# Atmos 0.69.6

- Added a user-controlled gradient typography option for the transparent 4×4 widget.
- When enabled, the widget temperature, degree symbol and large condition text use the same Atmos gradient language as the main Hero.
- Added under Settings → Home screen → 4×4 widget text.
