# Atmos 0.40.9 — Performance pass

- Added separate full-screen and compact Atmos render profiles.
- Saved-location cards now update at 30 fps instead of running full-screen 60 fps simulations.
- Compact scenes use adaptive particle limits based on rendered area, capped at 72 particles.
- Full-screen particle limits were reduced to 90 / 190 / 320 / 480 for Subtle, Balanced, Immersive and Ultra.
- Full-screen particle limits also scale with actual canvas area.
- Compact cards use fewer feathered cloud layers and haze banks while retaining the same visual features.
- Particle foreground layering is recalculated periodically rather than sorting hundreds of particles every frame.
- Compact heat shimmer uses fewer lines.
- Full-screen Hero and Immersive scenes retain the complete renderer and 60 fps target.
