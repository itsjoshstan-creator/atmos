# Atmos 0.40.5

## Animated atmosphere gradient fix

- Restored the Animated atmosphere gradient control as a true core-sky animation.
- Enabled state now animates gradient endpoints, blends the upper/middle/lower colour fields independently, and adds two slow moving feathered colour fields.
- Disabled state renders the current weather palette as a stable snapshot with no gradient drift or colour breathing.
- Solar lighting, clouds, precipitation, seasonal particles, wind, fog, thermal effects and lightning remain independently controlled.
- Updated version to 0.40.5 (build 145) and GitHub artifact name to Atmos-0.40.5-debug.
