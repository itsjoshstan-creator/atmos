# Atmos 0.64.7 — Shared Wallpaper Renderer

- Replaced the wallpaper-only approximate palette with the exact in-app solar-aware and atmospheric palette pipeline.
- Matched the hero diagonal three-colour gradient geometry.
- Matched unified solar, seasonal, humidity/visibility, pressure, moonlight, stars, and cloud-shadow lighting.
- Added the immersive layout dark lower-atmosphere treatment to the wallpaper.
- Wallpaper remains text-free and event-driven.
