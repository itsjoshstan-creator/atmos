# Atmos 0.50.10

## First-run forecast reveal

- The app no longer reveals the Home forecast until usable weather data exists for the location selected during setup.
- After layout setup, Atmos returns to the sunrise launch artwork while the first forecast finishes loading.
- The launch screen uses purposeful progress copy and a longer cinematic fade into the populated location forecast.
- The reveal waits for cached or freshly received observation/hourly data, avoiding an empty placeholder forecast.
- If location permission is denied or location resolution fails, setup returns to manual location selection rather than advancing with placeholder data.
