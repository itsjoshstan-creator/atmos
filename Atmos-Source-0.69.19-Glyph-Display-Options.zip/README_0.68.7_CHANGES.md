# Atmos 0.68.7

- Reworked the Android navigation shadow so it is cast upward across the Hero/page content.
- The navigation surface now reads as a distinct layer floating above Atmos content.
