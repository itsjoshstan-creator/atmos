# Atmos 0.66.8 build fix

- Fixed Kotlin compilation failure in `DualAtmosphereHero`.
- Replaced an invalid out-of-scope `displayedPalette` reference with the component's local `palette`.
- No intended visual or behavioural changes from the original 0.66.8 refinement.
