# Atmos 0.69.15 — Glyph SDK Packaging Fix

- Ensures the official Nothing Glyph Matrix SDK 2.0 AAR is downloaded during every Gradle configuration.
- Fails the build instead of silently producing an APK without Glyph support.
- Adds R8/ProGuard keep rules for all `com.nothing.ketchum` SDK classes and callback interfaces.
- Broadens Nothing Phone detection using manufacturer, brand, advertised Glyph Matrix features and SDK availability.
- Retains the structured 13×13 Phone (4a) Pro renderer and AOD Glyph Toy lifecycle from 0.69.14.
