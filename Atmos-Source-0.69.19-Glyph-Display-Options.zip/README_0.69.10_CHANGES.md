# Atmos 0.69.10

- Rebuilt rain particles with independent procedural lifecycles.
- Each drop now receives a fresh origin, depth, duration, length, opacity and slight turbulence when it respawns.
- Removed the visible short-loop behaviour and repeated grouped columns.
- Preserved the existing data-driven intensity, wind bearing, depth layers and smooth rain transitions.
- Updated the in-app changelog.
