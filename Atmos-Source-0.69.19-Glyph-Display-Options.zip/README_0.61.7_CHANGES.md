# Atmos 0.61.7

## Atmos Display toggle

- The floating-menu Atmos Display action now toggles the display on and off.
- Tapping it while Atmos Display is active immediately restores the normal interface.
- Manual deactivation also suppresses automatic Atmos Display for the remainder of the current app session, preventing an enabled Settings preference from instantly reactivating it.
- Tapping the action again clears the suppression and activates Atmos Display immediately.

## First-location loading

- The first selected location is no longer assigned to the visible weather UI with fallback data while its initial forecast is still downloading.
- First-run current-location and manual-location setup now load behind the full-screen Atmos loading artwork.
- The selected Place and completed WeatherState are committed together only after usable forecast data has arrived.
- The loading artwork remains visible through the final preparation stage, then fades into the completed location.
- A failed first forecast returns the user to location selection rather than revealing an incomplete weather screen.
