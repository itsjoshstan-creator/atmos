# Atmos 0.62.1

- Added the first on-device intelligent forecast summary engine.
- Replaced the fixed Today at a Glance sentence with a time-aware summary generated from Atmos forecast data.
- Summaries analyse temperature direction, upcoming rain timing, rain likelihood, wind changes, and the daily temperature range.
- Added tailored tomorrow summaries using condition, rainfall, high, and low data.
- Keeps all summary generation local, private, instant, and available with cached forecasts.
- Omits unimportant weather variables to keep the interface concise.
