# Atmos 0.69.11

- Restored the faster rain fall speed used by the 0.69.9 Rain Engine.
- Retained the procedural rain system introduced in 0.69.10.
- Drops continue to use independent lifetimes, randomised respawning, varied depth, length, opacity and subtle turbulence.
- Updated the in-app changelog.
