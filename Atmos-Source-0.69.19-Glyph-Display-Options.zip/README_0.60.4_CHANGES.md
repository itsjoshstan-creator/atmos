# Atmos 0.60.4

## Build fix and Ambient Display inset stability

- Replaced Compose's experimental `statusBarsIgnoringVisibility` layout API with a stable AndroidX Core inset helper.
- The helper reads the status-bar inset with `WindowInsetsCompat.getInsetsIgnoringVisibility`, so the normal top spacing remains reserved after status-bar icons are hidden.
- Location text stays below display cut-outs and front-facing camera holes in Ambient Display.
- Status-bar icons and Android navigation controls remain hidden while Ambient Display is active.
- The Expanded hero clock pill continues to use its minute-aligned clock loop and refreshes at each minute boundary.
- The existing 10-minute weather refresh remains unchanged.

## Version

- Version code: 304
- Version name: 0.60.4
- GitHub Actions artifact: `Atmos-0.60.4-debug`
