# Atmos 0.67.1

- Reworked sun god rays to originate from a broad, distant off-screen solar band.
- Rays are now mostly parallel with subtle divergence, like crepuscular rays over a landscape.
- Added a smooth daylight envelope: rays gradually appear after sunrise and fade before sunset.
- Preserved multiple independently drifting, breathing shafts and the 12 fps ray-only performance path.
- Fixed live wallpaper refresh coordination by adding an explicit wallpaper weather version, invalidating stale snapshots when weather cache changes, and strengthening snapshot metadata with observation and condition values.
- Version code 371.
