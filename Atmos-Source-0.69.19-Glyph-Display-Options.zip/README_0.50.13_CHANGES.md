# Atmos 0.50.13 changes

- Restored the forecast page handle to its original in-hero position for Expanded layout.
- Retained the card-stack handle placement for Compact layout.
- Added a lighter page-handle treatment during OLED night mode.
- Updated the left Saved Places overview to display every saved location in a scrollable list.
- Preserved direct tapping from each compact saved-place card to its forecast.

Version name: `0.50.13`
Version code: `213`
GitHub Actions artifact: `Atmos-0.50.13-debug`
