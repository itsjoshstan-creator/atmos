# Atmos 0.60.7

## Status-bar weather visibility

- Migrated the current-weather notification to a new `IMPORTANCE_DEFAULT` Android channel so it is no longer classified as silent by default.
- Removed the legacy low-importance channel used by 0.60.5 and 0.60.6.
- Added a minimal condition glyph beside the live temperature in the dynamic status-bar icon.
- Supports clear/day, clear/night, cloudy, rain and storm glyphs.
- Preserves the full ongoing forecast notification in the notification shade.

## Android limitation

Android status-bar icons are representations of posted notifications. The status icon cannot remain while hiding its corresponding notification from the notification shade.
