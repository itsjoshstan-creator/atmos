# Atmos 0.41.1

Performance regression fix for Home location paging.

- Restores `beyondViewportPageCount = 1` so the immediate destination forecast page is composed before the swipe begins.
- Prevents a third heavy forecast page from being constructed while a swipe is in progress.
- Uses a lightweight background shell only for pages more than one position away from the last settled page during the gesture.
- Keeps the dedicated Immersive destination atmosphere preloaded and cross-faded.
- Preserves the Atmos Off, Performance, Immersive, and Ultra profiles introduced in 0.41.0.
