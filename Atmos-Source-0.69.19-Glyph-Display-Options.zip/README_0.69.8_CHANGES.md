# Atmos 0.69.8

- Improved page-handle contrast in light mode.
- Active handles now use a darker condition-derived colour on bright interfaces.
- Inactive handles use a muted version of the same condition colour.
- Existing lighter night/OLED handle treatment is retained.
