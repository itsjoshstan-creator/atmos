# Atmos 0.50.2

## Performance
- Non-selected location cards use a frozen Compact Atmos preview and run no animation clock.
- Off-screen Atmos simulations are paused.
- During Immersive swipes, the settled source scene freezes while only the destination advances using the reduced Transition profile.

## Static Atmos mode
- Adds **Static** alongside Off, Performance, Immersive and Ultra.
- Static preserves the weather-derived palette and its observation/location cross-fades.
- Enabled clouds, rain, snow, haze and seasonal particles remain visible as a deterministic frozen scene.
- No continuous frame clock, particle spawning, particle integration, cloud drift, lightning or heat-shimmer animation runs in Static mode.
