# Atmos 0.64.8 — Wallpaper Recovery

- Fixed a black-screen live wallpaper failure by always painting a valid Atmos fallback before loading cached weather.
- Protected the wallpaper surface from cache, parsing, and device-specific rendering exceptions.
- Uses the canvas surface dimensions directly for every frame.
- Added robust weather-cache fallback when current-location coordinates and cache keys temporarily differ.
- Matched the app renderer’s thermal and seasonal radial grading passes.
- Retained the exact condition/solar palette, pressure, humidity/visibility, glare, moonlight, stars, cloud-shadow, and immersive lower darkening treatment.
- No text or UI is rendered in the wallpaper.
