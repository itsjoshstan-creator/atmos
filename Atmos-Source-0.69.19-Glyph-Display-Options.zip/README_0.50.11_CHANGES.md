# Atmos 0.50.11 changes

## Compact hero spacing

- Reserved a dedicated vertical clearance zone for the forecast page handle in Compact layout.
- Increased the Compact hero minimum height so wrapped current-condition descriptions cannot compete with the handle for space.
- Added more balanced space below the handle before **Today at a glance**.
- Kept the existing measured-line expansion, so unusually long descriptions still grow the hero further.

## Build metadata

- Version code: `211`
- Version name: `0.50.11`
- GitHub Actions artifact: `Atmos-0.50.11-debug`
