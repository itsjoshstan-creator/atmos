# Atmos 0.62.3

- The first item in the Today hourly slider now uses the same current observation temperature as the large hero temperature.
- The synthetic **Now** item also uses current observed humidity, wind and direction when available, while retaining the nearest forecast icon and rain probability.
- Hourly forecast items after **Now** are filtered to genuinely future timestamps, preventing the current or previous forecast hour from being labelled as Now.
- Sunrise and sunset events remain interleaved chronologically with the forecast timeline.
