# Atmos 0.65.9 Weather Effects

Adds individually toggleable premium weather overlays: rain, wind streaks, snow, haze, fog, heat haze, frost and lightning. Effects respond to current conditions, temperature, wind speed and direction and are isolated from the event-driven Atmos background renderer.
