# Atmos 0.66.5

## 4×4 widget forecast spacing

- Reduced the bottom reserve beneath the 4×4 Hero widget forecast summary from 12dp to 2dp.
- Allows the summary to use up to four lines when the launcher-provided widget height permits it.
- Preserves the existing Hero typography, horizontal padding, temperature layout and transparent presentation.
- Preserves the shared widget temperature fix and stable signing configuration from 0.66.4.

Version: 0.66.5 (365)
