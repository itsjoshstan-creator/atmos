# Atmos 0.69.5

- Introduced Weather Realism Model v1.
- Added shared cloud depth, surface light, air clarity, moisture weight and weather instability values.
- Existing lighting, clouds, haze, rain, stars, shadows and visibility now respond to the same coordinated model.
- Rain density, length and speed scale with inferred precipitation intensity.
- Kept the model event-driven with no additional continuous render loop.
