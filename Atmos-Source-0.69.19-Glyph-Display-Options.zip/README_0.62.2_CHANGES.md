# Atmos 0.62.2

- Connected the local intelligent forecast-summary engine to the main hero card narrative.
- Replaced the legacy condition-only hero description with a time-aware forecast summary.
- Limited the hero summary to the two most useful sentences to preserve the existing layout.
- Kept the fuller Today and Tomorrow at a Glance summaries unchanged.
- Compact mode continues to omit the duplicate hero narrative by design.
- Updated Android version to 0.62.2 (version code 322).
