# Atmos 0.41.2

## Performance and visual changes

- Removed the Animated atmosphere gradient feature from the active native renderer and Settings.
- Atmos now uses a static weather/solar/season/temperature palette that still cross-fades between locations.
- Performance mode description updated to reflect the removed gradient layer.
- OLED late-night transition now begins 90 minutes after sunset and reaches the near-black OLED palette at 2 hours after sunset.
- New cloud scenes fade in over 750 ms, preventing cloud bodies from popping into frame during location changes.
- Cloud feathering, precipitation, fog/haze, particles, thermal effects, solar lighting and OLED treatment remain intact.

## Version

- Version name: 0.41.2
- Version code: 152
