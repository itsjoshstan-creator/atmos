# Atmos 0.63.7 Changes

- Expanded Dual atmosphere into a horizontal pager of saved-location pairs.
- Every saved location now appears in Dual atmosphere, in saved order.
- Each page contains up to two equal-height compact Atmos hero cards.
- Added subtle page indicators when more than one pair is available.
- Odd final pages keep the lower half open with a simple Add Location button and no placeholder card.
- Dual atmosphere remains fixed-height and does not scroll vertically.
- Updated the Settings description to explain swipeable pages of two atmospheres.
