# Atmos 0.65.3 – Transparent Hero Widget

- Added a native 4×4 transparent home-screen widget.
- Mirrors the top half of the immersive hero: gradient location title, state, LIVE treatment, season and local-time pills, date, large temperature typography, condition, feels-like/high-low, and intelligent summary.
- Scales to the launcher-provided 4×4/half-screen dimensions.
- Uses the first saved location and updates with the existing widget/background weather pipeline.
- Tapping anywhere opens Atmos.
- Leaves the 0.65.2 in-app renderer and live wallpaper unchanged.
