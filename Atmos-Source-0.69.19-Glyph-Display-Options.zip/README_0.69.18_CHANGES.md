# Atmos 0.69.18

- Fixed the Glyph Matrix SDK 2.0 compile error by passing `applicationContext` to `GlyphMatrixFrame.Builder.build(...)`.
- Removed the duplicated Nothing Glyph permission declaration from the Android manifest.
- Retains native Phone (4a) Pro registration, AOD event handling and structured 13×13 weather frames.
