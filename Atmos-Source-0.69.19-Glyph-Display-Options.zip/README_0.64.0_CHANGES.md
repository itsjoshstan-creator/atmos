# Atmos 0.64.0 — Performance Release

- Added an installable release-optimised performance APK for real-world testing.
- Enabled R8 code optimisation and resource shrinking for the performance artifact.
- Consolidated per-location minute timers into one lifecycle-aware shared clock.
- Marked immutable weather and scene models for stronger Compose stability/skipping.
- Reused the existing AtmosPreferences instance inside hero cards instead of constructing one per page.
- Preserved the complete 0.63.9 interface, visuals, layout and feature behaviour.
