# Atmos 0.62.4

## Persistent notification intelligence

- Added the local intelligent forecast summary to the persistent weather notification.
- The expanded notification now presents the two most useful forecast sentences generated from current and hourly weather data.
- The collapsed notification uses the first concise forecast insight alongside the daily high and low.
- Notification summaries remain fully on-device and work with cached forecasts.
- No cloud AI service or external forecast-summary request is used.
