# Atmos 0.67.0 — Lightweight living sun rays

- Increased god-ray visibility in all daylight conditions while retaining weather-dependent density and strength.
- Clear skies now show up to nine soft shafts; cloudier conditions retain four to seven subdued shafts.
- Rays independently drift, breathe, widen, narrow, brighten and fade while remaining aligned to solar position.
- Hot weather produces warmer and stronger light.
- Replaced expensive Android BlurMaskFilter/Paint/Shader allocation passes with layered Compose wedges.
- Rays-only motion runs at 12 fps; precipitation/wind/heat/lightning retain their existing 30/60 fps paths.
- Rays stay enabled by default and remain independently toggleable.
- Version bumped to 0.67.0 (370).
