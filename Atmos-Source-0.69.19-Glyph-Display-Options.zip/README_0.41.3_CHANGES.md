# Atmos 0.41.3

## Atmospheric palette variables

- Humidity adds restrained pearl and cyan depth.
- Dry air adds clearer amber warmth near the horizon.
- Low pressure introduces steel and violet storm tones.
- High pressure adds a small amount of clearer blue.
- Cloud cover cools and softens the upper atmosphere.
- Seasonal colour has a stronger influence on the horizon.
- Sunrise and sunset add stronger location-aware horizon colour without a continuous animated gradient.

## Adaptive foregrounds

- Upper Hero text now evaluates the upper Atmos colour field.
- Fullscreen Hero lower text evaluates its brighter lower palette independently.
- Immersive lower text evaluates the app-coloured lower overlay independently.
- Chart strokes and precipitation colours choose contrast independently from chart labels and surrounding text.
- Light and dark app appearance bias the contrast thresholds without overriding actual readability.

## Dark mode at night

- Restored a separate `Dark mode at night` option under Appearance.
- The user still chooses Follow Device, Light, or Dark as the base appearance.
- When enabled, the selected location switches the app to the dark colour scheme at local night.
- The calculation updates once per minute and only follows the settled selected location, avoiding swipe-time theme interpolation.

## Version

- Version name: 0.41.3
- Version code: 153
- GitHub Actions artifact: `Atmos-0.41.3-debug`

## Validation

ZIP structure, workflow paths, version metadata, source delimiters, renderer call sites, and legacy enum references were checked. A local Android compile could not run because the Gradle wrapper distribution is unavailable without network access; GitHub Actions remains the definitive compiler validation.
