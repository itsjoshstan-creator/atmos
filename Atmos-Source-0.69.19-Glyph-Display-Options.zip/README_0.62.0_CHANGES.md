# Atmos 0.62.0

- Rebuilt device-location naming around one shared resolver.
- Added Android reverse geocoding for suburb/locality, state, country and country code.
- Australian device locations now prefer suburb or locality names instead of the nearest hardcoded city.
- Unified first-run, foreground refresh, Locations-page and background relocation naming.
- Added resilient fallbacks for devices where reverse geocoding is unavailable or temporarily fails.
- Retains the previous valid locality when a temporary geocoding lookup fails.
- Generates location IDs from the device coordinates to prevent unrelated city IDs being reused.
- Improved international current-location naming where Android supplies address information.
