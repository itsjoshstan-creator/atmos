# Atmos 0.61.5

## Background weather cache synchronisation

- Restores visible app updates from forecasts downloaded by WorkManager.
- When Atmos returns to the foreground, it reloads the shared disk cache and imports only entries newer than the current in-memory data.
- Does not trigger a duplicate network refresh on resume.
- Preserves the selected location and pager position.
- Handles a background relocation of the Current location card and its changed cache key.
- Persistent notification and widgets continue to use the same shared weather cache.

Based directly on Atmos 0.61.4.
