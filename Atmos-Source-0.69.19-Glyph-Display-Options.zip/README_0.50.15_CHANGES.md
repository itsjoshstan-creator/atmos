# Atmos 0.50.15

## Build fix

- Fixed the season-pill navigation callback in `HeroCard`.
- The callback is now passed from `HomePage` into both Card Style and Immersive hero layouts.
- This resolves the Kotlin compile error: `Unresolved reference onSeason`.

No intended visual or behavioural changes beyond restoring the season-page navigation introduced in 0.50.14.
