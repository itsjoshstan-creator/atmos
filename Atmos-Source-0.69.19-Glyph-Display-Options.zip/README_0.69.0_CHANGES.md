# Atmos 0.69.0

- Removed the opaque rectangular surface behind the rounded floating menu.
- Themed all floating-menu icons from the active location's Atmos condition palette.
- Replaced the humidity artwork with a compact, filled cloud/fog glyph matching the Wind and Rain metrics.
- Brightened page handles automatically for night and dark weather scenes.
