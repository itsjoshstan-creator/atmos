# Atmos 0.65.5

- Enlarged the text-only temperature glyph used by Temperature status-bar mode.
- Numerals now occupy more of Android's notification-icon mask for improved legibility.
- Retained the raised degree mark and removed no information.
- No circular background is used.
- Weather Condition status-bar icon mode is unchanged.
- Built from Atmos 0.65.4.
