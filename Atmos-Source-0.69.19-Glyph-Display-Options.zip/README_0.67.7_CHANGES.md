# Atmos 0.67.7 — Unified Hero Atmos Scene

Base: Atmos 0.67.5

## Fixed

- Card and Immersive Hero now use the same settled Atmos palette for the same location and weather state.
- Removed the duplicate settled Hero palette path.
- Fixed an input mismatch where the card used the nearest hourly forecast icon even when timeline scrubbing was inactive, while Immersive used the current/day icon.
- Timeline scrubbing still creates its own temporary, time-specific Atmos scene.
- Releasing the timeline returns to the shared current scene.

## Preserved

- 0.67.5 scene-shaping god rays.
- Existing renderer, weather effects, timeline, widget, wallpaper, notifications, navigation, and stable signing.
- No new continuous rendering loops.

## Build

- Version name: 0.67.7
- Version code: 377
