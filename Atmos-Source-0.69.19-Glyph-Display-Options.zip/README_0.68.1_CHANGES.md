# Atmos 0.68.1

- Removed Living Atmosphere, its renderer modulation, animation loop participation, preference and settings controls.
- Corrected LIVE pill content alignment with balanced horizontal padding.
- Added a themed Right now card above Atmos Moments showing current wind, humidity and rain chance.
- Increased Living Clouds visibility, scale and atmospheric influence while retaining the low-frequency 4 fps update path.
