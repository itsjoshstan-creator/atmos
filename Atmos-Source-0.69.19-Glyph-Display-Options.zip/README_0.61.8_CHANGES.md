# Atmos 0.61.8

- Added a compact temperature trend indicator directly beside the degree symbol.
- Rising temperatures show `↗`, falling temperatures show `↘`, and steady temperatures show `→`.
- Trend direction is calculated by comparing the current observation with the forecast approximately three hours ahead.
- Added a brief, subtle upward or downward temperature movement when refreshed weather data changes the trend.
- Steady temperatures remain motionless.
- The indicator uses the same typography and colour as the degree symbol to avoid adding visual clutter.
