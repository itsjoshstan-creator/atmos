# Atmos 0.60.9 Changes

- Added Android background-location permission support for the saved current-location entry.
- Added a Settings control that guides users through foreground location and the separate “Allow all the time” permission flow.
- Android 11 and newer open the app permission settings page, as required by Android.
- Background WorkManager refreshes now reposition the current-location entry before downloading weather when background access is granted.
- Persistent notification and widget data are updated from the refreshed current location.
- Reduced periodic background refresh interval from 30 minutes to 15 minutes, Android’s minimum periodic WorkManager interval.
- Safely falls back to the last saved coordinates when background permission or a fresh location is unavailable.
- Updated version to 0.60.9 (309).
