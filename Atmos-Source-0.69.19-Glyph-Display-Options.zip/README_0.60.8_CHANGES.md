# Atmos 0.60.8

- Reverted the Android status-bar icon to a temperature-only design.
- Changed the temperature icon to a filled circular alpha-mask with cut-out numerals for improved contrast alongside Android system icons.
- Added a larger solid condition icon to the notification shade, positioned by Android to the left of the location and forecast content.
- Preserved the default-importance notification channel introduced in 0.60.7.
- Updated versionName to 0.60.8 and versionCode to 308.
