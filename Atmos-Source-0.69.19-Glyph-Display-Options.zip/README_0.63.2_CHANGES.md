# Atmos 0.63.2

- Restored the native Material bottom navigation to its original solid surface colour.
- Added Seasons as a permanent fourth bottom-navigation destination.
- Removed Seasons from the floating overflow menu.
- Removed the Rain, Wind and Humidity strip from the immersive hero.
- Rebalanced hero spacing so the page indicator sits cleanly above the native bottom navigation.
- Added the Atmos gradient extra-bold heading treatment to the Seasons page.
- The floating menu's three-dot icon now uses the active location's condition palette.
