# Atmos 0.64.5 — Weather Details

- Reworked weather-detail cards with Atmos-native vector icons.
- Increased collapsed and expanded card heights and moved secondary information into expanded views.
- Fixed UV index cards to use real daily UV forecast data, including an Open-Meteo fallback for BOM locations.
- Added visible drag grips and live two-column drag-and-drop reordering for weather-detail cards.
- Added a horizontally scrollable hourly wind forecast card beneath hourly precipitation.
- Preserved the 0.64.4 unified lighting and performance build configuration.
