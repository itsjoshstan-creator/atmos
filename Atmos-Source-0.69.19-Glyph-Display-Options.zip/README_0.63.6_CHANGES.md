# Atmos 0.63.6

- Preserved the final, fully prepared Atmos hero for current and adjacent locations throughout horizontal swipes.
- Removed the previous static/simplified-to-live atmosphere handoff that could flash when a page settled.
- Deferred only below-the-fold forecast cards for adjacent pages until the destination becomes selected.
- Converted the weather feed from a fully composed vertical Column to LazyColumn.
- Removed redundant per-card graphics layers and the full-page alpha/translation compositing layer.
- Kept the current page fully rendered during a gesture so swiping from a vertically scrolled forecast does not collapse its content.
- Added stable lazy-item keys for hero, hourly, daily, precipitation, warnings, details, and footer sections.
- Preserved all 0.63.5 rebased features, including dual atmosphere layout and idle render-loop reductions.
