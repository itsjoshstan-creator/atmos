# Atmos 0.68.6

- Restyled the Right Now humidity symbol as a monochrome, Atmos-themed fog cloud matching the wind and rain icon treatment.
- Fixed the inline Timeline emphasis in Atmos Moments so it shares the sentence font and baseline while remaining bold and condition-themed.
- Added a soft, diffuse condition-tinted shadow above the Android navigation bar.
