# Atmos 0.63.5

- Removed the continuously animated decorative page gradient.
- Removed the continuously animated Settings glyphs.
- Kept the Atmos hero renderer event-driven: it redraws only for weather/location changes, minute solar ticks, and short scene transitions.
- Kept refresh, interaction, and Atmos Display animations scoped to the moments when those features are active.
- Reduced idle Compose frame production and associated CPU/GPU usage.
