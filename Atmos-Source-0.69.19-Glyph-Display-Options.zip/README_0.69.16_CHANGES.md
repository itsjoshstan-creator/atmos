# Atmos 0.69.16

- Fixed the Glyph Matrix SDK manifest merger failure.
- Added the required `tools:overrideLibrary="com.nothing.thirdparty"` declaration so Atmos can retain its existing minimum Android version.
- Restored the required `com.nothing.ketchum.permission.ENABLE` permission.
- Glyph code remains protected by device and Android-version checks, so it is not invoked on unsupported devices.
