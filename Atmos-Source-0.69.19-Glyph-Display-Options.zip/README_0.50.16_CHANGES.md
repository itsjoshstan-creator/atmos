# Atmos 0.50.16

Compile-fix release for the season detail navigation introduced in 0.50.14.

- Added the missing `onSeason` callback to `ForecastPage`.
- Forwarded the callback from `HomePage` through `ForecastPage` to `HeroCard`.
- Restores compilation of both Card Style and Immersive season-pill navigation paths.
- No intended visual or behavioural changes beyond completing the callback chain.
