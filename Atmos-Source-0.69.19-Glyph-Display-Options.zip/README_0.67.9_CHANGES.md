# Atmos 0.67.9

- Atmos Moments now uses the same themed gradient outline treatment as Today at a glance and the other forecast cards.
- The existing Atmos accent option is now a true dynamic colour-temperature mode. Native controls inherit the active Atmos scene accent and change naturally with weather and time of day. Follow wallpaper remains a separate Material You option.
- Added optional Atmospheric Soundscape under Settings > Weather experience. It generates a quiet procedural blend of wind, rain texture, and distant atmospheric tone, responds to current conditions, plays only while Atmos is open, uses no bundled/downloaded audio, and is off by default.
- Version code 379 / version name 0.67.9.
