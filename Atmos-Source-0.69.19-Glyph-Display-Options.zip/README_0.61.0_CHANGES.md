# Atmos 0.61.0 Changes

- Replaced the old status-bar temperature switch with an icon-style selector.
- Added Temperature and Weather condition status-bar icon choices.
- Added bold monochrome condition icons for clear day, clear night, cloud, rain and thunderstorm.
- Status-bar style changes rebuild the existing notification immediately without posting a second notification.
- Migrates the previous temperature-icon preference so existing users keep their closest matching choice.
- Preserves the notification-shade condition icon, background weather refresh and background-location behaviour from 0.60.9.
