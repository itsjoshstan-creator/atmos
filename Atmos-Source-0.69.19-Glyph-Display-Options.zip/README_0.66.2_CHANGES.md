# Atmos 0.66.2

- Added an optional 60 FPS mode for animated weather effects.
- Existing approximately 30 FPS weather-effects mode remains the default.
- 60 FPS is clearly labelled as using more battery and graphics performance.
- The high-frame-rate loop runs only while an enabled, condition-relevant effect is visible.
- All existing weather-effect toggles and visuals are unchanged.
