# Atmos 0.67.9 Build Compatibility Fix

- Removed an invalid `@Immutable` annotation from the top-level `AtmosphericSoundscapeEffect` composable.
- Scanned remaining `@Immutable` / `@Stable` annotations; all remaining uses target data classes or classes.
- Preserved Atmos Moments themed border, Dynamic Colour Temperature, and Atmospheric Soundscape behavior.
- Attempted `:app:compilePerformanceKotlin`; the local environment could not resolve `services.gradle.org`, so GitHub Actions remains the definitive compile check.
