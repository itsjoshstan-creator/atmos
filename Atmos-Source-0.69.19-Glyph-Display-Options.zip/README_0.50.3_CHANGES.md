# Atmos 0.50.3 changes

- Removed active cloud, precipitation, fog/haze, lightning, wind-layer, heat-shimmer and frost rendering.
- Retained solar lighting, seasonal colour and feels-like temperature grading.
- Retained seasonal particles as the only animated Atmos layer; particles default to off on fresh installs.
- Removed Atmos controls and the Atmos demo from Settings.
- Restored continuous Immersive swipe animation; particle simulation no longer pauses between location swipes.
- Existing weather-layer preferences are ignored by the lean renderer.
