# Atmos 0.40.3

- Retires the location-following weather appearance option and migrates existing users to Follow app appearance.
- Adds Ultra Atmos intensity (up to 650 active particles per scene).
- Reorganises Atmos settings into scene/lighting, weather layers, and particles/thermal effects.
- Adds persistent toggles for rain and snow, fog and haze, wind and breezes, and storm lightning.
- Slightly strengthens cloud visibility while retaining feathered radial-gradient edges.
- Strengthens rain, snow, and mist visibility and spawn density.
- Renders seasonal particles in the foreground and increases their wind/gust response.
- Preserves the shared native AtmosSceneRenderer integration and existing navigation/data features.
