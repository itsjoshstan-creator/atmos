# Atmos 0.50.5

## Rendering and performance
- Removed the native particle system, particle runtime, particle preferences, particle migration, spawning, sorting, wind integration, and particle drawing code.
- Replaced the remaining Atmos renderer with an event-driven gradient renderer.
- Removed the idle `withFrameNanos` loop completely.
- Solar state updates once per minute, aligned to the next minute boundary.
- Weather/location palette transitions are capped at approximately 30 fps for 900 ms, then the renderer becomes idle.
- The renderer now uses only solar lighting, seasonal colour, and feels-like temperature grading.

## Launch screen
- Moved the ATMOS title and tagline to the upper portion of the launch screen, above the sunrise artwork.
- Kept the loading status independently anchored near the bottom.

## Card style contrast
- Card-style Hero content now makes one light-or-dark foreground decision for the whole card.
- The location text, temperature, condition copy, page indicator, and Hero labels use that same contrast family rather than switching independently by vertical region.

## Removed UI and legacy code
- Removed the obsolete Atmos onboarding/demo code and particle preferences.
- Removed stale Atmos-system search entries and particle-focused About copy.
- Card-style Hero statistics now inherit the same foreground mode and adapt their backing surface accordingly.
