# Atmos 0.68.9

- Refined the Right Now humidity icon into a minimal fog-cloud glyph matching Wind and Rain.
- Condition-themed the selected Android navigation item.
- Redesigned the floating menu with rounded Atmos styling, border, spacing and a prominent shadow.
- Added optional gradient Hero typography for temperature, degree symbol and condition text.
- Added a compact Hero shadow matching the navigation layer depth.
