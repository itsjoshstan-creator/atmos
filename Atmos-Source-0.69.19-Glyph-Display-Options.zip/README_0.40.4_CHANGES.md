# Atmos 0.40.4

## Seasonal particle distribution

- Seasonal particles now spawn primarily across the full scene width.
- During a meaningful breeze, only a minority of new particles enter from the upwind edge.
- Calm conditions receive a small random horizontal drift so particles do not remain static.
- Seasonal particles gradually accelerate toward changing wind and gust conditions.
- Each scene is pre-populated with season-appropriate particles so the display is immediately distributed when opened.

Rain and snow continue to spawn from above.

## Particle visibility control

Settings now includes a dedicated **Particle visibility** slider from 45% to 200%.

The slider changes seasonal particle opacity and rendered size independently. It does not change overall Atmos intensity, particle population limits, clouds, precipitation, lighting, or thermal effects.

## Version

- Version name: 0.40.4
- Version code: 144
- GitHub Actions artifact: `Atmos-0.40.4-debug`
