# Atmos 0.41.1

## Performance mode
- Atmos modes are now Off, Performance, Immersive and Ultra.
- Performance disables the animated atmosphere gradient, clouds, precipitation, fog/haze, wind-driven weather motion, storm lightning and seasonal particles.
- Solar lighting, seasonal colour, feels-like temperature grading, heat shimmer, cold/frost and OLED late-night rendering remain enabled.
- Performance is selectable during onboarding and in Settings.
- Legacy Subtle and Balanced preferences migrate safely to Performance.

## Pager smoothness
- Removed the extra beyond-viewport forecast page from HorizontalPager.
- The settled page remains active until the gesture finishes.
- This prevents the page after the destination from entering composition during a swipe, which caused location 1 → 2 to stutter whenever a third saved location existed.
- Immersive background cross-fading remains handled by the dedicated preloaded Atmos compositor.
