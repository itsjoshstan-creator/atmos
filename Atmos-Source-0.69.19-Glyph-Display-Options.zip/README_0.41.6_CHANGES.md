# Atmos 0.41.6

- Dark mode at night now follows only the saved current-device location, never whichever saved location is being viewed.
- Removed the Atmos System stage from onboarding.
- First-run Atmos defaults to Ultra with all effects enabled except Clouds and Fog/Haze.
- First-run seasonal particle visibility is 200%.
- Removed all seeded saved locations; first-run persistence contains only the detected current location or the manually selected location.
- Onboarding personalisation now contains Device/Light/Dark appearance, Dark mode at night, and Card style/Immersive layout choices.
- Renamed Fullscreen Hero layout wording to Card style.
- Expanded the Atmos System demo with descriptive controls for every weather layer and particle visibility.
- Turning Atmos off in the demo now reveals the plain Atmos gradient artwork.
- OLED late-night colours are substantially darker and late-night overlays are attenuated to preserve near-black output.
- Increased feels-like temperature colour grading strength while keeping it static and performance-conscious.
