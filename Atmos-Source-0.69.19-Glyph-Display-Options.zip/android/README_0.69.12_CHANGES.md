# Atmos 0.69.12

## Nothing Glyph Matrix support

- Added an optional Atmos Weather Glyph Toy for the Nothing Phone (4a) Pro.
- Displays the current condition and temperature from the first saved Atmos location.
- Added compact 13×13 animations for sun, cloud, rain, snow, fog, storms and night.
- Added a direct Settings shortcut to the Nothing Glyph Toys manager.
- Kept the integration isolated so all non-Nothing Android devices remain unaffected.
