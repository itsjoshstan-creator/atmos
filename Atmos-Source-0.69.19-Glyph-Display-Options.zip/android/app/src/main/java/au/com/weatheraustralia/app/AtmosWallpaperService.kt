package au.com.weatheraustralia.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.util.Date

/**
 * Live wallpaper that displays a cached, completed snapshot of Atmos's immersive
 * scene. It does not recreate or alter the in-app renderer.
 */
class AtmosWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = AtmosWallpaperEngine()

    private inner class AtmosWallpaperEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private val rawPrefs by lazy { getSharedPreferences("atmos_native", MODE_PRIVATE) }
        private val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "weatherCache" || key == "savedPlaces" || key == "wallpaperWeatherVersion" || key == "wallpaperSnapshotVersion" ||
                key == "seasonalAtmosphere" || key == "temperatureAtmosphere" ||
                key == "wallpaperImmersiveBottomArgb") {
                drawFrame(forceSnapshot = key != "wallpaperSnapshotVersion")
            }
        }
        private val minuteTick = object : Runnable {
            override fun run() {
                if (!visible) return
                drawFrame(forceSnapshot = true)
                val now = System.currentTimeMillis()
                handler.postDelayed(this, 60_000L - now % 60_000L)
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            rawPrefs.registerOnSharedPreferenceChangeListener(listener)
        }

        override fun onDestroy() {
            handler.removeCallbacksAndMessages(null)
            rawPrefs.unregisterOnSharedPreferenceChangeListener(listener)
            super.onDestroy()
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(minuteTick)
            if (isVisible) {
                drawFrame(forceSnapshot = true)
                val now = System.currentTimeMillis()
                handler.postDelayed(minuteTick, 60_000L - now % 60_000L)
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            drawFrame(forceSnapshot = true)
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) {
            drawFrame(forceSnapshot = false)
        }

        private fun drawFrame(forceSnapshot: Boolean) {
            if (!surfaceHolder.surface.isValid) return
            val canvas = runCatching { surfaceHolder.lockCanvas() }.getOrNull() ?: return
            try {
                val displayWidth = resources.displayMetrics.widthPixels.coerceAtLeast(1)
                val displayHeight = resources.displayMetrics.heightPixels.coerceAtLeast(1)
                val bottom = rawPrefs.getInt("wallpaperImmersiveBottomArgb", Color.rgb(16, 24, 39))
                val weather = loadFirstWallpaperWeather(this@AtmosWallpaperService)
                val bitmap = when {
                    weather != null && forceSnapshot -> AtmosWallpaperSnapshotCache.getOrCreate(
                        context = this@AtmosWallpaperService,
                        weather = weather,
                        width = displayWidth,
                        height = displayHeight,
                        immersiveBottom = bottom,
                        now = Date()
                    )
                    else -> AtmosWallpaperSnapshotCache.load(this@AtmosWallpaperService)
                        ?: weather?.let {
                            AtmosWallpaperSnapshotCache.getOrCreate(
                                context = this@AtmosWallpaperService,
                                weather = it,
                                width = displayWidth,
                                height = displayHeight,
                                immersiveBottom = bottom,
                                now = Date()
                            )
                        }
                }
                if (bitmap != null) drawSnapshot(canvas, bitmap, displayHeight) else drawSafeColour(canvas)
            } finally {
                runCatching { surfaceHolder.unlockCanvasAndPost(canvas) }
            }
        }

        private fun drawSnapshot(canvas: Canvas, bitmap: Bitmap, visibleHeight: Int) {
            canvas.drawColor(Color.BLACK)
            val targetHeight = visibleHeight.coerceAtMost(canvas.height).coerceAtLeast(1)
            val destination = Rect(0, 0, canvas.width, targetHeight)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
            canvas.drawBitmap(bitmap, null, destination, paint)
            if (canvas.height > targetHeight) {
                val bottomColour = bitmap.getPixel(bitmap.width / 2, bitmap.height - 1)
                paint.color = bottomColour
                paint.style = Paint.Style.FILL
                canvas.drawRect(0f, targetHeight.toFloat(), canvas.width.toFloat(), canvas.height.toFloat(), paint)
            }
        }

        private fun drawSafeColour(canvas: Canvas) {
            canvas.drawColor(rawPrefs.getInt("wallpaperImmersiveBottomArgb", Color.rgb(16, 24, 39)))
        }
    }
}
