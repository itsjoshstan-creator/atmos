package au.com.weatheraustralia.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import java.util.Calendar;

public class AtmosSeasonsWidgetProvider extends AppWidgetProvider {
    @Override public void onEnabled(Context c){AtmosWidgetUpdater.schedule(c);AtmosWidgetUpdater.refresh(c,null);}
    @Override public void onDeleted(Context c,int[] ids){for(int id:ids)AtmosWidgetConfigActivity.delete(c,id);}
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)m.updateAppWidget(id,views(c,id));AtmosWidgetUpdater.schedule(c);AtmosWidgetUpdater.refresh(c,null);}
    static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);ComponentName n=new ComponentName(c,AtmosSeasonsWidgetProvider.class);for(int id:m.getAppWidgetIds(n))m.updateAppWidget(id,views(c,id));}
    private static RemoteViews views(Context c,int id){
        SharedPreferences p=c.getSharedPreferences("atmos_widget",Context.MODE_PRIVATE); RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_atmos_seasons);
        String season=AtmosWidgetStyle.season(); v.setTextViewText(R.id.widget_seasons_name,season.substring(0,1)+season.substring(1).toLowerCase());
        v.setTextViewText(R.id.widget_seasons_progress,seasonProgress()); v.setTextViewText(R.id.widget_seasons_temp,p.getString("temp","—")+"°"); v.setTextViewText(R.id.widget_seasons_location,p.getString("location","Open Atmos"));
        String symbol=season.equals("SUMMER")?"☀":season.equals("AUTUMN")?"◐":season.equals("WINTER")?"❄":"✦"; v.setTextViewText(R.id.widget_seasons_symbol,symbol);
        v.setOnClickPendingIntent(R.id.widget_seasons_root,AtmosWidgetProvider.openApp(c)); return v;
    }
    private static String seasonProgress(){Calendar now=Calendar.getInstance();int month=now.get(Calendar.MONTH)+1;int startMonth=(month==12||month<=2)?12:month<=5?3:month<=8?6:9;Calendar start=(Calendar)now.clone();start.set(Calendar.MONTH,startMonth-1);start.set(Calendar.DAY_OF_MONTH,1);if(start.after(now))start.add(Calendar.YEAR,-1);Calendar end=(Calendar)start.clone();end.add(Calendar.MONTH,3);long total=end.getTimeInMillis()-start.getTimeInMillis();long elapsed=now.getTimeInMillis()-start.getTimeInMillis();int pct=(int)Math.max(0,Math.min(100,Math.round(elapsed*100f/total)));return pct+"% through the season";}
}
