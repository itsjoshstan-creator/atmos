package au.com.weatheraustralia.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class AtmosWeeklyWidgetProvider extends AppWidgetProvider {
    @Override public void onEnabled(Context context) { AtmosWidgetUpdater.schedule(context); AtmosWidgetUpdater.refresh(context, null); }
    @Override public void onDeleted(Context context, int[] ids) { for (int id : ids) AtmosWidgetConfigActivity.delete(context, id); }
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) manager.updateAppWidget(id, views(context, id));
        AtmosWidgetUpdater.schedule(context); AtmosWidgetUpdater.refresh(context, null);
    }
    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, AtmosWeeklyWidgetProvider.class);
        for (int id : manager.getAppWidgetIds(name)) manager.updateAppWidget(id, views(context, id));
    }
    private static RemoteViews views(Context context, int id) {
        SharedPreferences p = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE);
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_atmos_weekly);
        v.setInt(R.id.widget_weekly_root, "setBackgroundResource", AtmosWidgetStyle.background(context, p, id));
        v.setImageViewResource(R.id.widget_weekly_icon, AtmosWidgetStyle.icon(p));
        v.setTextViewText(R.id.widget_weekly_temp, p.getString("temp", "—") + "°");
        v.setTextViewText(R.id.widget_weekly_condition, p.getString("condition", "Open Atmos"));
        v.setTextViewText(R.id.widget_weekly_meta, AtmosWidgetText.meta(p));
        v.setTextViewText(R.id.widget_weekly_season, "●  " + AtmosWidgetStyle.season());
        int[] names = {R.id.day_name_0,R.id.day_name_1,R.id.day_name_2,R.id.day_name_3,R.id.day_name_4,R.id.day_name_5,R.id.day_name_6};
        int[] icons = {R.id.day_icon_0,R.id.day_icon_1,R.id.day_icon_2,R.id.day_icon_3,R.id.day_icon_4,R.id.day_icon_5,R.id.day_icon_6};
        int[] ranges = {R.id.day_range_0,R.id.day_range_1,R.id.day_range_2,R.id.day_range_3,R.id.day_range_4,R.id.day_range_5,R.id.day_range_6};
        for (int i=0;i<7;i++) {
            v.setTextViewText(names[i], p.getString("day_name_"+i, i==0?"TODAY":"—"));
            SharedPreferences temp = context.getSharedPreferences("atmos_widget_day_"+i, Context.MODE_PRIVATE);
            String icon = p.getString("day_icon_"+i, "clear");
            temp.edit().putString("icon", icon).apply();
            v.setImageViewResource(icons[i], AtmosWidgetStyle.icon(temp));
            v.setTextViewText(ranges[i], p.getString("day_high_"+i,"—") + "°\n" + p.getString("day_low_"+i,"—") + "°");
        }
        v.setOnClickPendingIntent(R.id.widget_weekly_root, AtmosWidgetProvider.openApp(context));
        return v;
    }
}
