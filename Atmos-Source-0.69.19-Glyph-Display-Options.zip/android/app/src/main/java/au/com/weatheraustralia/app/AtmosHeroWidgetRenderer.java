package au.com.weatheraustralia.app;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

final class AtmosHeroWidgetRenderer {
    private AtmosHeroWidgetRenderer() {}

    static Bitmap render(Context context, AppWidgetManager manager, int id) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        Bundle o = manager.getAppWidgetOptions(id);
        int widthDp = Math.max(250, o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 320));
        int heightDp = Math.max(250, o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 330));
        int w = Math.max(1, Math.round(widthDp * dm.density));
        int h = Math.max(1, Math.round(heightDp * dm.density));
        // Keep RemoteViews bitmap memory sensible on very large launchers/tablets.
        float cap = Math.min(1f, 900f / Math.max(w, h));
        w = Math.max(1, Math.round(w * cap));
        h = Math.max(1, Math.round(h * cap));
        float d = w / (float) widthDp;

        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bitmap);
        c.drawColor(Color.TRANSPARENT);

        SharedPreferences p = context.getSharedPreferences("atmos_widget", Context.MODE_PRIVATE);
        String location = p.getString("location", "Open Atmos");
        String state = p.getString("state", "");
        String temp = p.getString("temp", "—");
        String condition = p.getString("condition", "Tap to load forecast");
        String feels = p.getString("feels", temp);
        String high = p.getString("high", "—");
        String low = p.getString("low", "—");
        String season = p.getString("season", AtmosWidgetStyle.season());
        String summary = p.getString("summary", condition + " conditions are expected today.");
        String zoneId = p.getString("time_zone", TimeZone.getDefault().getID());

        TimeZone zone;
        try { zone = TimeZone.getTimeZone(zoneId); } catch (Exception ignored) { zone = TimeZone.getDefault(); }
        Date now = new Date();
        SimpleDateFormat dateFmt = new SimpleDateFormat("EEEE d MMMM", Locale.getDefault());
        dateFmt.setTimeZone(zone);
        SimpleDateFormat timeFmt = new SimpleDateFormat("h:mm a", Locale.getDefault());
        timeFmt.setTimeZone(zone);

        int[] palette = paletteFor(AtmosWidgetStyle.kind(p));
        String intensity = p.getString("atmos_intensity", "Balanced");
        boolean useDarkText = p.getBoolean("use_dark_text", false);
        boolean gradientTypography = p.getBoolean("gradient_typography", false);
        int foreground = useDarkText ? Color.rgb(20, 32, 56) : Color.WHITE;
        int secondaryForeground = withAlpha(foreground, useDarkText ? 190 : 202);
        int tertiaryForeground = withAlpha(foreground, useDarkText ? 166 : 190);
        // Use a compact, even horizontal inset so the transparent hero fills the widget canvas.
        float x = 12f * d;
        float right = w - 12f * d;
        float y = 30f * d;

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));

        // Location title: same three-part weather-aware gradient treatment as the hero.
        paint.setTextSize(31f * d);
        paint.setLetterSpacing(-0.02f);
        float maxTitle = right - x;
        String fittedLocation = ellipsize(location, paint, maxTitle);
        float leftBlend = "Subtle".equals(intensity) ? .55f : ("Cinematic".equals(intensity) ? .20f : .32f);
        float rightBlend = "Subtle".equals(intensity) ? .66f : ("Cinematic".equals(intensity) ? .34f : .48f);
        paint.setShader(new LinearGradient(x, 0, x + Math.max(180f * d, paint.measureText(fittedLocation)), 0,
                new int[]{mix(palette[2], foreground, leftBlend), foreground, mix(palette[1], foreground, rightBlend)},
                null, Shader.TileMode.CLAMP));
        c.drawText(fittedLocation, x, y, paint);
        paint.setShader(null);

        y += 19f*d;
        paint.setShader(null); paint.setLetterSpacing(0); paint.setColor(tertiaryForeground);
        paint.setTextSize(14f*d); paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        c.drawText(state, x, y, paint);

        y += 25f*d;
        float seasonW = Math.max(92f*d, textWidth("●  " + season, 12f*d, true) + 28f*d);
        drawPill(c, x, y, seasonW, 34f*d, seasonBackground(season), seasonBorder(season), 18f*d);
        paint.setColor(seasonForeground(season)); paint.setTextSize(12f*d); paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        c.drawText("●  " + season, x + 14f*d, y + 22f*d, paint);
        float timeW = textWidth(timeFmt.format(now).toLowerCase(Locale.getDefault()), 12f*d, true) + 28f*d;
        drawPill(c, x + seasonW + 8f*d, y, timeW, 34f*d, withAlpha(foreground, 40), withAlpha(foreground, 85), 18f*d);
        paint.setColor(foreground); paint.setTextSize(12f*d); paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        c.drawText(timeFmt.format(now).toLowerCase(Locale.getDefault()), x + seasonW + 22f*d, y + 22f*d, paint);

        y += 58f*d;
        paint.setColor(secondaryForeground); paint.setTextSize(14f*d); paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        c.drawText(dateFmt.format(now), x, y, paint);

        y += 82f*d;
        paint.setColor(foreground); paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); paint.setLetterSpacing(-0.045f);
        paint.setTextSize(90f*d);
        if (gradientTypography) {
            paint.setShader(heroTypographyGradient(x, x + Math.max(150f*d, paint.measureText(temp) + 38f*d), palette, foreground, intensity));
        }
        c.drawText(temp, x, y, paint);
        float tempWidth = paint.measureText(temp);
        paint.setLetterSpacing(0); paint.setTextSize(34f*d);
        c.drawText("°", x + tempWidth + 1f*d, y - 43f*d, paint);
        paint.setShader(null);

        y += 38f*d;
        paint.setTextSize(30f*d); paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); paint.setColor(foreground);
        String fittedCondition = ellipsize(condition, paint, right-x);
        if (gradientTypography) {
            paint.setShader(heroTypographyGradient(x, x + Math.max(180f*d, paint.measureText(fittedCondition)), palette, foreground, intensity));
        }
        c.drawText(fittedCondition, x, y, paint);
        paint.setShader(null);

        y += 24f*d;
        paint.setTextSize(16f*d); paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); paint.setColor(withAlpha(foreground, 210));
        c.drawText("Feels like " + feels + "° · H " + high + "° · L " + low + "°", x, y, paint);

        y += 32f*d;
        paint.setTextSize(14f*d); paint.setColor(withAlpha(foreground, 214));
        float lineHeight = 20f*d;
        // Use nearly the full widget height for the forecast summary. The previous
        // 12dp bottom reserve often reduced a standard 4×4 widget to two visible
        // lines even when the launcher provided enough room for more.
        int maxLines = Math.max(1, Math.min(4, (int)((h - y - 2f*d) / lineHeight)));
        drawWrapped(c, summary, paint, x, y, right-x, lineHeight, maxLines);
        return bitmap;
    }

    private static Shader heroTypographyGradient(float startX, float endX, int[] palette, int foreground, String intensity) {
        float leftBlend = "Subtle".equals(intensity) ? .55f : ("Cinematic".equals(intensity) ? .20f : .32f);
        float rightBlend = "Subtle".equals(intensity) ? .66f : ("Cinematic".equals(intensity) ? .34f : .48f);
        return new LinearGradient(
                startX, 0, endX, 0,
                new int[]{mix(palette[2], foreground, leftBlend), foreground, mix(palette[1], foreground, rightBlend)},
                null, Shader.TileMode.CLAMP
        );
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private static int[] paletteFor(String kind) {
        switch (kind) {
            case "night": return new int[]{0xFF0B1638,0xFF35488D,0xFF9A73C8};
            case "storm": return new int[]{0xFF202A43,0xFF5B6480,0xFF9B84A7};
            case "rain": return new int[]{0xFF285A78,0xFF557C94,0xFF9CC7D7};
            case "cloudy": return new int[]{0xFF45677D,0xFF7C92A0,0xFFC5D0D6};
            case "fog": return new int[]{0xFF6C7B88,0xFF9AA6AE,0xFFD8DEE2};
            case "snow": return new int[]{0xFF6E9DB8,0xFFB5D7E8,0xFFEAF7FF};
            case "sunrise": return new int[]{0xFF6F61AF,0xFFE98D82,0xFFFFC879};
            case "sunset": return new int[]{0xFF5B4D98,0xFFD06A78,0xFFFFB26C};
            default: return new int[]{0xFF3C79AD,0xFF7FB8D8,0xFFF2C887};
        }
    }

    private static int mix(int a, int b, float f) {
        int r = Math.round(Color.red(a)*(1-f)+Color.red(b)*f);
        int g = Math.round(Color.green(a)*(1-f)+Color.green(b)*f);
        int bl = Math.round(Color.blue(a)*(1-f)+Color.blue(b)*f);
        return Color.rgb(r,g,bl);
    }
    private static int seasonBackground(String season) {
        String s=season.toLowerCase(Locale.ENGLISH);
        if(s.contains("winter")) return 0xDCE7F5FF; if(s.contains("autumn")) return 0xDCEFC7A0;
        if(s.contains("spring")) return 0xDCEFC5D9; return 0xDCE9D7A7;
    }
    private static int seasonForeground(String season) { return 0xFF253044; }
    private static int seasonBorder(String season) { return Color.argb(100,255,255,255); }
    private static float textWidth(String text,float size,boolean bold){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return p.measureText(text);}
    private static void drawPill(Canvas c,float x,float y,float w,float h,int fill,int border,float radius){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);RectF r=new RectF(x,y,x+w,y+h);p.setColor(fill);c.drawRoundRect(r,radius,radius,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1f,h/34f));p.setColor(border);c.drawRoundRect(r,radius,radius,p);}
    private static String ellipsize(String s,Paint p,float max){if(p.measureText(s)<=max)return s;String e="…";int n=s.length();while(n>0&&p.measureText(s.substring(0,n)+e)>max)n--;return s.substring(0,Math.max(0,n))+e;}
    private static void drawWrapped(Canvas c,String text,Paint p,float x,float y,float max,float lineHeight,int maxLines){String[] words=text.trim().split("\\s+");StringBuilder line=new StringBuilder();int lines=0;for(String word:words){String candidate=line.length()==0?word:line+" "+word;if(p.measureText(candidate)>max&&line.length()>0){lines++;String out=line.toString();if(lines==maxLines){out=ellipsize(out+" "+word,p,max);c.drawText(out,x,y,p);return;}c.drawText(out,x,y,p);y+=lineHeight;line=new StringBuilder(word);}else{line=new StringBuilder(candidate);}}if(line.length()>0&&lines<maxLines)c.drawText(line.toString(),x,y,p);}
}
