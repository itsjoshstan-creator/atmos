package au.com.weatheraustralia.app;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.os.Bundle;
import android.util.DisplayMetrics;
import java.text.SimpleDateFormat;
import java.util.*;

final class AtmosAdditionalWidgetRenderer {
    enum Type { RIGHT_NOW, MOMENTS, GLANCE }
    private AtmosAdditionalWidgetRenderer() {}

    static Bitmap render(Context context, AppWidgetManager manager, int id, Type type) {
        DisplayMetrics dm=context.getResources().getDisplayMetrics(); Bundle o=manager.getAppWidgetOptions(id);
        int defaultH=type==Type.RIGHT_NOW?210:type==Type.MOMENTS?310:145;
        int widthDp=Math.max(250,o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH,320));
        int heightDp=Math.max(defaultH,o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,defaultH));
        int w=Math.max(1,Math.round(widthDp*dm.density)), h=Math.max(1,Math.round(heightDp*dm.density));
        float cap=Math.min(1f,900f/Math.max(w,h)); w=Math.round(w*cap);h=Math.round(h*cap);float d=w/(float)widthDp;
        Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.drawColor(Color.TRANSPARENT);
        SharedPreferences p=context.getSharedPreferences("atmos_widget",Context.MODE_PRIVATE);
        boolean dark=p.getBoolean("use_dark_text",false); int fg=dark?Color.rgb(20,32,56):Color.WHITE;
        int secondary=alpha(fg,205), accent=accent(AtmosWidgetStyle.kind(p),dark);
        float x=12*d,right=w-12*d,y=28*d;
        Paint q=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);q.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        q.setColor(fg);q.setTextSize(25*d);c.drawText(title(type),x,y,q); y+=22*d;
        q.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));q.setTextSize(13*d);q.setColor(secondary);
        c.drawText(p.getString("location","Atmos"),x,y,q); y+=24*d;
        if(type==Type.RIGHT_NOW) drawRightNow(c,p,q,x,right,y,h,d,fg,secondary,accent);
        else if(type==Type.GLANCE) drawGlance(c,p,q,x,right,y,h,d,fg,secondary,accent);
        else drawMoments(c,p,q,x,right,y,h,d,fg,secondary,accent);
        return b;
    }
    private static String title(Type t){return t==Type.RIGHT_NOW?"Right now":t==Type.MOMENTS?"Atmos Moments":"Today at a glance";}
    private static void drawRightNow(Canvas c,SharedPreferences p,Paint q,float x,float right,float y,int h,float d,int fg,int sec,int accent){
        String[] values={p.getString("wind","—")+" km/h",p.getString("humidity","—")+"%",p.getString("rain","0")+"%"};
        String[] labels={"Wind","Humidity","Rain"}; float gap=10*d,cell=(right-x-gap*2)/3f;
        for(int i=0;i<3;i++){float cx=x+i*(cell+gap)+cell/2f; drawMetricIcon(c,q,cx,y+20*d,i,accent,d);q.setTextAlign(Paint.Align.CENTER);q.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));q.setTextSize(18*d);q.setColor(fg);c.drawText(values[i],cx,y+58*d,q);q.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));q.setTextSize(12*d);q.setColor(sec);c.drawText(labels[i],cx,y+78*d,q);}q.setTextAlign(Paint.Align.LEFT);
    }
    private static void drawMetricIcon(Canvas c,Paint p,float cx,float cy,int type,int color,float d){p.setColor(color);p.setStyle(Paint.Style.FILL);
        if(type==0){p.setStrokeWidth(3*d);p.setStyle(Paint.Style.STROKE);c.drawLine(cx-13*d,cy,cx+10*d,cy,p);c.drawLine(cx+10*d,cy,cx+3*d,cy-6*d,p);c.drawLine(cx+10*d,cy,cx+3*d,cy+6*d,p);}
        else if(type==1){c.drawCircle(cx-5*d,cy,7*d,p);c.drawCircle(cx+4*d,cy-3*d,9*d,p);c.drawRoundRect(cx-13*d,cy,cx+14*d,cy+8*d,5*d,5*d,p);p.setStrokeWidth(2*d);p.setStyle(Paint.Style.STROKE);c.drawLine(cx-11*d,cy+13*d,cx+10*d,cy+13*d,p);c.drawLine(cx-7*d,cy+18*d,cx+7*d,cy+18*d,p);}
        else {Path path=new Path();path.moveTo(cx,cy-15*d);path.cubicTo(cx-14*d,cy,cx-10*d,cy+14*d,cx,cy+15*d);path.cubicTo(cx+10*d,cy+14*d,cx+14*d,cy,cx,cy-15*d);c.drawPath(path,p);}p.setStyle(Paint.Style.FILL);
    }
    private static void drawGlance(Canvas c,SharedPreferences p,Paint q,float x,float right,float y,int h,float d,int fg,int sec,int accent){
        q.setColor(accent);q.setTextSize(31*d);q.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText(p.getString("condition","Current conditions"),x,y+26*d,q);
        q.setColor(sec);q.setTextSize(15*d);q.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));drawWrapped(c,p.getString("summary","Open Atmos for today's forecast."),q,x,y+54*d,right-x,20*d,2);
    }
    private static void drawMoments(Canvas c,SharedPreferences p,Paint q,float x,float right,float y,int h,float d,int fg,int sec,int accent){
        String sunrise=p.getString("sunrise","6:00 am"), sunset=p.getString("sunset","6:00 pm");
        String[] titles={daylightLabel(sunrise,sunset),"Best outdoor window","Today’s character"};
        String[] detail={daylightDetail(sunrise,sunset),"Around "+p.getString("hour_time_1","later today"),p.getString("condition","Current conditions")};
        for(int i=0;i<3;i++){float yy=y+i*65*d;q.setColor(accent);q.setStyle(Paint.Style.FILL);c.drawCircle(x+12*d,yy+13*d,10*d,q);q.setColor(fg);q.setTextSize(15*d);q.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText(titles[i],x+34*d,yy+10*d,q);q.setColor(sec);q.setTextSize(12*d);q.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText(ellipsize(detail[i],q,right-(x+34*d)),x+34*d,yy+30*d,q);}
    }
    private static String daylightLabel(String rise,String set){int now=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);return now>=6&&now<18?"Remaining daylight":"Until sunrise";}
    private static String daylightDetail(String rise,String set){return daylightLabel(rise,set).equals("Remaining daylight")?"Sunset at "+set:"Sunrise at "+rise;}
    private static int accent(String kind,boolean dark){int c;switch(kind){case"night":c=0xFFB8C8FF;break;case"storm":c=0xFFC2B6FF;break;case"rain":c=0xFF7ED7FF;break;case"fog":c=0xFFB9D5E6;break;case"sunset":c=0xFFFFB089;break;default:c=0xFFFFD27A;}return dark?mix(c,Color.rgb(25,45,75),.25f):c;}
    private static int mix(int a,int b,float f){return Color.rgb(Math.round(Color.red(a)*(1-f)+Color.red(b)*f),Math.round(Color.green(a)*(1-f)+Color.green(b)*f),Math.round(Color.blue(a)*(1-f)+Color.blue(b)*f));}
    private static int alpha(int c,int a){return Color.argb(a,Color.red(c),Color.green(c),Color.blue(c));}
    private static String ellipsize(String s,Paint p,float max){if(p.measureText(s)<=max)return s;while(s.length()>1&&p.measureText(s+"…")>max)s=s.substring(0,s.length()-1);return s+"…";}
    private static void drawWrapped(Canvas c,String text,Paint p,float x,float y,float max,float lh,int maxLines){String[] words=text.split("\\s+");String line="";int n=0;for(String word:words){String test=line.isEmpty()?word:line+" "+word;if(p.measureText(test)>max&&!line.isEmpty()){c.drawText(n==maxLines-1?ellipsize(line+" "+word,p,max):line,x,y,p);if(++n>=maxLines)return;y+=lh;line=word;}else line=test;}if(n<maxLines)c.drawText(line,x,y,p);}
}
