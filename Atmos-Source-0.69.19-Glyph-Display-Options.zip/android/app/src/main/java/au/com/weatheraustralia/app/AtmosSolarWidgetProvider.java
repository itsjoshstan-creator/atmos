package au.com.weatheraustralia.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import java.util.Calendar;

public class AtmosSolarWidgetProvider extends AppWidgetProvider {
    @Override public void onEnabled(Context c){AtmosWidgetUpdater.schedule(c);AtmosWidgetUpdater.refresh(c,null);}
    @Override public void onDeleted(Context c,int[] ids){for(int id:ids)AtmosWidgetConfigActivity.delete(c,id);}
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)m.updateAppWidget(id,views(c,id));AtmosWidgetUpdater.schedule(c);AtmosWidgetUpdater.refresh(c,null);}
    static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);ComponentName n=new ComponentName(c,AtmosSolarWidgetProvider.class);for(int id:m.getAppWidgetIds(n))m.updateAppWidget(id,views(c,id));}
    private static RemoteViews views(Context c,int id){SharedPreferences p=c.getSharedPreferences("atmos_widget",Context.MODE_PRIVATE);RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_atmos_solar);String sunrise=p.getString("sunrise","6:00 am"),sunset=p.getString("sunset","6:00 pm");int hour=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);boolean day=hour>=6&&hour<18;v.setTextViewText(R.id.widget_solar_location,p.getString("location","Atmos"));v.setTextViewText(R.id.widget_solar_status,day?"Daylight":"Night sky");v.setTextViewText(R.id.widget_solar_next,day?"Sunset is the next solar event":"Sunrise is the next solar event");v.setTextViewText(R.id.widget_solar_sunrise,sunrise);v.setTextViewText(R.id.widget_solar_sunset,sunset);v.setOnClickPendingIntent(R.id.widget_solar_root,AtmosWidgetProvider.openApp(c));return v;}
}
