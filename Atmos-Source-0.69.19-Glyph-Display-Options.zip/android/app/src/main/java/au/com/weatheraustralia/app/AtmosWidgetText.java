package au.com.weatheraustralia.app;

import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class AtmosWidgetText {
    private AtmosWidgetText() {}
    static String updated(SharedPreferences p) {
        long value = p.getLong("updated_at", 0L);
        if (value == 0L) return "Not updated yet";
        return "Updated " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date(value));
    }
    static String meta(SharedPreferences p) {
        return p.getString("location", "Open Atmos") + "  ·  " + updated(p);
    }
}
