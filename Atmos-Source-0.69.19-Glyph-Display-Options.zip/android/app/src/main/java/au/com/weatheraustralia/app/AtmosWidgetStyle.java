package au.com.weatheraustralia.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Calendar;

final class AtmosWidgetStyle {
    private AtmosWidgetStyle() {}

    static String kind(SharedPreferences p) {
        String value = (p.getString("icon", "clear") + " " + p.getString("condition", "")).toLowerCase();
        if (value.contains("storm") || value.contains("thunder")) return "storm";
        if (value.contains("snow") || value.contains("sleet") || value.contains("frost")) return "snow";
        if (value.contains("rain") || value.contains("shower") || value.contains("drizzle")) return "rain";
        if (value.contains("fog") || value.contains("mist") || value.contains("haze")) return "fog";
        if (value.contains("sunrise") || value.contains("dawn")) return "sunrise";
        if (value.contains("sunset") || value.contains("dusk")) return "sunset";
        if (value.contains("cloud") || value.contains("overcast")) return "cloudy";
        if (value.contains("night")) return "night";
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 6 || hour >= 18) return "night";
        return "sunny";
    }

    static int background(Context context, SharedPreferences p, int appWidgetId) {
        if (AtmosWidgetConfigActivity.isTransparent(context, appWidgetId)) return R.drawable.widget_bg_transparent;
        switch (kind(p)) {
            case "storm": return R.drawable.widget_bg_storm;
            case "snow": return R.drawable.widget_bg_snow;
            case "rain": return R.drawable.widget_bg_rain;
            case "fog": return R.drawable.widget_bg_fog;
            case "sunrise": return R.drawable.widget_bg_sunrise;
            case "sunset": return R.drawable.widget_bg_sunset;
            case "cloudy": return R.drawable.widget_bg_cloudy;
            case "night": return R.drawable.widget_bg_night;
            default: return R.drawable.widget_bg_sunny;
        }
    }

    static int icon(SharedPreferences p) {
        switch (kind(p)) {
            case "storm": return R.drawable.ic_weather_storm;
            case "rain": return R.drawable.ic_weather_rain;
            case "snow":
            case "fog":
            case "cloudy": return R.drawable.ic_weather_cloudy;
            case "night": return R.drawable.ic_weather_night;
            default: return R.drawable.ic_weather_sunny;
        }
    }

    static String season() {
        int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
        if (month == 12 || month <= 2) return "SUMMER";
        if (month <= 5) return "AUTUMN";
        if (month <= 8) return "WINTER";
        return "SPRING";
    }
}
