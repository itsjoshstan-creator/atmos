package au.com.weatheraustralia.app;
import android.appwidget.*;import android.content.*;import android.os.Bundle;import android.widget.RemoteViews;
public class AtmosMomentsWidgetProvider extends AppWidgetProvider {
 @Override public void onEnabled(Context c){AtmosWidgetUpdater.schedule(c);AtmosWidgetUpdater.refresh(c,null);}
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);AtmosWidgetUpdater.schedule(c);AtmosWidgetUpdater.refresh(c,null);}
 @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle o){update(c,m,id);}
 static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);ComponentName n=new ComponentName(c,AtmosMomentsWidgetProvider.class);for(int id:m.getAppWidgetIds(n))update(c,m,id);}
 private static void update(Context c,AppWidgetManager m,int id){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_atmos_moments);v.setImageViewBitmap(R.id.widget_image,AtmosAdditionalWidgetRenderer.render(c,m,id,AtmosAdditionalWidgetRenderer.Type.MOMENTS));v.setOnClickPendingIntent(R.id.widget_root,AtmosWidgetProvider.openApp(c));m.updateAppWidget(id,v);}
}
