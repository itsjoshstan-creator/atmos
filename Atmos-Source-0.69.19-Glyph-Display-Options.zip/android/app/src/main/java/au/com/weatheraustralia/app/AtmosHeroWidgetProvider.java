package au.com.weatheraustralia.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RemoteViews;

/** Transparent 4x4 widget mirroring the information hierarchy of the immersive hero. */
public class AtmosHeroWidgetProvider extends AppWidgetProvider {
    @Override public void onEnabled(Context context) {
        AtmosWidgetUpdater.schedule(context);
        AtmosWidgetUpdater.refresh(context, null);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (AtmosWidgetUpdater.ACTION_REFRESH.equals(intent.getAction())) {
            AtmosWidgetUpdater.refresh(context, goAsync());
        }
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
        AtmosWidgetUpdater.schedule(context);
        AtmosWidgetUpdater.refresh(context, null);
    }

    @Override public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int id, Bundle options) {
        update(context, manager, id);
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, AtmosHeroWidgetProvider.class);
        for (int id : manager.getAppWidgetIds(name)) update(context, manager, id);
    }

    private static void update(Context context, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_atmos_hero);
        views.setImageViewBitmap(R.id.widget_hero_image, AtmosHeroWidgetRenderer.render(context, manager, id));
        views.setOnClickPendingIntent(R.id.widget_hero_root, AtmosWidgetProvider.openApp(context));
        manager.updateAppWidget(id, views);
    }
}
