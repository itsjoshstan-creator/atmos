package au.com.weatheraustralia.app;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class AtmosWidgetConfigActivity extends Activity {
    private static final String PREFS = "atmos_widget_styles";
    private static final String PREFIX = "transparent_";
    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setResult(RESULT_CANCELED);
        appWidgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }

        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFF101724);

        TextView title = new TextView(this);
        title.setText("Atmos widget background");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(22);
        title.setPadding(0, 0, 0, pad / 2);
        root.addView(title);

        TextView detail = new TextView(this);
        detail.setText("Choose the matching Atmos weather gradient or a completely transparent widget with no background or border.");
        detail.setTextColor(0xFFCAD5E7);
        detail.setTextSize(14);
        detail.setPadding(0, 0, 0, pad);
        root.addView(detail);

        RadioGroup group = new RadioGroup(this);
        RadioButton gradient = new RadioButton(this);
        gradient.setText("Atmos weather gradient");
        gradient.setTextColor(0xFFFFFFFF);
        gradient.setId(View.generateViewId());
        RadioButton transparent = new RadioButton(this);
        transparent.setText("Transparent");
        transparent.setTextColor(0xFFFFFFFF);
        transparent.setId(View.generateViewId());
        group.addView(gradient);
        group.addView(transparent);
        group.check(isTransparent(this, appWidgetId) ? transparent.getId() : gradient.getId());
        root.addView(group);

        Button save = new Button(this);
        save.setText("Add widget");
        save.setOnClickListener(v -> {
            boolean useTransparent = group.getCheckedRadioButtonId() == transparent.getId();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(PREFIX + appWidgetId, useTransparent).apply();
            AtmosWidgetProvider.updateAll(this);
            AtmosWideWidgetProvider.updateAll(this);
            AtmosGlanceWidgetProvider.updateAll(this);
            AtmosWeeklyWidgetProvider.updateAll(this);
            Intent result = new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            setResult(RESULT_OK, result);
            finish();
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.topMargin = pad;
        root.addView(save, bp);
        setContentView(root);
    }

    static boolean isTransparent(Context context, int id) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(PREFIX + id, false);
    }

    static void delete(Context context, int id) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(PREFIX + id).apply();
    }
}
