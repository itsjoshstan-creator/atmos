# Atmos 0.69.13

- Fixed Glyph Matrix detection on the Nothing Phone (4a) Pro.
- Fixed the Glyph Toy service binder so Nothing OS can deliver toy events.
- Added correct `EVENT_AOD` handling for the Phone (4a) Pro's AOD-only Glyph Matrix.
- Removed app-mode Matrix calls from the Glyph Toy service.
- Renders an initial weather frame immediately after the SDK connects.
