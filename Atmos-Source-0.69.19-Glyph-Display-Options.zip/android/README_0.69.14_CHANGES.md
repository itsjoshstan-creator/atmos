# Atmos 0.69.14

- Replaced the incompatible raw 13×13 integer-array Glyph call with Nothing's structured GlyphMatrixObject and GlyphMatrixFrame API.
- Improved Phone (4a) Pro detection using the SDK matrix length where available, with a Nothing-device fallback.
- Added clearer Glyph service logging for connection, registration and frame rendering failures.
- Retains AOD Glyph Toy event handling introduced in 0.69.13.
