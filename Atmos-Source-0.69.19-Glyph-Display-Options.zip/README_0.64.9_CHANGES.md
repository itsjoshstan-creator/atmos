# Atmos 0.64.9 — Shared Scene Renderer

- Extracted the complete visual Atmos scene into `SharedAtmosSceneRenderer`.
- The in-app hero and live wallpaper now draw through the same renderer.
- Removed all wallpaper-specific gradient, glare, moon, star, pressure, humidity, thermal and seasonal approximation code.
- Wallpaper weather is loaded through `AtmosPreferences` and the same `WeatherState` parser used by the app.
- Wallpaper uses the first saved location and the exact same palette pipeline as the hero.
- Added the immersive lower darkening pass to the shared wallpaper output.
- Added a safe shared-renderer fallback so the surface cannot remain black.
