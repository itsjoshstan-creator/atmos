# Atmos 0.50.9

- Compact hero height now uses the actual rendered condition-description line count, preventing long descriptive text from being covered.
- Added extra Compact baseline space for narrow screens and longer conditions.
- Android status-bar icon contrast now follows the same light/dark foreground decision as the current-condition text.
- Southern and Northern Hemisphere season sections now independently highlight their current season from the current calendar date.
- Wet/dry highlighting remains location-specific and appears only for tropical user locations.
