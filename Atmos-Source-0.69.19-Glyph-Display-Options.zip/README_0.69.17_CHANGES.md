# Atmos 0.69.17

- Replaced the reflective Nothing SDK integration with direct native SDK calls.
- Uses the official GlyphMatrixManager.Callback implementation instead of Java Proxy.
- Registers DEVICE_25111p after the Nothing service connects.
- Sends a structured 13x13 GlyphMatrixFrame.
- Added detailed AtmosGlyph log messages for service binding, SDK connection, registration and frame delivery.
