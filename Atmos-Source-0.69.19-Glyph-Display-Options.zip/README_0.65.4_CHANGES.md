# Atmos 0.65.4

- Reduced the transparent hero widget left and right content insets so it uses more of the available 4×4 canvas.
- Expanded the location title and forecast summary width accordingly.
- Removed the LIVE pill from the widget only.
- Preserved the in-app hero, live wallpaper, typography, pills, gradients, and tap-to-open behaviour.
