# Atmos 0.50.12 changes

## Forecast page handle

- Moved the location pager handle out of the current-conditions hero and into the forecast card stack.
- The handle now sits consistently immediately above **Today at a glance** on every location page.
- Uses the same vertical spacing rhythm as the cards below it.
- Removed the hero-owned flexible clearance that allowed the handle to drift or disappear on different description lengths.
- The selected and unselected markers now use the current condition palette's top-gradient colour.
- Compact hero height was reduced by the space previously reserved for the embedded handle, preserving the existing position of the forecast cards.

## Build

- Version code: `212`
- Version name: `0.50.12`
- GitHub Actions artifact: `Atmos-0.50.12-debug`
