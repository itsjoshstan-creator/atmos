# Atmos 0.60.1

## Atmos Display

- Added an optional Atmos Display mode for Expanded forecasts.
- Keeps the screen awake for a user-selected duration: 15 minutes, 30 minutes, 1 hour or 2 hours.
- Hides the Android status bar and navigation bar while active.
- After 10 seconds without interaction, gently fades the temperature/precipitation chart, condition narrative, rain/wind/humidity panel, forecast page indicator, Home button and floating menu.
- A tap restores the faded interface and restarts the inactivity timer.
- Weather data refreshes every 10 minutes while Atmos Display is active.
- The existing minute-driven solar palette continues to progress between network refreshes.
- Atmos Display only operates in Expanded density and exits when its duration ends or the user leaves the forecast screen.
