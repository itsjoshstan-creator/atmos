# Atmos 0.40.8

- Rebuilt the animated sky into a more visible Living Atmosphere Gradient.
- Added stronger independent movement for upper, middle, and lower colour fields.
- Added weather-specific motion: storms and rain move more actively, fog remains slower and diffuse.
- Wind speed, direction, and gust spread now influence gradient travel.
- Increased slow colour breathing and colour exchange between atmospheric bands.
- Added a broad translucent flow field and subtle turbulence field with separate timing.
- Preserved a fully static weather palette when Animated atmosphere gradient is disabled.
- Clouds, precipitation, haze, particles, solar lighting, and thermal effects remain independently controlled.
