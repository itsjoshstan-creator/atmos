# Atmos 0.68.0 — The Living Atmosphere

Built from the corrected Atmos 0.67.9 source.

## Atmos Stories
- Replaces the generic descriptive text on the main Hero with a forecast-driven daily story.
- Stories analyse the upcoming hourly forecast, including temperature trend, rain timing, wind, humidity and condition evolution.
- Stories use the selected location's local time.
- Hero timeline scrubbing regenerates the story around the selected forecast time.
- Falls back to the existing local forecast summary when hourly data is unavailable.

## Living Atmosphere
- Adds a continuous, blended presentation layer that makes the settled Atmos scene visibly evolve between weather updates.
- Slowly modulates colour temperature, brightness, atmospheric depth and broad light movement.
- Uses independent long cycles so the movement does not form an obvious short loop.
- Does not alter forecast data or create abrupt static scene changes.
- Uses lightweight Compose gradients over the existing shared renderer rather than generating a second scene.

## Settings
Added under Settings > Weather experience > Living atmosphere:
- Off
- Subtle
- Standard (default)
- Enhanced

## Performance
- Living-only motion runs at 8 fps with continuous blended movement.
- Existing high-motion weather effects retain their existing 30/60 fps behaviour.
- Disabling Living Atmosphere returns the scene to the existing event-driven behaviour.

## Version
- Version name: 0.68.0
- Version code: 380
