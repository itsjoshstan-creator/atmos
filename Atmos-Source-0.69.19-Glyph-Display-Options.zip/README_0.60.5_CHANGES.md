# Atmos 0.60.5

## Persistent current-weather notification

- Added an opt-in persistent notification for the first saved location.
- Displays current temperature, today’s high and low, and a brief forecast description.
- Renders the current temperature as the status-bar notification icon.
- Supports Celsius and Fahrenheit using the app’s existing temperature setting.
- Updates from the existing foreground and WorkManager weather refresh paths.
- Restores the cached notification after reboot or app replacement.
- Added Android 13+ notification permission handling in Settings.

## Version

- versionName: 0.60.5
- versionCode: 305
