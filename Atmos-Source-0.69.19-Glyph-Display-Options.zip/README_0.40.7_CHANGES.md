# Atmos 0.40.7

- Seasonal particle visibility now defaults to 150%, including a one-time migration from the former 100% default.
- Seasonal particles are slightly larger while retaining the subtle, non-near-camera rendering introduced in 0.40.6.
- Fog and haze now use layered radial falloff and feathered mist particles with no visible hard boundaries.
- Weather appearance controls were removed from Settings and onboarding. Follow Device, Light and Dark now apply consistently to the whole app.
- Atmos onboarding was simplified: individual effect toggles were removed and users are directed to Settings for fine tuning.
