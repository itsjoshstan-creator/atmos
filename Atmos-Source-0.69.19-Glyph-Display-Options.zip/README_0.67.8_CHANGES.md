# Atmos 0.67.8

## Atmos Moments
- Adds a new forecast card that identifies up to three meaningful windows in the next 24 hours.
- Moments can include golden light, first light, the best outdoor window, approaching rain or storms, and the warmest point of the day.
- Uses each location's local time and real hourly forecast.
- Tapping the card opens Atmos Timeline for deeper exploration.

## Living Clouds
- Adds a new default-on Living Clouds effect under Settings > Weather experience > Weather effects.
- Uses a few enormous, slowly drifting cloud-light volumes rather than decorative cloud sprites.
- Cloud presence is driven by current condition and humidity.
- Shapes contrast, depth, and god-ray lighting while retaining the premium Atmos aesthetic.
- Runs at only 4 fps when it is the sole active effect and uses no runtime blur filters.

## Build
- Version name 0.67.8
- Version code 378
- Based on 0.67.7
