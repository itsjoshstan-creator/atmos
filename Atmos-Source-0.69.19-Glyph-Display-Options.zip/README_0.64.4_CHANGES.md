# Atmos 0.64.4 — Unified Atmos Lighting

- Built from the 0.64.3 Solar Glare / 0.64.0 Performance architecture.
- Added one unified event-driven environmental lighting pass.
- Seasonal sunlight now adjusts solar arc height, colour, intensity, and golden-hour diffusion.
- Humidity and inferred visibility now alter atmospheric softness, horizon haze, bloom, and clarity.
- Pressure now subtly changes sky depth, brightness, and visual weight.
- Added diffuse moonlight based on an on-device lunar phase approximation, without a visible moon disc.
- Added deterministic static stars that respond to darkness, cloud conditions, humidity/visibility, and moon brightness.
- Added broad cloud-shadow lighting modulation without drawing literal clouds or adding an idle animation loop.
- Corrected Wet season / Dry season tint matching.
- All effects remain bounded and composited into the existing Atmos gradient to preserve visual cohesion.
- No continuous render loop was added; the scene remains minute/event driven.
