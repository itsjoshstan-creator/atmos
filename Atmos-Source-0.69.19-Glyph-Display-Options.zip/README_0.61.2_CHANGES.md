# Atmos 0.61.2

## About Atmos
- Rewrote “The Atmos System” to describe the current native rebuild, coordinated cache/update pipeline, location-aware solar system, weather-driven atmosphere, layouts, widgets and persistent notification.

## Expanded layout gestures
- Added a bottom touch guard in Expanded layout so Android’s swipe-up home gesture does not also drag the Atmos forecast page by a few pixels.

## Solar details
- Removed hard-coded sunrise and sunset values from the Weather Details card.
- Sunrise and sunset are now calculated and formatted independently from each selected location’s latitude, longitude and time zone.
- Added a safe polar-day/polar-night fallback.

## Seasons
- Removed navigation to individual season detail pages.
- Season pills and navigation now lead to the single main Seasons page.
- Season information remains presented together on that page.

## Compact layout
- Reduced the gap between the atmospheric hero content and descriptive forecast text to a single compact text-line buffer.

## Adaptive contrast
- Rechecked hero, detail-card, chart and solar content foregrounds.
- Detail glyphs now choose a high-contrast foreground against their themed icon surface.
- Season status badges now use contrast-aware text.
- Existing atmosphere-aware chart and hero contrast resolution remains active across light, dark and OLED backgrounds.

## Version
- Version name: 0.61.2
- Version code: 312
