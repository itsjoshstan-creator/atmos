# Atmos 0.69.9

- Rain now activates from current measured precipitation as well as rain, shower, drizzle and storm conditions.
- Current precipitation is separated from accumulated rainfall, preventing old rainfall totals from exaggerating the live effect.
- Rain intensity prioritises current precipitation and uses forecast probability only as a small supporting signal.
- Rain angle now follows numeric wind bearing where available, with wind speed controlling the slant.
- Added smooth rain fade-in, fade-out and intensity transitions.
- Added lightweight foreground/background rain depth and subtle storm variability.
- Updated the in-app changelog.
