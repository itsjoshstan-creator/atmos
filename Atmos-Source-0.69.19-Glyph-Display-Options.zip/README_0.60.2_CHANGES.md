# Atmos 0.60.2

## Build correction

- Fixed the Atmos Display pointer-input compilation failure.
- Removed the invalid standalone `awaitPointerEventScope` import. The API is provided by the active `PointerInputScope` inside `pointerInput`, so the existing call remains valid without that import.
- Preserved all Atmos Display behaviour introduced in 0.60.1.
- Updated Android version metadata and the GitHub Actions artifact name.
