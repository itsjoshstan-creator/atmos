# Atmos 0.68.8

- Strengthened the upward navigation shadow so the menu reads more clearly above app content.
- Refreshed Weather Details cards with vibrant Atmos colours, stronger borders, and subtle colour-filled surfaces.
- Added Remaining daylight / Until sunrise as the first Atmos Moment.
- Restyled the floating Atmos menu as a circular control matching the condition-tinted navigation.
