# Atmos 0.69.1

- Brightened condition-themed card icons and highlighted text for dark weather and night scenes.
- Right Now icons now use a lighter adaptive condition accent after dark.
- Atmos Moments icons, Timeline emphasis and highlighted times remain legible in dark conditions.
- Existing daytime condition colouring is unchanged.
