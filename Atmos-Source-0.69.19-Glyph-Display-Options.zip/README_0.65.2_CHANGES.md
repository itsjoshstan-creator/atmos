# Atmos 0.65.2 — Wallpaper Snapshot

- Rebased exactly on 0.65.0.
- The in-app Atmos renderer and immersive dark gradient are unchanged.
- Live wallpaper now displays a cached full-screen snapshot of the completed immersive Atmos scene.
- The snapshot bakes in the exact 0.65.0 lower darkening overlay before Android receives it.
- Wallpaper surface size, launcher zoom, or extended canvas height can no longer move the dark section off-screen.
- Snapshot refreshes when weather, the first saved location, display size, theme background, or solar minute changes.
- No text or UI is included.
