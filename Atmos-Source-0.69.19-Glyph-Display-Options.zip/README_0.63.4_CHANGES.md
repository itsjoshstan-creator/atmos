# Atmos 0.63.4

- Expanded Dual atmosphere cards with a compact season pill.
- Added each location's local time to Dual atmosphere cards.
- Added the same intelligent current-condition description used by the full hero, shortened to fit the compact panel.
- Preserved the fixed, vertically non-scrollable two-card layout.
- Updated the Settings Dual atmosphere illustration to clearly show two stacked weather panels with independent condition context.
