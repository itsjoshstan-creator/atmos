# Atmos 0.41.4

## Build fix

- Fixed a Kotlin null-safety compilation error in the saved-location atmosphere preview.
- The preview now safely handles locations whose `WeatherState` has not loaded yet when selecting observation and forecast-condition data for its solar-aware palette.
- Updated Android version metadata and the GitHub Actions artifact name to 0.41.4.
