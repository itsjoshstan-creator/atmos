# Atmos 0.69.40

- Added a new stacked Clock Glyph as the first display option.
- Hours are shown on the upper row and minutes on the lower row.
- Added 12-hour and 24-hour format choices.
- In 12-hour mode, a single hour digit is centred.
- In 24-hour mode, the leading zero is retained.
- Added Clock to the user-selectable Auto Glyph Rotation list.
- Existing Glyph displays, timing and Nothing SDK integration are unchanged.
