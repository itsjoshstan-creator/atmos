package au.com.weatheraustralia.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import kotlin.math.roundToInt

/**
 * Optional Nothing Glyph Matrix weather toy.
 *
 * Uses Nothing's native SDK only inside this optional service. Runtime device guards keep
 * the rest of Atmos compatible with other Android devices.
 */
class AtmosGlyphWeatherService : Service(), android.content.SharedPreferences.OnSharedPreferenceChangeListener {
    private var manager: com.nothing.ketchum.GlyphMatrixManager? = null
    private var frameIndex = 0
    private var isBoundToToy = false
    private var autoRotationIndex = 0
    private var rotationScheduled = false
    private val glyphPreferences by lazy { getSharedPreferences("atmos_glyph", Context.MODE_PRIVATE) }

    private val animationRunnable = object : Runnable {
        override fun run() {
            renderNextFrame(fromAnimationLoop = true)
        }
    }

    private val rotationRunnable = object : Runnable {
        override fun run() {
            rotationScheduled = false
            if (!isBoundToToy || readGlyphSettings().mode != "auto_rotation") return
            val modes = autoRotationModes(readWeather())
            autoRotationIndex = (autoRotationIndex + 1) % modes.size
            frameIndex = 0
            serviceHandler.removeCallbacks(animationRunnable)
            renderNextFrame()
        }
    }

    private val serviceHandler = object : android.os.Handler(android.os.Looper.getMainLooper()) {
        override fun handleMessage(msg: android.os.Message) {
            if (msg.what == com.nothing.ketchum.GlyphToy.MSG_GLYPH_TOY) {
                val event = msg.data?.getString(com.nothing.ketchum.GlyphToy.MSG_GLYPH_TOY_DATA)
                Log.i(TAG, "Glyph Toy event received: $event")
                if (event == com.nothing.ketchum.GlyphToy.EVENT_AOD ||
                    event == com.nothing.ketchum.GlyphToy.EVENT_CHANGE
                ) {
                    renderNextFrame()
                }
                return
            }
            super.handleMessage(msg)
        }
    }
    private val serviceMessenger = android.os.Messenger(serviceHandler)

    override fun onCreate() {
        super.onCreate()
        glyphPreferences.registerOnSharedPreferenceChangeListener(this)
        Log.i(TAG, "Atmos Glyph Toy service created")
    }

    override fun onBind(intent: Intent?): IBinder {
        Log.i(TAG, "Atmos Glyph Toy service bound: ${intent?.action}")
        isBoundToToy = true
        autoRotationIndex = 0
        rotationScheduled = false
        startGlyph()
        return serviceMessenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Log.i(TAG, "Atmos Glyph Toy service unbound")
        isBoundToToy = false
        serviceHandler.removeCallbacks(animationRunnable)
        serviceHandler.removeCallbacks(rotationRunnable)
        rotationScheduled = false
        stopGlyph()
        return false
    }

    override fun onDestroy() {
        Log.i(TAG, "Atmos Glyph Toy service destroyed")
        glyphPreferences.unregisterOnSharedPreferenceChangeListener(this)
        isBoundToToy = false
        serviceHandler.removeCallbacks(animationRunnable)
        serviceHandler.removeCallbacks(rotationRunnable)
        rotationScheduled = false
        stopGlyph()
        super.onDestroy()
    }

    override fun onSharedPreferenceChanged(sharedPreferences: android.content.SharedPreferences?, key: String?) {
        if (!isBoundToToy || manager == null) return
        Log.i(TAG, "Glyph setting changed: $key; redrawing immediately")
        frameIndex = 0
        autoRotationIndex = 0
        rotationScheduled = false
        serviceHandler.removeCallbacks(animationRunnable)
        serviceHandler.removeCallbacks(rotationRunnable)
        serviceHandler.post { renderNextFrame() }
    }

    private fun startGlyph() {
        if (manager != null) return
        runCatching {
            val glyphManager = com.nothing.ketchum.GlyphMatrixManager.getInstance(applicationContext)
            manager = glyphManager
            glyphManager.init(object : com.nothing.ketchum.GlyphMatrixManager.Callback {
                override fun onServiceConnected(componentName: android.content.ComponentName) {
                    Log.i(TAG, "Nothing Glyph Matrix service connected: $componentName")
                    runCatching {
                        glyphManager.register(com.nothing.ketchum.Glyph.DEVICE_25111p)
                        Log.i(TAG, "Registered Phone (4a) Pro Glyph target")
                        renderNextFrame()
                    }.onFailure { Log.e(TAG, "Unable to register Glyph Matrix target", it) }
                }

                override fun onServiceDisconnected(componentName: android.content.ComponentName) {
                    Log.w(TAG, "Nothing Glyph Matrix service disconnected: $componentName")
                }
            })
        }.onFailure {
            manager = null
            Log.e(TAG, "Unable to initialise Nothing Glyph Matrix SDK", it)
        }
    }

    private fun renderNextFrame(fromAnimationLoop: Boolean = false) {
        serviceHandler.removeCallbacks(animationRunnable)
        val glyphManager = manager ?: run {
            Log.w(TAG, "Frame requested before Glyph manager was ready")
            return
        }
        val weather = readWeather()
        val settings = readGlyphSettings()
        val effectiveSettings = if (settings.mode == "auto_rotation") {
            val modes = autoRotationModes(weather)
            autoRotationIndex = autoRotationIndex.mod(modes.size)
            settings.copy(mode = modes[autoRotationIndex])
        } else {
            settings
        }
        val frames = AtmosGlyphFrames.frames(weather, effectiveSettings, System.currentTimeMillis())
        val pixels = frames[frameIndex.mod(frames.size)]
        if (settings.animatedSymbols && frames.size > 1) frameIndex++ else frameIndex = 0

        runCatching {
            val bitmapPixels = IntArray(pixels.size) { index ->
                val level = pixels[index].coerceIn(0, 255)
                android.graphics.Color.argb(255, level, level, level)
            }
            val bitmap = android.graphics.Bitmap.createBitmap(
                bitmapPixels,
                13,
                13,
                android.graphics.Bitmap.Config.ARGB_8888
            )

            val matrixObject = com.nothing.ketchum.GlyphMatrixObject.Builder()
                .setImageSource(bitmap)
                .setPosition(0, 0)
                .setScale(100)
                .setBrightness(settings.brightness)
                .build()

            val matrixFrame = com.nothing.ketchum.GlyphMatrixFrame.Builder()
                .addTop(matrixObject)
                .build(applicationContext)

            glyphManager.setMatrixFrame(matrixFrame)
            bitmap.recycle()
            Log.i(TAG, "Nothing SDK accepted a structured 13x13 Glyph frame")

            // Keep animated condition frames smooth while the toy is active and schedule
            // animation redraws independently from the fixed auto-rotation timer.
            if (isBoundToToy) {
                val refreshDelay = AtmosGlyphFrames.nextRefreshDelayMs(weather, effectiveSettings, System.currentTimeMillis(), frames.size)
                if (refreshDelay != null) serviceHandler.postDelayed(animationRunnable, refreshDelay)
                if (settings.mode == "auto_rotation") scheduleRotationIfNeeded()
            }
        }.onFailure {
            Log.e(TAG, "Nothing SDK rejected the Glyph frame", it)
            if (fromAnimationLoop) serviceHandler.removeCallbacks(animationRunnable)
        }
    }


    private fun autoRotationModes(weather: GlyphWeather): List<String> {
        val prefs = glyphPreferences
        val configured = buildList {
            if (prefs.getBoolean("rotation_clock", false)) add("clock")
            if (prefs.getBoolean("rotation_temperature", true)) add("temperature")
            if (prefs.getBoolean("rotation_forecast_high", false)) add("forecast_high")
            if (prefs.getBoolean("rotation_forecast_low", false)) add("forecast_low")
            if (prefs.getBoolean("rotation_next_solar", true)) add("next_solar")
            if (prefs.getBoolean("rotation_rain_chance", false) && weather.rainChance > 0) add("rain_chance")
            if (prefs.getBoolean("rotation_battery", true)) add("battery")
        }
        // Settings prevents the final item being disabled, but retain a service-side fallback
        // for migrated preferences and external preference edits.
        return configured.ifEmpty { listOf("temperature") }
    }

    private fun scheduleRotationIfNeeded() {
        if (rotationScheduled || !isBoundToToy) return
        rotationScheduled = true
        serviceHandler.postDelayed(rotationRunnable, AUTO_ROTATION_INTERVAL_MS)
    }

    private fun stopGlyph() {
        manager?.let { glyphManager ->
            runCatching { glyphManager.unInit() }
                .onFailure { Log.w(TAG, "Unable to uninitialise Glyph SDK", it) }
        }
        manager = null
    }

    private fun readWeather(): GlyphWeather {
        val glyphPrefs = getSharedPreferences("atmos_glyph", Context.MODE_PRIVATE)
        val source = glyphPrefs.getString("location_source", "first")
        val prefs = getSharedPreferences(if (source == "current") "atmos_glyph_current_weather" else "atmos_glyph_first_weather", Context.MODE_PRIVATE)
        val fallback = getSharedPreferences("atmos_widget", Context.MODE_PRIVATE)
        return GlyphWeather(
            temperature = (prefs.getString("temp", fallback.getString("temp", "18"))?.toDoubleOrNull() ?: 18.0).roundToInt().coerceIn(-99, 99),
            feelsLike = (prefs.getString("feels", prefs.getString("temp", fallback.getString("temp", "18")))?.toDoubleOrNull() ?: 18.0).roundToInt().coerceIn(-99, 99),
            condition = prefs.getString("condition", fallback.getString("condition", "Clear")).orEmpty(),
            rainChance = prefs.getString("rain", fallback.getString("rain", "0"))?.toIntOrNull()?.coerceIn(0, 100) ?: 0,
            forecastHigh = (prefs.getString("high", fallback.getString("high", "18"))?.toDoubleOrNull() ?: 18.0).roundToInt().coerceIn(-99, 99),
            forecastLow = (prefs.getString("low", fallback.getString("low", "10"))?.toDoubleOrNull() ?: 10.0).roundToInt().coerceIn(-99, 99),
            humidity = prefs.getString("humidity", fallback.getString("humidity", "0"))?.toIntOrNull()?.coerceIn(0, 100) ?: 0,
            wind = prefs.getString("wind", fallback.getString("wind", "0"))?.toIntOrNull()?.coerceAtLeast(0) ?: 0,
            pressure = prefs.getString("pressure", fallback.getString("pressure", "0"))?.toDoubleOrNull() ?: 0.0,
            approachingCondition = prefs.getString("approach_condition", "").orEmpty(),
            approachingChance = prefs.getString("approach_chance", "0")?.toIntOrNull()?.coerceIn(0, 100) ?: 0,
            approachingMinutes = prefs.getString("approach_minutes", "")?.toIntOrNull(),
            sunrise = prefs.getString("sunrise", fallback.getString("sunrise", "")).orEmpty(),
            sunset = prefs.getString("sunset", fallback.getString("sunset", "")).orEmpty(),
            timeZoneId = prefs.getString("time_zone", fallback.getString("time_zone", "")).orEmpty(),
            batteryPercentage = getSystemService(android.os.BatteryManager::class.java)
                ?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
                ?.takeIf { it in 0..100 } ?: 0
        )
    }

    private fun readGlyphSettings(): GlyphSettings {
        val prefs = glyphPreferences
        val storedMode = prefs.getString("display_mode", "auto_rotation") ?: "auto_rotation"
        val supportedMode = storedMode.takeIf { it in setOf("clock", "temperature", "forecast_high", "forecast_low", "rain_chance", "next_solar", "battery", "auto_rotation") } ?: "auto_rotation"
        return GlyphSettings(
            mode = supportedMode,
            animatedSymbols = prefs.getBoolean("animated_symbols", false),
            fahrenheit = prefs.getString("temperature_unit", "celsius") == "fahrenheit",
            useFeelsLike = prefs.getString("temperature_source", "actual") == "feels",
            brightness = prefs.getInt("brightness", 255).coerceIn(32, 255),
            clock24Hour = prefs.getString("clock_format", "12") == "24"
        )
    }

    data class GlyphWeather(
        val temperature: Int,
        val feelsLike: Int,
        val condition: String,
        val rainChance: Int,
        val forecastHigh: Int,
        val forecastLow: Int,
        val humidity: Int,
        val wind: Int,
        val pressure: Double,
        val approachingCondition: String,
        val approachingChance: Int,
        val approachingMinutes: Int?,
        val sunrise: String,
        val sunset: String,
        val timeZoneId: String,
        val batteryPercentage: Int
    )

    data class GlyphSettings(
        val mode: String,
        val animatedSymbols: Boolean,
        val fahrenheit: Boolean,
        val useFeelsLike: Boolean,
        val brightness: Int,
        val clock24Hour: Boolean
    )

    companion object {
        private const val TAG = "AtmosGlyph"
        private const val AUTO_ROTATION_INTERVAL_MS = 10_000L
    }
}

private object AtmosGlyphFrames {
    private const val SIZE = 13
    private const val ON = 255
    private const val DIM = 88
    private const val SOLAR_COUNTDOWN_WINDOW_MINUTES = 120
    private const val ANIMATION_DELAY_MS = 200L

    fun frames(weather: AtmosGlyphWeatherService.GlyphWeather, settings: AtmosGlyphWeatherService.GlyphSettings, now: Long): List<IntArray> {
        val sourceTemperature = if (settings.useFeelsLike) weather.feelsLike else weather.temperature
        val temperature = convertTemperature(sourceTemperature, settings.fahrenheit)
        val symbols = conditionFrames(weather, settings.animatedSymbols)
        val temperatureFrame = temperatureFrame(temperature)
        val selected = when (settings.mode) {
            "clock" -> listOf(clockFrame(now, settings.clock24Hour))
            "temperature" -> listOf(temperatureFrame)
            "forecast_high" -> listOf(forecastTemperatureFrame(convertTemperature(weather.forecastHigh, settings.fahrenheit), high = true))
            "forecast_low" -> listOf(forecastTemperatureFrame(convertTemperature(weather.forecastLow, settings.fahrenheit), high = false))
            "rain_chance" -> listOf(percentFrame(weather.rainChance))
            "next_solar" -> nextSolarDisplayFrames(weather, now)
            "battery" -> listOf(batteryFrame(weather.batteryPercentage))
            else -> listOf(temperatureFrame)
        }
        return selected.ifEmpty { listOf(temperatureFrame) }
    }

    private fun livingSkyFrames(
        weather: AtmosGlyphWeatherService.GlyphWeather,
        symbols: List<IntArray>,
        animated: Boolean,
        now: Long
    ): List<IntArray> {
        val next = nextSolarMinutes(weather, now)
        if (next != null && next.second <= SOLAR_COUNTDOWN_WINDOW_MINUTES) {
            val progress = 1f - (next.second.coerceIn(0, SOLAR_COUNTDOWN_WINDOW_MINUTES) / SOLAR_COUNTDOWN_WINDOW_MINUTES.toFloat())
            return solarHorizonFrames(next.first == 'R', progress, animated)
        }
        return symbols
    }

    private fun approachingWeatherFrames(
        weather: AtmosGlyphWeatherService.GlyphWeather,
        fallback: List<IntArray>,
        animated: Boolean
    ): List<IntArray> {
        val minutes = weather.approachingMinutes ?: return fallback
        val base = countdownFrame(minutes.coerceIn(0, 599), 'A')
        val kind = weather.approachingCondition.lowercase()
        val markerX = when {
            "storm" in kind || "thunder" in kind -> 10
            "snow" in kind || "sleet" in kind -> 3
            weather.approachingChance >= 50 || "rain" in kind -> 6
            else -> 1
        }
        put(base, markerX, 1, ON)
        if (!animated) return listOf(base)
        return listOf(base, base.copyOf().also { put(it, markerX, 2, DIM) })
    }

    fun nextRefreshDelayMs(
        weather: AtmosGlyphWeatherService.GlyphWeather,
        settings: AtmosGlyphWeatherService.GlyphSettings,
        now: Long,
        frameCount: Int
    ): Long? {
        if (settings.animatedSymbols && frameCount > 1) return ANIMATION_DELAY_MS
        if (settings.mode == "next_solar" || settings.mode == "clock") return millisUntilNextMinute(now)
        return null
    }

    private fun millisUntilNextMinute(now: Long): Long = (60_000L - (now % 60_000L)).coerceAtLeast(100L)

    private fun conditionFrames(weather: AtmosGlyphWeatherService.GlyphWeather, animated: Boolean): List<IntArray> {
        val kind = weather.condition.lowercase()
        val frames = when {
            "storm" in kind || "thunder" in kind -> listOf(storm(false, weather.wind), storm(true, weather.wind))
            "rain" in kind || "shower" in kind || "drizzle" in kind -> listOf(rain(0, weather.wind), rain(1, weather.wind), rain(2, weather.wind), rain(3, weather.wind), rain(4, weather.wind))
            "snow" in kind || "sleet" in kind -> listOf(snow(0), snow(1), snow(2))
            "fog" in kind || "mist" in kind || "haze" in kind -> listOf(fog(0), fog(1))
            "cloud" in kind || "overcast" in kind -> listOf(cloud())
            "night" in kind -> listOf(moon())
            else -> listOf(sun(0), sun(1))
        }
        return if (animated) frames else listOf(conditionStillFrame(kind, weather.wind))
    }

    /** Purpose-built compositions for users who prefer a static Living Sky. */
    private fun conditionStillFrame(kind: String, wind: Int): IntArray = when {
        "storm" in kind || "thunder" in kind -> stormStill(wind)
        "rain" in kind || "shower" in kind || "drizzle" in kind -> rainStill(wind)
        "snow" in kind || "sleet" in kind -> snowStill()
        "fog" in kind || "mist" in kind || "haze" in kind -> fogStill()
        "cloud" in kind || "overcast" in kind -> cloudStill()
        "night" in kind -> moonStill()
        else -> sunStill()
    }

    private fun convertTemperature(celsius: Int, fahrenheit: Boolean) =
        if (fahrenheit) (celsius * 9.0 / 5.0 + 32.0).roundToInt().coerceIn(-99, 199) else celsius

    private fun nextSolarDisplayFrames(weather: AtmosGlyphWeatherService.GlyphWeather, now: Long): List<IntArray> {
        val next = nextSolarMinutes(weather, now) ?: return listOf(unavailableFrame())
        return listOf(solarEventFrame(next.second, sunrise = next.first == 'R'))
    }

    private fun solarCountdownFrame(raw: String, zone: String, now: Long, sunrise: Boolean): IntArray {
        val minutes = minutesUntil(raw, zone, now) ?: return unavailableFrame()
        return countdownFrame(minutes, if (sunrise) 'R' else 'S')
    }

    private fun nextSolarMinutes(weather: AtmosGlyphWeatherService.GlyphWeather, now: Long): Pair<Char, Int>? {
        val rise = minutesUntil(weather.sunrise, weather.timeZoneId, now)
        val set = minutesUntil(weather.sunset, weather.timeZoneId, now)
        return listOfNotNull(rise?.let { 'R' to it }, set?.let { 'S' to it }).minByOrNull { it.second }
    }

    private fun minutesUntil(raw: String, zoneId: String, now: Long): Int? {
        if (raw.isBlank()) return null
        return runCatching {
            val zone = runCatching { java.util.TimeZone.getTimeZone(zoneId.ifBlank { java.util.TimeZone.getDefault().id }) }.getOrDefault(java.util.TimeZone.getDefault())
            val formats = listOf("h:mm a", "h:mma", "HH:mm", "yyyy-MM-dd'T'HH:mm")
            val parsed = formats.firstNotNullOfOrNull { pattern ->
                runCatching { java.text.SimpleDateFormat(pattern, java.util.Locale.ENGLISH).apply { timeZone = zone }.parse(raw.trim()) }.getOrNull()
            } ?: return null
            val target = java.util.Calendar.getInstance(zone).apply {
                timeInMillis = now
                set(java.util.Calendar.HOUR_OF_DAY, java.util.Calendar.getInstance(zone).apply { time = parsed }.get(java.util.Calendar.HOUR_OF_DAY))
                set(java.util.Calendar.MINUTE, java.util.Calendar.getInstance(zone).apply { time = parsed }.get(java.util.Calendar.MINUTE))
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
                if (timeInMillis <= now) add(java.util.Calendar.DAY_OF_YEAR, 1)
            }.timeInMillis
            ((target - now + 59_999L) / 60_000L).toInt().coerceAtLeast(0)
        }.getOrNull()
    }

    private fun solarEventFrame(minutes: Int, sunrise: Boolean): IntArray {
        val frame = blank()
        val value = if (minutes < 60) {
            minutes.coerceIn(0, 59)
        } else {
            kotlin.math.ceil(minutes / 60.0).toInt().coerceIn(1, 99)
        }
        val text = value.toString()
        val width = text.length * 4 - 1
        val startX = ((SIZE - width) / 2).coerceAtLeast(0)

        // Atmos digits use the same vertical origin as Temperature, Rain and Battery.
        drawText(frame, text, startX, 4)

        // Minimal four-LED solar event marks, centred over the numeric display.
        // A full blank row separates the icon from the digits in either direction.
        if (sunrise) {
            put(frame, 5, 2, DIM)
            put(frame, 6, 2, DIM)
            put(frame, 7, 2, DIM)
            put(frame, 6, 1, ON)
        } else {
            put(frame, 5, 10, DIM)
            put(frame, 6, 10, DIM)
            put(frame, 7, 10, DIM)
            put(frame, 6, 11, ON)
        }
        return frame
    }

    private fun countdownFrame(minutes: Int, event: Char): IntArray {
        val frame = blank()
        if (minutes > 60) {
            // Long countdowns stay glanceable: show whole hours until the final hour.
            val hours = (minutes / 60).coerceIn(1, 99)
            val hourText = hours.toString()
            val startX = if (hourText.length == 1) 3 else 1
            drawText(frame, hourText, startX, 4)
            drawChar(frame, 'h', startX + hourText.length * 4, 4)
        } else {
            // During the final hour, switch to an exact minute countdown.
            val minuteText = minutes.coerceIn(0, 60).toString()
            val startX = if (minuteText.length == 1) 3 else 1
            drawText(frame, minuteText, startX, 4)
            drawChar(frame, 'm', startX + minuteText.length * 4, 4)
        }
        // A dim top-corner pixel differentiates sunrise from sunset without crowding the digits.
        put(frame, when (event) { 'R' -> 1; 'A' -> 6; else -> 11 }, 1, DIM)
        return frame
    }

    private fun solarHorizonFrames(sunrise: Boolean, progress: Float, animated: Boolean): List<IntArray> {
        // Sunrise and sunset use distinct, intentionally simple 13x13 compositions.
        // Keeping the horizon fixed prevents the previous scene from collapsing or
        // moving in the wrong direction as the event approached.
        fun frame(phaseOffset: Int): IntArray = blank().also { f ->
            val horizonY = 8
            line(f, 1, horizonY, 11, horizonY, DIM)

            val eased = progress.coerceIn(0f, 1f)
            val sunCentreY = if (sunrise) {
                (10 - (eased * 4f).roundToInt() + phaseOffset).coerceIn(6, 10)
            } else {
                (6 + (eased * 4f).roundToInt() + phaseOffset).coerceIn(6, 10)
            }

            // Draw only the visible half of a compact sun around the horizon.
            for (yy in sunCentreY - 2..sunCentreY + 2) {
                for (xx in 4..8) {
                    val dx = xx - 6
                    val dy = yy - sunCentreY
                    val inside = dx * dx + dy * dy <= 5
                    val visible = if (sunrise) yy <= horizonY else yy >= horizonY
                    if (inside && visible) put(f, xx, yy)
                }
            }

            if (sunrise) {
                put(f, 6, 3, DIM)
                put(f, 3, 5, DIM)
                put(f, 9, 5, DIM)
                put(f, 2, 10, DIM)
                put(f, 10, 10, DIM)
            } else {
                put(f, 2, 3, DIM)
                put(f, 10, 3, DIM)
                put(f, 3, 5, DIM)
                put(f, 9, 5, DIM)
                put(f, 6, 11, DIM)
            }
        }
        val first = frame(0)
        if (!animated) return listOf(first)
        val secondOffset = if (sunrise) -1 else 1
        return listOf(first, frame(secondOffset.coerceIn(-1, 1)))
    }

    private fun percentFrame(value: Int): IntArray = blank().also { frame ->
        val text = value.coerceIn(0, 100).toString()
        val width = text.length * 4 - 1
        // Match Temperature and Battery: centre the numeric glyph independently of its marker.
        // Keep 100 one pixel left so the 2x2 marker cannot overwrite the final digit.
        val startX = if (text.length >= 3) 0 else ((SIZE - width) / 2).coerceAtLeast(0)
        drawText(frame, text, startX, 4)
        // Exact 2x2 percent marker: bright top-right/bottom-left, dim top-left/bottom-right.
        put(frame, 11, 4, DIM)
        put(frame, 12, 4, ON)
        put(frame, 11, 5, ON)
        put(frame, 12, 5, DIM)
    }

    private fun batteryFrame(value: Int): IntArray = blank().also { frame ->
        if (value >= 100) {
            // Keep the full-battery F centred exactly like a single numeric digit.
            drawChar(frame, 'F', 5, 4)
        } else {
            val text = value.coerceIn(0, 99).toString()
            val width = text.length * 4 - 1
            val startX = ((SIZE - width) / 2).coerceAtLeast(0)
            drawText(frame, text, startX, 4)
        }

        // Minimal centred lightning bolt below the battery value, matching the approved mockup.
        // The number occupies rows 4-8, row 9 stays blank, and the bolt occupies rows 10-11.
        put(frame, 6, 10, ON)
        put(frame, 7, 10, ON)
        put(frame, 5, 11, ON)
        put(frame, 6, 11, ON)
    }

    private fun forecastTemperatureFrame(value: Int, high: Boolean): IntArray = blank().also { frame ->
        val text = value.toString()
        val width = text.length * 4 - 1
        val startX = ((SIZE - width) / 2).coerceAtLeast(0)
        drawText(frame, text, startX, 4)

        // Minimal centred arrow from the approved mockups. A full blank row separates
        // the arrow from the shared Atmos number position.
        if (high) {
            put(frame, 6, 0, ON)
            put(frame, 5, 1, ON)
            put(frame, 6, 1, ON)
            put(frame, 7, 1, ON)
        } else {
            put(frame, 5, 11, ON)
            put(frame, 6, 11, ON)
            put(frame, 7, 11, ON)
            put(frame, 6, 12, ON)
        }
    }


    private fun clockFrame(now: Long, use24Hour: Boolean): IntArray = blank().also { frame ->
        val calendar = java.util.Calendar.getInstance().apply { timeInMillis = now }
        val hour24 = calendar.get(java.util.Calendar.HOUR_OF_DAY)
        val hourText = if (use24Hour) {
            hour24.toString().padStart(2, '0')
        } else {
            val hour12 = hour24 % 12
            (if (hour12 == 0) 12 else hour12).toString()
        }
        val minuteText = calendar.get(java.util.Calendar.MINUTE).toString().padStart(2, '0')

        fun drawCentred(text: String, y: Int) {
            val width = text.length * 4 - 1
            val startX = ((SIZE - width) / 2).coerceAtLeast(0)
            drawText(frame, text, startX, y)
        }

        // Two compact stacked rows, matching the approved mockup. In 12-hour mode a
        // single hour digit is centred; 24-hour mode always retains its leading zero.
        drawCentred(hourText, 1)
        drawCentred(minuteText, 7)
    }

    private fun unavailableFrame(): IntArray = blank().also { frame -> drawChar(frame, '-', 5, 4) }
    private fun temperatureFrame(value: Int): IntArray = blank().also { frame ->
        val text = value.toString()
        val width = text.length * 4 - 1
        val startX = ((SIZE - width) / 2).coerceAtLeast(0)
        drawText(frame, text, startX, 4)
        // A single dim pixel is the degree mark. The selected unit only changes the number.
        put(frame, (startX + width + 1).coerceAtMost(SIZE - 1), 4, DIM)
    }
    private fun drawText(frame: IntArray, text: String, ox: Int, oy: Int) = text.forEachIndexed { i, c -> drawChar(frame, c, ox + i * 4, oy) }

    private fun blank() = IntArray(SIZE * SIZE)
    private fun put(frame: IntArray, x: Int, y: Int, value: Int = ON) { if (x in 0 until SIZE && y in 0 until SIZE) frame[y * SIZE + x] = value }
    private fun line(frame: IntArray, x1: Int, y1: Int, x2: Int, y2: Int, value: Int = ON) { val steps=maxOf(kotlin.math.abs(x2-x1),kotlin.math.abs(y2-y1)).coerceAtLeast(1); for(i in 0..steps) put(frame,x1+(x2-x1)*i/steps,y1+(y2-y1)*i/steps,value) }

    // Cohesive minimal 13x13 Living Sky icon set. Each symbol uses a similar visual
    // weight and central footprint so conditions feel proportionally related.
    private fun sunStill() = blank().also { f ->
        // Compact filled sun with restrained cardinal rays.
        for (y in 4..8) for (x in 4..8)
            if ((x - 6) * (x - 6) + (y - 6) * (y - 6) <= 5) put(f, x, y)
        put(f, 6, 2, DIM); put(f, 6, 10, DIM); put(f, 2, 6, DIM); put(f, 10, 6, DIM)
    }

    private fun cloudStill() = blank().also { f ->
        // Soft, filled cloud silhouette with balanced proportions.
        line(f, 2, 8, 10, 8)
        line(f, 3, 7, 9, 7)
        line(f, 4, 6, 9, 6)
        line(f, 5, 5, 7, 5)
        put(f, 3, 6, DIM); put(f, 10, 7, DIM)
    }

    private fun rainStill(@Suppress("UNUSED_PARAMETER") wind: Int) = blank().also { f ->
        // Minimal filled water drop. The pointed crown and rounded base remain clear
        // at 13x13 while matching the visual weight of the other condition symbols.
        put(f, 6, 2)
        line(f, 5, 3, 7, 3)
        line(f, 4, 4, 8, 4)
        line(f, 3, 5, 9, 5)
        line(f, 3, 6, 9, 6)
        line(f, 3, 7, 9, 7)
        line(f, 4, 8, 8, 8)
        line(f, 5, 9, 7, 9)
        put(f, 4, 5, DIM); put(f, 4, 6, DIM)
    }

    private fun snowStill() = blank().also { f ->
        // One modern six-arm snowflake rather than scattered particles.
        line(f, 6, 2, 6, 10)
        line(f, 2, 6, 10, 6)
        line(f, 3, 3, 9, 9, DIM)
        line(f, 9, 3, 3, 9, DIM)
        arrayOf(5 to 2, 7 to 2, 5 to 10, 7 to 10, 2 to 5, 2 to 7, 10 to 5, 10 to 7)
            .forEach { (x, y) -> put(f, x, y, DIM) }
    }

    private fun fogStill() = blank().also { f ->
        // Three quiet, rounded horizontal bands.
        line(f, 2, 4, 10, 4, DIM)
        line(f, 1, 6, 11, 6)
        line(f, 3, 8, 9, 8, DIM)
    }

    private fun stormStill(@Suppress("UNUSED_PARAMETER") wind: Int) = blank().also { f ->
        // Single bold lightning mark with enough negative space to read instantly.
        line(f, 7, 2, 4, 7)
        line(f, 4, 7, 7, 7)
        line(f, 7, 7, 5, 11)
        put(f, 8, 3, DIM); put(f, 3, 8, DIM)
    }

    private fun moonStill() = blank().also { f ->
        // Clean crescent with two restrained stars.
        for (y in 2..10) for (x in 2..10) {
            val outer = (x - 6) * (x - 6) + (y - 6) * (y - 6)
            val cut = (x - 8) * (x - 8) + (y - 5) * (y - 5)
            if (outer <= 18 && cut > 11) put(f, x, y)
        }
        put(f, 10, 2, DIM); put(f, 11, 5, DIM)
    }

    private fun sun(phase:Int)=blank().also{f->for(y in 4..8)for(x in 4..8)if((x-6)*(x-6)+(y-6)*(y-6)<=6)put(f,x,y);(if(phase==0)arrayOf(6 to 1,6 to 11,1 to 6,11 to 6)else arrayOf(2 to 2,10 to 2,2 to 10,10 to 10)).forEach{(x,y)->put(f,x,y,DIM)}}
    private fun cloud()=blank().also{f->for(x in 2..10)put(f,x,8);for(x in 3..9)put(f,x,7);for(x in 4..8)put(f,x,6);for(x in 5..7)put(f,x,5);put(f,3,6,DIM);put(f,9,6,DIM)}
    private fun rain(phase: Int, wind: Int): IntArray = blank().also { frame ->
        val diagonal = wind >= 20
        val seeds = intArrayOf(0, 3, 6, 9, 12, 15, 18, 21)
        seeds.forEachIndexed { index, seed ->
            val y = (seed + phase * 3) % 16 - 2
            val baseX = (index * 4 + phase * 2) % SIZE
            for (trail in 0..2) {
                val py = y - trail
                val px = if (diagonal) baseX - trail else baseX
                put(frame, px, py, if (trail == 0) ON else if (trail == 1) 150 else DIM)
            }
        }
    }
    private fun snow(phase:Int)=cloud().also{f->arrayOf(3 to 10,6 to 11,9 to 10).forEachIndexed{i,(x,y)->put(f,x+((phase+i)%2),y+((phase+i)%2),if(i==1)ON else DIM)}}
    private fun fog(phase:Int)=blank().also{f->for(y in listOf(4,6,8)){val o=(phase+y)%2;line(f,1+o,y,10+o,y,if(y==6)ON else DIM)}}
    private fun storm(flash: Boolean, wind: Int) = rain(if (flash) 1 else 0, wind).also { f ->
        line(f, 7, 3, 5, 6); line(f, 5, 6, 7, 6); line(f, 7, 6, 5, 10)
        if (flash) for (x in 0 until SIZE) put(f, x, 0, DIM)
    }
    private fun moon()=blank().also{f->for(y in 2..10)for(x in 2..10){val d1=(x-6)*(x-6)+(y-6)*(y-6);val d2=(x-8)*(x-8)+(y-5)*(y-5);if(d1<=18&&d2>12)put(f,x,y)};put(f,10,2,DIM);put(f,11,5,DIM)}
    private fun drawChar(frame:IntArray,char:Char,ox:Int,oy:Int){(FONT[char]?:return).forEachIndexed{y,row->row.forEachIndexed{x,p->if(p=='1')put(frame,ox+x,oy+y)}}}
    private val FONT=mapOf(
        '-' to listOf("000","000","111","000","000"),'0' to listOf("111","101","101","101","111"),'1' to listOf("010","110","010","010","111"),'2' to listOf("111","001","111","100","111"),'3' to listOf("111","001","111","001","111"),'4' to listOf("101","101","111","001","001"),'5' to listOf("111","100","111","001","111"),'6' to listOf("111","100","111","101","111"),'7' to listOf("111","001","010","010","010"),'8' to listOf("111","101","111","101","111"),'9' to listOf("111","101","111","001","111"),
        'A' to listOf("010","101","111","101","101"),'B' to listOf("110","101","110","101","110"),'C' to listOf("111","100","100","100","111"),'D' to listOf("110","101","101","101","110"),'F' to listOf("111","100","110","100","100"),'G' to listOf("111","100","101","101","111"),'H' to listOf("101","101","111","101","101"),'h' to listOf("100","100","110","101","101"),'L' to listOf("100","100","100","100","111"),'M' to listOf("101","111","111","101","101"),'m' to listOf("000","000","111","111","101"),'O' to listOf("111","101","101","101","111"),'P' to listOf("110","101","110","100","100"),'R' to listOf("110","101","110","101","101"),'S' to listOf("111","100","111","001","111"),'T' to listOf("111","010","010","010","010"),'U' to listOf("101","101","101","101","111"),'W' to listOf("101","101","111","111","101"),'%' to listOf("101","001","010","100","101")
    )
}
