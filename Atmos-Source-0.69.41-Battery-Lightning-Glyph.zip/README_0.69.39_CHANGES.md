# Atmos 0.69.39

- Added **Forecast High** and **Forecast Low** Nothing Glyph Matrix displays.
- Forecast values use the shared centred Atmos numeric layout.
- Forecast High uses a minimal upward arrow above the number.
- Forecast Low uses a minimal downward arrow below the number.
- Added a **Glyphs in rotation** settings section.
- Users can independently include Temperature, Forecast High, Forecast Low, Next Solar Event, Chance of Rain and Battery Percentage.
- The established display order is retained and every selected Glyph receives a full stateful 10-second interval.
- At least one rotation item must remain enabled.
- Default rotation remains Temperature, Next Solar Event and Battery Percentage.
