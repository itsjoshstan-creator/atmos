# Atmos 0.69.41

- Redesigned the Battery Glyph to match the approved minimal lightning-bolt mockup.
- Removed the previous 1×2 battery marker.
- Added a centred 2-row lightning bolt below the battery value with one blank LED row of separation.
- Preserved centred single-digit battery values and the centred full-battery `F`.
- Left all other Glyph displays and Auto Glyph Rotation behaviour unchanged.
