# Atmos 0.16.0

Native Android weather app source.

## New in 0.16.0
- Optional full-screen current conditions layout with an edge-to-edge condition gradient.
- The condition gradient continues behind the forecast cards as the page scrolls.
- Classic Atmos card layout remains available.
- New post-location onboarding screen for choosing the preferred home layout.
- Layout can be changed later in Settings > Appearance.
