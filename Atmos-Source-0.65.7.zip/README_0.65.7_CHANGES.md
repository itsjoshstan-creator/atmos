# Atmos 0.65.7

## Performance and visual lifecycle
- Added a dedicated fog, mist and haze presence envelope.
- Soft atmospheric diffusion fades in over 1.05 seconds and fades out over 1.35 seconds instead of appearing or disappearing abruptly.
- The fade modifies the existing shared Atmos scene rather than adding another full-screen effect layer or idle renderer.
- Preserved event-driven rendering: redraws occur only during a weather transition, palette transition, or minute solar update.
- Kept the renderer shared between Hero, Timeline and wallpaper surfaces.

## Navigation
- Retained the common application-level fade and horizontal motion transition for every Atmos page.
- The current 0.65.6 source has one consolidated Settings screen rather than separately routed Settings sub-pages, so there were no nested Settings routes to animate independently.

## APK update continuity
- Version code increased from 355 to 356 and version name to 0.65.7.
- Performance builds now use the included stable Atmos development signing key instead of GitHub runner-generated debug signing.
- The first APK using this new key may require uninstalling an older differently signed build once. Every later APK built from this project can update over 0.65.7 without uninstalling, provided the application ID and signing key remain unchanged.
- Google Play release signing should use a separate protected production key or Play App Signing.
