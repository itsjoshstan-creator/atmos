# Atmos 0.65.6

## Timeline refinement

- Timeline now renders through the same `AtmosSceneRenderer` used by the main Hero.
- Added a renderer time override so Timeline scenes use the selected forecast time for solar lighting, stars, moonlight and seasonal grading.
- Atmos colours and forecast values interpolate continuously between adjacent hourly points while scrubbing.
- Slider follows the finger smoothly, then animates to the nearest hourly forecast point when released.
- Timeline typography now mirrors the immersive Hero: gradient location title, ultra-bold 90sp temperature, raised degree symbol, 30sp condition and matching secondary information.
- Preserved event-driven rendering; no idle frame loop was added.
