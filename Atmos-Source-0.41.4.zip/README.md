# Atmos 0.41.3

Atmos is a native Jetpack Compose weather app with one shared procedural Kotlin atmosphere renderer.

## This release

Atmos 0.41.3 expands location-to-location palette variation using low-cost weather calculations rather than a performance-heavy animated gradient. Humidity, dryness, pressure, cloud cover, season, and solar elevation now contribute to each scene's colour identity.

Foreground contrast is calculated separately for upper Hero text, lower Immersive text, chart labels, chart strokes, and precipitation. A separate Dark mode at night option has also returned while Follow Device, Light, and Dark remain the base appearance choices.

## Version

- Version name: 0.41.3
- Version code: 153
- GitHub Actions artifact: `Atmos-0.41.3-debug`

See `README_0.41.3_CHANGES.md` for details.

## 0.41.4

Fixed nullable weather-state handling in saved-location palette previews so the Android Kotlin build succeeds while forecast data is still loading.
