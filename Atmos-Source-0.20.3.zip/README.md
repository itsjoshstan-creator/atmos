# Atmos 0.20.3

Changes in this source release:

- Seasonal particles now use staggered, individual life cycles.
- Every particle fades in, drifts, fades out, and recycles invisibly.
- Particle timing, opacity, drift, and pulsing are varied to prevent group snapping.
- Onboarding has been redesigned with a cleaner, consistent Atmos visual language inspired by the About page.
- Theme/layout selection is separated from the Atmos System explanation to reduce clutter.
- The Atmos onboarding preview demonstrates the smoother particle life cycle.
- The current-conditions page has been removed from navigation.
- Tapping the hero card no longer opens the removed current-conditions page.

Version: 0.20.3
Build: 86

The Gradle compile step could not be completed in the generation environment because services.gradle.org was unreachable. Verify with GitHub Actions.
