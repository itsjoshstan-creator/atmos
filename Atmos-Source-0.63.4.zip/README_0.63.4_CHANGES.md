# Atmos 0.63.4

## Two-layer architecture

- Separated the Atmos renderer from the Android interface.
- Added a dedicated `atmosengine` package with an immutable scene contract.
- The Atmos engine now owns bitmap rendering, scene caching and scene lifecycle.
- Compose builds a small `AtmosSceneSpec` and displays the engine output beneath the interface.
- The engine has no dependency on weather repositories, navigation, settings, cards or screen content.
- Native Android UI remains independently composable above the renderer.
- Scene rendering continues off the main thread and only runs when scene inputs or dimensions change.
- Cached scenes are reused across recompositions.
- Existing visual appearance, weather summaries, notifications, background updates and navigation are preserved.
