# Atmos 0.60.2

Atmos Display build correction based on Atmos 0.60.1. See `README_0.60.2_CHANGES.md` for details.

## Architecture (0.63.4+)

Atmos uses two independent presentation layers:

1. **Atmos Engine** (`au.com.weatheraustralia.app.atmosengine`) — accepts an immutable `AtmosSceneSpec`, renders and caches the atmospheric bitmap off the main thread, and owns scene transitions.
2. **Android UI** — native Jetpack Compose and Material 3 controls, navigation, weather text, cards, charts, settings and interaction layered above the engine output.

The engine does not depend on repositories, navigation, preferences or Android UI components.
