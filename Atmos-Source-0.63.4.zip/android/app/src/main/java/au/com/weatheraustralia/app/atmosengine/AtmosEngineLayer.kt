package au.com.weatheraustralia.app.atmosengine

import android.graphics.Bitmap
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Compose host for the independent Atmos engine layer. */
@Composable
fun AtmosEngineLayer(
    spec: AtmosSceneSpec,
    modifier: Modifier = Modifier
) {
    val engine = remember { AtmosEngine() }
    var renderSize by remember { mutableStateOf(IntSize.Zero) }
    var currentBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var previousBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val sceneFade = remember { Animatable(1f) }

    LaunchedEffect(spec, renderSize) {
        if (renderSize.width <= 0 || renderSize.height <= 0) return@LaunchedEffect
        val rendered = withContext(Dispatchers.Default) {
            engine.render(spec, renderSize.width, renderSize.height)
        }
        if (rendered === currentBitmap) return@LaunchedEffect
        previousBitmap = currentBitmap
        currentBitmap = rendered
        sceneFade.snapTo(if (previousBitmap == null) 1f else 0f)
        if (previousBitmap != null) {
            sceneFade.animateTo(1f, tween(720, easing = FastOutSlowInEasing))
            previousBitmap = null
        }
    }

    DisposableEffect(Unit) {
        onDispose { engine.clear() }
    }

    Box(modifier.onSizeChanged { renderSize = it }) {
        previousBitmap?.let { bitmap ->
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize().alpha(1f - sceneFade.value)
            )
        }
        currentBitmap?.let { bitmap ->
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize().alpha(sceneFade.value)
            )
        } ?: Box(
            Modifier.fillMaxSize().background(
                Brush.linearGradient(
                    listOf(
                        Color(spec.topColor),
                        Color(spec.middleColor),
                        Color(spec.bottomColor)
                    )
                )
            )
        )
    }
}
