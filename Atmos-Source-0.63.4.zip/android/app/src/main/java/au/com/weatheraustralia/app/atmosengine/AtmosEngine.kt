package au.com.weatheraustralia.app.atmosengine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import androidx.annotation.ColorInt
import java.util.LinkedHashMap
import kotlin.math.max
import kotlin.math.min

/**
 * Immutable rendering contract between the Android UI and the Atmos engine.
 * The engine deliberately knows nothing about Compose, weather repositories,
 * navigation, settings, or screen content.
 */
data class AtmosSceneSpec(
    @ColorInt val topColor: Int,
    @ColorInt val middleColor: Int,
    @ColorInt val bottomColor: Int,
    val effectsEnabled: Boolean,
    @ColorInt val solarColor: Int,
    val solarAlpha: Float,
    @ColorInt val thermalColor: Int,
    val thermalAlpha: Float,
    @ColorInt val seasonalColor: Int,
    val seasonalAlpha: Float,
    val sceneIdentity: String
)

/**
 * Dedicated Atmos rendering layer. Expensive scene construction happens here,
 * away from Compose. Rendered scenes are cached by immutable scene input and size.
 */
class AtmosEngine(private val maxCachedScenes: Int = 4) {
    private val cache = object : LinkedHashMap<SceneKey, Bitmap>(maxCachedScenes, .75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<SceneKey, Bitmap>?): Boolean {
            return size > maxCachedScenes
        }
    }

    @Synchronized
    fun render(spec: AtmosSceneSpec, width: Int, height: Int): Bitmap {
        val safeWidth = width.coerceAtLeast(1)
        val safeHeight = height.coerceAtLeast(1)
        val key = SceneKey(spec, safeWidth, safeHeight)
        cache[key]?.takeUnless(Bitmap::isRecycled)?.let { return it }

        val bitmap = renderScene(spec, safeWidth, safeHeight)
        cache[key] = bitmap
        return bitmap
    }

    @Synchronized
    fun clear() {
        cache.clear()
    }

    private fun renderScene(spec: AtmosSceneSpec, width: Int, height: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)

        paint.shader = LinearGradient(
            0f,
            0f,
            width.toFloat(),
            height.toFloat(),
            intArrayOf(spec.topColor, spec.middleColor, spec.bottomColor),
            floatArrayOf(0f, .52f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        if (!spec.effectsEnabled) return bitmap

        fun drawGlow(color: Int, alpha: Float, centerX: Float, centerY: Float, radius: Float) {
            if (alpha <= 0f || radius <= 0f) return
            val clamped = alpha.coerceIn(0f, 1f)
            val opaque = (color and 0x00FFFFFF) or ((clamped * 255f).toInt() shl 24)
            val transparent = color and 0x00FFFFFF
            paint.shader = RadialGradient(
                centerX,
                centerY,
                radius,
                intArrayOf(opaque, transparent),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        }

        val minDimension = min(width, height).toFloat()
        val maxDimension = max(width, height).toFloat()
        drawGlow(spec.solarColor, spec.solarAlpha, width * .50f, height * .12f, minDimension * 1.05f)
        drawGlow(spec.thermalColor, spec.thermalAlpha, width * .52f, height * .62f, maxDimension * .76f)
        drawGlow(spec.seasonalColor, spec.seasonalAlpha, width * .20f, height * .72f, maxDimension * .72f)
        paint.shader = null
        return bitmap
    }

    private data class SceneKey(
        val spec: AtmosSceneSpec,
        val width: Int,
        val height: Int
    )
}
