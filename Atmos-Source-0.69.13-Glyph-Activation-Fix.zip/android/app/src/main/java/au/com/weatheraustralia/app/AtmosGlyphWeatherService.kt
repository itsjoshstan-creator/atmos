package au.com.weatheraustralia.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import java.lang.reflect.Proxy
import java.util.Timer
import java.util.TimerTask
import kotlin.math.roundToInt

/**
 * Optional Nothing Glyph Matrix weather toy.
 *
 * The Nothing SDK is loaded reflectively so Atmos remains fully compatible with every
 * other Android device. Official builds download and package the SDK AAR during CI.
 */
class AtmosGlyphWeatherService : Service() {
    private var manager: Any? = null
    private var frameIndex = 0

    private val serviceHandler = object : android.os.Handler(android.os.Looper.getMainLooper()) {
        override fun handleMessage(msg: android.os.Message) {
            runCatching {
                val glyphToyClass = Class.forName("com.nothing.ketchum.GlyphToy")
                val messageType = glyphToyClass.getField("MSG_GLYPH_TOY").getInt(null)
                if (msg.what == messageType) {
                    val key = glyphToyClass.getField("MSG_GLYPH_TOY_DATA").get(null) as String
                    val event = msg.data?.getString(key)
                    val aodEvent = glyphToyClass.getField("EVENT_AOD").get(null) as String
                    val changeEvent = runCatching {
                        glyphToyClass.getField("EVENT_CHANGE").get(null) as String
                    }.getOrNull()
                    if (event == aodEvent || event == changeEvent) {
                        renderNextFrame()
                    }
                    return
                }
            }.onFailure { Log.w(TAG, "Unable to process Glyph Toy event", it) }
            super.handleMessage(msg)
        }
    }
    private val serviceMessenger = android.os.Messenger(serviceHandler)

    override fun onBind(intent: Intent?): IBinder {
        startGlyph()
        return serviceMessenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopGlyph()
        return false
    }

    override fun onDestroy() {
        stopGlyph()
        super.onDestroy()
    }

    private fun startGlyph() {
        runCatching {
            val managerClass = Class.forName("com.nothing.ketchum.GlyphMatrixManager")
            val callbackClass = Class.forName("com.nothing.ketchum.GlyphMatrixManager\$Callback")
            val getInstance = managerClass.getMethod("getInstance", Context::class.java)
            manager = getInstance.invoke(null, applicationContext)
            val callback = Proxy.newProxyInstance(
                callbackClass.classLoader,
                arrayOf(callbackClass)
            ) { _, method, _ ->
                when (method.name) {
                    "onServiceConnected" -> registerAndRender()
                    "onServiceDisconnected" -> manager = null
                }
                null
            }
            managerClass.getMethod("init", callbackClass).invoke(manager, callback)
        }.onFailure { Log.w(TAG, "Glyph Matrix SDK unavailable", it) }
    }

    private fun registerAndRender() {
        val activeManager = manager ?: return
        runCatching {
            val glyphClass = Class.forName("com.nothing.ketchum.Glyph")
            val target = glyphClass.getField("DEVICE_25111p").get(null) as String
            activeManager.javaClass.getMethod("register", String::class.java).invoke(activeManager, target)
            // Draw immediately when selected. Phone (4a) Pro then sends EVENT_AOD each minute.
            renderNextFrame()
        }.onFailure { Log.w(TAG, "Unable to register Glyph Matrix", it) }
    }

    private fun renderNextFrame() {
        val activeManager = manager ?: return
        val weather = readWeather()
        val frames = AtmosGlyphFrames.frames(weather.condition, weather.temperature)
        val frame = frames[frameIndex.mod(frames.size)]
        frameIndex++
        runCatching {
            // Glyph Toy services must use setMatrixFrame. setAppMatrixFrame is only for
            // direct control while an Activity is open and can conflict with active toys.
            activeManager.javaClass.getMethod("setMatrixFrame", IntArray::class.java)
                .invoke(activeManager, frame)
        }.onFailure { error -> Log.w(TAG, "Unable to update Glyph Toy frame", error) }
    }

    private fun stopGlyph() {
        manager?.let { activeManager ->
            runCatching { activeManager.javaClass.getMethod("unInit").invoke(activeManager) }
        }
        manager = null
    }

    private fun readWeather(): GlyphWeather {
        val prefs = getSharedPreferences("atmos_widget", Context.MODE_PRIVATE)
        val rawTemp = prefs.getString("temp", "18")?.toDoubleOrNull() ?: 18.0
        return GlyphWeather(
            temperature = rawTemp.roundToInt().coerceIn(-99, 99),
            condition = prefs.getString("condition", "Clear").orEmpty()
        )
    }

    private data class GlyphWeather(val temperature: Int, val condition: String)

    companion object {
        private const val TAG = "AtmosGlyph"
    }
}

private object AtmosGlyphFrames {
    private const val SIZE = 13
    private const val ON = 255
    private const val DIM = 88

    fun frames(condition: String, temperature: Int): List<IntArray> {
        val kind = condition.lowercase()
        val symbolFrames = when {
            "storm" in kind || "thunder" in kind -> listOf(storm(false), storm(true))
            "rain" in kind || "shower" in kind || "drizzle" in kind -> listOf(rain(0), rain(1), rain(2))
            "snow" in kind || "sleet" in kind -> listOf(snow(0), snow(1), snow(2))
            "fog" in kind || "mist" in kind || "haze" in kind -> listOf(fog(0), fog(1))
            "cloud" in kind || "overcast" in kind -> listOf(cloud())
            "night" in kind -> listOf(moon())
            else -> listOf(sun(0), sun(1))
        }
        return symbolFrames + temperatureFrames(temperature)
    }

    private fun blank() = IntArray(SIZE * SIZE)
    private fun put(frame: IntArray, x: Int, y: Int, value: Int = ON) {
        if (x in 0 until SIZE && y in 0 until SIZE) frame[y * SIZE + x] = value
    }
    private fun line(frame: IntArray, x1: Int, y1: Int, x2: Int, y2: Int, value: Int = ON) {
        val steps = maxOf(kotlin.math.abs(x2 - x1), kotlin.math.abs(y2 - y1)).coerceAtLeast(1)
        for (i in 0..steps) put(frame, x1 + (x2 - x1) * i / steps, y1 + (y2 - y1) * i / steps, value)
    }

    private fun sun(phase: Int) = blank().also { f ->
        for (y in 4..8) for (x in 4..8) if ((x - 6) * (x - 6) + (y - 6) * (y - 6) <= 6) put(f, x, y)
        val rays = if (phase == 0) arrayOf(6 to 1, 6 to 11, 1 to 6, 11 to 6) else arrayOf(2 to 2, 10 to 2, 2 to 10, 10 to 10)
        rays.forEach { (x, y) -> put(f, x, y, DIM) }
    }

    private fun cloud() = blank().also { f ->
        for (x in 2..10) put(f, x, 8)
        for (x in 3..9) put(f, x, 7)
        for (x in 4..8) put(f, x, 6)
        for (x in 5..7) put(f, x, 5)
        put(f, 3, 6, DIM); put(f, 9, 6, DIM)
    }

    private fun rain(phase: Int) = cloud().also { f ->
        val drops = arrayOf(3, 6, 9)
        drops.forEachIndexed { index, x -> put(f, x, 10 + ((phase + index) % 3), if (index == 1) ON else DIM) }
    }

    private fun snow(phase: Int) = cloud().also { f ->
        arrayOf(3 to 10, 6 to 11, 9 to 10).forEachIndexed { index, (x, y) ->
            put(f, x + ((phase + index) % 2), y + ((phase + index) % 2), if (index == 1) ON else DIM)
        }
    }

    private fun fog(phase: Int) = blank().also { f ->
        for (y in listOf(4, 6, 8)) {
            val offset = (phase + y) % 2
            line(f, 1 + offset, y, 10 + offset, y, if (y == 6) ON else DIM)
        }
    }

    private fun storm(flash: Boolean) = rain(if (flash) 1 else 0).also { f ->
        line(f, 7, 8, 5, 10, ON); line(f, 5, 10, 7, 10, ON); line(f, 7, 10, 5, 12, ON)
        if (flash) for (x in 0 until SIZE) put(f, x, 0, DIM)
    }

    private fun moon() = blank().also { f ->
        for (y in 2..10) for (x in 2..10) {
            val d1 = (x - 6) * (x - 6) + (y - 6) * (y - 6)
            val d2 = (x - 8) * (x - 8) + (y - 5) * (y - 5)
            if (d1 <= 18 && d2 > 12) put(f, x, y)
        }
        put(f, 10, 2, DIM); put(f, 11, 5, DIM)
    }

    private fun temperatureFrames(value: Int): List<IntArray> {
        val text = value.toString()
        val frame = blank()
        val width = text.length * 4 - 1
        val startX = ((SIZE - width) / 2).coerceAtLeast(0)
        text.forEachIndexed { index, char -> drawChar(frame, char, startX + index * 4, 4) }
        put(frame, (startX + width + 1).coerceAtMost(12), 4, DIM)
        return listOf(frame)
    }

    private fun drawChar(frame: IntArray, char: Char, ox: Int, oy: Int) {
        val rows = FONT[char] ?: return
        rows.forEachIndexed { y, row ->
            row.forEachIndexed { x, pixel -> if (pixel == '1') put(frame, ox + x, oy + y) }
        }
    }

    private val FONT = mapOf(
        '-' to listOf("000", "000", "111", "000", "000"),
        '0' to listOf("111", "101", "101", "101", "111"),
        '1' to listOf("010", "110", "010", "010", "111"),
        '2' to listOf("111", "001", "111", "100", "111"),
        '3' to listOf("111", "001", "111", "001", "111"),
        '4' to listOf("101", "101", "111", "001", "001"),
        '5' to listOf("111", "100", "111", "001", "111"),
        '6' to listOf("111", "100", "111", "101", "111"),
        '7' to listOf("111", "001", "010", "010", "010"),
        '8' to listOf("111", "101", "111", "101", "111"),
        '9' to listOf("111", "101", "111", "001", "111")
    )
}
