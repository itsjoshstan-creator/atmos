# Atmos 0.68.3

- Added a Settings changelog showing the latest three versions.
- Added animated wind, humidity/fog and rain visuals to Right Now.
- Added compact Atmos Stories without increasing Hero height.
- Removed Atmos Moments tap navigation and themed Timeline/times to the active atmosphere.
- Smoothed the Hero temperature timeline curve.
- Replaced the scrub-handle time badge with the coloured forecast condition icon.
