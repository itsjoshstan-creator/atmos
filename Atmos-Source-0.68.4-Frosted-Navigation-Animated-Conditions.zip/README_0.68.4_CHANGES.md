# Atmos 0.68.4

- Replaced immersive navigation auto-hide with persistent adaptive frosted navigation across every layout.
- Navigation glass inherits and smoothly blends colours from the active Atmos scene.
- Added custom minimal Atmos-inspired navigation glyphs.
- Replaced the Right Now wind icon with a wind-responsive animated windsock.
- Replaced the rain icon with multiple fine animated rain streaks whose density follows rain chance.
- Kept the animated humidity fog cloud and refined its movement.
- Increased compact Atmos Story typography to match expanded mode while retaining the two-line limit.
- Rebuilt the timeline temperature line using a Catmull-Rom/Bézier curve for smoother, less stepped temperature changes.
