# Atmos 0.30.1

Highlights:
- Completely redesigned Locations page with large weather-driven Atmos cards.
- Cards show location, current temperature, condition, local time and native Atmos artwork.
- Long-press drag reordering follows the user's finger; current location remains first.
- Settings and Locations use an enhanced About-style ambient background.
- Settings section illustrations enlarged and made more visually prominent.
- Version 0.30.1 (code 96).
