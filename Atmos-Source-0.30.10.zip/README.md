# Atmos 0.30.9

Changes in this build:
- Independent lower-screen text and chart contrast for Fullscreen Hero and Immersive.
- Immersive previews now show the darker lower-screen treatment in onboarding and Settings.
- Settings cards use solid theme surfaces without gradients for improved light-mode legibility.
- New interactive Atmos System page with a live fullscreen demo, layer controls, and an explanation of the renderer and design philosophy.
- Version code 104 / version name 0.30.9.

## 0.30.10
- Added Automatic (Location) appearance mode.
- Theme day/night state follows calculated sunrise and sunset at the selected observation location and its timezone.
- Added Automatic, Follow Device, Light and Dark choices to onboarding and Settings.
- Automatic (Location) is the recommended default for new installs.
- Theme state is refreshed every minute and immediately recalculated when the selected location changes.
- Light and Dark remain fixed; Follow Device follows Android appearance.
