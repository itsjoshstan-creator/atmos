# Atmos 0.16.6

Native Android source for Atmos 0.16.6.

Changes in this build:
- Full-screen chart runs from midnight to midnight.
- Condition-themed vertical progress fill extends to the current time.
- Sunrise and sunset are both shown for the day.
- Improved chart labels, precipitation bars and location page indicator contrast.
- When current location is enabled, its card is always first in the location pager.

Build the Android project in the `android` directory.
