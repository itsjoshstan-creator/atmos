# Atmos 0.20.6

Natural Motion now responds more clearly to real wind speed and direction.

- 0–10 km/h: calm, turbulence-only wandering with no directional push.
- 10–20 km/h: progressively visible directional drift.
- 20 km/h and above: particles move clearly through the hero card, with depth variation and intermittent gusts.
- Meteorological wind direction is converted from “from” direction into the direction particles travel.
- Spring petals, summer motes, autumn leaves and winter crystals retain their individual movement profiles.
- Version: 0.20.6 (89).
