package au.com.weatheraustralia.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Event-driven Atmos live wallpaper. It intentionally renders only the atmosphere:
 * no text, controls, cards, clocks or forecast UI.
 */
class AtmosWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = AtmosWallpaperEngine()

    private inner class AtmosWallpaperEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
        private var visible = false
        private var width = 1
        private var height = 1
        private val prefs by lazy { getSharedPreferences("atmos_native", MODE_PRIVATE) }
        private val preferenceListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "weatherCache" || key == "savedPlaces" || key == "seasonalAtmosphere" || key == "temperatureAtmosphere") drawFrame()
        }
        private val minuteTick = object : Runnable {
            override fun run() {
                if (!visible) return
                drawFrame()
                val now = System.currentTimeMillis()
                handler.postDelayed(this, 60_000L - (now % 60_000L))
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.registerOnSharedPreferenceChangeListener(preferenceListener)
        }

        override fun onDestroy() {
            handler.removeCallbacksAndMessages(null)
            prefs.unregisterOnSharedPreferenceChangeListener(preferenceListener)
            super.onDestroy()
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(minuteTick)
            if (isVisible) {
                drawFrame()
                val now = System.currentTimeMillis()
                handler.postDelayed(minuteTick, 60_000L - (now % 60_000L))
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, newWidth: Int, newHeight: Int) {
            width = newWidth.coerceAtLeast(1)
            height = newHeight.coerceAtLeast(1)
            drawFrame()
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) = drawFrame()

        private fun drawFrame() {
            if (!surfaceHolder.surface.isValid) return
            val scene = loadFirstScene()
            val canvas = runCatching { surfaceHolder.lockCanvas() }.getOrNull() ?: return
            try {
                renderAtmos(canvas, scene)
            } finally {
                runCatching { surfaceHolder.unlockCanvasAndPost(canvas) }
            }
        }

        private fun loadFirstScene(): WallpaperScene {
            val places = runCatching { JSONArray(prefs.getString("savedPlaces", "[]")) }.getOrDefault(JSONArray())
            val first = places.optJSONObject(0)
            if (first == null) return WallpaperScene.default()
            val latitude = first.optDouble("lat", -31.95)
            val longitude = first.optDouble("lon", 115.86)
            val state = first.optString("state", "Western Australia")
            val timeZoneId = first.optString("timeZoneId", "").ifBlank { australianZone(state, longitude, latitude) }
            val key = String.format(Locale.US, "%.4f:%.4f", latitude, longitude)
            val cache = runCatching { JSONObject(prefs.getString("weatherCache", "{}")) }.getOrDefault(JSONObject())
            val weather = cache.optJSONObject(key)
            val day = weather?.optJSONArray("days")?.optJSONObject(0)
            val observation = weather?.optJSONObject("observation")
            return WallpaperScene(
                latitude = latitude,
                longitude = longitude,
                timeZoneId = timeZoneId,
                icon = day?.optString("icon", "partly_cloudy") ?: "partly_cloudy",
                condition = day?.optString("condition", "Current conditions") ?: "Current conditions",
                temperature = observation?.optInt("temp", (day?.optInt("high", 22) ?: 22) - 2) ?: 20,
                humidity = observation?.optInt("humidity", 55) ?: 55,
                pressure = observation?.optDouble("pressure", 1013.25) ?: 1013.25
            )
        }

        private fun renderAtmos(canvas: Canvas, scene: WallpaperScene) {
            val now = Date()
            val zone = TimeZone.getTimeZone(scene.timeZoneId)
            val solar = solarTimes(now, scene.latitude, scene.longitude, zone)
            val current = now.time
            val night = solar?.let { current < it.first || current >= it.second } ?: isNightFallback(now, zone)
            val palette = solarPalette(scene.icon, night, solar, current)
            val seasonal = seasonName(scene.latitude, now, zone)
            val seasonTint = when (seasonal) {
                "Spring" -> Color.rgb(255, 177, 201)
                "Summer" -> Color.rgb(255, 201, 102)
                "Autumn" -> Color.rgb(216, 119, 62)
                "Winter" -> Color.rgb(132, 180, 255)
                else -> Color.rgb(118, 190, 226)
            }
            val humidity = scene.humidity.coerceIn(0, 100) / 100f
            val pressureMood = ((scene.pressure - 1013.25) / 32.0).toFloat().coerceIn(-1f, 1f)
            val seasonalStrength = if (night) .045f else .14f
            val top = mix(palette.first, seasonTint, seasonalStrength * .45f)
            val bottom = mix(palette.second, seasonTint, seasonalStrength)

            paint.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), top, bottom, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

            // Pressure mood and humidity scattering are baked into the static scene.
            val moodColor = if (pressureMood >= 0f) Color.rgb(69, 116, 178) else Color.rgb(35, 45, 72)
            paint.shader = RadialGradient(width * .52f, height * .42f, maxOf(width, height) * .78f,
                intArrayOf(withAlpha(moodColor, (18 + 20 * kotlin.math.abs(pressureMood)).toInt()), Color.TRANSPARENT),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

            // Invisible-sun glare: a broad field only, never a visible solar disc.
            solar?.let { (sunrise, sunset) ->
                if (current in sunrise until sunset) {
                    val progress = ((current - sunrise).toFloat() / (sunset - sunrise).toFloat()).coerceIn(0f, 1f)
                    val energy = sin(PI * progress).toFloat().coerceIn(0f, 1f)
                    val x = width * (.08f + .84f * progress)
                    val y = height * (.56f - .40f * energy)
                    val glareAlpha = ((34f + 44f * energy) * (1f - humidity * .26f)).toInt().coerceIn(12, 78)
                    paint.shader = RadialGradient(x, y, maxOf(width, height) * (.62f + humidity * .16f),
                        intArrayOf(withAlpha(Color.rgb(255, 232, 177), glareAlpha), withAlpha(Color.rgb(255, 190, 107), glareAlpha / 3), Color.TRANSPARENT),
                        floatArrayOf(0f, .34f, 1f), Shader.TileMode.CLAMP)
                    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
                }
            }

            // Atmospheric horizon softness; stronger in humid/foggy conditions.
            val condition = scene.condition.lowercase(Locale.ENGLISH)
            val haze = (humidity * .40f + if ("fog" in condition || "mist" in condition) .34f else 0f).coerceIn(0f, .72f)
            if (haze > .02f) {
                paint.shader = LinearGradient(0f, height * .42f, 0f, height.toFloat(),
                    intArrayOf(Color.TRANSPARENT, withAlpha(Color.WHITE, (haze * 42).toInt()), withAlpha(bottom, 35)),
                    floatArrayOf(0f, .64f, 1f), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            }

            // Moonlight and a calm deterministic star field, only in suitable night conditions.
            if (night) {
                val moon = moonIllumination(current)
                val cloud = cloudWeight(scene.condition)
                val visibility = (1f - humidity * .45f - cloud * .35f).coerceIn(0f, 1f)
                val moonAlpha = (moon * visibility * 36f).toInt()
                paint.shader = RadialGradient(width * .72f, height * .22f, maxOf(width, height) * .62f,
                    intArrayOf(withAlpha(Color.rgb(190, 214, 255), moonAlpha), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
                val starAlpha = ((1f - cloud) * visibility * (1f - moon * .55f) * 150f).toInt().coerceIn(0, 135)
                if (starAlpha > 8) drawStars(canvas, key = (scene.latitude * 1000 + scene.longitude * 100).toLong(), alpha = starAlpha)
            }
            paint.shader = null
        }

        private fun drawStars(canvas: Canvas, key: Long, alpha: Int) {
            var seed = key xor 0x9E3779B97F4A7C15UL.toLong()
            repeat(42) { i ->
                seed = seed * 6364136223846793005L + 1442695040888963407L
                val x = ((seed ushr 16) and 0xFFFF).toFloat() / 65535f * width
                seed = seed * 6364136223846793005L + 1442695040888963407L
                val y = ((seed ushr 16) and 0xFFFF).toFloat() / 65535f * height * .58f
                paint.shader = null
                paint.color = Color.argb((alpha * (.45f + (i % 5) * .10f)).toInt().coerceAtMost(180), 235, 242, 255)
                canvas.drawCircle(x, y, if (i % 7 == 0) 1.6f else 1f, paint)
            }
        }
    }
}

private data class WallpaperScene(
    val latitude: Double,
    val longitude: Double,
    val timeZoneId: String,
    val icon: String,
    val condition: String,
    val temperature: Int,
    val humidity: Int,
    val pressure: Double
) {
    companion object {
        fun default() = WallpaperScene(-31.95, 115.86, "Australia/Perth", "partly_cloudy", "Partly cloudy", 20, 55, 1013.25)
    }
}

private fun conditionPalette(icon: String, night: Boolean): Pair<Int, Int> {
    val s = icon.lowercase(Locale.ENGLISH)
    return when {
        night -> Color.rgb(38, 60, 96) to Color.rgb(67, 54, 87)
        "storm" in s || "thunder" in s -> Color.rgb(98, 84, 141) to Color.rgb(52, 59, 98)
        "rain" in s || "shower" in s -> Color.rgb(78, 131, 167) to Color.rgb(70, 99, 141)
        "cloud" in s || "overcast" in s -> Color.rgb(137, 154, 185) to Color.rgb(104, 122, 159)
        else -> Color.rgb(255, 198, 90) to Color.rgb(238, 125, 98)
    }
}

private fun solarPalette(icon: String, night: Boolean, solar: Pair<Long, Long>?, now: Long): Pair<Int, Int> {
    val day = conditionPalette(icon, false)
    val dark = conditionPalette(icon, true)
    if (solar == null) return if (night) dark else day
    val (rise, set) = solar
    val hour = 60L * 60_000L
    return when {
        now < rise - hour -> dark
        now < rise + hour -> blendPair(dark, Color.rgb(93,111,168) to Color.rgb(255,139,114), ((now-(rise-hour)).toFloat()/(2*hour)).coerceIn(0f,1f))
        now < set - hour -> day
        now < set + hour -> blendPair(day, Color.rgb(118,92,158) to Color.rgb(255,126,96), ((now-(set-hour)).toFloat()/(2*hour)).coerceIn(0f,1f))
        else -> dark
    }
}

private fun blendPair(a: Pair<Int,Int>, b: Pair<Int,Int>, t: Float) = mix(a.first,b.first,t) to mix(a.second,b.second,t)
private fun mix(a: Int, b: Int, t: Float): Int {
    val f = t.coerceIn(0f,1f)
    return Color.rgb(
        (Color.red(a)+(Color.red(b)-Color.red(a))*f).toInt(),
        (Color.green(a)+(Color.green(b)-Color.green(a))*f).toInt(),
        (Color.blue(a)+(Color.blue(b)-Color.blue(a))*f).toInt()
    )
}
private fun withAlpha(color: Int, alpha: Int) = Color.argb(alpha.coerceIn(0,255), Color.red(color), Color.green(color), Color.blue(color))
private fun cloudWeight(condition: String): Float = when {
    condition.contains("storm", true) || condition.contains("thunder", true) -> .92f
    condition.contains("rain", true) || condition.contains("shower", true) -> .78f
    condition.contains("overcast", true) -> .84f
    condition.contains("cloud", true) -> .58f
    condition.contains("fog", true) || condition.contains("mist", true) -> .72f
    else -> .10f
}
private fun moonIllumination(now: Long): Float {
    val knownNewMoon = 947182440000L
    val month = 29.530588853 * 86_400_000.0
    val phase = (((now-knownNewMoon)%month+month)%month/month)
    return ((1.0-cos(2.0*PI*phase))*.5).toFloat().coerceIn(0f,1f)
}
private fun seasonName(latitude: Double, date: Date, zone: TimeZone): String {
    val month = Calendar.getInstance(zone).apply { time = date }.get(Calendar.MONTH)+1
    val south = latitude < 0
    return if (south) when(month){12,1,2->"Summer";3,4,5->"Autumn";6,7,8->"Winter";else->"Spring"}
    else when(month){12,1,2->"Winter";3,4,5->"Spring";6,7,8->"Summer";else->"Autumn"}
}
private fun isNightFallback(date: Date, zone: TimeZone): Boolean {
    val hour = Calendar.getInstance(zone).apply { time = date }.get(Calendar.HOUR_OF_DAY)
    return hour < 6 || hour >= 19
}
private fun australianZone(state: String, lon: Double, lat: Double): String = when {
    state.contains("Western Australia", true) -> "Australia/Perth"
    state.contains("Northern Territory", true) -> "Australia/Darwin"
    state.contains("South Australia", true) -> "Australia/Adelaide"
    state.contains("Queensland", true) -> "Australia/Brisbane"
    state.contains("Tasmania", true) -> "Australia/Hobart"
    state.contains("Victoria", true) -> "Australia/Melbourne"
    state.contains("New South Wales", true) || state.contains("Capital Territory", true) -> "Australia/Sydney"
    lon < 129 -> "Australia/Perth"; lon < 138 -> "Australia/Darwin"; lon < 141 -> "Australia/Adelaide"
    lat > -29 && lon > 141 -> "Australia/Brisbane"; else -> "Australia/Sydney"
}
private fun solarTimes(date: Date, latitude: Double, longitude: Double, zone: TimeZone): Pair<Long,Long>? {
    fun event(sunrise: Boolean): Long? {
        val cal = Calendar.getInstance(zone).apply { time=date }
        val day = cal.get(Calendar.DAY_OF_YEAR)
        val lngHour = longitude/15.0
        val t = day + ((if(sunrise)6.0 else 18.0)-lngHour)/24.0
        val m = 0.9856*t-3.289
        var l = m+1.916*sin(Math.toRadians(m))+.020*sin(Math.toRadians(2*m))+282.634
        l=(l%360+360)%360
        var ra=Math.toDegrees(kotlin.math.atan(.91764*kotlin.math.tan(Math.toRadians(l))))
        ra=(ra%360+360)%360
        ra += (kotlin.math.floor(l/90)*90-kotlin.math.floor(ra/90)*90); ra/=15
        val sinDec=.39782*sin(Math.toRadians(l)); val cosDec=cos(kotlin.math.asin(sinDec))
        val cosH=(cos(Math.toRadians(90.833))-sinDec*sin(Math.toRadians(latitude)))/(cosDec*cos(Math.toRadians(latitude)))
        if(cosH !in -1.0..1.0) return null
        var h=if(sunrise)360-Math.toDegrees(kotlin.math.acos(cosH)) else Math.toDegrees(kotlin.math.acos(cosH)); h/=15
        val localMean=h+ra-.06571*t-6.622
        val utc=(localMean-lngHour)%24
        val base=Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { time=date; set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0) }
        return base.timeInMillis+(utc*3_600_000.0).toLong()
    }
    val rise=event(true)?:return null; val set=event(false)?:return null
    return rise to set
}
