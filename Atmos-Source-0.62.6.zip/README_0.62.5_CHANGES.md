# Atmos 0.62.5

- Pauses Atmos scene clocks and visual transitions when a location is off-screen or the app is not resumed.
- Keeps only the settled immersive location scene fully active; swipe destination scenes use a static pre-rendered atmosphere until selected.
- Caches full-screen gradient brushes with `drawWithCache` instead of recreating them during every draw.
- Reduces palette cross-fade work from 27 to 18 frames while retaining the same transition duration and visual character.
- Stops inactive Hero cards from running their own minute clock loops.
- Preserves all current weather, notification, location, Atmos Display, and local forecast intelligence behaviour.
