# Atmos 0.62.6

- Added lightweight hero-only previews for adjacent forecast pages while swiping.
- Converted the main forecast feed from a fully composed scrolling Column to LazyColumn.
- Forecast cards below the fold are now composed only when they approach the viewport.
- Removed redundant per-card graphics layers.
- Removed the full-page alpha/translation animation when refreshed weather arrives.
- Preserved the full active atmosphere and forecast feed once a location settles.
