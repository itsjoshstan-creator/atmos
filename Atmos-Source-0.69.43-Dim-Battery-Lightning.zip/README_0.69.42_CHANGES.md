# Atmos 0.69.42

- Clock Glyph now always renders a two-digit hour in both 12-hour and 24-hour modes. Hours 1–9 use a leading zero.
- Chance of Rain no longer uses a percent symbol.
- Chance of Rain now uses three centred vertical precipitation strokes below the value.
- Precipitation numbers use the same centred numeric positioning as the other Glyph displays, including 100.
