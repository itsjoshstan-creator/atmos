# Atmos 0.69.43

- Changed the Battery Glyph lightning bolt from full brightness to the shared dim LED intensity.
- Battery value positioning, bolt shape, spacing, and all other Glyph behaviour are unchanged.
